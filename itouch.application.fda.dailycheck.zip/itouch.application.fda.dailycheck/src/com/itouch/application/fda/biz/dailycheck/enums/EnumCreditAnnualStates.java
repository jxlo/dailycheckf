/**
 * @Description:TODO
 * @project:itouch.application.fda.dailycheck
 * @class:EnumCreditAnnualStates.java
 * @author:zhangzt
 * @email:taonyzhang@gmail.com
 * @time:2016年3月2日 下午3:27:47
 */

package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author:zhangzt
 * @email:taonyzhang@gmail.com
 */
public enum EnumCreditAnnualStates implements
		PersistentEnum<EnumCreditAnnualStates>, ICodeDict {

	ToReport("10", "待上报"), 
	ToCheck("20", "待检查"),
	Checked("30", "已检查"),
	todo("40", "已初评"),
	ToArchived("90", "待归档"),
	Archived("100", "已归档");

	private String value;
	private final String codeName;
	private static Map<String, EnumCreditAnnualStates> valueMap = new HashMap<String, EnumCreditAnnualStates>();
	static {
		for (EnumCreditAnnualStates _enum : EnumCreditAnnualStates.values()) {
			valueMap.put(_enum.value, _enum);
		}
	}

	private EnumCreditAnnualStates(String value, String codeName) {
		this.value = value;
		this.codeName = codeName;
	}

	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getValue() {
		return value;
	}

	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumCreditAnnualStates>
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public EnumCreditAnnualStates getEnum(String value) {
		return valueMap.get(value);
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumCreditAnnualStates>
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public Map<String, EnumCreditAnnualStates> getAllValueMap() {
		return valueMap;
	}

	@Override
	public String toString() {
		return this.getCodeName();
	}
}