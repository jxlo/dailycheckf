/**
 * @Description:信用评定类型
 * @project:itouch.application.fda.dailycheck
 * @class:EnumCreditTypes.java
 * @author:zhangzt
 * @email:taonyzhang@gmail.com
 * @time:2016年2月19日 上午9:59:38
 */

package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author:zhangzt
 * @email:taonyzhang@gmail.com
 */
public enum EnumCreditTypes implements PersistentEnum<EnumCreditTypes>,ICodeDict{
	Annual("1","年度评级"),
	Dynamic("2","动态评级");
	
	private String value;
	private final String codeName;
	private static Map<String,EnumCreditTypes> valueMap = new HashMap<String, EnumCreditTypes>();
	static{
		for(EnumCreditTypes _enum : EnumCreditTypes.values()){
			valueMap.put(_enum.value, _enum);
		}
	}
	private EnumCreditTypes(String value,String codeName){
		this.value = value;
		this.codeName = codeName;
	}
	
	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getValue() {
		return value;
	}

	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumCreditTypes>
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public EnumCreditTypes getEnum(String value) {
		return valueMap.get( value );
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumCreditTypes>
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public Map<String, EnumCreditTypes> getAllValueMap() {
		return valueMap;
	}

	@Override
	public String toString() {
		return this.getCodeName();
	}
}
