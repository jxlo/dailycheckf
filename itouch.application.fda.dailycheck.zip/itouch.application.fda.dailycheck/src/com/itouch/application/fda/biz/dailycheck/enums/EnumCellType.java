/**
 * @Description:单元格类型
 * @project:itouch.application.fda.biz
 * @class:EnumCellType.java
 * @author:zhangzt
 * @time:2015年10月12日 下午7:50:10
 */

package com.itouch.application.fda.biz.dailycheck.enums;

/**
 * @author:zhangzt
 *
 */
public enum EnumCellType {

	None,
    /// <summary>
    /// 分数单元格
    /// </summary>
    Score,
    /// <summary>
    /// 单选按钮单元格
    /// </summary>
    RadioButtonList,
    /// <summary>
    /// 字符型文本单元格，放置一些“缺陷原因”，“扣分原因”等文本框
    /// </summary>
    Text,
    /// <summary>
    /// 系数单元格
    /// </summary>
    Coefficient,
    /// <summary>
    /// 复选框单元格
    /// </summary>
    CheckBox
}
