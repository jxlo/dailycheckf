/**
 * @Description:检查结论
 * @project:itouch.application.fda.biz
 * @class:EnumCheckVerdict.java
 * @author:zhangzt
 * @time:2015年10月30日 下午1:17:13
 */

package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author:zhangzt
 *
 */
public enum EnumCheckVerdicts implements PersistentEnum<EnumCheckVerdicts>,ICodeDict{

	/*未发现问题*/
	Normal("0","未发现问题"),
	/*发现问题*/
	ReviewNow ("-1","责令当场整改"),
	ReviewDeadline ("-2","责令限期整改"),
	Illegal("-3","涉嫌违章违法"),
	ReviewPunish("-4","限期整改兼处罚"),
	Others ("-99","其他");
	
	private String value;
	private final String codeName;
	private static Map<String, EnumCheckVerdicts> valueMap = new HashMap<String, EnumCheckVerdicts>();
	static {
		for ( EnumCheckVerdicts _enum : EnumCheckVerdicts.values() ){
		valueMap.put( _enum.value, _enum );
		}
	}
	private EnumCheckVerdicts(String value,String codeName ){
		this.value = value;
		this.codeName = codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getDisplayName()
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getEnum(java.lang.Object)
	 */
	@Override
	public EnumCheckVerdicts getEnum(String value) {
		return valueMap.get( value );
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getAllValueMap()
	 */
	@Override
	public Map<String, EnumCheckVerdicts> getAllValueMap() {
		return valueMap;
	}
	
	@Override
	public String toString() {
		return this.getCodeName();
	} 
}
