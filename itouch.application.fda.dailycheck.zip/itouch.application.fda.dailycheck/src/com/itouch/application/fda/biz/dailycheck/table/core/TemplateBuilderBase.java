/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateBuilder.java
 * @author:zhangzt
 * @time:2015年10月12日 下午2:03:55
 */

package com.itouch.application.fda.biz.dailycheck.table.core;

import iTouch.framework.application.manager.IAppBusinessManagerMapper;
import iTouch.framework.utility.text.StringUtil;

import java.util.ArrayList;
import java.util.List;

import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateDetailManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateHeaderManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateItemManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateSmallSubjectManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateSubjectManager;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.AbstractTemplate;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateDetailInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateHeaderInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateItemInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSmallSubjectInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSubjectInfo;

/**
 * @author:zhangzt
 *
 */
public class TemplateBuilderBase {

	/**
	 * @Description:获取抽象模板对象数据
	 * @param templateId
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月12日 下午4:02:01
	 */
	public AbstractTemplate getAbstractTemplate(IAppBusinessManagerMapper mapper, String templateId) {

		AbstractTemplate template = new AbstractTemplate(); // 抽象模板对象

		if (StringUtil.isNotEmpty(templateId)) {

			ITemplateManager bllTemplate = mapper.getMapper(ITemplateManager.class); // 模板业务逻辑对象
			TemplateInfo templateInfo = bllTemplate.getEntity(templateId); // 模板信息
			template.setTemplateInfo(templateInfo); // 添加模板对象

			ITemplateHeaderManager bllITemplateHeader = mapper.getMapper(ITemplateHeaderManager.class); // 模板头部业务逻辑对象
			List<TemplateHeaderInfo> templateHeaderInfoList = bllITemplateHeader.getListByTemplateId(templateId); // 头部集合
			template.setTemplateHeaderInfoList(templateHeaderInfoList);// 添加头部集合

			ITemplateSubjectManager bllTemplateSubject = mapper.getMapper(ITemplateSubjectManager.class); // 大项业务逻辑对象
			List<TemplateSubjectInfo> templateSubjectInfoList = bllTemplateSubject.getListByTemplateId(templateId); // 大项集合
			template.setTemplateSubjectInfoList(templateSubjectInfoList);// 添加大项集合

			ITemplateSmallSubjectManager bllTemplateSmallSubject = mapper.getMapper(ITemplateSmallSubjectManager.class);// 小项业务逻辑对象
			List<TemplateSmallSubjectInfo> templateSmallSubjectInfoList = bllTemplateSmallSubject.getListByTemplateId(templateId); // 小项集合
			template.setTemplateSmallSubjectInfoList(templateSmallSubjectInfoList);

			ITemplateItemManager bllTemplateItem = mapper.getMapper(ITemplateItemManager.class);// 条款业务逻辑对象
			List<TemplateItemInfo> templateItemInfoList = bllTemplateItem.getListByTemplateId(templateId); // 条款集合
			template.setTemplateItemInfoList(templateItemInfoList); // 添加条款集合

			ITemplateDetailManager bllTemplateItemDetail = mapper.getMapper(ITemplateDetailManager.class);// 条款明细业务逻辑
			List<TemplateDetailInfo> templateItemDetailInfoList = bllTemplateItemDetail.getListByTemplateId(templateId);// 条款明细集合
			template.setTemplateDetailInfoList(templateItemDetailInfoList);// 添加条款明细集合

		}

		return template;
	}

	/**
	 * @Description:根据大项获取小项
	 * @param subjectId
	 *            项目Id
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月13日 下午8:05:53
	 */
	public List<TemplateSmallSubjectInfo> getSmallSubjectListBySubjectId(String strSubjectId, AbstractTemplate template) {
		List<TemplateSmallSubjectInfo> list = new ArrayList<TemplateSmallSubjectInfo>();
		if (template != null && template.getTemplateSmallSubjectInfoList() != null) {
			for (TemplateSmallSubjectInfo subject : template.getTemplateSmallSubjectInfoList()) {
				if (subject.getSubjectId() == strSubjectId) {
					list.add(subject);
				}
			}
		}
		return list;
	}

	/**
	 * @Description:根据大项获取条款
	 * @param subjectId
	 *            项目Id
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月13日 下午8:05:53
	 */
	public List<TemplateItemInfo> getItemBySubjectId(String strSubjectId, AbstractTemplate template) {
		List<TemplateItemInfo> list = new ArrayList<TemplateItemInfo>();
		if (template != null && template.getTemplateItemInfoList() != null) {
			for (TemplateItemInfo item : template.getTemplateItemInfoList()) {
				if (item.getSubjectId() == strSubjectId) {
					list.add(item);
				}
			}
		}
		return list;
	}

	/**
	 * @Description:根据小项项获取条款
	 * @param subjectId
	 *            项目Id
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月13日 下午8:05:53
	 */
	public List<TemplateItemInfo> getItemBySmallSubjectId(String strSmallSubjectId, AbstractTemplate template) {
		List<TemplateItemInfo> list = new ArrayList<TemplateItemInfo>();
		if (template != null && template.getTemplateItemInfoList() != null) {
			for (TemplateItemInfo item : template.getTemplateItemInfoList()) {
				if (item.getSmallSubjectId() == strSmallSubjectId) {
					list.add(item);
				}
			}
		}
		return list;
	}

	/**
	 * @Description:根据条款获取条款明细
	 * @param subjectId
	 *            项目Id
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月13日 下午8:05:53
	 */
	public List<TemplateDetailInfo> getItemDetailByItemId(String strItemId, AbstractTemplate template) {
		List<TemplateDetailInfo> list = new ArrayList<TemplateDetailInfo>();
		if (template != null && template.getTemplateDetailInfoList() != null) {
			for (TemplateDetailInfo item : template.getTemplateDetailInfoList()) {
				if (item.getItemId() == strItemId) {
					list.add(item);
				}
			}
		}
		return list;
	}
}
