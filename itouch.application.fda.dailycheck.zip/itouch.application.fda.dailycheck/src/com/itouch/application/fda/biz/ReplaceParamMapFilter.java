/**
 * @Description:TODO
 * @project:itouch.application.fda.online
 * @class:ReplaceParamMapFilter.java
 * @author:zhanglai
 * @time:2015年7月16日 下午5:37:56
 */

package com.itouch.application.fda.biz;

import iTouch.framework.application.service.IRequestParamMapFilter;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author  zhanglai
 *
 */
public class ReplaceParamMapFilter implements IRequestParamMapFilter{
	/** 正则表达式*/
	private String mask = null;
	/** 替换值*/
	private String value = null;
	
	
	
	/**
	 * @Description: 设置  正则表达式
	 * @param mask  正则表达式
	 * @author: zhanglai
	 * @time:2015年7月16日 下午5:38:29
	 */
	public void setMask(String mask) {
		this.mask = mask;
	}



	/**
	 * @Description: 设置  替换值
	 * @param value  替换值
	 * @author: zhanglai
	 * @time:2015年7月16日 下午5:38:29
	 */
	public void setValue(String value) {
		this.value = value;
	}



	/* (non-Javadoc)
	 * @see iTouch.framework.application.service.IRequestParamMapFilter#filter(java.util.Map)
	 */
	@Override
	public void filter(Map<String, Object> paramMap) {
		if(this.mask == null || this.value == null)
			return;
		Set<String> keySet = new HashSet(paramMap.keySet());
		for(String key:keySet){
			Object obj = paramMap.get(key);
			if(obj instanceof String){
				paramMap.put(key, ((String)obj).replaceAll(mask, value));
			}else if(obj instanceof String[]){
				String[] strs = (String[])obj;
				for(int i=0;i<strs.length;i++){
					if(strs[i] != null)
						strs[i] = strs[i].replaceAll(mask, value); 
				}
			}
		}
		
	}
}
