/**
 * @Description:检查类型枚举
 * @project:itouch.application.fda.biz
 * @class:EnumCheckTypes.java
 * @author:zhangzt
 * @time:2015年10月30日 下午1:14:31
 */

package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * 监管结论类型枚举
 * @author qiuy
 */
public enum EnumVerdictType implements PersistentEnum<EnumVerdictType>,ICodeDict {
	
	None("0", "无"),
	Result("1","结果"),
	Number("2","次数");
	//AverageScoring("3","平均得分"),
	//Coefficient ("4","平均得分×系数"),
	//AverageScoringRate("5","总得分率"),
	//SubjectItemScoringRate ("6","大项得分率"),
	
	private String value;
	private final String codeName;
	private static Map<String, EnumVerdictType> valueMap = new HashMap<String, EnumVerdictType>();
	static {
		for ( EnumVerdictType _enum : EnumVerdictType.values() ){
		valueMap.put( _enum.value, _enum );
		}
	}
	private EnumVerdictType(String value,String codeName ){
		this.value = value;
		this.codeName = codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getDisplayName()
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getEnum(java.lang.Object)
	 */
	@Override
	public EnumVerdictType getEnum(String value) {
		return valueMap.get( value );
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getAllValueMap()
	 */
	@Override
	public Map<String, EnumVerdictType> getAllValueMap() {
		return valueMap;
	}
	
	@Override
	public String toString() {
		return this.getCodeName();
	} 
}
