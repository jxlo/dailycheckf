/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITemplateBuilder.java
 * @author:zhangzt
 * @time:2015年10月12日 下午8:04:48
 */

package com.itouch.application.fda.biz.dailycheck.table.core;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.AbstractTemplate;

/**
 * @author:zhangzt
 *
 */
public interface ITemplateBuilder {

	/**
	 * @Description:生成表头
	 * @param template 模板对象
	 * @return 表头
	 */
	public String buildHeader(AbstractTemplate template);

	/**
	 * @Description:生成表主体
	 * @param template 模板对象
	 * @return 表主体
	 */
	public String buildBody(AbstractTemplate template);

	/**
	 * @Description:返回结果
	 * @param template 模板对象
	 * @return 组装结果
	 */
	public String getResult(AbstractTemplate template);

}
