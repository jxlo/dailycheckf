/**
 * @Description:TODO
 * @project:itouch.application.fda.online
 * @class:Context.java
 * @author:zhanglai
 * @time:2015年7月16日 下午5:36:30
 */

package com.itouch.application.fda.biz;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * @author  zhanglai
 *
 */
public class Context implements ApplicationContextAware{
	/** Spring容器*/
	private static ApplicationContext springContext = null;
	
	public static ApplicationContext getSpringAppContext(){
		return springContext;
	}
	
	public ApplicationContext getSpringContext(){
		return springContext;
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0)
			throws BeansException {
		springContext = arg0;
	}
}
