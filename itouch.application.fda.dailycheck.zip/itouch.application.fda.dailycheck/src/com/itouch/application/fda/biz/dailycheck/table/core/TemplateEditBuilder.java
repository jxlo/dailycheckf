/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateEditBuilder.java
 * @author:zhangzt
 * @time:2015年10月12日 下午8:03:00
 */

package com.itouch.application.fda.biz.dailycheck.table.core;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.AbstractTemplate;

/**
 * @author:zhangzt
 *
 */
public class TemplateEditBuilder extends TemplateBuilderBase implements
		ITemplateBuilder {


	@Override
	public String buildHeader(AbstractTemplate template) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String buildBody(AbstractTemplate template) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getResult(AbstractTemplate template) {
		// TODO Auto-generated method stub
		return null;
	}

}
