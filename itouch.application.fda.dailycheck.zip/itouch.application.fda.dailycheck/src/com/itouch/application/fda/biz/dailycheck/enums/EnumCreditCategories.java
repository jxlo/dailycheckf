package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

public enum EnumCreditCategories implements PersistentEnum<EnumCreditCategories>,ICodeDict{
	Normal("0","常规"),
	First("1","等级首评"),
	Preview("2","等级初评");
	
	private String value;
	private final String codeName;
	private static Map<String,EnumCreditCategories> valueMap = new HashMap<String, EnumCreditCategories>();
	static{
		for(EnumCreditCategories _enum : EnumCreditCategories.values()){
			valueMap.put(_enum.value, _enum);
		}
	}
	private EnumCreditCategories(String value,String codeName){
		this.value = value;
		this.codeName = codeName;
	}
	
	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getValue() {
		return value;
	}

	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumCreditCategories>
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public EnumCreditCategories getEnum(String value) {
		return valueMap.get( value );
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumCreditCategories>
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public Map<String, EnumCreditCategories> getAllValueMap() {
		return valueMap;
	}

	@Override
	public String toString() {
		return this.getCodeName();
	}
}
