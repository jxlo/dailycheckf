/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateViewBuilder.java
 * @author:zhangzt
 * @time:2015年10月12日 下午8:03:16
 */

package com.itouch.application.fda.biz.dailycheck.table.core;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.AbstractTemplate;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateDetailInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateHeaderInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateItemInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSmallSubjectInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSubjectInfo;

/**
 * @author:zhangzt
 *
 */
public class TemplateViewBuilder extends TemplateBuilderBase implements
		ITemplateBuilder {

	@Override
	public String buildHeader(AbstractTemplate template) {
		String strHtml = "";

		List<TemplateHeaderInfo> list = template.getTemplateHeaderInfoList();
		if (null != list && null != list && list.size() > 0) {

			// 拼接头部
			strHtml += "<thead><tr>";

			// 项目列
			if (template.getTemplateSubjectInfoList() != null
					&& template.getTemplateSubjectInfoList().size() > 0) {
				strHtml += BuilderUtil.renderHeaderCell("项目");
			}

			// 子项目列
			if (template.getTemplateSubjectInfoList() != null
					&& template.getTemplateSubjectInfoList().size() > 0) {
				strHtml += BuilderUtil.renderHeaderCell("子项目");
			}

			// 遍历头部
			for (TemplateHeaderInfo header : list) {
				strHtml += BuilderUtil.renderHeaderCell(header.getText());
			}

			// 结束拼接
			strHtml += "</tr></thead>";
		}

		return strHtml;
	}

	@Override
	public String buildBody(AbstractTemplate template) {
		String strHtml = "";

		// 项目列
		if (template.getTemplateSubjectInfoList() != null
				&& template.getTemplateSubjectInfoList().size() > 0) {

			List<TemplateSubjectInfo> subjects = template
					.getTemplateSubjectInfoList(); // 项目集合

			if (null != subjects && subjects.size() > 0) {

				for (TemplateSubjectInfo subject : subjects) {
					List<TemplateSmallSubjectInfo> smallSubjects = this
							.getSmallSubjectListBySubjectId(
									subject.getSubjectId(), template);
					List<TemplateItemInfo> items = this.getItemBySubjectId(
							subject.getSubjectId(), template);

					strHtml += "<tr>"; // 输出行

					if (smallSubjects.size() > 0 && items.size() > 0) {
						// 如果子项
						strHtml += BuilderUtil.renderSpanCell(
								subject.getText(), items.size(), 0);
					}

					else if (smallSubjects.size() > 0 && items.size() == 0) {

						strHtml += BuilderUtil.renderSpanCell(
								subject.getText(), items.size(), 2);

					} else {
						strHtml += BuilderUtil.renderCell(subject.getText());
					}

					strHtml += "</tr>"; // 结束行
				}

			} else {
				// 直接输出条款
				List<TemplateItemInfo> items = template
						.getTemplateItemInfoList();

				// 输出条款行
				strHtml += renderItems(items, template);
			}
		}
		return strHtml;
	}

	// 输出条款
	private String renderItems(List<TemplateItemInfo> items,
			AbstractTemplate template) {

		String strHtml = "";

		if (null != items) {

			for (TemplateItemInfo item : items) {

				strHtml += "<tr>";

				List<TemplateDetailInfo> details = this
						.getItemDetailByItemId(item.getItemId(), template);

				for (TemplateDetailInfo detail : details) {
					strHtml += BuilderUtil.renderCell(detail.getText());
				}

				strHtml += "</tr>";
			}
		}

		return strHtml;

	}

	@Override
	public String getResult(AbstractTemplate template) {
		String strHeader = buildHeader(template);
		String strBody = buildBody(template);
		return "<table class='table table-bordered'>" + strHeader + strBody + "</table>";
	}

}
