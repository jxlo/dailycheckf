package com.itouch.application.fda.biz.dailycheck.table.core;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.AbstractTemplate;

/**
 * @author zhangzt
 * 模板创建指挥者
 */
public class TemplateDirector {

	/**
	 * 模板创建者
	 */
	public ITemplateBuilder builder;
	/**
	 * 抽象模板对象
	 */
	public AbstractTemplate template;

	public TemplateDirector(ITemplateBuilder builder,AbstractTemplate template) {
		this.setBuilder(builder);
		this.setTemplate(template);
	}

	// 创建
	public String build() {
		return builder.getResult(template);
	}

	public ITemplateBuilder getBuilder() {
		return builder;
	}

	public void setBuilder(ITemplateBuilder builder) {
		this.builder = builder;
	}

	public AbstractTemplate getTemplate() {
		return template;
	}

	public void setTemplate(AbstractTemplate template) {
		this.template = template;
	}
}
