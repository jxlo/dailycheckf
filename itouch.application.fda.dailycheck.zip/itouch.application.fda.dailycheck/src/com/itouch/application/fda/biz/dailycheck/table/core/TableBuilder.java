/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TableBuilder.java
 * @author:zhangzt
 * @time:2015年10月12日 下午2:04:06
 */

package com.itouch.application.fda.biz.dailycheck.table.core;


/**
 * @author:zhangzt
 *
 */
public class TableBuilder extends TemplateBuilderBase {
	

}
