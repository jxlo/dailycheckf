/**
 * @Description:TODO
 * @project:itouch.application.fda.online
 * @class:Constants.java
 * @author:zhanglai
 * @time:2015年7月21日 上午11:01:14
 */

package com.itouch.application.fda.biz;

/**
 * @author  zhanglai
 *
 */
public final class Constants {
	/** 存储用户的key*/
	public static final String REQUEST_USER = "UserInfo";
	/** 存储服务返回的业务对象的key*/
	public static final String RESPONSE_BUSINESSOBJECT = "businessObject";
	/** 存储服务返回对象的key*/
	public static final String BUSINESSRESPONSE = "businessResponse";
}
