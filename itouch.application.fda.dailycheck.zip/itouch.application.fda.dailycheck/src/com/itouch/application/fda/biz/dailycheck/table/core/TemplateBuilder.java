package com.itouch.application.fda.biz.dailycheck.table.core;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.AbstractTemplate;

public abstract class TemplateBuilder {

	/**
	 * @Description:生成表头
	 * @param template 模板对象
	 * @return 表头
	 */
	public abstract String buildHeader(AbstractTemplate template);

	/**
	 * @Description:生成表主体
	 * @param template 模板对象
	 * @return 表主体
	 */
	public abstract String buildBody(AbstractTemplate template);

	/**
	 * @Description:返回结果
	 * @param template 模板对象
	 * @return 组装结果
	 */
	public abstract String getResult(AbstractTemplate template);
	
}
