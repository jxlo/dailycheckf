/**  
* @Title: EnumTaskState.java 
* @Package com.itouch.application.fda.biz.dailycheck.enums 
* @author wangk    
* @date 2015-10-28 下午3:40:26  
*/ 
package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-28 下午3:40:26  
 */
public enum EnumTaskState implements PersistentEnum<EnumTaskState>,ICodeDict{

	Reception("1","待接收"),
	AlreadyIssued("2","已下发"),
	Received("3","已接收"),
	ToBeReported("4","待上报"),
	HaveBeenReported("5","已上报");
	
	private String value;
	private final String codeName;
	private static Map<String,EnumTaskState> valueMap = new HashMap<String, EnumTaskState>();
	static{
		for(EnumTaskState _enum : EnumTaskState.values()){
			valueMap.put(_enum.value, _enum);
		}
	}
	private EnumTaskState(String value,String codeName){
		this.value = value;
		this.codeName = codeName;
	}
	
	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getValue() {
		return value;
	}

	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumTaskState>
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public EnumTaskState getEnum(String value) {
		return valueMap.get( value );
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumTaskState>
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public Map<String, EnumTaskState> getAllValueMap() {
		return valueMap;
	}

	@Override
	public String toString() {
		return this.getCodeName();
	}
}
