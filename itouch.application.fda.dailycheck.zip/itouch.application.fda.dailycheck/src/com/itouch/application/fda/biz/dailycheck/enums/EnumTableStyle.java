/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:EnumTableStyle.java
 * @author:zhangzt
 * @time:2015年10月12日 下午7:29:42
 */

package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author:zhangzt
 *
 */
public enum EnumTableStyle implements PersistentEnum<EnumTableStyle>,ICodeDict {

	GradedMonomial("1","评分式(单条)"),
	GradedMonomialAddLackItem("11","评分式(单条+合理缺项)"),
	GradedCollect("2","评分式(汇总)"),
	GradedCoefficient("3","评分式(系数)"),
	GradedCoefficientAddLackItem("33","评分式(系数+合理缺项)"),
	MultipleChoice("4","选择式"),
	MultipleChoiceGraded("5","评分选择式"),
	SummaryStyle("6","汇总式");
	
	private String value;
	private final String codeName;
	private static Map<String, EnumTableStyle> valueMap = new HashMap<String, EnumTableStyle>();
	static {
		for ( EnumTableStyle _enum : EnumTableStyle.values() ){
		valueMap.put( _enum.value, _enum );
		}
	}
	private EnumTableStyle(String value,String codeName ){
		this.value = value;
		this.codeName = codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getDisplayName()
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getEnum(java.lang.Object)
	 */
	@Override
	public EnumTableStyle getEnum(String value) {
		return valueMap.get( value );
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getAllValueMap()
	 */
	@Override
	public Map<String, EnumTableStyle> getAllValueMap() {
		return valueMap;
	}
	
	@Override
	public String toString() {
		return this.getCodeName();
	}
}
