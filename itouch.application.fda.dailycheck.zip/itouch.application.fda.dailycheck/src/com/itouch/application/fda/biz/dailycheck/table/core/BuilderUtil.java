package com.itouch.application.fda.biz.dailycheck.table.core;

/**
 * @author zhangzt
 *
 */
public class BuilderUtil {

	/**
	 * @Description:获取标题文本
	 * @param text
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月13日 下午8:39:40
	 */
	public static String renderHeaderCell(String text) {
		return "<th>" + text + "</th>";
	}

	/**
	 * @Description:一般表格文本
	 * @param text
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月13日 下午8:40:44
	 */
	public static String renderCell(String text) {
		return "<td>" + text + "</td>";
	}

	/**
	 * @Description:一般表格文本
	 * @param text
	 * @return
	 * @author:zhangzt
	 * @time:2015年10月13日 下午8:40:44
	 */
	public static String renderSpanCell(String text, Integer numRowspan,Integer numColspan) {
		return "<td rowspan='" + numRowspan + "' colspan='" + numColspan + "'>"	+ text + "</td>";
	}
	
}
