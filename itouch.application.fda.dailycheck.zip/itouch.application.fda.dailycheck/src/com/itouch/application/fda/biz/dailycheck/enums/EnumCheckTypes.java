/**
 * @Description:检查类型枚举
 * @project:itouch.application.fda.biz
 * @class:EnumCheckTypes.java
 * @author:zhangzt
 * @time:2015年10月30日 下午1:14:31
 */

package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author:zhangzt
 *
 */
public enum EnumCheckTypes implements PersistentEnum<EnumCheckTypes>,ICodeDict {
	
	DailyCheck("1","日常检查"),
	TaskCheck("2","专项检查"),
	AccCheck("3","许可检查"),
	FlightCheck ("4","飞行检查"),
	SampleCheck("5","监督抽查"),
	Others ("99","其他");
	
	private String value;
	private final String codeName;
	private static Map<String, EnumCheckTypes> valueMap = new HashMap<String, EnumCheckTypes>();
	static {
		for ( EnumCheckTypes _enum : EnumCheckTypes.values() ){
		valueMap.put( _enum.value, _enum );
		}
	}
	private EnumCheckTypes(String value,String codeName ){
		this.value = value;
		this.codeName = codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getDisplayName()
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getEnum(java.lang.Object)
	 */
	@Override
	public EnumCheckTypes getEnum(String value) {
		return valueMap.get( value );
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getAllValueMap()
	 */
	@Override
	public Map<String, EnumCheckTypes> getAllValueMap() {
		return valueMap;
	}
	
	@Override
	public String toString() {
		return this.getCodeName();
	} 
}
