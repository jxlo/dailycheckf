/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:EnumTalk.java
 * @author:fanghailong
 * @time:2015-10-13 下午3:16:23
 */
package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;
/**
 * @author:fanghailong 
 */
public enum EnumTalkState implements PersistentEnum<EnumTalkState>,ICodeDict{
	
	Apply("10","申请"),
	Approve("20","审批"),
	Record("30","记录");
	
	private String value;
	private final String codeName;
	private static Map<String, EnumTalkState> valueMap = new HashMap<String, EnumTalkState>();
	static {
		for ( EnumTalkState _enum : EnumTalkState.values() ){
		valueMap.put( _enum.value, _enum );
		}
	}
	private EnumTalkState(String value,String codeName ){
		this.value = value;
		this.codeName = codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getDisplayName()
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getEnum(java.lang.Object)
	 */
	@Override
	public EnumTalkState getEnum(String value) {
		return valueMap.get( value );
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getAllValueMap()
	 */
	@Override
	public Map<String, EnumTalkState> getAllValueMap() {
		return valueMap;
	}
	
	@Override
	public String toString() {
		return this.getCodeName();
	}

}
