/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:EnumReviewVerdicts.java
 * @author:zhangzt
 * @time:2015年10月30日 下午3:54:20
 */

package com.itouch.application.fda.biz.dailycheck.enums;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author:zhangzt
 *
 */
public enum EnumReviewVerdicts implements PersistentEnum<EnumReviewVerdicts>,ICodeDict {

	/*没问题*/
	Pass("1","整改后合格"),
	/*有问题*/
	ContinueReview ("-1","继续整改"),
	TransToInspect ("-2","移交稽查");
	
	private String value;
	private final String codeName;
	private static Map<String, EnumReviewVerdicts> valueMap = new HashMap<String, EnumReviewVerdicts>();
	static {
		for ( EnumReviewVerdicts _enum : EnumReviewVerdicts.values() ){
		valueMap.put( _enum.value, _enum );
		}
	}
	private EnumReviewVerdicts(String value,String codeName ){
		this.value = value;
		this.codeName = codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getValue()
	 */
	@Override
	public String getValue() {
		return value;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getDisplayName()
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getEnum(java.lang.Object)
	 */
	@Override
	public EnumReviewVerdicts getEnum(String value) {
		return valueMap.get( value );
	}

	/* (non-Javadoc)
	 * @see iTouch.framework.application.code.codedata.services.enumcode.PersistentEnum#getAllValueMap()
	 */
	@Override
	public Map<String, EnumReviewVerdicts> getAllValueMap() {
		return valueMap;
	}
	
	@Override
	public String toString() {
		return this.getCodeName();
	} 
}
