/**
 * @Description:报表编码
 * @project:itouch.application.fda.dailycheck
 * @class:EnumReportFormCodes.java
 * @author:zhangzt
 * @email:taonyzhang@gmail.com
 * @time:2016年3月16日 下午2:23:17
 */

package com.itouch.application.fda.biz.dailycheck.report;

import iTouch.framework.application.entities.code.ICodeDict;
import iTouch.framework.application.entities.code.PersistentEnum;

import java.util.HashMap;
import java.util.Map;


/**
 * @author:zhangzt
 * @email:taonyzhang@gmail.com
 */
public enum EnumReportFormCodes implements PersistentEnum<EnumReportFormCodes>, ICodeDict {

	HFoodDailyCheckReport("HFoodDailyCheckReport", "保健食品生产经营企业日常监管情况统计表"), 
	ComsDailyCheckReport("ComsDailyCheckReport", "化妆品品生产经营企业日常监管情况统计表");

	private String value;
	private final String codeName;
	private static Map<String, EnumReportFormCodes> valueMap = new HashMap<String, EnumReportFormCodes>();
	static {
		for (EnumReportFormCodes _enum : EnumReportFormCodes.values()) {
			valueMap.put(_enum.value, _enum);
		}
	}

	private EnumReportFormCodes(String value, String codeName) {
		this.value = value;
		this.codeName = codeName;
	}

	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getValue() {
		return value;
	}

	/**
	 * @Description:TODO
	 * @pram：ICodeDict
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public String getCodeName() {
		return codeName;
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumReportFormCodes>
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public EnumReportFormCodes getEnum(String value) {
		return valueMap.get(value);
	}

	/**
	 * @Description:TODO
	 * @pram：PersistentEnum<EnumReportFormCodes>
	 * @author: wangk
	 * @return:
	 * @time:2015-10-28 下午3:40:56
	 */
	@Override
	public Map<String, EnumReportFormCodes> getAllValueMap() {
		return valueMap;
	}

	@Override
	public String toString() {
		return this.getCodeName();
	}
}
