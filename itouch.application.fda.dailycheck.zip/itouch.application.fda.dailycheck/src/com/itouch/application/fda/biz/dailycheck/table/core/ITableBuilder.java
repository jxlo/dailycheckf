/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITableBuilder.java
 * @author:zhangzt
 * @time:2015年10月12日 下午7:05:27
 */

package com.itouch.application.fda.biz.dailycheck.table.core;

/**
 * @author:zhangzt
 *
 */
public interface ITableBuilder {
	
	public void buildHeader();
	
	public void buildBody();
	
	public void buidFoodter();
}
