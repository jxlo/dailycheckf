package com.itouch.application.fda.biz.dailycheck.enums;


/**
 * @author qiuy
 * 条件评定结果枚举
 */
public enum EnumRatingResults {
	/**
	 * 正常
	 */
	Normal,
	
	/**
	 * 通过
	 */
	Pass,
	
	/**
	 * 没有通过
	 */
	NoPass,
	
	/**
	 * 没有数据
	 */
	NoData,
	
	/**
	 * 废弃
	 */
	Abandoned,
	
	
	/**
	 * 无 
	 */
	Null;
}
