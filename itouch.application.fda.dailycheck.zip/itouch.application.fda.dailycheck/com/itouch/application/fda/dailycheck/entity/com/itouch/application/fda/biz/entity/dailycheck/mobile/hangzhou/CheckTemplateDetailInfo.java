package com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * 检查模板明细表
 */
@Entity
@Table(name="DC_HZ_RCJC_JCMBMX")
public class CheckTemplateDetailInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 主键
	 */
	@Id
	@Column(name="ID")
	private String id;

	/**
	 * 模板id
	 */
	@Column(name="TEMPLATEID")
	private String templateId;

	/**
	 * 检查项目编号
	 */
	@Column(name="CHECKNO")
	private String checkNo;

	/**
	 * 检查项名称
	 */
	@Column(name="CHECKITEM")
	private String checkItem;
	
	/**
	 * 上级id
	 */
	@Column(name="PARID")
	private String parId;
	
	/**
	 * 级别
	 */
	@Column(name="LV")
	private String lv;
	
	/**
	 * 是否评定等级
	 */
	@Column(name="SFPDDJ")
	private String sfpddj;
	
	/**
	 * 顺序值
	 */
	@Column(name="ORDERBY")
	private Integer orderBy;
	
	/**
	 * 分值
	 */
	@Column(name="SCORE")
	private Integer score;
	
	/**
	 * 最高分
	 */
	@Column(name="HIGHESTSCORE")
	private Integer highestScore;
	
	/**
	 * 录入方式
	 */
	@Column(name="INPUTMODE")
	private String inputMode;

	/**
	 * 是否关键项
	 */
	@Column(name="ISKEY")
	private String isKey;

	/**
	 * 类型
	 */
	@Column(name="TYPE")
	private String type;


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getCheckNo() {
		return checkNo;
	}

	public void setCheckNo(String checkNo) {
		this.checkNo = checkNo;
	}

	public String getCheckItem() {
		return checkItem;
	}

	public void setCheckItem(String checkItem) {
		this.checkItem = checkItem;
	}

	public String getParId() {
		return parId;
	}

	public void setParId(String parId) {
		this.parId = parId;
	}

	public String getLv() {
		return lv;
	}

	public void setLv(String lv) {
		this.lv = lv;
	}

	public String getSfpddj() {
		return sfpddj;
	}

	public void setSfpddj(String sfpddj) {
		this.sfpddj = sfpddj;
	}

	public Integer getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(Integer orderBy) {
		this.orderBy = orderBy;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getHighestScore() {
		return highestScore;
	}

	public void setHighestScore(Integer highestScore) {
		this.highestScore = highestScore;
	}

	public String getInputMode() {
		return inputMode;
	}

	public void setInputMode(String inputMode) {
		this.inputMode = inputMode;
	}


	public String getIsKey() {
		return isKey;
	}

	public void setIsKey(String isKey) {
		this.isKey = isKey;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}