package com.itouch.application.fda.biz.entity.dailycheck.check.upload;

/**
 * 上传返回结果
 */
public class UploadResult {
	
	/**
	 * 文件名称
	 */
	private String name;
	
	/**
	 * 文件url
	 */
	private String url;
	
	/**
	 * 附件Id
	 */
	private String fileId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
}
