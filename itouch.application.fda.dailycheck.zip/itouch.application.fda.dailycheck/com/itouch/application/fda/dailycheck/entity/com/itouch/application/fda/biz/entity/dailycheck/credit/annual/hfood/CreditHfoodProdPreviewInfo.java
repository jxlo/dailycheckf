/**  
  * @Description: TODO
  * @Title: CreditHfoodProdForm.java 
  * @Package: com.itouch.application.fda.biz.entity.dailycheck.credit.hfood 
  * @author: xh
  * @date 2016-3-10 上午10:02:22 
  */ 
package com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description: TODO
 * @ClassName: CreditHfoodProdForm 
 * @author xh
 * @date 2016-3-10 上午10:02:22  
 */
@Entity
@Table(name="DC_Credit_HFood_Prod_Preview")
public class CreditHfoodProdPreviewInfo implements IBusinessObject{

	
	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 主键Id **/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id; 
	
	/** 年度信用评级ID **/
	@Column(name="CREDIT_ID")
	private String creditId;

	/** 考评组成员Id**/
	@Column(name="CHECK_USER_IDS")
	private String checkUserIds;

	/** 考评组成员**/
	@Column(name="CHECK_USER_NAMES")
	private String checkUserNames;

	/** GMP执行等级**/
	@Column(name="GMP_LEVEL")
	private String gmpLevel;

	/** 关键项(合计)**/
	@Column(name="KEY_ITEM_COUNT")
	private Integer keyItemCount;

	/** 关键项(不合格)**/
	@Column(name="KEY_ITEM_DIS_COUNT")
	private Integer keyItemDisCount;

	/** 关键项不合格项明细**/
	@Column(name="KEY_ITEM_REMARK")
	private String keyItemRemark;

	/** 重点项(合计)**/
	@Column(name="MAIN_ITEM_COUNT")
	private Integer mainItemCount;

	/** 重点项(不合格)**/
	@Column(name="MAIN_ITEM_DIS_COUNT")
	private Integer mainItemDisCount;

	/** 重点项(不合格明细)**/
	@Column(name="MAIN_ITEM_DIS_REMARK")
	private String mainItemDisRemark;

	/** 一般项(合计)**/
	@Column(name="NORMAL_ITEM_COUNT")
	private Integer normalItemCount;

	/** 一般项(不合格)**/
	@Column(name="NORMAL_ITEM_DIS_COUNT")
	private Integer normalItemDisCount;

	/** 一般项(不合格明细)**/
	@Column(name="NORMAL_ITEM_DIS_REMARK")
	private String normalItemDisRemark;

	/** 日常监督检查情况**/
	@Column(name="CHECK_DESC")
	private String checkDesc;

	/** 初评日期自**/
	@Column(name="CREDIT_DATE_FROM")
	private Date creditDateFrom;

	/** 初评日期至**/
	@Column(name="CREDIT_DATE_TO")
	private Date creditDateTo;

	
	/** 评定等级 **/
	@Column(name="CREDIT_VALUE")
	private String creditValue;
	
	/** 级别名称 **/
	@Column(name="CREDIT_NAME")
	private String creditName;
	
	/** 评定得分 **/
	@Column(name="CREDIT_SCORE")
	private String creditScore;

	/** 创建人Id**/
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	/** 创建人姓名**/
	@Column(name="CREATE_USER_NAME")
	private String createUserName;

	/** 创建时间**/
	@Column(name="CREATE_TIME")
	private Date createTime;

	/** 备注**/
	@Column(name="REAMRK")
	private String remark;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreditId() {
		return creditId;
	}

	public void setCreditId(String creditId) {
		this.creditId = creditId;
	}

	public String getCheckUserIds() {
		return checkUserIds;
	}

	public void setCheckUserIds(String checkUserIds) {
		this.checkUserIds = checkUserIds;
	}

	public String getCheckUserNames() {
		return checkUserNames;
	}

	public void setCheckUserNames(String checkUserNames) {
		this.checkUserNames = checkUserNames;
	}

	public String getGmpLevel() {
		return gmpLevel;
	}

	public void setGmpLevel(String gmpLevel) {
		this.gmpLevel = gmpLevel;
	}

	public Integer getKeyItemCount() {
		return keyItemCount;
	}

	public void setKeyItemCount(Integer keyItemCount) {
		this.keyItemCount = keyItemCount;
	}

	public Integer getKeyItemDisCount() {
		return keyItemDisCount;
	}

	public void setKeyItemDisCount(Integer keyItemDisCount) {
		this.keyItemDisCount = keyItemDisCount;
	}

	public String getKeyItemRemark() {
		return keyItemRemark;
	}

	public void setKeyItemRemark(String keyItemRemark) {
		this.keyItemRemark = keyItemRemark;
	}

	public Integer getMainItemCount() {
		return mainItemCount;
	}

	public void setMainItemCount(Integer mainItemCount) {
		this.mainItemCount = mainItemCount;
	}

	public Integer getMainItemDisCount() {
		return mainItemDisCount;
	}

	public void setMainItemDisCount(Integer mainItemDisCount) {
		this.mainItemDisCount = mainItemDisCount;
	}

	public String getMainItemDisRemark() {
		return mainItemDisRemark;
	}

	public void setMainItemDisRemark(String mainItemDisRemark) {
		this.mainItemDisRemark = mainItemDisRemark;
	}

	public Integer getNormalItemCount() {
		return normalItemCount;
	}

	public void setNormalItemCount(Integer normalItemCount) {
		this.normalItemCount = normalItemCount;
	}

	public Integer getNormalItemDisCount() {
		return normalItemDisCount;
	}

	public void setNormalItemDisCount(Integer normalItemDisCount) {
		this.normalItemDisCount = normalItemDisCount;
	}

	public String getNormalItemDisRemark() {
		return normalItemDisRemark;
	}

	public void setNormalItemDisRemark(String normalItemDisRemark) {
		this.normalItemDisRemark = normalItemDisRemark;
	}

	public String getCheckDesc() {
		return checkDesc;
	}

	public void setCheckDesc(String checkDesc) {
		this.checkDesc = checkDesc;
	}

	public Date getCreditDateFrom() {
		return creditDateFrom;
	}

	public void setCreditDateFrom(Date creditDateFrom) {
		this.creditDateFrom = creditDateFrom;
	}

	public Date getCreditDateTo() {
		return creditDateTo;
	}

	public void setCreditDateTo(Date creditDateTo) {
		this.creditDateTo = creditDateTo;
	}

	public String getCreditValue() {
		return creditValue;
	}

	public void setCreditValue(String creditValue) {
		this.creditValue = creditValue;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCreateUserName() {
		return createUserName;
	}

	public void setCreateUserName(String createUserName) {
		this.createUserName = createUserName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	public String getCreditName() {
		return creditName;
	}

	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}

	public String getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}

}
