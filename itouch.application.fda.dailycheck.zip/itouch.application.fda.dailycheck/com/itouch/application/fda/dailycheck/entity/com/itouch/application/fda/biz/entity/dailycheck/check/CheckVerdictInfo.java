package com.itouch.application.fda.biz.entity.dailycheck.check;

/**
 * 监管结论实体
 */
public class CheckVerdictInfo {
	
	/**结论Id*/
	private String verdictId;
	
	/**结论名称*/
	private String verdictName;

	public String getVerdictId() {
		return verdictId;
	}

	public void setVerdictId(String verdictId) {
		this.verdictId = verdictId;
	}

	public String getVerdictName() {
		return verdictName;
	}

	public void setVerdictName(String verdictName) {
		this.verdictName = verdictName;
	}
}
