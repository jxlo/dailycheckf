package com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 检查结果明细表
 */
@Entity
@Table(name = "DC_HZ_RCJC_JCJGMX")
public class CheckResultDetailInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 主键
	 */
	@Id
	@Column(name = "ID")
	private String id;

	/**
	 * 检查结果序号
	 */
	@Column(name = "CHECKID")
	private String checkId;

	/**
	 * 检查项名称
	 */
	@Column(name = "CHECKNAME")
	private String checkName;

	/**
	 * 检查项编号
	 */
	@Column(name = "CHECKNO")
	private String checkNo;

	/**
	 * 检查结果
	 */
	@Column(name = "CHECKRESULT")
	private String checkResult;

	/**
	 * 单位分值
	 */
	@Column(name = "UNIT")
	private Integer unit;

	/**
	 * 数量
	 */
	@Column(name = "COUNT")
	private Integer count;

	/**
	 * 得分
	 */
	@Column(name = "SCORE")
	private Integer score;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCheckId() {
		return checkId;
	}

	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	public String getCheckName() {
		return checkName;
	}

	public void setCheckName(String checkName) {
		this.checkName = checkName;
	}

	public String getCheckNo() {
		return checkNo;
	}

	public void setCheckNo(String checkNo) {
		this.checkNo = checkNo;
	}

	public String getCheckResult() {
		return checkResult.equals("0") ? "正常" : "异常";
	}

	public void setCheckResult(String checkResult) {
		this.checkResult = checkResult;
	}

	public Integer getUnit() {
		return unit;
	}

	public void setUnit(Integer unit) {
		this.unit = unit;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

}