/**  
* @Title: TaskInfo.java 
* @Package com.itouch.application.fda.biz.entity.dailycheck.task 
* @author wangk    
* @date 2015-10-26 上午11:29:40  
*/ 
package com.itouch.application.fda.biz.entity.dailycheck.task;

import iTouch.framework.data.operation.IBusinessObject;

import java.sql.Clob;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanUserInfo;

/**
 * @author wangk
 * @Description: 专项检查
 * @date 2015-10-26 上午11:29:40  
 */
@Entity
@Table(name="DC_TASK")
public class TaskInfo implements IBusinessObject{
	
	/** @Fields taskId : 任务Id **/ 
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="TASK_ID")
	private String taskId;
	
	/** @Fields taskName : 任务名称 **/ 
	@Column(name="TASK_NAME")
	private String taskName;
	
	/** @Fields taskDesc : 任务说明 **/ 
	@Column(name="TASK_DESC")
	private Clob taskDesc;
	
	/** @Fields taskBeginDate : 任务时间自 **/ 
	@Column(name="TASK_BEGIN_DATE")
	private Date taskBeginDate;
	
	/** @Fields taskEndDate : 计划时间至 **/ 
	@Column(name="TASK_END_DATE")
	private Date taskEndDate;
	
	/** @Fields taskCreatorId : 任务发布人Id **/ 
	@Column(name="TASK_CREATOR_ID")
	private String taskCreatorId;
	
	/** @Fields taskCreatorName : 任务发布人 **/ 
	@Column(name="TASK_CREATOR_NAME")
	private String taskCreatorName;
	
	/** @Fields taskCreateTime : 任务发布时间 **/ 
	@Column(name="TASK_CREATE_TIME")
	private Date taskCreateTime;
	
	/** @Fields taskCreateOrg : 任务制定单位 **/ 
	@Column(name="TASK_CREATE_ORG")
	private String taskCreateOrg;
	
	/** @Fields isCompleted : 任务进度 **/ 
	@Column(name="IS_COMPLETED")
	private Integer isCompleted;
	
	/** @Fields attachmentCode : 附件组号 **/ 
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;
	
	/** @Fields completedDate : 完成时间 **/ 
	@Column(name="COMPLETED_DATE")
	private Date completedDate;
	
	/** @Fields tableId : 检查表Id **/ 
	@Column(name="TABLE_ID")
	private String tableId;
	/** @Fields tableName : 检查表名称 **/ 
	@Column(name="TABLE_NAME")
	private String tableName;
	/**剩余天数**/
	@Transient
	private int restDay;
	
	public int getRestDay() {
		return restDay;
	}

	public void setRestDay(int restDay) {
		this.restDay = restDay;
	}

	/** @Fields remark : 备注 **/ 
	@Column(name="REMARK")
	private String remark;
	
	/** @Fields taskSource : 任务来源 **/
	@Column(name="TASK_SOURCE")
	private String taskSource;
	
	/** @Fields taskUnitList : 专项检查单位检查记录  **/
	@Transient
	private List<TaskUnitInfo> taskUnitList;
	
	
	/** @Fields taskSource : 任务类型**/
	@Column(name="TASK_TYPE")
	private String TaskType;
	
	@Transient
	private List<CheckInfo> checkInfo;
	
	
	
	public List<CheckInfo> getCheckInfo() {
		return checkInfo;
	}

	public void setCheckInfo(List<CheckInfo> checkInfo) {
		this.checkInfo = checkInfo;
	}

	public String getTaskType() {
		return TaskType;
	}

	public void setTaskType(String taskType) {
		TaskType = taskType;
	}

	/**
	 * 获取taskId
	 * @return taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**  
	 * 设置taskId  
	 * @param taskId
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * 获取taskName
	 * @return taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**  
	 * 设置taskName  
	 * @param taskName
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * 获取taskDesc
	 * @return taskDesc
	 */
	public Clob getTaskDesc() {
		return taskDesc;
	}

	/**  
	 * 设置taskDesc  
	 * @param taskDesc
	 */
	public void setTaskDesc(Clob taskDesc) {
		this.taskDesc = taskDesc;
	}

	/**
	 * 获取taskBeginDate
	 * @return taskBeginDate
	 */
	public Date getTaskBeginDate() {
		return taskBeginDate;
	}

	/**  
	 * 设置taskBeginDate  
	 * @param taskBeginDate
	 */
	public void setTaskBeginDate(Date taskBeginDate) {
		this.taskBeginDate = taskBeginDate;
	}

	/**
	 * 获取taskEndDate
	 * @return taskEndDate
	 */
	public Date getTaskEndDate() {
		return taskEndDate;
	}

	/**  
	 * 设置taskEndDate  
	 * @param taskEndDate
	 */
	public void setTaskEndDate(Date taskEndDate) {
		this.taskEndDate = taskEndDate;
	}

	/**
	 * 获取taskCreatorId
	 * @return taskCreatorId
	 */
	public String getTaskCreatorId() {
		return taskCreatorId;
	}

	/**  
	 * 设置taskCreatorId  
	 * @param taskCreatorId
	 */
	public void setTaskCreatorId(String taskCreatorId) {
		this.taskCreatorId = taskCreatorId;
	}

	/**
	 * 获取taskCreatorName
	 * @return taskCreatorName
	 */
	public String getTaskCreatorName() {
		return taskCreatorName;
	}

	/**  
	 * 设置taskCreatorName  
	 * @param taskCreatorName
	 */
	public void setTaskCreatorName(String taskCreatorName) {
		this.taskCreatorName = taskCreatorName;
	}

	/**
	 * 获取taskCreateTime
	 * @return taskCreateTime
	 */
	public Date getTaskCreateTime() {
		return taskCreateTime;
	}

	/**  
	 * 设置taskCreateTime  
	 * @param taskCreateTime
	 */
	public void setTaskCreateTime(Date taskCreateTime) {
		this.taskCreateTime = taskCreateTime;
	}

	/**
	 * 获取taskCreateOrg
	 * @return taskCreateOrg
	 */
	public String getTaskCreateOrg() {
		return taskCreateOrg;
	}

	/**  
	 * 设置taskCreateOrg  
	 * @param taskCreateOrg
	 */
	public void setTaskCreateOrg(String taskCreateOrg) {
		this.taskCreateOrg = taskCreateOrg;
	}

	/**
	 * 获取isCompleted
	 * @return isCompleted
	 */
	public Integer getIsCompleted() {
		return isCompleted;
	}

	/**  
	 * 设置isCompleted  
	 * @param isCompleted
	 */
	public void setIsCompleted(Integer isCompleted) {
		this.isCompleted = isCompleted;
	}

	/**
	 * 获取attachmentCode
	 * @return attachmentCode
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**  
	 * 设置attachmentCode  
	 * @param attachmentCode
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * 获取completedDate
	 * @return completedDate
	 */
	public Date getCompletedDate() {
		return completedDate;
	}

	/**  
	 * 设置completedDate  
	 * @param completedDate
	 */
	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	/**
	 * 获取tableId
	 * @return tableId
	 */
	public String getTableId() {
		return tableId;
	}

	/**  
	 * 设置tableId  
	 * @param tableId
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * 获取tableName
	 * @return tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**  
	 * 设置tableName  
	 * @param tableName
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * 获取remark
	 * @return remark
	 */
	public String getRemark() {
		return remark;
	}

	/**  
	 * 设置remark  
	 * @param remark
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	public List<TaskUnitInfo> getTaskUnitList() {
		return taskUnitList;
	}

	public void setTaskUnitList(List<TaskUnitInfo> taskUnitList) {
		this.taskUnitList = taskUnitList;
	}

	public String getTaskSource() {
		return taskSource;
	}

	public void setTaskSource(String taskSource) {
		this.taskSource = taskSource;
	}
	
}
