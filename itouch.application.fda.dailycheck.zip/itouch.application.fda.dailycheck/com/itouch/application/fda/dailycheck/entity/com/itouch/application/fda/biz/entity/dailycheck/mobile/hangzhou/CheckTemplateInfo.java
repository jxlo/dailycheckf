package com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * 检查模板表
 */
@Entity
@Table(name="DC_HZ_RCJC_JCMB")
public class CheckTemplateInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 主键
	 */
	@Id
	@Column(name="ID")
	private String id;

	/**
	 * 模板名称
	 */
	@Column(name="TEMPLATENAME")
	private String templateName;
	
	/**
	 * 备注说明
	 */
	@Column(name="NOTE")
	private String note;
	
	/**
	 * 创建者部门
	 */
	@Column(name="CREATERDEPT")
	private String createrDept;
	
	/**
	 * 创建者
	 */
	@Column(name="CREATER")
	private String creater;

	/**
	 * 创建时间
	 */
	@Column(name="CREATETIME")
	private Date createTime;

	/**
	 * 状态
	 */
	@Column(name="STATE")
	private String state;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getCreaterDept() {
		return createrDept;
	}

	public void setCreaterDept(String createrDept) {
		this.createrDept = createrDept;
	}

	public String getCreater() {
		return creater;
	}

	public void setCreater(String creater) {
		this.creater = creater;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}