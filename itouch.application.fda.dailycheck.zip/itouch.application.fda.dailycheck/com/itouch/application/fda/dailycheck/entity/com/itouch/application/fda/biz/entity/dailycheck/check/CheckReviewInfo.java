/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckReviewInfo.java
 * @author:fanghailong
 * @time:2015-10-20 下午4:37:57
 */
package com.itouch.application.fda.biz.entity.dailycheck.check;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author:fanghailong 
 */
@Entity
@Table(name="DC_CHECK_REVIEW")
public class CheckReviewInfo implements IBusinessObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**整改Id*/
	@Id
	@Column(name="REVIEW_ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String reviewId;
	
	/**检查记录id*/
	@Column(name="CHECK_ID")
	private String checkId;
	
	/**复查开始日期*/
	@Column(name="VALID_FROM_DATE")
	private Date validFromDate;
	
	/**复查结束日期*/
	@Column(name="VALID_TO_DATE")
	private Date validToDate;
	
	/**复查截止日期*/
	@Column(name="REVIEW_EXPIRE_DATE")
	private Date reviewExpireDate;
	
	/**检查结论id*/
	@Column(name="RESULT_VERDICT_ID")
	private Integer resultVerdictId;
	
	/**检查结论*/
	@Column(name="RESULT_VERDICT_NAME")
	private String resultVerdictName;
	
	/**检查结果信息*/
	@Column(name="RESULT_MEMO")
	private String resultMemo;
	
	/**检查意见*/
	@Column(name="RESULT_IDEA")
	private String resultIdea;
	
	/**检查人员ids*/
	@Column(name="REVIEW_USER_IDS")
	private String reviewUserIds;
	
	/**检查人员姓名*/
	@Column(name="REVIEW_USER_NAMES")
	private String reviewUserNames;
	
	/**陪同检查人员*/
	@Column(name="ACCOMP_USERS")
	private String accompUsers;
	
	/**陪同检查人员电话*/
	@Column(name="ACCOMP_USERS_TEL")
	private String accompUsersTel;
	
	/**监察单位编号*/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/**监察单位名称*/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/**创建人id*/
	@Column(name="CREATOR_ID")
	private String creatorId;
	
	/**创建人姓名*/
	@Column(name="CREATOR_NAME")
	private String creatorName;
	
	/**创建时间*/
	@Column(name="CREATE_TIME")
	private Date createTime;
	
	/**更新人id*/
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	
	/**更新人*/
	@Column(name="UPDATE_USER_NAME")
	private String updateUserName;
	
	/**更新时间*/
	@Column(name="UPDATE_TIME")
	private Date updateTime;
	
	/**附件组号*/
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;
	
	/**备注*/
	@Column(name="REMARK")
	private String remark;
	
	/**是否完成*/
	@Column(name="IS_FINISHED")
	private Integer isFinished;
	
	
	/**
	 * @Description:获取{note}
	 * @return:isFinished
	 * @author:fanghailong
	 * @time:2015-11-5 上午10:31:20
	 */
	public Integer getIsFinished() {
		return isFinished;
	}

	/**
	 * @Description:设置{note}
	 * @param：isFinished
	 * @author:fanghailong
	 * @time:2015-11-5 上午10:31:20
	 */
	public void setIsFinished(Integer isFinished) {
		this.isFinished = isFinished;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewExpireDate
	 * @author:fanghailong
	 * @time:2015-11-3 下午6:02:47
	 */
	public Date getReviewExpireDate() {
		return reviewExpireDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewExpireDate
	 * @author:fanghailong
	 * @time:2015-11-3 下午6:02:47
	 */
	public void setReviewExpireDate(Date reviewExpireDate) {
		this.reviewExpireDate = reviewExpireDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:resultMemo
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public String getResultMemo() {
		return resultMemo;
	}

	/**
	 * @Description:设置{note}
	 * @param：resultMemo
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public void setResultMemo(String resultMemo) {
		this.resultMemo = resultMemo;
	}

	/**
	 * @Description:获取{note}
	 * @return:resultIdea
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public String getResultIdea() {
		return resultIdea;
	}

	/**
	 * @Description:设置{note}
	 * @param：resultIdea
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public void setResultIdea(String resultIdea) {
		this.resultIdea = resultIdea;
	}

	/**
	 * @Description:获取{note}
	 * @return:accompUsers
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public String getAccompUsers() {
		return accompUsers;
	}

	/**
	 * @Description:设置{note}
	 * @param：accompUsers
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public void setAccompUsers(String accompUsers) {
		this.accompUsers = accompUsers;
	}

	/**
	 * @Description:获取{note}
	 * @return:accompUsersTel
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public String getAccompUsersTel() {
		return accompUsersTel;
	}

	/**
	 * @Description:设置{note}
	 * @param：accompUsersTel
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public void setAccompUsersTel(String accompUsersTel) {
		this.accompUsersTel = accompUsersTel;
	}

	/**
	 * @Description:获取{note}
	 * @return:serialVersionUID
	 * @author:fanghailong
	 * @time:2015-10-30 下午4:52:54
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getReviewId() {
		return reviewId;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setReviewId(String reviewId) {
		this.reviewId = reviewId;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getCheckId() {
		return checkId;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * @Description:获取{note}
	 * @return:validFromDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public Date getValidFromDate() {
		return validFromDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：validFromDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setValidFromDate(Date validFromDate) {
		this.validFromDate = validFromDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:validToDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public Date getValidToDate() {
		return validToDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：validToDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setValidToDate(Date validToDate) {
		this.validToDate = validToDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:resultVerdictId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public Integer getResultVerdictId() {
		return resultVerdictId;
	}

	/**
	 * @Description:设置{note}
	 * @param：resultVerdictId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setResultVerdictId(Integer resultVerdictId) {
		this.resultVerdictId = resultVerdictId;
	}

	/**
	 * @Description:获取{note}
	 * @return:resultVerdictIName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getResultVerdictName() {
		return resultVerdictName;
	}

	/**
	 * @Description:设置{note}
	 * @param：resultVerdictIName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setResultVerdictName(String resultVerdictName) {
		this.resultVerdictName = resultVerdictName;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewUserIds
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getReviewUserIds() {
		return reviewUserIds;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewUserIds
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setReviewUserIds(String reviewUserIds) {
		this.reviewUserIds = reviewUserIds;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewUserNames
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getReviewUserNames() {
		return reviewUserNames;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewUserNames
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setReviewUserNames(String reviewUserNames) {
		this.reviewUserNames = reviewUserNames;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description:获取{note}
	 * @return:creatorId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getCreatorId() {
		return creatorId;
	}

	/**
	 * @Description:设置{note}
	 * @param：creatorId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	/**
	 * @Description:获取{note}
	 * @return:creatorName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getCreatorName() {
		return creatorName;
	}

	/**
	 * @Description:设置{note}
	 * @param：creatorName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	/**
	 * @Description:获取{note}
	 * @return:createTime
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * @Description:设置{note}
	 * @param：createTime
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * @Description:获取{note}
	 * @return:updateUserId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getUpdateUserId() {
		return updateUserId;
	}

	/**
	 * @Description:设置{note}
	 * @param：updateUserId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	/**
	 * @Description:获取{note}
	 * @return:updateUserName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getUpdateUserName() {
		return updateUserName;
	}

	/**
	 * @Description:设置{note}
	 * @param：updateUserName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	/**
	 * @Description:获取{note}
	 * @return:updateTime
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @Description:设置{note}
	 * @param：updateTime
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @Description:获取{note}
	 * @return:attachmentCode
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**
	 * @Description:设置{note}
	 * @param：attachmentCode
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * @Description:获取{note}
	 * @return:remark
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description:设置{note}
	 * @param：remark
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:59:00
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
}
