package com.itouch.application.fda.biz.entity.dailycheck.system.report;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description:
 * @ClassName: ReporFromInfo 
 * @author: wangk
 * @date: 2016-3-16 下午1:37:44  
 */
@Entity
@Table(name="DC_SYS_REPORT_FORM")
public class ReportFormInfo implements IBusinessObject{
	
	/** 表单Id **/
	@Id
	@Column(name="FORM_ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String formId;
	
	/** 表单编码 **/
	@Column(name="FORM_CODE")
	private String formCode;
	
	/** 表单名称 **/
	@Column(name="FORM_NAME")
	private String formName;
	
	/** 创建人Id **/
	@Column(name="CREATOR_ID")
	private String creatorId;
	
	/** 创建人姓名 **/
	@Column(name="CREATOR_NAME")
	private String creatorName;
	
	/** 创建时间 **/
	@Column(name="CREATE_TIME")
	private Date createTime;
	
	/** 更新人Id **/
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	
	/** 更新人 **/
	@Column(name="UPDATE_USER_NAME")
	private String updateUserName;
	
	/** 更新时间 **/
	@Column(name="UPDATE_TIME")
	private Date updateTime;
	
	/** 编辑页面（Edit） **/
	@Column(name="FORM_EDIT_URL")
	private String formEditUrl;
	
	/** 预览页面（View） **/
	@Column(name="FORM_VIEW_URL")
	private String formViewUrl;
	
	/** 保存服务（Action） **/
	@Column(name="FORM_SERVICE_URL")
	private String formServiceUrl;
	
	/** 表单类型Id **/
	@Column(name="FORM_TYPE_ID")
	private String formTypeId;
	
	/** 表单类型名称 **/
	@Column(name="FORM_TYPE_NAME")
	private String formTypeName;
	
	/** 备注 **/
	@Column(name="REMARK")
	private String remark;

	/**
	 * @Description: 获取 表单Id
	 * @return: formId
	 * @author: wangk
	 * @date: 2016-3-16 下午4:35:13 
	 */
	public String getFormId() {
		return formId;
	}

	/**   
	 * @Description: 设置 表单Id   
	 * @param: formId 
	 * @author: wangk
	 * @date: 2016-3-16 下午4:35:13 
	 */
	public void setFormId(String formId) {
		this.formId = formId;
	}

	/**
	 * @Description: 获取 表单编码
	 * @return: formCode
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getFormCode() {
		return formCode;
	}

	/**   
	 * @Description: 设置 表单编码   
	 * @param: formCode 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setFormCode(String formCode) {
		this.formCode = formCode;
	}

	/**
	 * @Description: 获取 表单名称
	 * @return: formName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getFormName() {
		return formName;
	}

	/**   
	 * @Description: 设置 表单名称   
	 * @param: formName 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setFormName(String formName) {
		this.formName = formName;
	}

	/**
	 * @Description: 获取 创建人Id
	 * @return: creatorId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getCreatorId() {
		return creatorId;
	}

	/**   
	 * @Description: 设置 创建人Id   
	 * @param: creatorId 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	/**
	 * @Description: 获取 创建人姓名
	 * @return: creatorName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getCreatorName() {
		return creatorName;
	}

	/**   
	 * @Description: 设置 创建人姓名   
	 * @param: creatorName 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	/**
	 * @Description: 获取 创建时间
	 * @return: createTime
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**   
	 * @Description: 设置 创建时间   
	 * @param: createTime 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * @Description: 获取 更新人Id
	 * @return: updateUserId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getUpdateUserId() {
		return updateUserId;
	}

	/**   
	 * @Description: 设置 更新人Id   
	 * @param: updateUserId 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	/**
	 * @Description: 获取 更新人
	 * @return: updateUserName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getUpdateUserName() {
		return updateUserName;
	}

	/**   
	 * @Description: 设置 更新人   
	 * @param: updateUserName 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	/**
	 * @Description: 获取 更新时间
	 * @return: updateTime
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**   
	 * @Description: 设置 更新时间   
	 * @param: updateTime 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @Description: 获取 编辑页面（Edit）
	 * @return: formEditUrl
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getFormEditUrl() {
		return formEditUrl;
	}

	/**   
	 * @Description: 设置 编辑页面（Edit）   
	 * @param: formEditUrl 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setFormEditUrl(String formEditUrl) {
		this.formEditUrl = formEditUrl;
	}

	/**
	 * @Description: 获取 预览页面（View）
	 * @return: formViewUrl
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getFormViewUrl() {
		return formViewUrl;
	}

	/**   
	 * @Description: 设置 预览页面（View）   
	 * @param: formViewUrl 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setFormViewUrl(String formViewUrl) {
		this.formViewUrl = formViewUrl;
	}

	/**
	 * @Description: 获取 保存服务（Action）
	 * @return: formServiceUrl
	 * @author: wangk
	 * @date: 2016-3-16 下午2:20:36 
	 */
	public String getFormServiceUrl() {
		return formServiceUrl;
	}

	/**   
	 * @Description: 设置 保存服务（Action）   
	 * @param: formServiceUrl 
	 * @author: wangk
	 * @date: 2016-3-16 下午2:20:36 
	 */
	public void setFormServiceUrl(String formServiceUrl) {
		this.formServiceUrl = formServiceUrl;
	}

	/**
	 * @Description: 获取 表单类型Id
	 * @return: formTypeId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getFormTypeId() {
		return formTypeId;
	}

	/**   
	 * @Description: 设置 表单类型Id   
	 * @param: formTypeId 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setFormTypeId(String formTypeId) {
		this.formTypeId = formTypeId;
	}

	/**
	 * @Description: 获取 表单类型名称
	 * @return: formTypeName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getFormTypeName() {
		return formTypeName;
	}

	/**   
	 * @Description: 设置 表单类型名称   
	 * @param: formTypeName 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setFormTypeName(String formTypeName) {
		this.formTypeName = formTypeName;
	}

	/**
	 * @Description: 获取 备注
	 * @return: remark
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public String getRemark() {
		return remark;
	}

	/**   
	 * @Description: 设置 备注   
	 * @param: remark 
	 * @author: wangk
	 * @date: 2016-3-16 下午1:47:07 
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
