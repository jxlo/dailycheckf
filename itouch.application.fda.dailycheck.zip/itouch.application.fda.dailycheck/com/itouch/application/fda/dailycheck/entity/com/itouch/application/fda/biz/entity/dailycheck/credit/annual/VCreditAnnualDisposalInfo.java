package com.itouch.application.fda.biz.entity.dailycheck.credit.annual;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "V_DC_CREDIT_ANNUAL_DISPOSAL")
public class VCreditAnnualDisposalInfo implements IBusinessObject{

	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID")
	private String id;

	@Column(name = "CREDIT_ID")
	private String creditId; 
	
	/** 企业名称 **/
	@Column(name="ENT_NAME")
	private String entName;
	
	/** 企业编号 **/
	@Column(name="ENT_CODE")
	private String entCode;
	
	/** 企业类型分组Id **/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/** 企业类型分组名称 **/
	@Column(name="ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;

	/** 企业类型Id **/
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/*生产地址*/
	@Column(name="ent_Prod_Addr")
	private String entProdAddr;
	
	/** 企业类型名称 **/
	@Column(name="ENT_TYPE_NAME")
	private String entTypeName;
	
	/** 监管单位编号 **/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** 监管单位名称 **/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** 评定年份 **/
	@Column(name="CREDIT_YEAR")
	private int creditYear;
	
	/** 评定人Id **/
	@Column(name="CREDIT_USER_ID")
	private String creditUserId;
	
	/** 评定人 **/
	@Column(name="CREDIT_USER_NAME")
	private String creditUserName;
	
	/** 评定时间 **/
	@Column(name="CREDIT_TIME")
	private Date creditTime;
	
	/** 评定等级 **/
	@Column(name="CREDIT_VALUE")
	private String creditValue;
	
	/** 级别名称 **/
	@Column(name="CREDIT_NAME")
	private String creditName;
	
	/** 评定得分 **/
	@Column(name="CREDIT_SCORE")
	private String creditScore;
	
	/** 评级类型Id **/
	@Column(name="CREDIT_TYPE_ID")
	private Integer creditTypeId;
	
	/** 评级类型名称 **/
	@Column(name="CREDIT_TYPE_NAME")
	private String creditTypeName;
	
	/** 评级种类Id **/
	@Column(name="CREDIT_CATEGORY_ID")
	private String creditCategoryId;
	
	/** 评级种类名称 **/
	@Column(name="CREDIT_CATEGORY_NAME")
	private String creditCategoryName;

	/** 评定单位Id **/
	@Column(name="CREDIT_UNIT_ID")
	private String creditUnitId;
	
	/** 评定单位名称 **/
	@Column(name="CREDIT_UNIT_NAME")
	private String creditUnitName;
	
	/** 评级状态Id **/
	@Column(name="CREDIT_STATE_ID")
	private String creditStateId;
	
	/** 评级状态 **/
	@Column(name="CREDIT_STATE_NAME")
	private String creditStateName;
	
	/** 存档单位Id **/
	@Column(name="ARCHIVE_UNIT_ID")
	private String archiveUnitId;
	
	/** 存档单位名称 **/
	@Column(name="ARCHIVE_UNIT_NAME")
	private String archiveUnitName;
	
	/** 备注 **/
	@Column(name="REMARK")
	private String remark;
	
	/** 附件组号 **/
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;
	
	@Column(name = "FROM_UNIT_ID")
	private String fromUnitId;
	
	// 来源单位名称
	@Column(name = "From_Unit_Name")
	private String fromUnitName;
	
	// 来源部门Id
	@Column(name = "From_Dept_Id")
	private String fromDeptId;
	
	// 来源部门名称
	@Column(name = "From_Dept_Name")
	private String fromDeptName;
	
	// 来源人员Id
	@Column(name = "From_User_Id")
	private String fromUserId;

	// 来源人员名称
	@Column(name = "From_User_Name")
	private String fromUserName;
	
	// 来源日期
	@Column(name = "From_Date")
	private Date fromDate;
	
	// 是否已处理
	@Column(name = "Is_Disp")
	private int isDisp;
	
	// 处理单位Id
	@Column(name = "Disp_Unit_Id")
	private String dispUnitId;

	// 处理单位名称
	@Column(name = "Disp_Unit_Name")
	private String dispUnitName;
	
	// 处理人Id
	@Column(name = "Disp_User_Id")
	private String dispUserId;
	
	// 处理人
	@Column(name = "Disp_User_Name")
	private String dispUserName;
	
	// 处理时间
	@Column(name = "Disp_Date")
	private String dispDate;
	
	// 处理环节名称
	@Column(name = "Disp_Node_Name")
	private String dispNodeName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreditId() {
		return creditId;
	}

	public void setCreditId(String creditId) {
		this.creditId = creditId;
	}

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getEntCode() {
		return entCode;
	}

	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}

	public String getEntTypeId() {
		return entTypeId;
	}

	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	public String getEntProdAddr() {
		return entProdAddr;
	}

	public void setEntProdAddr(String entProdAddr) {
		this.entProdAddr = entProdAddr;
	}

	public String getEntTypeName() {
		return entTypeName;
	}

	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public int getCreditYear() {
		return creditYear;
	}

	public void setCreditYear(int creditYear) {
		this.creditYear = creditYear;
	}

	public String getCreditUserId() {
		return creditUserId;
	}

	public void setCreditUserId(String creditUserId) {
		this.creditUserId = creditUserId;
	}

	public String getCreditUserName() {
		return creditUserName;
	}

	public void setCreditUserName(String creditUserName) {
		this.creditUserName = creditUserName;
	}

	public Date getCreditTime() {
		return creditTime;
	}

	public void setCreditTime(Date creditTime) {
		this.creditTime = creditTime;
	}

	public String getCreditValue() {
		return creditValue;
	}

	public void setCreditValue(String creditValue) {
		this.creditValue = creditValue;
	}

	public String getCreditName() {
		return creditName;
	}

	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}

	public String getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}

	public Integer getCreditTypeId() {
		return creditTypeId;
	}

	public void setCreditTypeId(Integer creditTypeId) {
		this.creditTypeId = creditTypeId;
	}

	public String getCreditTypeName() {
		return creditTypeName;
	}

	public void setCreditTypeName(String creditTypeName) {
		this.creditTypeName = creditTypeName;
	}

	public String getCreditCategoryId() {
		return creditCategoryId;
	}

	public void setCreditCategoryId(String creditCategoryId) {
		this.creditCategoryId = creditCategoryId;
	}

	public String getCreditCategoryName() {
		return creditCategoryName;
	}

	public void setCreditCategoryName(String creditCategoryName) {
		this.creditCategoryName = creditCategoryName;
	}

	public String getCreditUnitId() {
		return creditUnitId;
	}

	public void setCreditUnitId(String creditUnitId) {
		this.creditUnitId = creditUnitId;
	}

	public String getCreditUnitName() {
		return creditUnitName;
	}

	public void setCreditUnitName(String creditUnitName) {
		this.creditUnitName = creditUnitName;
	}

	public String getCreditStateId() {
		return creditStateId;
	}

	public void setCreditStateId(String creditStateId) {
		this.creditStateId = creditStateId;
	}

	public String getCreditStateName() {
		return creditStateName;
	}

	public void setCreditStateName(String creditStateName) {
		this.creditStateName = creditStateName;
	}

	public String getArchiveUnitId() {
		return archiveUnitId;
	}

	public void setArchiveUnitId(String archiveUnitId) {
		this.archiveUnitId = archiveUnitId;
	}

	public String getArchiveUnitName() {
		return archiveUnitName;
	}

	public void setArchiveUnitName(String archiveUnitName) {
		this.archiveUnitName = archiveUnitName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAttachmentCode() {
		return attachmentCode;
	}

	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	public String getFromUnitId() {
		return fromUnitId;
	}

	public void setFromUnitId(String fromUnitId) {
		this.fromUnitId = fromUnitId;
	}

	public String getFromUnitName() {
		return fromUnitName;
	}

	public void setFromUnitName(String fromUnitName) {
		this.fromUnitName = fromUnitName;
	}

	public String getFromDeptId() {
		return fromDeptId;
	}

	public void setFromDeptId(String fromDeptId) {
		this.fromDeptId = fromDeptId;
	}

	public String getFromDeptName() {
		return fromDeptName;
	}

	public void setFromDeptName(String fromDeptName) {
		this.fromDeptName = fromDeptName;
	}

	public String getFromUserId() {
		return fromUserId;
	}

	public void setFromUserId(String fromUserId) {
		this.fromUserId = fromUserId;
	}

	public String getFromUserName() {
		return fromUserName;
	}

	public void setFromUserName(String fromUserName) {
		this.fromUserName = fromUserName;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public int getIsDisp() {
		return isDisp;
	}

	public void setIsDisp(int isDisp) {
		this.isDisp = isDisp;
	}

	public String getDispUnitId() {
		return dispUnitId;
	}

	public void setDispUnitId(String dispUnitId) {
		this.dispUnitId = dispUnitId;
	}

	public String getDispUnitName() {
		return dispUnitName;
	}

	public void setDispUnitName(String dispUnitName) {
		this.dispUnitName = dispUnitName;
	}

	public String getDispUserId() {
		return dispUserId;
	}

	public void setDispUserId(String dispUserId) {
		this.dispUserId = dispUserId;
	}

	public String getDispUserName() {
		return dispUserName;
	}

	public void setDispUserName(String dispUserName) {
		this.dispUserName = dispUserName;
	}

	public String getDispDate() {
		return dispDate;
	}

	public void setDispDate(String dispDate) {
		this.dispDate = dispDate;
	}

	public String getDispNodeName() {
		return dispNodeName;
	}

	public void setDispNodeName(String dispNodeName) {
		this.dispNodeName = dispNodeName;
	}
}
