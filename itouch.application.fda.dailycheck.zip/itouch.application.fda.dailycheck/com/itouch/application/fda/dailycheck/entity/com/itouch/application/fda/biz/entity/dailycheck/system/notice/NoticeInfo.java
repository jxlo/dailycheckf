/**
 * 
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.notice;

import java.util.Date;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**   
 * @ClassName: TaskSourceInfo   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-12 下午4:04:51      
 */
@Entity
@Table(name="DC_SYS_NOTICE")
public class NoticeInfo implements IBusinessObject{
	
	/** @Fields id : 主键Id **/ 
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="ID")
	private String id;
	
	/** @Fields title : 标题 **/
	@Column(name="TITLE")
	private String title;
	
	/** @Fields summary : 概述 **/
	@Column(name="SUMMARY")
	private String summary;
	
	/** @Fields content : 内容 **/
	@Column(name="CONTENT")
	private String content;
	
	/** @Fields startTime : 开始时间 **/
	@Column(name="STARTTIME")
	private Date startTime;
	
	/** @Fields endtime : 结束时间 **/
	@Column(name="ENDTIME")
	private Date endTime;
	
	/** @Fields creatorId : 创建人id **/
	@Column(name="CREATORID")
	private String creatorId;
	
	/** @Fields creatorName : 创建人姓名 **/
	@Column(name="CREATORNAME")
	private String creatorName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	
}
