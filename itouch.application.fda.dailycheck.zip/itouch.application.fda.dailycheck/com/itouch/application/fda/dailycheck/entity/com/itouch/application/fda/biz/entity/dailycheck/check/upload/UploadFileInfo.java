package com.itouch.application.fda.biz.entity.dailycheck.check.upload;

/**
 * 附件信息
 */
public class UploadFileInfo {
	
	/**
	 * 文件Id
	 */
	private String fileId;
	
	/**
	 * 附件标识（必填）
	 */
	private String attachmentCode;
	
	/**
	 * 文件内容（字符串）
	 */
	private String uploadFileDateInfo;
	
	/**
	 * 文件Url
	 */
	private String uploadFileUrl;
	
	/**
	 * 文件类型
	 */
	private String fileType;
	
	/**
	 * 文件名称
	 */
	private String fileName;
	
	/**
	 * 文件全称
	 */
	private String fileFullName;
	
	/**
	 * 文件类型
	 */
	private String fileExtension;
	
	/**
	 * 文件大小
	 */
	private String fileSize;
	
	/**
	 * 单位Id
	 */
	private String unitId;
	
	/**
	 * 单位名称
	 */
	private String unitName;
	
	/**
	 * 用户Id
	 */
	private String userId;
	
	/**
	 * 用户名称
	 */
	private String userName;
	
	/**
	 * 上传时间
	 */
	private String uploadTime;

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getUploadFileDateInfo() {
		return uploadFileDateInfo;
	}

	public void setUploadFileDateInfo(String uploadFileDateInfo) {
		this.uploadFileDateInfo = uploadFileDateInfo;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileFullName() {
		return fileFullName;
	}

	public void setFileFullName(String fileFullName) {
		this.fileFullName = fileFullName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(String uploadTime) {
		this.uploadTime = uploadTime;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getAttachmentCode() {
		return attachmentCode;
	}

	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	public String getUploadFileUrl() {
		return uploadFileUrl;
	}

	public void setUploadFileUrl(String uploadFileUrl) {
		this.uploadFileUrl = uploadFileUrl;
	}
}
