/**  
* @Title: DcTemplateSmallSubject.java 
* @Package com.itouch.application.fda.biz.entity.dailycheck.system.table 
* @author wangk    
* @date 2015-10-10 下午2:53:26  
*/ 
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * @author wangk
 * @Description: 检查模板项小项目
 * @date 2015-10-10 下午2:53:26  
 */
@Entity
@Table(name="DC_TEMPLATE_SMALL_SUBJECT")
public class TemplateSmallSubjectInfo {

	/**小项Id**/
	@Id
	@Column(name="SMALL_SUBJECT_ID")
	private String smallSubjectId;
	
	/**标识符**/
	@Column(name="SUBJECT_ID")
	private String subjectId;
	
	/**模板Id**/
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**文本**/
	@Column(name="TEXT")
	private String text;
	
	/**编号**/
	@Column(name="NO")
	private String no;

	@Transient
	public List<TemplateItemInfo> templateItemInfoList = new ArrayList<TemplateItemInfo>();
	
	/**
	 * 获取smallSubjectId
	 * @return smallSubjectId
	 */
	public String getSmallSubjectId() {
		return smallSubjectId;
	}

	/**  
	 * 设置smallSubjectId  
	 * @param smallSubjectId
	 */
	public void setSmallSubjectId(String smallSubjectId) {
		this.smallSubjectId = smallSubjectId;
	}

	/**
	 * 获取subjectId
	 * @return subjectId
	 */
	public String getSubjectId() {
		return subjectId;
	}

	/**  
	 * 设置subjectId  
	 * @param subjectId
	 */
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	/**
	 * 获取templateId
	 * @return templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**  
	 * 设置templateId  
	 * @param templateId
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * 获取text
	 * @return text
	 */
	public String getText() {
		return text;
	}

	/**  
	 * 设置text  
	 * @param text
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * 获取no
	 * @return no
	 */
	public String getNo() {
		return no;
	}

	/**  
	 * 设置no  
	 * @param no
	 */
	public void setNo(String no) {
		this.no = no;
	}

	
}
