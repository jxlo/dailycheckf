/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:VCheckReviewInfo.java
 * @author:fanghailong
 * @time:2015-11-2 下午3:01:09
 */
package com.itouch.application.fda.biz.entity.dailycheck.check;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author:fanghailong 
 */
@Entity
@Table(name="V_DC_CHECK_REVIEW")
public class VCheckReviewInfo implements IBusinessObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**整改修复Id*/
	@Id
	@Column(name="REVIEW_ID")
	private String reviewId;
	
	/**检查记录id*/
	@Column(name="CHECK_ID")
	private String checkId;
	
	/**复查开始日期*/
	@Column(name="VALID_FROM_DATE")
	private Date validFromDate;
	
	/**复查截止日期*/
	@Column(name="VALID_TO_DATE")
	private Date validToDate;
	
	/**检查结论id*/
	@Column(name="RESULT_VERDICT_ID")
	private Integer resultVerdictId;
	
	/**检查结论*/
	@Column(name="RESULT_VERDICT_NAME")
	private String resultVerdictName;
	
	/**检查人员ids*/
	@Column(name="REVIEW_USER_IDS")
	private String reviewUserIds;
	
	/**检查人员姓名*/
	@Column(name="REVIEW_USER_NAMES")
	private String reviewUserNames;
	
	/**陪同检查人员*/
	@Column(name="ACCOMP_USERS")
	private String accompUsers;
	
	/**陪同检查人员电话*/
	@Column(name="ACCOMP_USERS_TEL")
	private String accompUsersTel;
	
	/**创建时间*/
	@Column(name="CREATE_TIME")
	private Date createTime;
	
	/**复查截止日期*/
	@Column(name="REVIEW_EXPIRE_DATE")
	private Date reviewExpireDate;
	
	/** @Fields checkTypeId : 检查类别Id **/ 
	@Column(name="CHECK_TYPE_ID")
	private String checkTypeId;
	
	/** @Fields checkTypeName : 检查类别Id **/ 
	@Column(name="CHECK_TYPE_NAME")
	private String checkTypeName;
	
	/** @Fields checkUserIds : 检查人Ids **/ 
	@Column(name="CHECK_USER_IDS")
	private String checkUserIds;
	
	/** @Fields checkUserNames : 检查人姓名 **/ 
	@Column(name="CHECK_USER_NAMES")
	private String checkUserNames;
	
	/** @Fields checkBeginDate : 检查开始日期 **/ 
	@Column(name="CHECK_BEGIN_DATE")
	private Date checkBeginDate;
	
	/** @Fields checkEndDate : 检查结束日期 **/ 
	@Column(name="CHECK_END_DATE")
	private Date checkEndDate;
	
	/** @Fields tableId : 表Id **/ 
	@Column(name="TABLE_ID")
	private String tableId;
	
	/** @Fields unitId : 监管单位编号 **/ 
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** @Fields unitName : 监管单位名称 **/ 
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** @Fields resultVerdictId : 检查结论Id **/ 
	@Column(name="VERDICT_ID")
	private Integer verdictId;
	
	/** @Fields resultVerdictName : 检查结论 **/ 
	@Column(name="VERDICT_NAME")
	private String verdictName;
	
	/** @Fields entName : 企业名称 **/ 
	@Column(name="ENT_NAME")
	private String entName;
	
	/** @Fields entTypeId : 企业类型Id **/ 
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/** @Fields entTypeName : 企业类型名称 **/ 
	@Column(name="ENT_TYPE_NAME")
	private String entTypeName;
	
	/** 企业类型分组Id  **/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/** @Fields regAddr : 企业注册地址 **/ 
	@Column(name="REG_ADDR")
	private String regAddr;
	
	/** @Fields ent_principal_id : 企业负责人Id **/ 
	@Column(name="ENT_PRINCIPAL_ID")
	private String entPrincipalId;
	
	/** @Fields entPrincipal : 企业负责人 **/ 
	@Column(name="ENT_PRINCIPAL")
	private String entPrincipal;
	
	/** @Fields entTel : 企业电话 **/ 
	@Column(name="ENT_TEL")
	private String entTel;
	
	/**是否完成*/
	@Column(name="IS_FINISHED")
	private Integer isFinished;
	
	/**附件组号*/
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;
		
	@Transient
	private int restDay;
	
	@Transient
	private String result;
	
	/**
	 * @Description:获取{note}
	 * @return:result
	 * @author:fanghailong
	 * @time:2015-11-27 上午10:14:38
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @Description:设置{note}
	 * @param：result
	 * @author:fanghailong
	 * @time:2015-11-27 上午10:14:38
	 */
	public void setResult(String result) {
		this.result = result;
	}

	/**
	 * @Description:获取{note}
	 * @return:restDay
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:20:58
	 */
	public int getRestDay() {
		return restDay;
	}

	/**
	 * @Description:设置{note}
	 * @param：restDay
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:20:58
	 */
	public void setRestDay(int restDay) {
		this.restDay = restDay;
	}

	/**
	 * @Description:获取{note}
	 * @return:attachmentCode
	 * @author:fanghailong
	 * @time:2015-11-10 下午2:30:02
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**
	 * @Description:设置{note}
	 * @param：attachmentCode
	 * @author:fanghailong
	 * @time:2015-11-10 下午2:30:02
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewExpireDate
	 * @author:fanghailong
	 * @time:2015-11-4 下午7:26:16
	 */
	public Date getReviewExpireDate() {
		return reviewExpireDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewExpireDate
	 * @author:fanghailong
	 * @time:2015-11-4 下午7:26:16
	 */
	public void setReviewExpireDate(Date reviewExpireDate) {
		this.reviewExpireDate = reviewExpireDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:isFinished
	 * @author:fanghailong
	 * @time:2015-11-5 上午10:36:51
	 */
	public Integer getIsFinished() {
		return isFinished;
	}

	/**
	 * @Description:设置{note}
	 * @param：isFinished
	 * @author:fanghailong
	 * @time:2015-11-5 上午10:36:51
	 */
	public void setIsFinished(Integer isFinished) {
		this.isFinished = isFinished;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getReviewId() {
		return reviewId;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setReviewId(String reviewId) {
		this.reviewId = reviewId;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getCheckId() {
		return checkId;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * @Description:获取{note}
	 * @return:validFromDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public Date getValidFromDate() {
		return validFromDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：validFromDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setValidFromDate(Date validFromDate) {
		this.validFromDate = validFromDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:validToDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public Date getValidToDate() {
		return validToDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：validToDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setValidToDate(Date validToDate) {
		this.validToDate = validToDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:resultVerdictId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public Integer getResultVerdictId() {
		return resultVerdictId;
	}

	/**
	 * @Description:设置{note}
	 * @param：resultVerdictId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setResultVerdictId(Integer resultVerdictId) {
		this.resultVerdictId = resultVerdictId;
	}

	/**
	 * @Description:获取{note}
	 * @return:resultVerdictName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getResultVerdictName() {
		return resultVerdictName;
	}

	/**
	 * @Description:设置{note}
	 * @param：resultVerdictName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setResultVerdictName(String resultVerdictName) {
		this.resultVerdictName = resultVerdictName;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewUserIds
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getReviewUserIds() {
		return reviewUserIds;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewUserIds
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setReviewUserIds(String reviewUserIds) {
		this.reviewUserIds = reviewUserIds;
	}

	/**
	 * @Description:获取{note}
	 * @return:reviewUserNames
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getReviewUserNames() {
		return reviewUserNames;
	}

	/**
	 * @Description:设置{note}
	 * @param：reviewUserNames
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setReviewUserNames(String reviewUserNames) {
		this.reviewUserNames = reviewUserNames;
	}

	/**
	 * @Description:获取{note}
	 * @return:accompUsers
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getAccompUsers() {
		return accompUsers;
	}

	/**
	 * @Description:设置{note}
	 * @param：accompUsers
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setAccompUsers(String accompUsers) {
		this.accompUsers = accompUsers;
	}

	/**
	 * @Description:获取{note}
	 * @return:accompUsersTel
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getAccompUsersTel() {
		return accompUsersTel;
	}

	/**
	 * @Description:设置{note}
	 * @param：accompUsersTel
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setAccompUsersTel(String accompUsersTel) {
		this.accompUsersTel = accompUsersTel;
	}
	
	
	/**
	 * @Description:获取{note}
	 * @return:createTime
	 * @author:fanghailong
	 * @time:2015-11-4 下午12:46:07
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * @Description:设置{note}
	 * @param：createTime
	 * @author:fanghailong
	 * @time:2015-11-4 下午12:46:07
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkTypeId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getCheckTypeId() {
		return checkTypeId;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkTypeId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkTypeName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getCheckTypeName() {
		return checkTypeName;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkTypeName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkUserIds
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getCheckUserIds() {
		return checkUserIds;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkUserIds
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setCheckUserIds(String checkUserIds) {
		this.checkUserIds = checkUserIds;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkUserNames
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getCheckUserNames() {
		return checkUserNames;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkUserNames
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setCheckUserNames(String checkUserNames) {
		this.checkUserNames = checkUserNames;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkBeginDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public Date getCheckBeginDate() {
		return checkBeginDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkBeginDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setCheckBeginDate(Date checkBeginDate) {
		this.checkBeginDate = checkBeginDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkEndDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public Date getCheckEndDate() {
		return checkEndDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkEndDate
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setCheckEndDate(Date checkEndDate) {
		this.checkEndDate = checkEndDate;
	}
		
	/**
	 * @Description:获取{note}
	 * @return:tableId
	 * @author:fanghailong
	 * @time:2015-11-11 下午4:03:17
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * @Description:设置{note}
	 * @param：tableId
	 * @author:fanghailong
	 * @time:2015-11-11 下午4:03:18
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description:获取{note}
	 * @return:verdictId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public Integer getVerdictId() {
		return verdictId;
	}

	/**
	 * @Description:设置{note}
	 * @param：verdictId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setVerdictId(Integer verdictId) {
		this.verdictId = verdictId;
	}

	/**
	 * @Description:获取{note}
	 * @return:verdictName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getVerdictName() {
		return verdictName;
	}

	/**
	 * @Description:设置{note}
	 * @param：verdictName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setVerdictName(String verdictName) {
		this.verdictName = verdictName;
	}

	/**
	 * @Description:获取{note}
	 * @return:entName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getEntName() {
		return entName;
	}

	/**
	 * @Description:设置{note}
	 * @param：entName
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}

	/**
	 * @Description:获取{note}
	 * @return:entTypeId
	 * @author:fanghailong
	 * @time:2015-11-3 上午10:32:10
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTypeId
	 * @author:fanghailong
	 * @time:2015-11-3 上午10:32:10
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description:获取{note}
	 * @return:entTypeName
	 * @author:fanghailong
	 * @time:2015-11-3 上午10:32:10
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTypeName
	 * @author:fanghailong
	 * @time:2015-11-3 上午10:32:10
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description:获取{note}
	 * @return:regAddr
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getRegAddr() {
		return regAddr;
	}

	/**
	 * @Description:设置{note}
	 * @param：regAddr
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setRegAddr(String regAddr) {
		this.regAddr = regAddr;
	}

	/**
	 * @Description:获取{note}
	 * @return:entPrincipalId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getEntPrincipalId() {
		return entPrincipalId;
	}

	/**
	 * @Description:设置{note}
	 * @param：entPrincipalId
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setEntPrincipalId(String entPrincipalId) {
		this.entPrincipalId = entPrincipalId;
	}

	/**
	 * @Description:获取{note}
	 * @return:entPrincipal
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getEntPrincipal() {
		return entPrincipal;
	}

	/**
	 * @Description:设置{note}
	 * @param：entPrincipal
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setEntPrincipal(String entPrincipal) {
		this.entPrincipal = entPrincipal;
	}

	/**
	 * @Description:获取{note}
	 * @return:entTel
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public String getEntTel() {
		return entTel;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTel
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public void setEntTel(String entTel) {
		this.entTel = entTel;
	}

	/**
	 * @Description:获取{note}
	 * @return:serialVersionUID
	 * @author:fanghailong
	 * @time:2015-11-2 下午3:10:22
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @Description: 获取 企业类型分组Id
	 * @return: entTypeGroupId
	 * @author wangk
	 * @date 2016-2-24 上午9:55:06 
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**   
	 * @Description: 设置 企业类型分组Id   
	 * @param: entTypeGroupId 
	 * @author wangk
	 * @date 2016-2-24 上午9:55:06 
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}
	
}
