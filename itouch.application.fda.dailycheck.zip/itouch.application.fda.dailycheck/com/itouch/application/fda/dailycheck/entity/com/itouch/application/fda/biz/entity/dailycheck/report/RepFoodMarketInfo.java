/**  
  * @Description: TODO
  * @Title: RepFoodMarketInfo.java 
  * @Package: com.itouch.application.fda.biz.entity.dailycheck.report 
  * @author: xh
  * @date 2016-3-24 上午11:24:15 
  */ 
package com.itouch.application.fda.biz.entity.dailycheck.report;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description: 食品集中交易市场情况
 * @ClassName: RepFoodMarketInfo 
 * @author xh
 * @date 2016-3-24 上午11:24:15  
 */
@Entity
@Table(name="DC_REP_FOOD_MARKET")
public class RepFoodMarketInfo implements IBusinessObject {

	/**主键Id*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	

	/**报表Id*/
	@Column(name="REPORT_ID")
	private String reportId;
	
	/**单位类别Id*/
	@Column(name="TYPE_ID")
	private String entTypeId;
	
	/**单位类别名称*/
	@Column(name="TYPE_NAME")
	private String entTypeName;
	
	/**小计*/
	@Column(name="TOTAL_COUNT")
	private Integer smallCount;
	
	/**有配套冷藏冷冻库市场*/
	@Column(name="HAS_COLD_COUNT")
	private Integer hasColdCount;
	
	/**有设置食品安全检测室市场*/
	@Column(name="HAS_DETECT_COUNT")
	private Integer hasDetectCount;
	
	/**已注册登记企业*/
	@Column(name="REG_COUNT")
	private Integer regCount;
	
	/**开办者是否注册(其他)*/
	@Column(name="UNREG_COUNT")
	private Integer unregCount;
	
	/**所在区域(城市)*/
	@Column(name="CITY_COUNT")
	private Integer cityCount;
	
	/**所在区域(农村)*/
	@Column(name="VILLAGE_COUNT")
	private Integer villageCount;
	
	/**活禽专业市场*/
	@Column(name="POULTRY_COUNT")
	private Integer poultryCount;
	
	/**水产品专业市场*/
	@Column(name="AQUATIC_COUNT")
	private Integer aquaticCount;
	
	/**果蔬专业市场*/
	@Column(name="FRUIT_COUNT")
	private Integer fruitCount;
	
	/**非专业市场*/
	@Column(name="NON_PRO_COUNT")
	private Integer nonProCount;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public String getId() {
		return id;
	}

	/**   
	 * @Description: 设置 主键Id   
	 * @param: id 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 报表Id
	 * @return: reportId
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public String getReportId() {
		return reportId;
	}

	/**   
	 * @Description: 设置 报表Id   
	 * @param: reportId 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	/**
	 * @Description: 获取 单位类别Id
	 * @return: entTypeId
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**   
	 * @Description: 设置 单位类别Id   
	 * @param: entTypeId 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 单位类别名称
	 * @return: entTypeName
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**   
	 * @Description: 设置 单位类别名称   
	 * @param: entTypeName 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description: 获取 小计
	 * @return: smallCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getSmallCount() {
		return smallCount;
	}

	/**   
	 * @Description: 设置 小计   
	 * @param: smallCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setSmallCount(Integer smallCount) {
		this.smallCount = smallCount;
	}

	/**
	 * @Description: 获取 有配套冷藏冷冻库市场
	 * @return: hasColdCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getHasColdCount() {
		return hasColdCount;
	}

	/**   
	 * @Description: 设置 有配套冷藏冷冻库市场   
	 * @param: hasColdCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setHasColdCount(Integer hasColdCount) {
		this.hasColdCount = hasColdCount;
	}

	/**
	 * @Description: 获取 有设置食品安全检测室市场
	 * @return: hasDetectCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getHasDetectCount() {
		return hasDetectCount;
	}

	/**   
	 * @Description: 设置 有设置食品安全检测室市场   
	 * @param: hasDetectCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setHasDetectCount(Integer hasDetectCount) {
		this.hasDetectCount = hasDetectCount;
	}

	/**
	 * @Description: 获取 已注册登记企业
	 * @return: regCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getRegCount() {
		return regCount;
	}

	/**   
	 * @Description: 设置 已注册登记企业   
	 * @param: regCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setRegCount(Integer regCount) {
		this.regCount = regCount;
	}

	/**
	 * @Description: 获取 开办者是否注册(其他)
	 * @return: unregCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getUnregCount() {
		return unregCount;
	}

	/**   
	 * @Description: 设置 开办者是否注册(其他)   
	 * @param: unregCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setUnregCount(Integer unregCount) {
		this.unregCount = unregCount;
	}

	/**
	 * @Description: 获取 所在区域(城市)
	 * @return: cityCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getCityCount() {
		return cityCount;
	}

	/**   
	 * @Description: 设置 所在区域(城市)   
	 * @param: cityCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setCityCount(Integer cityCount) {
		this.cityCount = cityCount;
	}

	/**
	 * @Description: 获取 所在区域(农村)
	 * @return: villageCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getVillageCount() {
		return villageCount;
	}

	/**   
	 * @Description: 设置 所在区域(农村)   
	 * @param: villageCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setVillageCount(Integer villageCount) {
		this.villageCount = villageCount;
	}

	/**
	 * @Description: 获取 活禽专业市场
	 * @return: poultryCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getPoultryCount() {
		return poultryCount;
	}

	/**   
	 * @Description: 设置 活禽专业市场   
	 * @param: poultryCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setPoultryCount(Integer poultryCount) {
		this.poultryCount = poultryCount;
	}

	/**
	 * @Description: 获取 水产品专业市场
	 * @return: aquaticCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getAquaticCount() {
		return aquaticCount;
	}

	/**   
	 * @Description: 设置 水产品专业市场   
	 * @param: aquaticCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setAquaticCount(Integer aquaticCount) {
		this.aquaticCount = aquaticCount;
	}

	/**
	 * @Description: 获取 果蔬专业市场
	 * @return: fruitCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getFruitCount() {
		return fruitCount;
	}

	/**   
	 * @Description: 设置 果蔬专业市场   
	 * @param: fruitCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setFruitCount(Integer fruitCount) {
		this.fruitCount = fruitCount;
	}

	/**
	 * @Description: 获取 非专业市场
	 * @return: nonProCount
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public Integer getNonProCount() {
		return nonProCount;
	}

	/**   
	 * @Description: 设置 非专业市场   
	 * @param: nonProCount 
	 * @author xh
	 * @date 2016-3-24 上午11:31:25 
	 */
	public void setNonProCount(Integer nonProCount) {
		this.nonProCount = nonProCount;
	}
	
	
}
