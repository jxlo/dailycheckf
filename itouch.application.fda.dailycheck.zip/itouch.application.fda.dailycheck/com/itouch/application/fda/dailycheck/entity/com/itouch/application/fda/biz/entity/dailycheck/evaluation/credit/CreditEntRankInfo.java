package com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.itouch.application.ent.entity.basic.VEntBasic;
import com.itouch.application.ent.enums.EnumEntTypeGroup;

/**
 * @author qiuy
 * 企业年度信用评级实体
 */
@Entity
@Table(name="DC_CREDIT_ENT_RANK")
public class CreditEntRankInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	public CreditEntRankInfo() { }
	
	public CreditEntRankInfo(VEntBasic vEntBasic) {
		setAreaCode(vEntBasic.getAreaCode());
		setAreaName(vEntBasic.getAreaName());
		setEntCode(vEntBasic.getEntCode());
		setEntName(vEntBasic.getEntName());
		setEntTypeGroupId(vEntBasic.getEntTypeGroupId());
		EnumEntTypeGroup entTypeGroup = EnumEntTypeGroup.Other.getEnum(getEntTypeGroupId());
		if(entTypeGroup != null) {
			setEntTypeGroupName(entTypeGroup.toString());
		}
		setEntTypeId(vEntBasic.getEntTypeId());
		setEntTypeName(vEntBasic.getEntTypeName());
		setUnitId(vEntBasic.getUnitId());
		setUnitName(vEntBasic.getUnitName());
	}
	
	//主键Id
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="CREDIT_ID")
	private String creditId;
	
	//企业编号
	@Column(name="ENT_CODE")
	private String entCode;

	//企业名称
	@Column(name="ENT_NAME")
	private String entName;

	//企业类型分组编号
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;

	//企业类型分组名称
	@Column(name="ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;

	//企业类型编号
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;

	//企业类型名称
	@Column(name="ENT_TYPE_NAME")
	private String entTypeName;

	//监管单位编号
	@Column(name="UNIT_ID")
	private String unitId;

	//监管单位名称
	@Column(name="UNIT_NAME")
	private String unitName;
	
	//地区编号
	@Column(name="AREA_CODE")
	private String areaCode;

	//地区名称
	@Column(name="AREA_NAME")
	private String areaName;
	
	//评定年份
	@Column(name="CREDIT_YEAR")
	private Integer creditYear;
	
	//评定人编号
	@Column(name="CREDIT_USER_ID")
	private String creditUserId;

	//评定人名称
	@Column(name="CREDIT_USER_NAME")
	private String creditUserName;
	
	//评定单位编号
	@Column(name="CREDIT_UNIT_ID")
	private String creditUnitId;

	//评定单位名称
	@Column(name="CREDIT_UNIT_NAME")
	private String creditUnitName;
	
	//评定时间
	@Column(name="CREDIT_TIME")
	private Date creditTime;

	//评定等级
	@Column(name="CREDIT_VALUE")
	private String creditValue;
	
	//评定体系编号
	@Column(name="CRITERION_ID")
	private String criterionId;

	//评定体系名称
	@Column(name="CRITERION_NAME")
	private String criterionName;

	//备注
	@Column(name="REMARK")
	private String remark;

	public String getCreditId() {
		return this.creditId;
	}

	public void setCreditId(String creditId) {
		this.creditId = creditId;
	}

	public Date getCreditTime() {
		return this.creditTime;
	}

	public void setCreditTime(Date creditTime) {
		this.creditTime = creditTime;
	}

	public String getCreditUnitId() {
		return this.creditUnitId;
	}

	public void setCreditUnitId(String creditUnitId) {
		this.creditUnitId = creditUnitId;
	}

	public String getCreditUnitName() {
		return this.creditUnitName;
	}

	public void setCreditUnitName(String creditUnitName) {
		this.creditUnitName = creditUnitName;
	}

	public String getCreditUserId() {
		return this.creditUserId;
	}

	public void setCreditUserId(String creditUserId) {
		this.creditUserId = creditUserId;
	}

	public String getCreditUserName() {
		return this.creditUserName;
	}

	public void setCreditUserName(String creditUserName) {
		this.creditUserName = creditUserName;
	}

	public String getCreditValue() {
		return this.creditValue;
	}

	public void setCreditValue(String creditValue) {
		this.creditValue = creditValue;
	}

	public Integer getCreditYear() {
		return this.creditYear;
	}

	public void setCreditYear(Integer creditYear) {
		this.creditYear = creditYear;
	}

	public String getCriterionId() {
		return this.criterionId;
	}

	public void setCriterionId(String criterionId) {
		this.criterionId = criterionId;
	}

	public String getCriterionName() {
		return this.criterionName;
	}

	public void setCriterionName(String criterionName) {
		this.criterionName = criterionName;
	}

	public String getEntCode() {
		return this.entCode;
	}

	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	public String getEntName() {
		return this.entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getEntTypeGroupId() {
		return this.entTypeGroupId;
	}

	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	public String getEntTypeGroupName() {
		return this.entTypeGroupName;
	}

	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}

	public String getEntTypeId() {
		return this.entTypeId;
	}

	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	public String getEntTypeName() {
		return this.entTypeName;
	}

	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getUnitId() {
		return this.unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return this.unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
}
