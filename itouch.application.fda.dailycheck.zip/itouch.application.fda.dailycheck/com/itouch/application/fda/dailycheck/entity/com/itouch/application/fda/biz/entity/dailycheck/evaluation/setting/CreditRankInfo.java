package com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author qiuy
 * 信用评定等级实体
 */
@Entity
@Table(name="DC_CREDIT_RANK")
public class CreditRankInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	//评定等级编号
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="RANK_ID")
	private String rankId;

	//评定等级名称
	@Column(name="RANK_NAME")
	private String rankName;
	
	//评定体系编号
	@Column(name="CRITERION_ID")
	private String criterionId;

	//评定体系名称
	@Column(name="CRITERION_NAME")
	private String criterionName;

	//是否启用
	@Column(name="IS_ENABLED")
	private Integer isEnabled;

	//排序号
	@Column(name="ORDER_ID")
	private Integer orderId;

	//备注
	@Column(name="REMARK")
	private String remark;

	public String getRankId() {
		return this.rankId;
	}

	public void setRankId(String rankId) {
		this.rankId = rankId;
	}

	public String getCriterionId() {
		return this.criterionId;
	}

	public void setCriterionId(String criterionId) {
		this.criterionId = criterionId;
	}

	public String getCriterionName() {
		return this.criterionName;
	}

	public void setCriterionName(String criterionName) {
		this.criterionName = criterionName;
	}

	public Integer getIsEnabled() {
		return this.isEnabled;
	}

	public void setIsEnabled(Integer isEnabled) {
		this.isEnabled = isEnabled;
	}

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getRankName() {
		return this.rankName;
	}

	public void setRankName(String randName) {
		this.rankName = randName;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
