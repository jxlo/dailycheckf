package com.itouch.application.fda.biz.entity.dailycheck.credit;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: VCreditToCheckInfo 
 * @author: wangk
 * @date: 2016-3-15 上午10:13:59  
 */
@Entity
@Table(name="V_DC_CREDIT_TO_CHECK")
public class VCreditToCheckInfo implements IBusinessObject{
	private static final long serialVersionUID = 3431290389023663608L;

	/** 主键Id **/
	@Id
	@Column(name="ID")
	private String id;
	
	/** 企业编号 **/
	@Column(name="ENT_CODE")
	private String entCode;
	
	/** 企业名称 **/
	@Column(name="ENT_NAME")
	private String entName;
	
	/** 监管单位ID **/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** 监管单位名称 **/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** 企业类型Id **/
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/** 企业类型分组Id **/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/** 企业注册地址 **/
	@Column(name="REG_ADDR")
	private String regAddr;
	
	/** 地区街道 **/
	@Column(name="AREA_NAME")
	private String areaName;
	
	/** 证书编号 **/
	@Column(name="LIC_CODE")
	private String licCode;
	
	/** 有效期自 **/
	@Column(name="VALID_FROM_DATE")
	private Date validFromDate;
	
	/** 有效期至 **/
	@Column(name="VALID_TO_DATE")
	private Date validToDate;
	
	/** 最近评定年份 **/
	@Column(name="LAST_CREDIT_YEAR")
	private Integer lastCreditYear;
	
	/** 最近年度等级 **/
	@Column(name="LAST_CREDIT_VALUE")
	private String lastCreditValue;
	
	/** 最近年度等级 **/
	@Column(name="LAST_CREDIT_NAME")
	private String lastCreditName;
	
	/** 已检查次数 **/
	@Column(name="CHECKED_TIMES")
	private Integer checkedTimes;
	
	/** 应检查次数 **/
	@Column(name="TO_CHECKED_TIMES")
	private Integer toCheckedTimes;
	
	/** 最后一次评定的年份 **/
	@Column(name="LAST_ANNUAL_CREDIT_YEAR")
	private Integer lastAnnualCreditYear;

	/** 首次评定年份 **/
	@Column(name="FIRST_CREDIT_YEAR")
	private Integer firstCreditYear;
	
	/** 首次年度等级 **/
	@Column(name="FIRST_CREDIT_VALUE")
	private String firstCreditValue;
	
	/** 首次年度等级 **/
	@Column(name="FIRST_CREDIT_NAME")
	private String firstCreditName;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getId() {
		return id;
	}

	/**   
	 * @Description: 设置 主键Id   
	 * @param: id 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 企业编号
	 * @return: entCode
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getEntCode() {
		return entCode;
	}

	/**   
	 * @Description: 设置 企业编号   
	 * @param: entCode 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	/**
	 * @Description: 获取 企业名称
	 * @return: entName
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getEntName() {
		return entName;
	}

	/**   
	 * @Description: 设置 企业名称   
	 * @param: entName 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}

	/**
	 * @Description: 获取 监管单位ID
	 * @return: unitId
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getUnitId() {
		return unitId;
	}

	/**   
	 * @Description: 设置 监管单位ID   
	 * @param: unitId 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description: 获取 监管单位名称
	 * @return: unitName
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getUnitName() {
		return unitName;
	}

	/**   
	 * @Description: 设置 监管单位名称   
	 * @param: unitName 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description: 获取 企业类型Id
	 * @return: entTypeId
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**   
	 * @Description: 设置 企业类型Id   
	 * @param: entTypeId 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 企业注册地址
	 * @return: regAddr
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getRegAddr() {
		return regAddr;
	}

	/**   
	 * @Description: 设置 企业注册地址   
	 * @param: regAddr 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setRegAddr(String regAddr) {
		this.regAddr = regAddr;
	}

	/**
	 * @Description: 获取 证书编号
	 * @return: licCode
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public String getLicCode() {
		return licCode;
	}

	/**   
	 * @Description: 设置 证书编号   
	 * @param: licCode 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setLicCode(String licCode) {
		this.licCode = licCode;
	}

	/**
	 * @Description: 获取 有效期自
	 * @return: validFromDate
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public Date getValidFromDate() {
		return validFromDate;
	}

	/**   
	 * @Description: 设置 有效期自   
	 * @param: validFromDate 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setValidFromDate(Date validFromDate) {
		this.validFromDate = validFromDate;
	}

	/**
	 * @Description: 获取 有效期至
	 * @return: validToDate
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public Date getValidToDate() {
		return validToDate;
	}

	/**   
	 * @Description: 设置 有效期至   
	 * @param: validToDate 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setValidToDate(Date validToDate) {
		this.validToDate = validToDate;
	}

	/**
	 * @Description: 获取 年度
	 * @return: lastCreditYear
	 * @author: wangk
	 * @date: 2016-3-15 下午1:57:43 
	 */
	public Integer getLastCreditYear() {
		return lastCreditYear;
	}

	/**   
	 * @Description: 设置 年度   
	 * @param: lastCreditYear 
	 * @author: wangk
	 * @date: 2016-3-15 下午1:57:43 
	 */
	public void setLastCreditYear(Integer lastCreditYear) {
		this.lastCreditYear = lastCreditYear;
	}

	/**
	 * @Description: 获取 已检查次数
	 * @return: checkedTimes
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public Integer getCheckedTimes() {
		return checkedTimes;
	}

	/**   
	 * @Description: 设置 已检查次数   
	 * @param: checkedTimes 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setCheckedTimes(Integer checkedTimes) {
		this.checkedTimes = checkedTimes;
	}

	/**
	 * @Description: 获取 应检查次数
	 * @return: toCheckedTimes
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public Integer getToCheckedTimes() {
		return toCheckedTimes;
	}

	/**   
	 * @Description: 设置 应检查次数   
	 * @param: toCheckedTimes 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:31:21 
	 */
	public void setToCheckedTimes(Integer toCheckedTimes) {
		this.toCheckedTimes = toCheckedTimes;
	}

	/**
	 * @Description: 获取 企业类型分组Id
	 * @return: entTypeGroupId
	 * @author: wangk
	 * @date: 2016-3-15 上午10:55:08 
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**   
	 * @Description: 设置 企业类型分组Id   
	 * @param: entTypeGroupId 
	 * @author: wangk
	 * @date: 2016-3-15 上午10:55:08 
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	/**
	 * @Description: 获取 应检查次数
	 * @return: lastAnnualCreditYear
	 * @author: wangk
	 * @date: 2016-3-15 下午2:36:48 
	 */
	public Integer getLastAnnualCreditYear() {
		return lastAnnualCreditYear;
	}

	/**   
	 * @Description: 设置 应检查次数   
	 * @param: lastAnnualCreditYear 
	 * @author: wangk
	 * @date: 2016-3-15 下午2:36:48 
	 */
	public void setLastAnnualCreditYear(Integer lastAnnualCreditYear) {
		this.lastAnnualCreditYear = lastAnnualCreditYear;
	}
	
	
	public String getLastCreditValue() {
		return lastCreditValue;
	}

	public void setLastCreditValue(String lastCreditValue) {
		this.lastCreditValue = lastCreditValue;
	}

	public String getLastCreditName() {
		return lastCreditName;
	}

	public void setLastCreditName(String lastCreditName) {
		this.lastCreditName = lastCreditName;
	}

	public String getFirstCreditValue() {
		return firstCreditValue;
	}

	public void setFirstCreditValue(String firstCreditValue) {
		this.firstCreditValue = firstCreditValue;
	}
	
	public Integer getFirstCreditYear() {
		return firstCreditYear;
	}

	public void setFirstCreditYear(Integer firstCreditYear) {
		this.firstCreditYear = firstCreditYear;
	}

	public String getFirstCreditName() {
		return firstCreditName;
	}

	public void setFirstCreditName(String firstCreditName) {
		this.firstCreditName = firstCreditName;
	}
	
	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
}
