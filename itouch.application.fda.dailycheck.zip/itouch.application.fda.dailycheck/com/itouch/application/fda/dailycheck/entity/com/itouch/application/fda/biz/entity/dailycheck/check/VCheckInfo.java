package com.itouch.application.fda.biz.entity.dailycheck.check;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "V_DC_CHECK")
public class VCheckInfo implements IBusinessObject {

	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** @Fields checkId :检查记录Id **/
	@Id
	@Column(name = "CHECK_ID")
	private String checkId;

	/** @Fields checkTypeId : 检查类别Id **/
	@Column(name = "CHECK_TYPE_ID")
	private String checkTypeId;

	/** @Fields checkTypeName : 检查类别Id **/
	@Column(name = "CHECK_TYPE_NAME")
	private String checkTypeName;

	/** @Fields checkLeaderId : 实际检查带队人Id **/
	@Column(name = "CHECK_LEADER_ID")
	private String checkLeaderId;

	/** @Fields checkLeaderName : 实际检查带队人姓名 **/
	@Column(name = "CHECK_LEADER_NAME")
	private String checkLeaderName;

	/** @Fields accompUsersTel : 陪同检查人员电话 **/
	@Column(name = "ACCOMP_USERS_TEL")
	private String accompUsersTel;

	/** @Fields checkUserIds : 检查人Ids **/
	@Column(name = "CHECK_USER_IDS")
	private String checkUserIds;

	/** @Fields checkUserNames : 检查人姓名 **/
	@Column(name = "CHECK_USER_NAMES")
	private String checkUserNames;

	/** @Fields checkBeginDate : 检查开始日期 **/
	@Column(name = "CHECK_BEGIN_DATE")
	private Date checkBeginDate;

	/** @Fields checkEndDate : 检查结束日期 **/
	@Column(name = "CHECK_END_DATE")
	private Date checkEndDate;

	/** @Fields tableId : 表Id **/
	@Column(name = "TABLE_ID")
	private String tableId;

	/** @Fields unitId : 监管单位编号 **/
	@Column(name = "ENT_UNIT_ID")
	private String entUnitId;

	/** @Fields unitName : 监管单位名称 **/
	@Column(name = "ENT_UNIT_NAME")
	private String entUnitName;

	/** @Fields creatorId : 创建人Id **/
	@Column(name = "CREATOR_ID", updatable = false)
	private String creatorId;

	/** @Fields creatorName : 创建人姓名 **/
	@Column(name = "CREATOR_NAME", updatable = false)
	private String creatorName;

	/** @Fields createTime : 创建时间 **/

	@Column(name = "CREATE_TIME", updatable = false)
	private Date createTime;

	/** @Fields updateUserId : 更新人Id **/
	@Column(name = "UPDATE_USER_ID")
	private String updateUserId;

	/** @Fields updateUserName : 更新人 **/
	@Column(name = "UPDATE_USER_NAME")
	private String updateUserName;

	/** @Fields updateTime : 更新时间 **/
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	/** @Fields isArchived : 是否归档 **/
	@Column(name = "IS_ARCHIVED")
	private Integer isArchived = 0;

	/** @Fields isTemp : 是否暂存 **/
	@Column(name = "IS_TEMP")
	private Integer isTemp = 0;

	/** @Fields isDelete : 是否已删除 **/
	@Column(name = "IS_DELETE")
	private Integer isDelete = 0;

	/** @Fields grade : 等级 **/
	@Column(name = "GRADE")
	private String grade;

	/** @Fields flowKey : 流程编号 **/
	@Column(name = "FLOW_KEY")
	private String flowKey;

	/** @Fields resultVerdictId : 检查结论Id **/
	@Column(name = "RESULT_VERDICT_ID")
	private Integer resultVerdictId;

	/** @Fields resultVerdictName : 检查结论 **/
	@Column(name = "RESULT_VERDICT_NAME")
	private String resultVerdictName;

	/** @Fields RESULT_MEMO : 检查结果信息 **/
	@Column(name = "RESULT_MEMO")
	private String resultMemo;

	/** @Fields resultIdea : 检查意见 **/
	@Column(name = "RESULT_IDEA")
	private String resultIdea;

	/** @Fields isHasScore : 是否得分 **/
	@Column(name = "IS_HAS_SCORE")
	private Integer isHasScore;

	/** @Fields resultScore : 检查结果得分 **/
	@Column(name = "RESULT_SCORE")
	private Integer resultScore;

	/** @Fields attachmentCode : 附件组号 **/
	@Column(name = "ATTACHMENT_CODE")
	private String attachmentCode;

	/** @Fields remark : 备注 **/
	@Column(name = "REMARK")
	private String remark;

	/** @Fields TASK_ID : 任务Id **/
	@Column(name = "TASK_ID")
	private String taskId;

	/** @Fields taskName : 任务名称 **/
	@Column(name = "TASK_NAME")
	private String taskName;

	/** @Fields unitTaskId : 单位任务Id **/
	@Column(name = "UNIT_TASK_ID")
	private String unitTaskId;

	/** @Fields entId : 企业Id **/
	@Column(name = "ENT_ID")
	private String entId;

	/** @Fields entCode : 企业编号 **/
	@Column(name = "ENT_CODE")
	private String entCode;

	/** @Fields entName : 企业名称 **/
	@Column(name = "ENT_NAME")
	private String entName;

	/** @Fields parentEntCode : 隶属企业编号 **/
	@Column(name = "PARENT_ENT_CODE")
	private String parentEntCode;

	/** @Fields parentNntName : 隶属企业名称 **/
	@Column(name = "PARENT_ENT_NAME")
	private String parentNntName;

	/** @Fields orgCode : 组织机构代码 CA03 **/
	@Column(name = "ORG_CODE")
	private String orgCode;

	/** @Fields bizLicNo : 营业执照注册号 **/
	@Column(name = "BIZ_LIC_NO")
	private String bizLicNo;

	/** @Fields taxRegNo : 纳税人识别号 **/
	@Column(name = "TAX_REG_NO")
	private String taxRegNo;

	/** @Fields legalRepRegNo : 法人登记证号 **/
	@Column(name = "LEGAL_REP_REG_NO")
	private String legalRepRegNo;

	/** @Fields uniteCreditNo : 统一社会信用代码 **/
	@Column(name = "UNITE_CREDIT_NO")
	private String uniteCreditNo;

	/** @Fields corpRegNo : 社团登记证号 **/
	@Column(name = "CORP_REG_NO")
	private String corpRegNo;

	/** @Fields entPropertyId : 经济性质编号 CA06 **/
	@Column(name = "ENT_PROPERTY_ID")
	private String entPropertyId;

	/** @Fields entPropertyName : 经济性质名称 **/
	@Column(name = "ENT_PROPERTY_NAME")
	private String entPropertyName;

	/** @Fields accountTypeId : 企业核算形式编号 CA07 **/
	@Column(name = "ACCOUNT_TYPE_ID")
	private String accountTypeId;

	/** @Fields accountTypeName : 企业核算形式名称 **/
	@Column(name = "ACCOUNT_TYPE_NAME")
	private String accountTypeName;

	/** @Fields regAddr : 企业注册地址 **/
	@Column(name = "REG_ADDR")
	private String regAddr;

	/** @Fields regAddrPostalCode : 企业注册地址邮编 **/
	@Column(name = "REG_ADDR_POSTAL_CODE")
	private String regAddrPostalCode;

	/** @Fields entLegalRepId : 企业法定代表人Id **/
	@Column(name = "ENT_LEGAL_REP_ID")
	private String entLegalRepId;

	/** @Fields ent_legal_rep : 企业法定代表人 **/
	@Column(name = "ENT_LEGAL_REP")
	private String entLegalRep;

	/** @Fields ent_principal_id : 企业负责人Id **/
	@Column(name = "ENT_PRINCIPAL_ID")
	private String entPrincipalId;

	/** @Fields entPrincipal : 企业负责人 **/
	@Column(name = "ENT_PRINCIPAL")
	private String entPrincipal;

	/** @Fields entLinkmanId : 企业联系人Id **/
	@Column(name = "ENT_LINKMAN_ID")
	private String entLinkmanId;

	/** @Fields entLinkman : 企业联系人 **/
	@Column(name = "ENT_LINKMAN")
	private String entLinkman;

	/** @Fields entTel : 企业电话 **/
	@Column(name = "ENT_TEL")
	private String entTel;

	/** @Fields entFax : 企业传真 **/
	@Column(name = "ENT_FAX")
	private String entFax;

	/** @Fields entEmail : 企业电子邮箱地址 **/
	@Column(name = "ENT_EMAIL")
	private String entEmail;

	/** @Fields estDate : 企业成立时间 **/
	@Column(name = "EST_DATE")
	private Date estDate;

	/** @Fields regCap : 企业注册资本 **/
	@Column(name = "REG_CAP")
	private Double regCap;

	/** @Fields unitId : 监管单位编号 **/
	@Column(name = "UNIT_ID")
	private String unitId;

	/** @Fields unitName : 监管单位名称 **/
	@Column(name = "UNIT_NAME")
	private String unitName;

	/** @Fields areaCode : 地区街道编号 CA09 **/
	@Column(name = "AREA_CODE")
	private String areaCode;

	/** @Fields areaName : 地区街道 **/
	@Column(name = "AREA_NAME")
	private String areaName;

	/** @Fields areaTypeId : 区域类型编号（1 区内、2 区外、3 海岛） **/
	@Column(name = "AREA_TYPE_ID")
	private String areaTypeId;

	/** @Fields areaTypeName : 区域类型名称 **/
	@Column(name = "AREA_TYPE_NAME")
	private String areaTypeName;

	/** @Fields longitude : 企业地理位置经度 **/
	@Column(name = "LONGITUDE")
	private String longitude;

	/** @Fields latitude : 维度 **/
	@Column(name = "LATITUDE")
	private String latitude;

	/** @Fields entState : 企业状态 **/
	@Column(name = "ENT_STATE")
	private Integer entState = 1;

	/** @Fields workScope : 经营范围 **/
	@Column(name = "WORK_SCOPE")
	private String workScope;

	/** @Fields entTypeId : 企业类型Id **/
	@Column(name = "ENT_TYPE_ID")
	private String entTypeId;

	/** @Fields entTypeName : 企业类型名称 **/
	@Column(name = "ENT_TYPE_NAME")
	private String entTypeName;

	/** @Fields entTypeGroupId : 企业类型分组Id **/
	@Column(name = "ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;

	/** @Fields entTypeGroupName : 企业类型分组名称 **/
	@Column(name = "ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;

	/** @Fields isUnlicensed : 是否无证企业 **/
	@Column(name = "IS_UNLICENSED", updatable = false)
	private Integer isUnlicensed;
	@Transient
	private int restDay;

	public int getRestDay() {
		return restDay;
	}

	public void setRestDay(int restDay) {
		this.restDay = restDay;
	}

	public String getCheckId() {
		return checkId;
	}

	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	public String getCheckTypeId() {
		return checkTypeId;
	}

	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	public String getCheckTypeName() {
		return checkTypeName;
	}

	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	public String getCheckLeaderId() {
		return checkLeaderId;
	}

	public void setCheckLeaderId(String checkLeaderId) {
		this.checkLeaderId = checkLeaderId;
	}

	public String getCheckLeaderName() {
		return checkLeaderName;
	}

	public void setCheckLeaderName(String checkLeaderName) {
		this.checkLeaderName = checkLeaderName;
	}

	public String getAccompUsersTel() {
		return accompUsersTel;
	}

	public void setAccompUsersTel(String accompUsersTel) {
		this.accompUsersTel = accompUsersTel;
	}

	public String getCheckUserIds() {
		return checkUserIds;
	}

	public void setCheckUserIds(String checkUserIds) {
		this.checkUserIds = checkUserIds;
	}

	public String getCheckUserNames() {
		return checkUserNames;
	}

	public void setCheckUserNames(String checkUserNames) {
		this.checkUserNames = checkUserNames;
	}

	public Date getCheckBeginDate() {
		return checkBeginDate;
	}

	public void setCheckBeginDate(Date checkBeginDate) {
		this.checkBeginDate = checkBeginDate;
	}

	public Date getCheckEndDate() {
		return checkEndDate;
	}

	public void setCheckEndDate(Date checkEndDate) {
		this.checkEndDate = checkEndDate;
	}

	public String getTableId() {
		return tableId;
	}

	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public String getEntUnitId() {
		return entUnitId;
	}

	public void setEntUnitId(String entUnitId) {
		this.entUnitId = entUnitId;
	}

	public String getEntUnitName() {
		return entUnitName;
	}

	public void setEntUnitName(String entUnitName) {
		this.entUnitName = entUnitName;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUpdateUserName() {
		return updateUserName;
	}

	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getIsArchived() {
		return isArchived;
	}

	public void setIsArchived(Integer isArchived) {
		this.isArchived = isArchived;
	}

	public Integer getIsTemp() {
		return isTemp;
	}

	public void setIsTemp(Integer isTemp) {
		this.isTemp = isTemp;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getFlowKey() {
		return flowKey;
	}

	public void setFlowKey(String flowKey) {
		this.flowKey = flowKey;
	}

	public Integer getResultVerdictId() {
		return resultVerdictId;
	}

	public void setResultVerdictId(Integer resultVerdictId) {
		this.resultVerdictId = resultVerdictId;
	}

	public String getResultVerdictName() {
		return resultVerdictName;
	}

	public void setResultVerdictName(String resultVerdictName) {
		this.resultVerdictName = resultVerdictName;
	}

	public String getResultMemo() {
		return resultMemo;
	}

	public void setResultMemo(String resultMemo) {
		this.resultMemo = resultMemo;
	}

	public String getResultIdea() {
		return resultIdea;
	}

	public void setResultIdea(String resultIdea) {
		this.resultIdea = resultIdea;
	}

	public Integer getIsHasScore() {
		return isHasScore;
	}

	public void setIsHasScore(Integer isHasScore) {
		this.isHasScore = isHasScore;
	}

	public Integer getResultScore() {
		return resultScore;
	}

	public void setResultScore(Integer resultScore) {
		this.resultScore = resultScore;
	}

	public String getAttachmentCode() {
		return attachmentCode;
	}

	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getUnitTaskId() {
		return unitTaskId;
	}

	public void setUnitTaskId(String unitTaskId) {
		this.unitTaskId = unitTaskId;
	}

	public String getEntId() {
		return entId;
	}

	public void setEntId(String entId) {
		this.entId = entId;
	}

	public String getEntCode() {
		return entCode;
	}

	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getParentEntCode() {
		return parentEntCode;
	}

	public void setParentEntCode(String parentEntCode) {
		this.parentEntCode = parentEntCode;
	}

	public String getParentNntName() {
		return parentNntName;
	}

	public void setParentNntName(String parentNntName) {
		this.parentNntName = parentNntName;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getBizLicNo() {
		return bizLicNo;
	}

	public void setBizLicNo(String bizLicNo) {
		this.bizLicNo = bizLicNo;
	}

	public String getTaxRegNo() {
		return taxRegNo;
	}

	public void setTaxRegNo(String taxRegNo) {
		this.taxRegNo = taxRegNo;
	}

	public String getLegalRepRegNo() {
		return legalRepRegNo;
	}

	public void setLegalRepRegNo(String legalRepRegNo) {
		this.legalRepRegNo = legalRepRegNo;
	}

	public String getUniteCreditNo() {
		return uniteCreditNo;
	}

	public void setUniteCreditNo(String uniteCreditNo) {
		this.uniteCreditNo = uniteCreditNo;
	}

	public String getCorpRegNo() {
		return corpRegNo;
	}

	public void setCorpRegNo(String corpRegNo) {
		this.corpRegNo = corpRegNo;
	}

	public String getEntPropertyId() {
		return entPropertyId;
	}

	public void setEntPropertyId(String entPropertyId) {
		this.entPropertyId = entPropertyId;
	}

	public String getEntPropertyName() {
		return entPropertyName;
	}

	public void setEntPropertyName(String entPropertyName) {
		this.entPropertyName = entPropertyName;
	}

	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public String getAccountTypeName() {
		return accountTypeName;
	}

	public void setAccountTypeName(String accountTypeName) {
		this.accountTypeName = accountTypeName;
	}

	public String getRegAddr() {
		return regAddr;
	}

	public void setRegAddr(String regAddr) {
		this.regAddr = regAddr;
	}

	public String getRegAddrPostalCode() {
		return regAddrPostalCode;
	}

	public void setRegAddrPostalCode(String regAddrPostalCode) {
		this.regAddrPostalCode = regAddrPostalCode;
	}

	public String getEntLegalRepId() {
		return entLegalRepId;
	}

	public void setEntLegalRepId(String entLegalRepId) {
		this.entLegalRepId = entLegalRepId;
	}

	public String getEntLegalRep() {
		return entLegalRep;
	}

	public void setEntLegalRep(String entLegalRep) {
		this.entLegalRep = entLegalRep;
	}

	public String getEntPrincipalId() {
		return entPrincipalId;
	}

	public void setEntPrincipalId(String entPrincipalId) {
		this.entPrincipalId = entPrincipalId;
	}

	public String getEntPrincipal() {
		return entPrincipal;
	}

	public void setEntPrincipal(String entPrincipal) {
		this.entPrincipal = entPrincipal;
	}

	public String getEntLinkmanId() {
		return entLinkmanId;
	}

	public void setEntLinkmanId(String entLinkmanId) {
		this.entLinkmanId = entLinkmanId;
	}

	public String getEntLinkman() {
		return entLinkman;
	}

	public void setEntLinkman(String entLinkman) {
		this.entLinkman = entLinkman;
	}

	public String getEntTel() {
		return entTel;
	}

	public void setEntTel(String entTel) {
		this.entTel = entTel;
	}

	public String getEntFax() {
		return entFax;
	}

	public void setEntFax(String entFax) {
		this.entFax = entFax;
	}

	public String getEntEmail() {
		return entEmail;
	}

	public void setEntEmail(String entEmail) {
		this.entEmail = entEmail;
	}

	public Date getEstDate() {
		return estDate;
	}

	public void setEstDate(Date estDate) {
		this.estDate = estDate;
	}

	public Double getRegCap() {
		return regCap;
	}

	public void setRegCap(Double regCap) {
		this.regCap = regCap;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getAreaTypeId() {
		return areaTypeId;
	}

	public void setAreaTypeId(String areaTypeId) {
		this.areaTypeId = areaTypeId;
	}

	public String getAreaTypeName() {
		return areaTypeName;
	}

	public void setAreaTypeName(String areaTypeName) {
		this.areaTypeName = areaTypeName;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public Integer getEntState() {
		return entState;
	}

	public void setEntState(Integer entState) {
		this.entState = entState;
	}

	public String getWorkScope() {
		return workScope;
	}

	public void setWorkScope(String workScope) {
		this.workScope = workScope;
	}

	public String getEntTypeId() {
		return entTypeId;
	}

	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	public String getEntTypeName() {
		return entTypeName;
	}

	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}

	public Integer getIsUnlicensed() {
		return isUnlicensed;
	}

	public void setIsUnlicensed(Integer isUnlicensed) {
		this.isUnlicensed = isUnlicensed;
	}
	
	
}
