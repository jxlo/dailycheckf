/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:AbstractTable.java
 * @author:zhangzt
 * @time:2015年10月10日 下午8:01:27
 */

package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import java.util.List;

/**
 * @author:zhangzt
 *
 */
public class AbstractTable extends AbstractTemplate {
	

	/**
	 * 检查表信息实体
	 */
	private TableInfo tableInfo;
	
	/**
	 * 检查结果记录
	 */
	private List<TableCheckResult> tableCheckResultInfoList;
	
	
	/**
	 * @return
	 */
	public TableInfo getTableInfo() {
		return tableInfo;
	}

	/**
	 * @param tableInfo
	 */
	public void setTableInfo(TableInfo tableInfo) {
		this.tableInfo = tableInfo;
	}

	/**
	 * @return
	 */
	public List<TableCheckResult> getTableCheckResultInfoList() {
		return tableCheckResultInfoList;
	}

	/**
	 * @param tableCheckResultInfoList
	 */
	public void setTableCheckResultInfoList(List<TableCheckResult> tableCheckResultInfoList) {
		this.tableCheckResultInfoList = tableCheckResultInfoList;
	}

	
}
