/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:DcSysCheckType.java
 * @author:xh
 * @time:2015-10-10 下午2:53:39
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.param;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author xh
 */
@Entity
@Table(name="DC_SYS_CHECK_TYPE")
public class CheckTypeInfo {
	/**ID*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**检查类型ID*/
	@Column(name ="CHECK_TYPE_ID")
	private String checkTypeId;
	
	/**检查类型名称*/
	@Column(name ="CHECK_TYPE_NAME")
	private String checkTypeName;
	
	/**备注*/
	@Column(name ="REMARK")
	private String remark;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCheckTypeId() {
		return checkTypeId;
	}

	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	public String getCheckTypeName() {
		return checkTypeName;
	}

	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
