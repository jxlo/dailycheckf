package com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="DC_CREDIT_HFOOD_PROD_CHECK")
public class CreditHfoodProdCheckInfo implements IBusinessObject{

	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 主键Id **/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id; 
	
	/** 年度信用评级ID **/
	@Column(name="CREDIT_ID")
	private String creditId;

	/** 检查时间自**/
	@Column(name="CHECK_DATE_FROM")
	private Date checkDateFrom;

	/** 检查时间至**/
	@Column(name="CHECK_DATE_TO")
	private String checkDateTo;

	/** 监管方式**/
	@Column(name="CHECK_METHOD")
	private String checkMethod;

	/** 企业违法违规情况**/
	@Column(name="UNLAWFUL_DESC")
	private String unlawfulDesc;

	/** 检查结论Id**/
	@Column(name="CHECK_RESULT_ID")
	private String checkResultId;

	/** 检查结论**/
	@Column(name="CHECK_RESULT_NAME")
	private String checkResultName;

	/** 整改通知下达时间**/
	@Column(name="REVIEW_NOTICE_TIME")
	private Date reviewNoticeTime;
	
	/**GMP检查结论**/
	@Column(name="GMP_CHECK_RESULT")
	private String gmpCheckResult;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreditId() {
		return creditId;
	}

	public void setCreditId(String creditId) {
		this.creditId = creditId;
	}

	public Date getCheckDateFrom() {
		return checkDateFrom;
	}

	public void setCheckDateFrom(Date checkDateFrom) {
		this.checkDateFrom = checkDateFrom;
	}

	public String getCheckDateTo() {
		return checkDateTo;
	}

	public void setCheckDateTo(String checkDateTo) {
		this.checkDateTo = checkDateTo;
	}

	public String getCheckMethod() {
		return checkMethod;
	}

	public void setCheckMethod(String checkMethod) {
		this.checkMethod = checkMethod;
	}

	public String getUnlawfulDesc() {
		return unlawfulDesc;
	}

	public void setUnlawfulDesc(String unlawfulDesc) {
		this.unlawfulDesc = unlawfulDesc;
	}

	public String getCheckResultId() {
		return checkResultId;
	}

	public void setCheckResultId(String checkResultId) {
		this.checkResultId = checkResultId;
	}

	public String getCheckResultName() {
		return checkResultName;
	}

	public void setCheckResultName(String checkResultName) {
		this.checkResultName = checkResultName;
	}

	public Date getReviewNoticeTime() {
		return reviewNoticeTime;
	}

	public void setReviewNoticeTime(Date reviewNoticeTime) {
		this.reviewNoticeTime = reviewNoticeTime;
	}

	public String getGmpCheckResult() {
		return gmpCheckResult;
	}

	public void setGmpCheckResult(String gmpCheckResult) {
		this.gmpCheckResult = gmpCheckResult;
	}
}
