/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableOption.java
 * @author:fanghailong
 * @time:2015-10-12 上午11:25:18
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author:fanghailong 
 * 检查表选项
 */
@Entity
@Table(name="DC_TABLE_OPTION")
public class TableOptionInfo implements IBusinessObject {
	
	/**选项Id */
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="OPTION_ID")
	private String optionId;
	
	/**选项名称 */
	@Column(name="OPTION_NAME")
	private String optionName;
	
	/**检查表id */
	@Column(name="TABLE_ID")
	private String tableId;

	/**
	 * @Description:获取选项Id 
	 * @return:optionId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:27:52
	 */
	public String getOptionId() {
		return optionId;
	}

	/**
	 * @Description:设置选项Id 
	 * @param：optionId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:27:52
	 */
	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

	/**
	 * @Description:获取选项名称 
	 * @return:optionName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:27:52
	 */
	public String getOptionName() {
		return optionName;
	}

	/**
	 * @Description:设置选项名称 
	 * @param：optionName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:27:52
	 */
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}

	/**
	 * @Description:获取检查表id
	 * @return:tableId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:27:52
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * @Description:设置检查表id
	 * @param：tableId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:27:52
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}
	
	
}
