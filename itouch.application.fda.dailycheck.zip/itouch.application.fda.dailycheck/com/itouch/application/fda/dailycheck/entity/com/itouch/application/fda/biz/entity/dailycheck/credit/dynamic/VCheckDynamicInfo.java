/**  
 * @Description: TODO
 * @Title: VCheckDynamicInfo.java 
 * @Package: com.itouch.application.fda.biz.entity.dailycheck.credit.food.catering.dynamic 
 * @author: wangk
 * @date 2016-2-24 下午4:22:03 
 */
package com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: VCheckDynamicInfo
 * @author wangk
 * @date 2016-2-24 下午4:22:03
 */
@Entity
@Table(name = "V_DC_CHECK_DYNAMIC")
public class VCheckDynamicInfo implements IBusinessObject {

	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 动态信用评级主键Id **/
	@Id
	@Column(name = "Credit_Id")
	private String id;

	/** 等级名称 **/
	@Column(name = "CREDIT_NAME")
	private String creditName;

	/** 评级值 **/
	@Column(name = "CREDIT_VALUE")
	private String creditValue;

	/** 评定分数 **/
	@Column(name = "CREDIT_SCORE")
	private String creditScore;

	/** 评定年份 **/
	@Column(name = "CREDIT_YEAR")
	private Integer creditYear;

	/** 评定人Id **/
	@Column(name = "CREDIT_USER_ID")
	private String creditUserId;

	/** 评定人 **/
	@Column(name = "CREDIT_USER_NAME")
	private String creditUserName;

	/** 评定时间 **/
	@Column(name = "CREDIT_TIME")
	private Date creditTime;

	/** 检查类别Id **/
	@Column(name = "CHECK_TYPE_ID")
	private String checkTypeId;

	/** 检查类别名称 **/
	@Column(name = "CHECK_TYPE_NAME")
	private String checkTypeName;

	/** 检查人Ids **/
	@Column(name = "CHECK_USER_IDS")
	private String checkUserIds;

	/** 检查人姓名 **/
	@Column(name = "CHECK_USER_NAMES")
	private String checkUserNames;

	/** 检查开始日期 **/
	@Column(name = "CHECK_BEGIN_DATE")
	private Date checkBeginDate;

	/** 检查结束日期 **/
	@Column(name = "CHECK_END_DATE")
	private Date checkEndDate;

	/** 表Id **/
	@Column(name = "TABLE_ID")
	private String tableId;

	/** 检查结论Id **/
	@Column(name = "RESULT_VERDICT_ID")
	private Integer resultVerdictId;

	/** 检查结论 **/
	@Column(name = "RESULT_VERDICT_NAME")
	private String resultVerdictName;

	/** 企业编号 **/
	@Column(name = "ENT_CODE")
	private String entCode;

	/** 企业名称 **/
	@Column(name = "ENT_NAME")
	private String entName;

	/** 企业类型Id **/
	@Column(name = "ENT_TYPE_ID")
	private String entTypeId;

	/** 企业类型名称 **/
	@Column(name = "ENT_TYPE_NAME")
	private String entTypeName;

	/** 企业类型分组Id **/
	@Column(name = "ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;

	/** 企业注册地址 **/
	@Column(name = "REG_ADDR")
	private String regAddr;

	/** 企业负责人Id **/
	@Column(name = "ENT_PRINCIPAL_ID")
	private String entPrincipalId;

	/** 企业负责人 **/
	@Column(name = "ENT_PRINCIPAL")
	private String entPrincipal;

	/** 企业电话 **/
	@Column(name = "ENT_TEL")
	private String entTel;

	/** 监管单位编号 **/
	@Column(name = "UNIT_ID")
	private String unitId;

	/** 监管单位名称 **/
	@Column(name = "UNIT_NAME")
	private String unitName;

	/**
	 * @Description: 获取 动态信用评级主键Id
	 * @return: id
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getId() {
		return id;
	}

	/**
	 * @Description: 设置 动态信用评级主键Id
	 * @param: id
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 等级名称
	 * @return: creditName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCreditName() {
		return creditName;
	}

	/**
	 * @Description: 设置 等级名称
	 * @param: creditName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}

	/**
	 * @Description: 获取 评级值
	 * @return: creditValue
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCreditValue() {
		return creditValue;
	}

	/**
	 * @Description: 设置 评级值
	 * @param: creditValue
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCreditValue(String creditValue) {
		this.creditValue = creditValue;
	}

	/**
	 * @Description: 获取 评定年份
	 * @return: creditYear
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public Integer getCreditYear() {
		return creditYear;
	}

	/**
	 * @Description: 设置 评定年份
	 * @param: creditYear
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCreditYear(Integer creditYear) {
		this.creditYear = creditYear;
	}

	/**
	 * @Description: 获取 评定人Id
	 * @return: creditUserId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCreditUserId() {
		return creditUserId;
	}

	/**
	 * @Description: 设置 评定人Id
	 * @param: creditUserId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCreditUserId(String creditUserId) {
		this.creditUserId = creditUserId;
	}

	/**
	 * @Description: 获取 评定人
	 * @return: creditUserName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCreditUserName() {
		return creditUserName;
	}

	/**
	 * @Description: 设置 评定人
	 * @param: creditUserName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCreditUserName(String creditUserName) {
		this.creditUserName = creditUserName;
	}

	/**
	 * @Description: 获取 评定时间
	 * @return: creditTime
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public Date getCreditTime() {
		return creditTime;
	}

	/**
	 * @Description: 设置 评定时间
	 * @param: creditTime
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCreditTime(Date creditTime) {
		this.creditTime = creditTime;
	}

	/**
	 * @Description: 获取 检查类别Id
	 * @return: checkTypeId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCheckTypeId() {
		return checkTypeId;
	}

	/**
	 * @Description: 设置 检查类别Id
	 * @param: checkTypeId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	/**
	 * @Description: 获取 检查类别名称
	 * @return: checkTypeName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCheckTypeName() {
		return checkTypeName;
	}

	/**
	 * @Description: 设置 检查类别名称
	 * @param: checkTypeName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	/**
	 * @Description: 获取 检查人Ids
	 * @return: checkUserIds
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCheckUserIds() {
		return checkUserIds;
	}

	/**
	 * @Description: 设置 检查人Ids
	 * @param: checkUserIds
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCheckUserIds(String checkUserIds) {
		this.checkUserIds = checkUserIds;
	}

	/**
	 * @Description: 获取 检查人姓名
	 * @return: checkUserNames
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getCheckUserNames() {
		return checkUserNames;
	}

	/**
	 * @Description: 设置 检查人姓名
	 * @param: checkUserNames
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCheckUserNames(String checkUserNames) {
		this.checkUserNames = checkUserNames;
	}

	/**
	 * @Description: 获取 检查开始日期
	 * @return: checkBeginDate
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public Date getCheckBeginDate() {
		return checkBeginDate;
	}

	/**
	 * @Description: 设置 检查开始日期
	 * @param: checkBeginDate
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCheckBeginDate(Date checkBeginDate) {
		this.checkBeginDate = checkBeginDate;
	}

	/**
	 * @Description: 获取 检查结束日期
	 * @return: checkEndDate
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public Date getCheckEndDate() {
		return checkEndDate;
	}

	/**
	 * @Description: 设置 检查结束日期
	 * @param: checkEndDate
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setCheckEndDate(Date checkEndDate) {
		this.checkEndDate = checkEndDate;
	}

	/**
	 * @Description: 获取 表Id
	 * @return: tableId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * @Description: 设置 表Id
	 * @param: tableId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * @Description: 获取 检查结论Id
	 * @return: resultVerdictId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public Integer getResultVerdictId() {
		return resultVerdictId;
	}

	/**
	 * @Description: 设置 检查结论Id
	 * @param: resultVerdictId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setResultVerdictId(Integer resultVerdictId) {
		this.resultVerdictId = resultVerdictId;
	}

	/**
	 * @Description: 获取 检查结论
	 * @return: resultVerdictName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getResultVerdictName() {
		return resultVerdictName;
	}

	/**
	 * @Description: 设置 检查结论
	 * @param: resultVerdictName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setResultVerdictName(String resultVerdictName) {
		this.resultVerdictName = resultVerdictName;
	}

	/**
	 * @Description: 获取 企业名称
	 * @return: entName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getEntName() {
		return entName;
	}

	/**
	 * @Description: 设置 企业名称
	 * @param: entName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}

	/**
	 * @Description: 获取 企业类型Id
	 * @return: entTypeId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**
	 * @Description: 设置 企业类型Id
	 * @param: entTypeId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 企业类型名称
	 * @return: entTypeName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**
	 * @Description: 设置 企业类型名称
	 * @param: entTypeName
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description: 获取 企业类型分组Id
	 * @return: entTypeGroupId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**
	 * @Description: 设置 企业类型分组Id
	 * @param: entTypeGroupId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	/**
	 * @Description: 获取 企业注册地址
	 * @return: regAddr
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getRegAddr() {
		return regAddr;
	}

	/**
	 * @Description: 设置 企业注册地址
	 * @param: regAddr
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setRegAddr(String regAddr) {
		this.regAddr = regAddr;
	}

	/**
	 * @Description: 获取 企业负责人Id
	 * @return: entPrincipalId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getEntPrincipalId() {
		return entPrincipalId;
	}

	/**
	 * @Description: 设置 企业负责人Id
	 * @param: entPrincipalId
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setEntPrincipalId(String entPrincipalId) {
		this.entPrincipalId = entPrincipalId;
	}

	/**
	 * @Description: 获取 企业负责人
	 * @return: entPrincipal
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getEntPrincipal() {
		return entPrincipal;
	}

	/**
	 * @Description: 设置 企业负责人
	 * @param: entPrincipal
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setEntPrincipal(String entPrincipal) {
		this.entPrincipal = entPrincipal;
	}

	/**
	 * @Description: 获取 企业电话
	 * @return: entTel
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public String getEntTel() {
		return entTel;
	}

	/**
	 * @Description: 设置 企业电话
	 * @param: entTel
	 * @author wangk
	 * @date 2016-2-24 下午4:36:28
	 */
	public void setEntTel(String entTel) {
		this.entTel = entTel;
	}

	/**
	 * @Description: 获取 监管单位编号
	 * @return: unitId
	 * @author wangk
	 * @date 2016-2-25 上午10:03:11
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description: 设置 监管单位编号
	 * @param: unitId
	 * @author wangk
	 * @date 2016-2-25 上午10:03:11
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description: 获取 监管单位名称
	 * @return: unitName
	 * @author wangk
	 * @date 2016-2-25 上午10:03:11
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description: 设置 监管单位名称
	 * @param: unitName
	 * @author wangk
	 * @date 2016-2-25 上午10:03:11
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description: 获取 企业编号
	 * @return: entCode
	 * @author wangk
	 * @date 2016-3-2 上午10:00:20
	 */
	public String getEntCode() {
		return entCode;
	}

	/**
	 * @Description: 设置 企业编号
	 * @param: entCode
	 * @author wangk
	 * @date 2016-3-2 上午10:00:20
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	/**
	 * @Description: 获取 评定分数
	 * @return: creditScore
	 * @author: wangk
	 * @date: 2016-3-3 下午5:05:18
	 */
	public String getCreditScore() {
		return creditScore;
	}

	/**
	 * @Description: 设置 评定分数
	 * @param: creditScore
	 * @author: wangk
	 * @date: 2016-3-3 下午5:05:18
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}
}
