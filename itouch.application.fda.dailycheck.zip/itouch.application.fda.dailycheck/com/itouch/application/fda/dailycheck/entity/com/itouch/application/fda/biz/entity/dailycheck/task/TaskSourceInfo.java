/**     
  * @Title: TaskSourceInfo.java   
  * @Package com.itouch.application.fda.biz.entity.dailycheck.task   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-12 下午4:04:51     
  */ 
package com.itouch.application.fda.biz.entity.dailycheck.task;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

/**   
 * @ClassName: TaskSourceInfo   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-12 下午4:04:51      
 */
@Entity
@Table(name="DC_SYS_TASK_SOURCE")
public class TaskSourceInfo implements IBusinessObject{
	
	/** @Fields id : 主键Id **/ 
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="ID")
	private String id;
	
	/** @Fields name : 来源名称 **/
	@Column(name="NAME")
	private String name;
	
	/** @Fields unitId : 单位Id **/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** @Fields unitName : 单位名称 **/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** @Fields orderNumber : 排序号 **/
	@Column(name="ORDER_NUMBER")
	private String orderNumber;
	
	/** @Fields remark : 备注 **/
	@Column(name="REMARK")
	private String remark;

	@Transient
	private String orderNumFlag;
	
	
	
	public String getOrderNumFlag() {
		return orderNumFlag;
	}

	public void setOrderNumFlag(String orderNumFlag) {
		this.orderNumFlag = orderNumFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
