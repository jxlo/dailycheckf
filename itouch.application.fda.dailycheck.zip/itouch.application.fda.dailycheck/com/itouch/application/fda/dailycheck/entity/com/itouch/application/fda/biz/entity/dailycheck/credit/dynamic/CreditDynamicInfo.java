/**  
 * @Description: TODO
 * @Title: CreditDynamiclInfo.java 
 * @Package: com.itouch.application.fda.biz.entity.dailycheck.credit.food.catering.dynamic 
 * @author: wangk
 * @date 2016-2-24 下午4:00:08 
 */ 
package com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: CreditDynamiclInfo 
 * @author wangk
 * @date 2016-2-24 下午4:00:08  
 */
@Entity
@Table(name="DC_CREDIT_DYNAMIC")
public class CreditDynamicInfo implements IBusinessObject {
	
	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** 主键Id **/
	@Id
	@Column(name="CREDIT_ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String creditId; 
	
	/** 检查记录Id **/
	@Column(name="CHECK_ID")
	private String checkId;
	
	/** 等级名称 **/
	@Column(name="CREDIT_NAME")
	private String creditName;
	
	/** 评级值 **/
	@Column(name="CREDIT_VALUE")
	private String creditValue;
	
	/** 评定分数 **/
	@Column(name="CREDIT_SCORE")
	private String creditScore;
	
	/** 评定年份 **/
	@Column(name="CREDIT_YEAR")
	private Integer creditYear;
	
	/** 评定人Id **/
	@Column(name="CREDIT_USER_ID")
	private String creditUserId;
	
	/** 评定人 **/
	@Column(name="CREDIT_USER_NAME")
	private String creditUserName;
	
	/** 评定时间 **/
	@Column(name="CREDIT_TIME")
	private Date creditTime;
	

	public String getCreditId() {
		return creditId;
	}

	public void setCreditId(String creditId) {
		this.creditId = creditId;
	}

	/**
	 * @Description: 获取 检查记录Id
	 * @return: checkId
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public String getCheckId() {
		return checkId;
	}

	/**   
	 * @Description: 设置 检查记录Id   
	 * @param: checkId 
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * @Description: 获取 等级名称
	 * @return: creditName
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public String getCreditName() {
		return creditName;
	}

	/**   
	 * @Description: 设置 等级名称   
	 * @param: creditName 
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}

	/**
	 * @Description: 获取 评级值
	 * @return: creditValue
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public String getCreditValue() {
		return creditValue;
	}

	/**   
	 * @Description: 设置 评级值   
	 * @param: creditValue 
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public void setCreditValue(String creditValue) {
		this.creditValue = creditValue;
	}

	/**
	 * @Description: 获取 评定年份
	 * @return: creditYear
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public Integer getCreditYear() {
		return creditYear;
	}

	/**   
	 * @Description: 设置 评定年份   
	 * @param: creditYear 
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public void setCreditYear(Integer creditYear) {
		this.creditYear = creditYear;
	}

	/**
	 * @Description: 获取 评定人Id
	 * @return: creditUserId
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public String getCreditUserId() {
		return creditUserId;
	}

	/**   
	 * @Description: 设置 评定人Id   
	 * @param: creditUserId 
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public void setCreditUserId(String creditUserId) {
		this.creditUserId = creditUserId;
	}

	/**
	 * @Description: 获取 评定人
	 * @return: creditUserName
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public String getCreditUserName() {
		return creditUserName;
	}

	/**   
	 * @Description: 设置 评定人   
	 * @param: creditUserName 
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public void setCreditUserName(String creditUserName) {
		this.creditUserName = creditUserName;
	}

	/**
	 * @Description: 获取 评定时间
	 * @return: creditTime
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public Date getCreditTime() {
		return creditTime;
	}

	/**   
	 * @Description: 设置 评定时间   
	 * @param: creditTime 
	 * @author wangk
	 * @date 2016-2-24 下午4:04:58 
	 */
	public void setCreditTime(Date creditTime) {
		this.creditTime = creditTime;
	}

	/**
	 * @Description: 获取 评定分数
	 * @return: creditScore
	 * @author: wangk
	 * @date: 2016-3-3 下午4:57:46 
	 */
	public String getCreditScore() {
		return creditScore;
	}

	/**   
	 * @Description: 设置 评定分数   
	 * @param: creditScore 
	 * @author: wangk
	 * @date: 2016-3-3 下午4:57:46 
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}
}
