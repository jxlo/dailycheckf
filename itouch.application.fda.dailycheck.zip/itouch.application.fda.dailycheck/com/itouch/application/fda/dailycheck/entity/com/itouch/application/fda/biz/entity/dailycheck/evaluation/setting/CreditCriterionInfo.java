package com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author qiuy
 * 信用评定体系实体
 */
@Entity
@Table(name="DC_CREDIT_CRITERION")
public class CreditCriterionInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	//评定体系编号
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="CRITERION_ID")
	private String criterionId;

	//评定体系名称
	@Column(name="CRITERION_NAME")
	private String criterionName;

	//监管单位编号
	@Column(name="UNIT_ID")
	private String unitId;

	//监管单位名称
	@Column(name="UNIT_NAME")
	private String unitName;
	
	//监管部门编号
	@Column(name="DEPT_ID")
	private String deptId;

	//监管部门名称
	@Column(name="DEPT_NAME")
	private String deptName;

	//是否启用
	@Column(name="IS_ENABLED")
	private Integer isEnabled;

	//排序号
	@Column(name="ORDER_ID")
	private Integer orderId;

	//备注
	@Column(name="REMARK")
	private String remark;

	public String getCriterionId() {
		return this.criterionId;
	}

	public void setCriterionId(String criterionId) {
		this.criterionId = criterionId;
	}

	public String getCriterionName() {
		return this.criterionName;
	}

	public void setCriterionName(String criterionName) {
		this.criterionName = criterionName;
	}

	public String getDeptId() {
		return this.deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return this.deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public Integer getIsEnabled() {
		return this.isEnabled;
	}

	public void setIsEnabled(Integer isEnabled) {
		this.isEnabled = isEnabled;
	}

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getUnitId() {
		return this.unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return this.unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
}
