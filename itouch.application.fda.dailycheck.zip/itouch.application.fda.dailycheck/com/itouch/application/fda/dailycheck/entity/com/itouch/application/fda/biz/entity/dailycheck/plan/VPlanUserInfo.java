/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:VPlanUserInfo.java
 * @author:fanghailong
 * @time:2015-10-28 下午4:50:39
 */
package com.itouch.application.fda.biz.entity.dailycheck.plan;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author:fanghailong 
 */
@Entity
@Table(name="V_DC_PLAN_USER")
public class VPlanUserInfo implements IBusinessObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private String id;
	
	/**计划id*/
	@Column(name="PLAN_ID")
	private String planId;
	
	/**计划类型id*/
	@Column(name="PLAN_TYPE_ID")
	private String planTypeId;
	
	/**计划类型*/
	@Column(name="PLAN_TYPE_NAME")
	private String planTypeName;
	
	/**计划说明*/
	@Column(name="PLAN_NAME")
	private String planName;
	
	/**计划时间自*/
	@Column(name="PLAN_BEGIN_DATE")
	private Date planBeginDate;
	
	/**计划时间至*/
	@Column(name="PLAN_END_DATE")
	private Date planEndDate;
	
	/**计划进度*/
	@Column(name="IS_PLAN_COMPLETED")
	private String isPlanCompleted;
	
	/**是否完成*/
	@Column(name="IS_COMPLETED")
	private Integer isCompleted;
	
	/**用户id*/
	@Column(name="USER_ID")
	private String userId;
	
	/**用户id*/
	@Column(name="USER_NAME")
	private String userName;
	

	/**机构代码*//*
	@Column(name="ORG_ID")
	private String orgId;*/
	

	/** @Fields checkId : 检查Id **/ 
	@Column(name="CHECK_ID")
	private String checkId;
	
	/** @Fields entCode : 企业编号 **/ 
	@Column(name="ENT_CODE")
	private String entCode;
	
	/** @Fields entName : 企业名称 **/ 
	@Column(name="ENT_NAME")
	private String entName;
	
	/** @Fields checkUserNames : 检查人姓名 **/ 
	@Column(name="CHECK_USER_NAMES")
	private String checkUserNames;
	
	/** @Fields checkBeginDate : 检查开始日期 **/ 
	@Column(name="CHECK_BEGIN_DATE")
	private Date checkBeginDate;
	
	/** @Fields checkEndDate : 检查结束日期 **/ 
	@Column(name="CHECK_END_DATE")
	private Date checkEndDate;
	
	/** @Fields resultVerdictName : 检查结论 **/ 
	@Column(name="RESULT_VERDICT_NAME")
	private String resultVerdictName;
	
	/**计划总结*/
	@Column(name="PLAN_SUM")
	private String planSum;
	
	/**备注*/
	@Column(name="REMARK")
	private String remark;
	
	/**企业类型分组id*/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/** @Fields entTypeGroupName : 企业类型分组名称 **/ 
	@Column(name="ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;
	
	/** @Fields entTypeId : 企业类型Id **/ 
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/** @Fields entTypeName : 企业类型名称 **/ 
	@Column(name="ENT_TYPE_NAME")
	private String entTypeName;
	
	/** @Fields unitId : 监管单位编号 **/ 
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** @Fields unitName : 监管单位名称 **/ 
	@Column(name="UNIT_NAME")
	private String unitName;
	
	@Transient
	private int restDay;
		
	/**
	 * @Description:获取{note}
	 * @return:unitId
	 * @author:fanghailong
	 * @time:2015-11-16 下午12:24:21
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitId
	 * @author:fanghailong
	 * @time:2015-11-16 下午12:24:21
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitName
	 * @author:fanghailong
	 * @time:2015-11-16 下午12:24:21
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitName
	 * @author:fanghailong
	 * @time:2015-11-16 下午12:24:21
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description:获取{note}
	 * @return:userName
	 * @author:fanghailong
	 * @time:2015-11-9 上午11:31:21
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @Description:设置{note}
	 * @param：userName
	 * @author:fanghailong
	 * @time:2015-11-9 上午11:31:22
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @Description:获取{note}
	 * @return:entCode
	 * @author:fanghailong
	 * @time:2015-11-6 下午2:58:07
	 */
	public String getEntCode() {
		return entCode;
	}

	/**
	 * @Description:设置{note}
	 * @param：entCode
	 * @author:fanghailong
	 * @time:2015-11-6 下午2:58:07
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	/**
	 * @Description:获取{note}
	 * @return:entTypeGroupId
	 * @author:fanghailong
	 * @time:2015-11-6 下午2:27:33
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTypeGroupId
	 * @author:fanghailong
	 * @time:2015-11-6 下午2:27:33
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}
	
	
	/**
	 * @Description:获取{note}
	 * @return:entTypeGroupName
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:13:36
	 */
	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTypeGroupName
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:13:36
	 */
	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}

	/**
	 * @Description:获取{note}
	 * @return:entTypeId
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:13:36
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTypeId
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:13:36
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description:获取{note}
	 * @return:entTypeName
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:13:36
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTypeName
	 * @author:fanghailong
	 * @time:2015-11-26 下午3:13:36
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description:获取{note}
	 * @return:planSum
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:36:45
	 */
	public String getPlanSum() {
		return planSum;
	}

	/**
	 * @Description:设置{note}
	 * @param：planSum
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:36:45
	 */
	public void setPlanSum(String planSum) {
		this.planSum = planSum;
	}

	/**
	 * @Description:获取{note}
	 * @return:remark
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:36:45
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description:设置{note}
	 * @param：remark
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:36:45
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkUserNames
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public String getCheckUserNames() {
		return checkUserNames;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkUserNames
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public void setCheckUserNames(String checkUserNames) {
		this.checkUserNames = checkUserNames;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkBeginDate
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public Date getCheckBeginDate() {
		return checkBeginDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkBeginDate
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public void setCheckBeginDate(Date checkBeginDate) {
		this.checkBeginDate = checkBeginDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkEndDate
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public Date getCheckEndDate() {
		return checkEndDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkEndDate
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public void setCheckEndDate(Date checkEndDate) {
		this.checkEndDate = checkEndDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:resultVerdictName
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public String getResultVerdictName() {
		return resultVerdictName;
	}

	/**
	 * @Description:设置{note}
	 * @param：resultVerdictName
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:26:05
	 */
	public void setResultVerdictName(String resultVerdictName) {
		this.resultVerdictName = resultVerdictName;
	}

	/**
	 * @Description:获取{note}
	 * @return:restDay
	 * @author:fanghailong
	 * @time:2015-10-28 下午5:23:51
	 */
	public int getRestDay() {
		return restDay;
	}

	/**
	 * @Description:设置{note}
	 * @param：restDay
	 * @author:fanghailong
	 * @time:2015-10-28 下午5:23:51
	 */
	public void setRestDay(int restDay) {
		this.restDay = restDay;
	}

	/**
	 * @Description:获取{note}
	 * @return:id
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getId() {
		return id;
	}

	/**
	 * @Description:设置{note}
	 * @param：id
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description:获取{note}
	 * @return:planId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getPlanId() {
		return planId;
	}

	/**
	 * @Description:设置{note}
	 * @param：planId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}

	/**
	 * @Description:获取{note}
	 * @return:planTypeId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getPlanTypeId() {
		return planTypeId;
	}

	/**
	 * @Description:设置{note}
	 * @param：planTypeId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setPlanTypeId(String planTypeId) {
		this.planTypeId = planTypeId;
	}

	/**
	 * @Description:获取{note}
	 * @return:planTypeName
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getPlanTypeName() {
		return planTypeName;
	}

	/**
	 * @Description:设置{note}
	 * @param：planTypeName
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setPlanTypeName(String planTypeName) {
		this.planTypeName = planTypeName;
	}

	/**
	 * @Description:获取{note}
	 * @return:planName
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getPlanName() {
		return planName;
	}

	/**
	 * @Description:设置{note}
	 * @param：planName
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}

	/**
	 * @Description:获取{note}
	 * @return:planBeginDate
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public Date getPlanBeginDate() {
		return planBeginDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：planBeginDate
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setPlanBeginDate(Date planBeginDate) {
		this.planBeginDate = planBeginDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:planEndDate
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public Date getPlanEndDate() {
		return planEndDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：planEndDate
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setPlanEndDate(Date planEndDate) {
		this.planEndDate = planEndDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:isPlanCompleted
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getIsPlanCompleted() {
		return isPlanCompleted;
	}

	/**
	 * @Description:设置{note}
	 * @param：isPlanCompleted
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setIsPlanCompleted(String isPlanCompleted) {
		this.isPlanCompleted = isPlanCompleted;
	}

	/**
	 * @Description:获取{note}
	 * @return:isCompleted
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public Integer getIsCompleted() {
		return isCompleted;
	}

	/**
	 * @Description:设置{note}
	 * @param：isCompleted
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setIsCompleted(Integer isCompleted) {
		this.isCompleted = isCompleted;
	}

	/**
	 * @Description:获取{note}
	 * @return:userId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @Description:设置{note}
	 * @param：userId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getCheckId() {
		return checkId;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkId
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * @Description:获取{note}
	 * @return:entName
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public String getEntName() {
		return entName;
	}

	/**
	 * @Description:设置{note}
	 * @param：entName
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}
	
	/**
	 * @Description:获取{note}
<<<<<<< .mine
	 * @return:orgId
	 * @author:zsq
	 * @time:2016-12-26 下午14:56:43
	 *//*
	public String getOrgId() {
		return orgId;
	}
	
	*//**
	 * @Description:设置获取{note}
	 * @return:orgId
	 * @author:zsq
	 * @time:2016-12-26 下午14:56:43
	 *//*
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}*/

	/**
	 * @Description:获取{note}
=======
>>>>>>> .r25516
	 * @return:serialVersionUID
	 * @author:fanghailong
	 * @time:2015-10-28 下午4:56:43
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
