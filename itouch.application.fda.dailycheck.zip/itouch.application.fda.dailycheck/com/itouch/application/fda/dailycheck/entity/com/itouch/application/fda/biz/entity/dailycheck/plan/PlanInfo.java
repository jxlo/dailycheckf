/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:PlanInfo.java
 * @author:fanghailong
 * @time:2015-10-20 下午2:52:51
 */
package com.itouch.application.fda.biz.entity.dailycheck.plan;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
/**
 * @author:fanghailong 
 */
@Entity
@Table(name="DC_PLAN")
public class PlanInfo implements IBusinessObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**计划Id*/
	@Id
	@Column(name="PLAN_ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String planId;
	
	/**计划类型id*/
	@Column(name="PLAN_TYPE_ID")
	private String planTypeId;
	
	/**计划类型*/
	@Column(name="PLAN_TYPE_NAME")
	private String planTypeName;
	
	/**计划说明*/
	@Column(name="PLAN_NAME")
	private String planName;
	
	/**计划时间自*/
	@Column(name="PLAN_BEGIN_DATE")
	private Date planBeginDate;
	
	/**计划时间至*/
	@Column(name="PLAN_END_DATE")
	private Date planEndDate;
	
	/**计划制定人id*/
	@Column(name="PLAN_CREATOR_ID")
	private String planCreatorId;
	
	/**计划制定人*/
	@Column(name="PLAN_CREATOR_NAME")
	private String planCreatorName;
	
	/**计划制定时间*/
	@Column(name="PLAN_CREATE_TIME")
	private Date planCreateTime;
	
	/**计划进度*/
	@Column(name="IS_COMPLETED")
	private String isCompleted;
	
	/**附件组号*/
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;
	
	/**计划总结*/
	@Column(name="PLAN_SUM")
	private String planSum;
	
	/**完成时间*/
	@Column(name="COMPLETED_DATE")
	private Date completedDate;
	
	/**备注*/
	@Column(name="REMARK")
	private String remark;
	
	/**剩余天数**/
	@Transient
	private int restDay;			
	
	/**是否该计划下的任务已完成**/
	@Transient
	private String allCompleted;	
	
	@Transient
	private List<PlanUserInfo> planUserInfo;
	
	
	/**
	 * @Description:获取{note}
	 * @return:allCompleted
	 * @author:fanghailong
	 * @time:2015-11-9 下午2:07:04
	 */
	public String getAllCompleted() {
		return allCompleted;
	}

	/**
	 * @Description:设置{note}
	 * @param：allCompleted
	 * @author:fanghailong
	 * @time:2015-11-9 下午2:07:04
	 */
	public void setAllCompleted(String allCompleted) {
		this.allCompleted = allCompleted;
	}

	
	/**
	 * @Description:获取{note}
	 * @return:planUserInfo
	 * @author:fanghailong
	 * @time:2015-10-30 上午10:11:32
	 */
	public List<PlanUserInfo> getPlanUserInfo() {
		return planUserInfo;
	}

	/**
	 * @Description:设置{note}
	 * @param：planUserInfo
	 * @author:fanghailong
	 * @time:2015-10-30 上午10:11:33
	 */
	public void setPlanUserInfo(List<PlanUserInfo> planUserInfo) {
		this.planUserInfo = planUserInfo;
	}

	/**
	 * @Description:获取{note}
	 * @return:serialVersionUID
	 * @author:fanghailong
	 * @time:2015-10-30 上午10:11:33
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @Description:获取{note}
	 * @return:restDay
	 * @author:fanghailong
	 * @time:2015-10-25 下午2:51:30
	 */
	public int getRestDay() {
		return restDay;
	}

	/**
	 * @Description:设置{note}
	 * @param：restDay
	 * @author:fanghailong
	 * @time:2015-10-25 下午2:51:30
	 */
	public void setRestDay(int restDay) {
		this.restDay = restDay;
	}

	/**
	 * @Description:获取{note}
	 * @return:planId
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getPlanId() {
		return planId;
	}

	/**
	 * @Description:设置{note}
	 * @param：planId
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}

	/**
	 * @Description:获取{note}
	 * @return:planTypeId
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getPlanTypeId() {
		return planTypeId;
	}

	/**
	 * @Description:设置{note}
	 * @param：planTypeId
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanTypeId(String planTypeId) {
		this.planTypeId = planTypeId;
	}

	/**
	 * @Description:获取{note}
	 * @return:planTypeName
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getPlanTypeName() {
		return planTypeName;
	}

	/**
	 * @Description:设置{note}
	 * @param：planTypeName
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanTypeName(String planTypeName) {
		this.planTypeName = planTypeName;
	}

	/**
	 * @Description:获取{note}
	 * @return:planName
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getPlanName() {
		return planName;
	}

	/**
	 * @Description:设置{note}
	 * @param：planName
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}

	/**
	 * @Description:获取{note}
	 * @return:planBeginDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public Date getPlanBeginDate() {
		return planBeginDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：planBeginDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanBeginDate(Date planBeginDate) {
		this.planBeginDate = planBeginDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:planEndDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public Date getPlanEndDate() {
		return planEndDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：planEndDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanEndDate(Date planEndDate) {
		this.planEndDate = planEndDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:planCreatorId
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getPlanCreatorId() {
		return planCreatorId;
	}

	/**
	 * @Description:设置{note}
	 * @param：planCreatorId
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanCreatorId(String planCreatorId) {
		this.planCreatorId = planCreatorId;
	}

	/**
	 * @Description:获取{note}
	 * @return:planCreatorName
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getPlanCreatorName() {
		return planCreatorName;
	}

	/**
	 * @Description:设置{note}
	 * @param：planCreatorName
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanCreatorName(String planCreatorName) {
		this.planCreatorName = planCreatorName;
	}

	/**
	 * @Description:获取{note}
	 * @return:planCreateTime
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public Date getPlanCreateTime() {
		return planCreateTime;
	}

	/**
	 * @Description:设置{note}
	 * @param：planCreateTime
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanCreateTime(Date planCreateTime) {
		this.planCreateTime = planCreateTime;
	}

	/**
	 * @Description:获取{note}
	 * @return:isCompleted
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getIsCompleted() {
		return isCompleted;
	}

	/**
	 * @Description:设置{note}
	 * @param：isCompleted
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setIsCompleted(String isCompleted) {
		this.isCompleted = isCompleted;
	}

	/**
	 * @Description:获取{note}
	 * @return:attachmentCode
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**
	 * @Description:设置{note}
	 * @param：attachmentCode
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * @Description:获取{note}
	 * @return:planSum
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getPlanSum() {
		return planSum;
	}

	/**
	 * @Description:设置{note}
	 * @param：planSum
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setPlanSum(String planSum) {
		this.planSum = planSum;
	}

	/**
	 * @Description:获取{note}
	 * @return:completedDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public Date getCompletedDate() {
		return completedDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：completedDate
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:remark
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description:设置{note}
	 * @param：remark
	 * @author:fanghailong
	 * @time:2015-10-20 下午3:04:34
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}
