/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TalkInfo.java
 * @author:fanghailong
 * @time:2015-10-13 下午2:32:27
 */
package com.itouch.application.fda.biz.entity.dailycheck.talk;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author:fanghailong 
 * 企业约谈信息
 */
@Entity
@Table(name="DC_TALK")
public class TalkInfo implements IBusinessObject{
	
	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**约谈Id*/
	@Id
	@Column(name="TALK_ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String talkId;
	
	/**编号(年份-流水号)*/
	@Column(name="SERIAL_CODE")
	private String serialCode;
	
	/**流水号*/
	@Column(name="SERIAL_NUMBER")
	private Integer serialNumber;
	
	/**拟定时间*/
	@Column(name="PRE_TALK_DATE")
	private Date preTalkDate;
	
	/**查询用拟定开始时间 */
	@Transient
	private String preTalkDateBegin;
	/**查询用拟定结束时间 */
	@Transient
	private String preTalkDateEnd;
	
	/**拟定地点*/
	@Column(name="PRE_TALK_ADDR")
	private String preTalkAddr;
	
	/**约谈事由*/
	@Column(name="PRE_TALK_REASON")
	private String preTalkReason;
	
	/**约谈事项*/
	@Column(name="PRE_TALK_Content")
	private String preTalkContent;
	
	/**约谈组织形式*/
	@Column(name="PRE_TALK_FORM")
	private String preTalkForm;
	
	/**企业编号*/
	@Column(name="ENT_CODE")
	private String entCode;
	
	/**企业名称*/
	@Column(name="ENT_NAME")
	private String entName;
	
	/**企业地址*/
	@Column(name="ENT_ADDR")
	private String entAddr;
	
	/**联系人*/
	@Column(name="ENT_LINKMAN")
	private String entLinkman;
	
	/**联系电话*/
	@Column(name="ENT_TEL")
	private String entTel;
	
	/**监管单位编号*/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/**监管单位名称*/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/**部门id*/
	@Column(name="DEPT_ID")
	private String deptId;
	
	/**部门名称*/
	@Column(name="DEPT_NAME")
	private String deptName;
	
	/**申请人id*/
	@Column(name="APPLY_USER_ID")
	private String applyUserId;
	
	/**申请人姓名*/
	@Column(name="APPLY_USER_Name")
	private String applyUserName;
	
	/**申请时间*/
	@Column(name="APPLY_TIME")
	private Date applyTime;
	
	/**流程编号*/
	@Column(name="FLOW_KEY")
	private String flowKey;
	
	/**是否完成*/
	@Column(name="IS_FINISHED")
	private Integer isFinished;
	
	/**审批人id*/
	@Column(name="APPROVE_USER_ID")
	private String approveUserId;
	
	/**审批人*/
	@Column(name="APPROVE_USER_NAME")
	private String approveUserName;
	
	/**审批时间*/
	@Column(name="APPROVE_TIME")
	private Date approveTime;
	
	/**约谈人员*/
	@Column(name="RECORD_UNIT_TALKERS")
	private String recordUnitTalkers;
	
	/**被约谈人员*/
	@Column(name="RECORD_ENT_TALKERS")
	private String recordEntTalkers;
	
	/**记录人*/
	@Column(name="RECORD_USERS")
	private String recordUsers;
	
	/**约谈记录*/
	@Column(name="RECORD_CONTENT")
	private String recordContent;
	
	/**记录时间*/
	@Column(name="RECORD_DATE")
	private Date recordDate;
	
	/**约谈时间*/
	@Column(name="RECORD_TALK_DATE")
	private Date recordTalkDate;
	
	/**约谈地点*/
	@Column(name="RECORD_TALK_ADDR")
	private String recordTalkAddr;
	
	/**状态*/
	@Column(name="STATE")
	private Integer state;
	
	/**备注*/
	@Column(name="REMARK")
	private String remark;
	
	
	/**
	 * @Description:获取{note}
	 * @return:preTalkDateBegin
	 * @author:fanghailong
	 * @time:2015-10-14 下午12:01:31
	 */
	public String getPreTalkDateBegin() {
		return preTalkDateBegin;
	}

	/**
	 * @Description:设置{note}
	 * @param：preTalkDateBegin
	 * @author:fanghailong
	 * @time:2015-10-14 下午12:01:31
	 */
	public void setPreTalkDateBegin(String preTalkDateBegin) {
		this.preTalkDateBegin = preTalkDateBegin;
	}

	/**
	 * @Description:获取{note}
	 * @return:preTalkDateEnd
	 * @author:fanghailong
	 * @time:2015-10-14 下午12:01:31
	 */
	public String getPreTalkDateEnd() {
		return preTalkDateEnd;
	}

	/**
	 * @Description:设置{note}
	 * @param：preTalkDateEnd
	 * @author:fanghailong
	 * @time:2015-10-14 下午12:01:31
	 */
	public void setPreTalkDateEnd(String preTalkDateEnd) {
		this.preTalkDateEnd = preTalkDateEnd;
	}

	/**
	 * @Description:获取{note}
	 * @return:talkId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getTalkId() {
		return talkId;
	}

	/**
	 * @Description:设置{note}
	 * @param：talkId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setTalkId(String talkId) {
		this.talkId = talkId;
	}

	/**
	 * @Description:获取{note}
	 * @return:serialCode
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getSerialCode() {
		return serialCode;
	}

	/**
	 * @Description:设置{note}
	 * @param：serialCode
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setSerialCode(String serialCode) {
		this.serialCode = serialCode;
	}

	/**
	 * @Description:获取{note}
	 * @return:serialNumber
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Integer getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @Description:设置{note}
	 * @param：serialNumber
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setSerialNumber(Integer serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @Description:获取{note}
	 * @return:preTalkDate
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Date getPreTalkDate() {
		return preTalkDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：preTalkDate
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setPreTalkDate(Date preTalkDate) {
		this.preTalkDate = preTalkDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:preTalkAddr
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getPreTalkAddr() {
		return preTalkAddr;
	}

	/**
	 * @Description:设置{note}
	 * @param：preTalkAddr
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setPreTalkAddr(String preTalkAddr) {
		this.preTalkAddr = preTalkAddr;
	}

	/**
	 * @Description:获取{note}
	 * @return:preTalkReason
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getPreTalkReason() {
		return preTalkReason;
	}

	/**
	 * @Description:设置{note}
	 * @param：preTalkReason
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setPreTalkReason(String preTalkReason) {
		this.preTalkReason = preTalkReason;
	}

	/**
	 * @Description:获取{note}
	 * @return:preTalkContent
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getPreTalkContent() {
		return preTalkContent;
	}

	/**
	 * @Description:设置{note}
	 * @param：preTalkContent
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setPreTalkContent(String preTalkContent) {
		this.preTalkContent = preTalkContent;
	}

	/**
	 * @Description:获取{note}
	 * @return:preTalkForm
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getPreTalkForm() {
		return preTalkForm;
	}

	/**
	 * @Description:设置{note}
	 * @param：preTalkForm
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setPreTalkForm(String preTalkForm) {
		this.preTalkForm = preTalkForm;
	}

	/**
	 * @Description:获取{note}
	 * @return:entCode
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getEntCode() {
		return entCode;
	}

	/**
	 * @Description:设置{note}
	 * @param：entCode
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	/**
	 * @Description:获取{note}
	 * @return:entName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getEntName() {
		return entName;
	}

	/**
	 * @Description:设置{note}
	 * @param：entName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}

	/**
	 * @Description:获取{note}
	 * @return:entAddr
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getEntAddr() {
		return entAddr;
	}

	/**
	 * @Description:设置{note}
	 * @param：entAddr
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setEntAddr(String entAddr) {
		this.entAddr = entAddr;
	}

	/**
	 * @Description:获取{note}
	 * @return:entLinkman
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getEntLinkman() {
		return entLinkman;
	}

	/**
	 * @Description:设置{note}
	 * @param：entLinkman
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setEntLinkman(String entLinkman) {
		this.entLinkman = entLinkman;
	}

	/**
	 * @Description:获取{note}
	 * @return:entTel
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getEntTel() {
		return entTel;
	}

	/**
	 * @Description:设置{note}
	 * @param：entTel
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setEntTel(String entTel) {
		this.entTel = entTel;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description:获取{note}
	 * @return:deptId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getDeptId() {
		return deptId;
	}

	/**
	 * @Description:设置{note}
	 * @param：deptId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	/**
	 * @Description:获取{note}
	 * @return:deptName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getDeptName() {
		return deptName;
	}

	/**
	 * @Description:设置{note}
	 * @param：deptName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/**
	 * @Description:获取{note}
	 * @return:applyUserId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getApplyUserId() {
		return applyUserId;
	}

	/**
	 * @Description:设置{note}
	 * @param：applyUserId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setApplyUserId(String applyUserId) {
		this.applyUserId = applyUserId;
	}

	/**
	 * @Description:获取{note}
	 * @return:applyUserName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getApplyUserName() {
		return applyUserName;
	}

	/**
	 * @Description:设置{note}
	 * @param：applyUserName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setApplyUserName(String applyUserName) {
		this.applyUserName = applyUserName;
	}

	/**
	 * @Description:获取{note}
	 * @return:applyTime
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Date getApplyTime() {
		return applyTime;
	}

	/**
	 * @Description:设置{note}
	 * @param：applyTime
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}

	/**
	 * @Description:获取{note}
	 * @return:flowKey
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getFlowKey() {
		return flowKey;
	}

	/**
	 * @Description:设置{note}
	 * @param：flowKey
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setFlowKey(String flowKey) {
		this.flowKey = flowKey;
	}

	/**
	 * @Description:获取{note}
	 * @return:isFinished
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Integer getIsFinished() {
		return isFinished;
	}

	/**
	 * @Description:设置{note}
	 * @param：isFinished
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setIsFinished(Integer isFinished) {
		this.isFinished = isFinished;
	}

	/**
	 * @Description:获取{note}
	 * @return:approveUserId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getApproveUserId() {
		return approveUserId;
	}

	/**
	 * @Description:设置{note}
	 * @param：approveUserId
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setApproveUserId(String approveUserId) {
		this.approveUserId = approveUserId;
	}

	/**
	 * @Description:获取{note}
	 * @return:approveUserName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getApproveUserName() {
		return approveUserName;
	}

	/**
	 * @Description:设置{note}
	 * @param：approveUserName
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setApproveUserName(String approveUserName) {
		this.approveUserName = approveUserName;
	}

	/**
	 * @Description:获取{note}
	 * @return:approveTime
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Date getApproveTime() {
		return approveTime;
	}

	/**
	 * @Description:设置{note}
	 * @param：approveTime
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setApproveTime(Date approveTime) {
		this.approveTime = approveTime;
	}
	
	
	/**
	 * @Description:获取{note}
	 * @return:recordUnitTalkers
	 * @author:fanghailong
	 * @time:2015-10-15 上午11:34:58
	 */
	public String getRecordUnitTalkers() {
		return recordUnitTalkers;
	}

	/**
	 * @Description:设置{note}
	 * @param：recordUnitTalkers
	 * @author:fanghailong
	 * @time:2015-10-15 上午11:34:58
	 */
	public void setRecordUnitTalkers(String recordUnitTalkers) {
		this.recordUnitTalkers = recordUnitTalkers;
	}

	/**
	 * @Description:获取{note}
	 * @return:recordEntTalkers
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getRecordEntTalkers() {
		return recordEntTalkers;
	}

	/**
	 * @Description:设置{note}
	 * @param：recordEntTalkers
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setRecordEntTalkers(String recordEntTalkers) {
		this.recordEntTalkers = recordEntTalkers;
	}

	/**
	 * @Description:获取{note}
	 * @return:recordUsers
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getRecordUsers() {
		return recordUsers;
	}

	/**
	 * @Description:设置{note}
	 * @param：recordUsers
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setRecordUsers(String recordUsers) {
		this.recordUsers = recordUsers;
	}

	/**
	 * @Description:获取{note}
	 * @return:recordContent
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getRecordContent() {
		return recordContent;
	}

	/**
	 * @Description:设置{note}
	 * @param：recordContent
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setRecordContent(String recordContent) {
		this.recordContent = recordContent;
	}

	/**
	 * @Description:获取{note}
	 * @return:recordDate
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Date getRecordDate() {
		return recordDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：recordDate
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setRecordDate(Date recordDate) {
		this.recordDate = recordDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:recordTalkDate
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Date getRecordTalkDate() {
		return recordTalkDate;
	}

	/**
	 * @Description:设置{note}
	 * @param：recordTalkDate
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setRecordTalkDate(Date recordTalkDate) {
		this.recordTalkDate = recordTalkDate;
	}

	/**
	 * @Description:获取{note}
	 * @return:recordTalkAddr
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getRecordTalkAddr() {
		return recordTalkAddr;
	}

	/**
	 * @Description:设置{note}
	 * @param：recordTalkAddr
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setRecordTalkAddr(String recordTalkAddr) {
		this.recordTalkAddr = recordTalkAddr;
	}

	/**
	 * @Description:获取{note}
	 * @return:state
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public Integer getState() {
		return state;
	}

	/**
	 * @Description:设置{note}
	 * @param：state
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setState(Integer state) {
		this.state = state;
	}

	/**
	 * @Description:获取{note}
	 * @return:remark
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description:设置{note}
	 * @param：remark
	 * @author:fanghailong
	 * @time:2015-10-13 下午2:56:43
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}
