package com.itouch.application.fda.biz.entity.dailycheck.report;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description:  食品经营许可（流通）情况统计表
 * @ClassName: RepFoodCirculPermitInfo 
 * @author: wangk
 * @date: 2016-3-24 上午11:17:23  
 */
@Entity
@Table(name="DC_REP_FOOD_CIRCUL_PERMIT")
public class RepFoodCirculPermitInfo implements IBusinessObject {
	
	/**主键Id*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**报表Id*/
	@Column(name="REPORT_ID")
	private String reportId;
	
	/**单位类别Id*/
	@Column(name="TYPE_ID")
	private String typeId;
	
	/**单位类别名称*/
	@Column(name="TYPE_NAME")
	private String typeName;
	
	/** 上期末实有 **/
	@Column(name="LAST_END_HAVE_COUNT")
	private Integer lastEndHaveCount;
	
	/** 本期新增 **/
	@Column(name="CUR_ADD_COUNT")
	private Integer curAddCount;
	
	/** 本期减少 **/
	@Column(name="CUR_REDUCE_COUNT")
	private Integer curReduceCount;
	
	/** 期末实有 **/
	@Column(name="CUR_END_COUNT")
	private Integer curEndCount;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author: wangk
	 * @date: 2016-3-24 上午11:28:34 
	 */
	public String getId() {
		return id;
	}

	/**   
	 * @Description: 设置 主键Id   
	 * @param: id 
	 * @author: wangk
	 * @date: 2016-3-24 上午11:28:34 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 报表Id
	 * @return: reportId
	 * @author: wangk
	 * @date: 2016-3-24 上午11:28:34 
	 */
	public String getReportId() {
		return reportId;
	}

	/**   
	 * @Description: 设置 报表Id   
	 * @param: reportId 
	 * @author: wangk
	 * @date: 2016-3-24 上午11:28:34 
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	/**
	 * @Description: 获取 单位类别Id
	 * @return: typeId
	 * @author: wangk
	 * @date: 2016-3-25 上午10:16:35 
	 */
	public String getTypeId() {
		return typeId;
	}

	/**   
	 * @Description: 设置 单位类别Id   
	 * @param: typeId 
	 * @author: wangk
	 * @date: 2016-3-25 上午10:16:35 
	 */
	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	/**
	 * @Description: 获取 单位类别名称
	 * @return: typeName
	 * @author: wangk
	 * @date: 2016-3-25 上午10:16:35 
	 */
	public String getTypeName() {
		return typeName;
	}

	/**   
	 * @Description: 设置 单位类别名称   
	 * @param: typeName 
	 * @author: wangk
	 * @date: 2016-3-25 上午10:16:35 
	 */
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	
	/**
	 * @Description: 获取 上期末实有
	 * @return: lastEndHaveCount
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public Integer getLastEndHaveCount() {
		return lastEndHaveCount;
	}

	/**   
	 * @Description: 设置 上期末实有   
	 * @param: lastEndHaveCount 
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public void setLastEndHaveCount(Integer lastEndHaveCount) {
		this.lastEndHaveCount = lastEndHaveCount;
	}

	/**
	 * @Description: 获取 本期新增
	 * @return: curAddCount
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public Integer getCurAddCount() {
		return curAddCount;
	}

	/**   
	 * @Description: 设置 本期新增   
	 * @param: curAddCount 
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public void setCurAddCount(Integer curAddCount) {
		this.curAddCount = curAddCount;
	}

	/**
	 * @Description: 获取 本期减少
	 * @return: curReduceCount
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public Integer getCurReduceCount() {
		return curReduceCount;
	}

	/**   
	 * @Description: 设置 本期减少   
	 * @param: curReduceCount 
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public void setCurReduceCount(Integer curReduceCount) {
		this.curReduceCount = curReduceCount;
	}

	/**
	 * @Description: 获取 期末实有
	 * @return: curEndCount
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public Integer getCurEndCount() {
		return curEndCount;
	}

	/**   
	 * @Description: 设置 期末实有   
	 * @param: curEndCount 
	 * @author: wangk
	 * @date: 2016-3-24 下午4:27:29 
	 */
	public void setCurEndCount(Integer curEndCount) {
		this.curEndCount = curEndCount;
	}
}
