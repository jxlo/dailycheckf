/**  
  * @Description: TODO
  * @Title: CreditParamInfo.java 
  * @Package: com.itouch.application.fda.biz.entity.dailycheck.system.param 
  * @author: wangk
  * @date 2016-2-19 下午2:15:48 
  */ 
package com.itouch.application.fda.biz.entity.dailycheck.system.param;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: CreditParamInfo 
 * @author wangk
 * @date 2016-2-19 下午2:15:48  
 */
@Entity
@Table(name="DC_SYS_CREDIT_PARAM")
public class CreditParamInfo implements IBusinessObject{

	/** 主键Id **/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/** 等级名称 **/
	@Column(name="CREDIT_NAME")
	private String creditName;
	
	/** 评级值 **/
	@Column(name="CREDIT_VALUE")
	private String creditValue;
	
	/** 最小分 **/
	@Column(name="MIN_SCORE")
	private String minScore;
	
	/** 最大分 **/
	@Column(name="MAX_SCORE")
	private String maxScore;
	
	/** 企业类型分组Id **/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/** 企业类型分组名称 **/
	@Column(name="ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;
	
	/** 排序号 **/
	@Column(name="ORDER_NUMBER")
	private Integer orderNumber;
	
	/** 检查次数 **/
	@Column(name="CHECK_TIMES")
	private Integer checkTimes;
	
	/** 评级类型Id **/
	@Column(name="CREDIT_TYPE_ID")
	private Integer creditTypeId;
	
	/** 评级类型名称 **/
	@Column(name="CREDIT_TYPE_NAME")
	private String creditTypeName;
	
	/** 备注 **/
	@Column(name="REMARK")
	private String remark;
	
	/** 图标 **/
	@Column(name="ICON")
	private String icon;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public String getId() {
		return id;
	}

	/**   
	 * @Description: 设置 主键Id   
	 * @param: id 
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 等级名称
	 * @return: creditName
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public String getCreditName() {
		return creditName;
	}

	/**   
	 * @Description: 设置 等级名称   
	 * @param: creditName 
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}

	/**
	 * @Description: 获取 评级值
	 * @return: creditValue
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public String getCreditValue() {
		return creditValue;
	}

	/**   
	 * @Description: 设置 评级值   
	 * @param: creditValue 
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public void setCreditValue(String creditValue) {
		this.creditValue = creditValue;
	}

	/**
	 * @Description: 获取 企业类型分组Id
	 * @return: entTypeGroupId
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**   
	 * @Description: 设置 企业类型分组Id   
	 * @param: entTypeGroupId 
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	/**
	 * @Description: 获取 企业类型分组名称
	 * @return: entTypeGroupName
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	/**   
	 * @Description: 设置 企业类型分组名称   
	 * @param: entTypeGroupName 
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}


	/**
	 * @Description: 获取 排序号
	 * @return: orderNumber
	 * @author wangk
	 * @date 2016-2-19 下午5:03:42 
	 */
	public Integer getOrderNumber() {
		return orderNumber;
	}

	/**   
	 * @Description: 设置 排序号   
	 * @param: orderNumber 
	 * @author wangk
	 * @date 2016-2-19 下午5:03:42 
	 */
	public void setOrderNumber(Integer orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * @Description: 获取 检查次数
	 * @return: checkTimes
	 * @author wangk
	 * @date 2016-2-19 下午5:03:42 
	 */
	public Integer getCheckTimes() {
		return checkTimes;
	}

	/**   
	 * @Description: 设置 检查次数   
	 * @param: checkTimes 
	 * @author wangk
	 * @date 2016-2-19 下午5:03:42 
	 */
	public void setCheckTimes(Integer checkTimes) {
		this.checkTimes = checkTimes;
	}

	/**
	 * @Description: 获取 评级类型Id
	 * @return: creditTypeId
	 * @author wangk
	 * @date 2016-2-19 下午5:03:42 
	 */
	public Integer getCreditTypeId() {
		return creditTypeId;
	}

	/**   
	 * @Description: 设置 评级类型Id   
	 * @param: creditTypeId 
	 * @author wangk
	 * @date 2016-2-19 下午5:03:42 
	 */
	public void setCreditTypeId(Integer creditTypeId) {
		this.creditTypeId = creditTypeId;
	}

	/**
	 * @Description: 获取 评级类型名称
	 * @return: creditTypeName
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public String getCreditTypeName() {
		return creditTypeName;
	}

	/**   
	 * @Description: 设置 评级类型名称   
	 * @param: creditTypeName 
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public void setCreditTypeName(String creditTypeName) {
		this.creditTypeName = creditTypeName;
	}

	/**
	 * @Description: 获取 备注
	 * @return: remark
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public String getRemark() {
		return remark;
	}

	/**   
	 * @Description: 设置 备注   
	 * @param: remark 
	 * @author wangk
	 * @date 2016-2-19 下午2:23:48 
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @Description: 获取 最小分
	 * @return: minScore
	 * @author: wangk
	 * @date: 2016-3-3 下午4:36:08 
	 */
	public String getMinScore() {
		return minScore;
	}

	/**   
	 * @Description: 设置 最小分   
	 * @param: minScore 
	 * @author: wangk
	 * @date: 2016-3-3 下午4:36:08 
	 */
	public void setMinScore(String minScore) {
		this.minScore = minScore;
	}

	/**
	 * @Description: 获取 最大分
	 * @return: maxScore
	 * @author: wangk
	 * @date: 2016-3-3 下午4:36:08 
	 */
	public String getMaxScore() {
		return maxScore;
	}

	/**   
	 * @Description: 设置 最大分   
	 * @param: maxScore 
	 * @author: wangk
	 * @date: 2016-3-3 下午4:36:08 
	 */
	public void setMaxScore(String maxScore) {
		this.maxScore = maxScore;
	}

	/**
	 * @Description: 获取 图标
	 * @return: icon
	 * @author: wangk
	 * @date: 2016-3-3 下午4:36:08 
	 */
	public String getIcon() {
		return icon;
	}

	/**   
	 * @Description: 设置 图标   
	 * @param: icon 
	 * @author: wangk
	 * @date: 2016-3-3 下午4:36:08 
	 */
	public void setIcon(String icon) {
		this.icon = icon;
	}
}
