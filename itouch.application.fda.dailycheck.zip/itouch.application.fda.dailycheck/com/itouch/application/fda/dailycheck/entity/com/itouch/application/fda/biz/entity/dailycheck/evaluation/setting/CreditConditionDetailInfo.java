package com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author qiuy
 * 信用评定条件细项实体
 */
@Entity
@Table(name="DC_CREDIT_CONDITION_DETAIL")
public class CreditConditionDetailInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	//条件详细编号
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="DETAIL_ID")
	private String detailId;

	//条件详细名称
	@Column(name="DETAIL_NAME")
	private String detailName;
	
	//评定条件编号
	@Column(name="CONDITION_ID")
	private String conditionId;

	//评定条件名称
	@Column(name="CONDITION_NAME")
	private String conditionName;
	
	//括号
	@Column(name="PARENTHESIS")
	private String parenthesis;
	
	//逻辑运算符
	@Column(name="LOGICAL_OPERATOR")
	private String logicalOperator;
	
	//监管类型编号
	@Column(name="CHECK_TYPE_ID")
	private String checkTypeId;

	//监管类型名称
	@Column(name="CHECK_TYPE_NAME")
	private String checkTypeName;

	//监管结论编号
	@Column(name="CHECK_VERDICT_ID")
	private String checkVerdictId;

	//监管结论名称
	@Column(name="CHECK_VERDICT_NAME")
	private String checkVerdictName;

	//结论类型编号
	@Column(name="VERDICT_TYPE_ID")
	private String verdictTypeId;

	//结论类型名称
	@Column(name="VERDICT_TYPE_NAME")
	private String verdictTypeName;
	
	//关系运算符
	@Column(name="RELATIONAL_OPERATOR")
	private String relationalOperator;
	
	//次数或分值
	@Column(name="VERDICT_VALUE")
	private Integer verdictValue;
	
	//系数
	@Column(name="COEFFICIENT")
	private Double coefficient;

	//排序号
	@Column(name="ORDER_ID")
	private Integer orderId;

	//备注
	@Column(name="REMARK")
	private String remark;

	public String getDetailId() {
		return this.detailId;
	}

	public void setDetailId(String detailId) {
		this.detailId = detailId;
	}

	public String getCheckTypeId() {
		return this.checkTypeId;
	}

	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	public String getCheckTypeName() {
		return this.checkTypeName;
	}

	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	public String getCheckVerdictId() {
		return this.checkVerdictId;
	}

	public void setCheckVerdictId(String checkVerdictId) {
		this.checkVerdictId = checkVerdictId;
	}

	public String getCheckVerdictName() {
		return this.checkVerdictName;
	}

	public void setCheckVerdictName(String checkVerdictName) {
		this.checkVerdictName = checkVerdictName;
	}

	public Double getCoefficient() {
		return this.coefficient;
	}

	public void setCoefficient(Double coefficient) {
		this.coefficient = coefficient;
	}

	public String getConditionId() {
		return this.conditionId;
	}

	public void setConditionId(String conditionId) {
		this.conditionId = conditionId;
	}

	public String getConditionName() {
		return this.conditionName;
	}

	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}

	public String getDetailName() {
		return this.detailName;
	}

	public void setDetailName(String detailName) {
		this.detailName = detailName;
	}

	public String getLogicalOperator() {
		return this.logicalOperator;
	}

	public void setLogicalOperator(String logicalOperator) {
		this.logicalOperator = logicalOperator;
	}

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getParenthesis() {
		return this.parenthesis;
	}

	public void setParenthesis(String parenthesis) {
		this.parenthesis = parenthesis;
	}

	public String getRelationalOperator() {
		return this.relationalOperator;
	}

	public void setRelationalOperator(String relationalOperator) {
		this.relationalOperator = relationalOperator;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getVerdictTypeId() {
		return this.verdictTypeId;
	}

	public void setVerdictTypeId(String verdictTypeId) {
		this.verdictTypeId = verdictTypeId;
	}

	public String getVerdictTypeName() {
		return this.verdictTypeName;
	}

	public void setVerdictTypeName(String verdictTypeName) {
		this.verdictTypeName = verdictTypeName;
	}

	public Integer getVerdictValue() {
		return this.verdictValue;
	}

	public void setVerdictValue(Integer verdictValue) {
		this.verdictValue = verdictValue;
	}
}
