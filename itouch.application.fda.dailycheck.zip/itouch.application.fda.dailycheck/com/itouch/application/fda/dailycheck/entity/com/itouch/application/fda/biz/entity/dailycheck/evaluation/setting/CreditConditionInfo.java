package com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author qiuy
 * 信用评定条件实体
 */
@Entity
@Table(name="DC_CREDIT_CONDITION")
public class CreditConditionInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	//评定条件编号
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="CONDITION_ID")
	private String conditionId;

	//评定条件名称
	@Column(name="CONDITION_NAME")
	private String conditionName;

	//评定等级编号
	@Column(name="RANK_ID")
	private String rankId;
	
	//评定等级名称
	@Column(name="RANK_NAME")
	private String rankName;
	
	//是否启用
	@Column(name="IS_ENABLED")
	private Integer isEnabled;

	//排序号
	@Column(name="ORDER_ID")
	private Integer orderId;
	
	//备注
	@Column(name="REMARK")
	private String remark;
	
	public String getConditionId() {
		return this.conditionId;
	}

	public void setConditionId(String conditionId) {
		this.conditionId = conditionId;
	}

	public String getConditionName() {
		return this.conditionName;
	}

	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}

	public Integer getIsEnabled() {
		return this.isEnabled;
	}

	public void setIsEnabled(Integer isEnabled) {
		this.isEnabled = isEnabled;
	}

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getRankName() {
		return this.rankName;
	}

	public void setRankName(String rankName) {
		this.rankName = rankName;
	}

	public String getRankId() {
		return this.rankId;
	}

	public void setRankId(String rankId) {
		this.rankId = rankId;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
