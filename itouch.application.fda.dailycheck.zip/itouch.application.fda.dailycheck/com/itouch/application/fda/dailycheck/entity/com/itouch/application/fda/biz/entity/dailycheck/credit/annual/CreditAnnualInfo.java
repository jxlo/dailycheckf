/**  
 * @Description: TODO
 * @Title: CreditAnnualInfo.java 
 * @Package: com.itouch.application.fda.biz.entity.dailycheck.credit.food.catering.annual 
 * @author: wangk
 * @date 2016-2-24 下午3:23:11 
 */
package com.itouch.application.fda.biz.entity.dailycheck.credit.annual;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.itouch.application.ent.entity.basic.VEntBasic;
import com.itouch.application.fda.foundation.util.GlobalUtil;

/** 
 * @Description: 年度信用评级
 * @ClassName: CreditAnnualInfo 
 * @author wangk
 * @date 2016-2-24 下午3:23:11  
 */
@Entity
@Table(name="DC_CREDIT_ANNUAL")
public class CreditAnnualInfo implements IBusinessObject{
	
	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	public CreditAnnualInfo(){
		this.creditId=GlobalUtil.createUUID();
		this.attachmentCode=GlobalUtil.createGlobalKey();
	}
	
	public CreditAnnualInfo(String unitId,Number count)
	{
		this.unitId=unitId;
		this.count=count;
	}
	
	
	/**
	 * @param entBasic
	 */
	public CreditAnnualInfo(VEntBasic entBasic){
		this();
		this.entCode=entBasic.getEntCode();
		this.entName=entBasic.getEntName();
		this.entProdAddr=entBasic.getRegAddr();
		this.entTypeId=entBasic.getEntTypeId();
		this.entTypeName=entBasic.getEntTypeName();
		this.entTypeGroupId=entBasic.getEntTypeGroupId();
		
	}
	

	/** 主键Id **/
	@Id
	@Column(name = "CREDIT_ID")
	private String creditId; 
	
	/** 企业名称 **/
	@Column(name="ENT_NAME")
	private String entName;
	
	/** 企业编号 **/
	@Column(name="ENT_CODE")
	private String entCode;
	
	/** 企业类型分组Id **/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/** 企业类型分组名称 **/
	@Column(name="ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;

	/** 企业类型Id **/
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/*生产地址*/
	@Column(name="ent_Prod_Addr")
	private String entProdAddr;
	
	/** 企业类型名称 **/
	@Column(name="ENT_TYPE_NAME")
	private String entTypeName;
	
	/** 监管单位编号 **/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** 监管单位名称 **/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** 评定年份 **/
	@Column(name="CREDIT_YEAR")
	private int creditYear;
	
	/** 评定人Id **/
	@Column(name="CREDIT_USER_ID")
	private String creditUserId;
	
	/** 评定人 **/
	@Column(name="CREDIT_USER_NAME")
	private String creditUserName;
	
	/** 评定时间 **/
	@Column(name="CREDIT_TIME")
	private Date creditTime;
	
	/** 评定等级 **/
	@Column(name="CREDIT_VALUE")
	private String creditValue;
	
	/** 级别名称 **/
	@Column(name="CREDIT_NAME")
	private String creditName;
	
	/** 评定得分 **/
	@Column(name="CREDIT_SCORE")
	private String creditScore;
	
	/** 评级类型Id **/
	@Column(name="CREDIT_TYPE_ID")
	private Integer creditTypeId;
	
	/** 评级类型名称 **/
	@Column(name="CREDIT_TYPE_NAME")
	private String creditTypeName;
	
	/** 评级种类Id **/
	@Column(name="CREDIT_CATEGORY_ID")
	private String creditCategoryId;
	
	/** 评级种类名称 **/
	@Column(name="CREDIT_CATEGORY_NAME")
	private String creditCategoryName;

	/** 评定单位Id **/
	@Column(name="CREDIT_UNIT_ID")
	private String creditUnitId;
	
	/** 评定单位名称 **/
	@Column(name="CREDIT_UNIT_NAME")
	private String creditUnitName;
	
	/** 评级状态Id **/
	@Column(name="CREDIT_STATE_ID")
	private int creditStateId;
	
	/** 评级状态 **/
	@Column(name="CREDIT_STATE_NAME")
	private String creditStateName;
	
	/** 存档单位Id **/
	@Column(name="ARCHIVE_UNIT_ID")
	private String archiveUnitId;
	
	/** 存档单位名称 **/
	@Column(name="ARCHIVE_UNIT_NAME")
	private String archiveUnitName;
	
	/** 备注 **/
	@Column(name="REMARK")
	private String remark;
	
	/** 附件组号 **/
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;

	@Transient
	private Number count;
	
	public String getCreditId() {
		return creditId;
	}

	public void setCreditId(String creditId) {
		this.creditId = creditId;
	}
	
	/**
	 * @Description: 获取 企业编号
	 * @return: entName
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getEntName() {
		return entName;
	}

	/**   
	 * @Description: 设置 企业编号   
	 * @param: entName 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}

	/**
	 * @Description: 获取 企业名称
	 * @return: entCode
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getEntCode() {
		return entCode;
	}

	/**   
	 * @Description: 设置 企业名称   
	 * @param: entCode 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	/**
	 * @Description: 获取 企业类型分组Id
	 * @return: entTypeGroupId
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**   
	 * @Description: 设置 企业类型分组Id   
	 * @param: entTypeGroupId 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	/**
	 * @Description: 获取 企业类型分组名称
	 * @return: entTypeGroupName
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	/**   
	 * @Description: 设置 企业类型分组名称   
	 * @param: entTypeGroupName 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}
	
	/**
	 * @Description: 获取 企业类型Id *
	 * @return entTypeId  企业类型Id *
	 * @author:zhangzt
	 * @time:2016年3月2日 下午1:43:17
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**
	 * @Description: 设置  企业类型Id *
	 * @param entTypeId  企业类型Id *
	 * @author:zhangzt
	 * @time:2016年3月2日 下午1:43:17
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 企业类型名称 *
	 * @return entTypeName  企业类型名称 *
	 * @author:zhangzt
	 * @time:2016年3月2日 下午1:43:17
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**
	 * @Description: 设置  企业类型名称 *
	 * @param entTypeName  企业类型名称 *
	 * @author:zhangzt
	 * @time:2016年3月2日 下午1:43:17
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description: 获取 监管单位编号
	 * @return: unitId
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getUnitId() {
		return unitId;
	}

	/**   
	 * @Description: 设置 监管单位编号   
	 * @param: unitId 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description: 获取 监管单位名称
	 * @return: unitName
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getUnitName() {
		return unitName;
	}

	/**   
	 * @Description: 设置 监管单位名称   
	 * @param: unitName 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description: 获取 评定年份
	 * @return: creditYear
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public int getCreditYear() {
		return creditYear;
	}

	/**   
	 * @Description: 设置 评定年份   
	 * @param: creditYear 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditYear(int creditYear) {
		this.creditYear = creditYear;
	}

	/**
	 * @Description: 获取 评定人Id
	 * @return: creditUserId
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getCreditUserId() {
		return creditUserId;
	}

	/**   
	 * @Description: 设置 评定人Id   
	 * @param: creditUserId 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditUserId(String creditUserId) {
		this.creditUserId = creditUserId;
	}

	/**
	 * @Description: 获取 评定人
	 * @return: creditUserName
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getCreditUserName() {
		return creditUserName;
	}

	/**   
	 * @Description: 设置 评定人   
	 * @param: creditUserName 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditUserName(String creditUserName) {
		this.creditUserName = creditUserName;
	}

	/**
	 * @Description: 获取 评定时间
	 * @return: creditTime
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public Date getCreditTime() {
		return creditTime;
	}

	/**   
	 * @Description: 设置 评定时间   
	 * @param: creditTime 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditTime(Date creditTime) {
		this.creditTime = creditTime;
	}

	/**
	 * @Description: 获取 评定等级
	 * @return: creditValue
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getCreditValue() {
		return creditValue;
	}

	/**   
	 * @Description: 设置 评定等级   
	 * @param: creditValue 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditValue(String creditValue) {
		this.creditValue = creditValue;
	}

	/**
	 * @Description: 获取 评级类型Id
	 * @return: creditTypeId
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public Integer getCreditTypeId() {
		return creditTypeId;
	}

	/**   
	 * @Description: 设置 评级类型Id   
	 * @param: creditTypeId 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditTypeId(Integer creditTypeId) {
		this.creditTypeId = creditTypeId;
	}

	/**
	 * @Description: 获取 评级类型名称
	 * @return: creditTypeName
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getCreditTypeName() {
		return creditTypeName;
	}

	/**   
	 * @Description: 设置 评级类型名称   
	 * @param: creditTypeName 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditTypeName(String creditTypeName) {
		this.creditTypeName = creditTypeName;
	}

	/**
	 * @Description: 获取 评定单位Id
	 * @return: creditUnitId
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getCreditUnitId() {
		return creditUnitId;
	}

	/**   
	 * @Description: 设置 评定单位Id   
	 * @param: creditUnitId 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditUnitId(String creditUnitId) {
		this.creditUnitId = creditUnitId;
	}

	/**
	 * @Description: 获取 评定单位名称
	 * @return: creditUnitName
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getCreditUnitName() {
		return creditUnitName;
	}

	/**   
	 * @Description: 设置 评定单位名称   
	 * @param: creditUnitName 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditUnitName(String creditUnitName) {
		this.creditUnitName = creditUnitName;
	}

	/**
	 * @Description: 获取 评级状态Id
	 * @return: creditStateId
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public int getCreditStateId() {
		return creditStateId;
	}

	/**   
	 * @Description: 设置 评级状态Id   
	 * @param: creditStateId 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditStateId(int creditStateId) {
		this.creditStateId = creditStateId;
	}

	/**
	 * @Description: 获取 评级状态
	 * @return: creditStateName
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getCreditStateName() {
		return creditStateName;
	}

	/**   
	 * @Description: 设置 评级状态   
	 * @param: creditStateName 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setCreditStateName(String creditStateName) {
		this.creditStateName = creditStateName;
	}

	/**
	 * @Description: 获取 备注
	 * @return: remark
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public String getRemark() {
		return remark;
	}

	/**   
	 * @Description: 设置 备注   
	 * @param: remark 
	 * @author wangk
	 * @date 2016-2-24 下午4:08:06 
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @Description: 获取 级别名称
	 * @return: creditName
	 * @author wangk
	 * @date 2016-3-2 下午3:09:38 
	 */
	public String getCreditName() {
		return creditName;
	}

	/**   
	 * @Description: 设置 级别名称   
	 * @param: creditName 
	 * @author wangk
	 * @date 2016-3-2 下午3:09:38 
	 */
	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}

	/**
	 * @Description: 获取 评定得分
	 * @return: creditScore
	 * @author wangk
	 * @date 2016-3-2 下午3:09:38 
	 */
	public String getCreditScore() {
		return creditScore;
	}

	/**   
	 * @Description: 设置 评定得分   
	 * @param: creditScore 
	 * @author wangk
	 * @date 2016-3-2 下午3:09:38 
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}

	/**
	 * @Description: 获取 存档单位Id
	 * @return: archiveUnitId
	 * @author: wangk
	 * @date: 2016-3-7 下午3:17:13 
	 */
	public String getArchiveUnitId() {
		return archiveUnitId;
	}

	/**   
	 * @Description: 设置 存档单位Id   
	 * @param: archiveUnitId 
	 * @author: wangk
	 * @date: 2016-3-7 下午3:17:13 
	 */
	public void setArchiveUnitId(String archiveUnitId) {
		this.archiveUnitId = archiveUnitId;
	}

	/**
	 * @Description: 获取 存档单位名称
	 * @return: archiveUnitName
	 * @author: wangk
	 * @date: 2016-3-7 下午3:17:13 
	 */
	public String getArchiveUnitName() {
		return archiveUnitName;
	}

	/**   
	 * @Description: 设置 存档单位名称   
	 * @param: archiveUnitName 
	 * @author: wangk
	 * @date: 2016-3-7 下午3:17:13 
	 */
	public void setArchiveUnitName(String archiveUnitName) {
		this.archiveUnitName = archiveUnitName;
	}

	/**
	 * @Description: 获取 count
	 * @return: count
	 * @author xh
	 * @date 2016-3-28 下午5:30:13 
	 */
	public Number getCount() {
		return count;
	}

	/**   
	 * @Description: 设置 count   
	 * @param: count 
	 * @author xh
	 * @date 2016-3-28 下午5:30:13 
	 */
	public void setCount(Number count) {
		this.count = count;
	}

	public String getEntProdAddr() {
		return entProdAddr;
	}

	public void setEntProdAddr(String entProdAddr) {
		this.entProdAddr = entProdAddr;
	}

	public String getAttachmentCode() {
		return attachmentCode;
	}

	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}
	
	public String getCreditCategoryId() {
		return creditCategoryId;
	}

	public void setCreditCategoryId(String creditCategoryId) {
		this.creditCategoryId = creditCategoryId;
	}

	public String getCreditCategoryName() {
		return creditCategoryName;
	}

	public void setCreditCategoryName(String creditCategoryName) {
		this.creditCategoryName = creditCategoryName;
	}
}
