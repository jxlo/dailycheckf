package com.itouch.application.fda.biz.entity.dailycheck.credit;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "DC_CREDIT_DISPOSAL")
public class CreditDisposalInfo implements IBusinessObject {

	/**
	 * @author:zhangzt
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String id;

	@Column(name = "CREDIT_ID")
	private String creditId;
	
	@Column(name = "FROM_UNIT_ID")
	private String fromUnitId;
	
	// 来源单位名称
	@Column(name = "From_Unit_Name")
	private String fromUnitName;
	
	// 来源部门Id
	@Column(name = "From_Dept_Id")
	private String fromDeptId;
	
	// 来源部门名称
	@Column(name = "From_Dept_Name")
	private String fromDeptName;
	
	// 来源人员Id
	@Column(name = "From_User_Id")
	private String fromUserId;

	// 来源人员名称
	@Column(name = "From_User_Name")
	private String fromUserName;
	
	// 来源日期
	@Column(name = "From_Date")
	private Date fromDate;
	
	// 是否已处理
	@Column(name = "Is_Disp")
	private int isDisp;
	
	// 处理单位Id
	@Column(name = "Disp_Unit_Id")
	private String dispUnitId;

	// 处理单位名称
	@Column(name = "Disp_Unit_Name")
	private String dispUnitName;
	
	// 处理人Id
	@Column(name = "Disp_User_Id")
	private String dispUserId;
	
	// 处理人
	@Column(name = "Disp_User_Name")
	private String dispUserName;
	
	// 处理时间
	@Column(name = "Disp_Date")
	private Date dispDate;
	
	// 处理环节名称
	@Column(name = "Disp_Node_Name")
	private String dispNodeName;
	
	// 备注
	@Column(name = "Remark")
	private String Remark;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreditId() {
		return creditId;
	}

	public void setCreditId(String creditId) {
		this.creditId = creditId;
	}

	public String getFromUnitId() {
		return fromUnitId;
	}

	public void setFromUnitId(String fromUnitId) {
		this.fromUnitId = fromUnitId;
	}

	public String getFromUnitName() {
		return fromUnitName;
	}

	public void setFromUnitName(String fromUnitName) {
		this.fromUnitName = fromUnitName;
	}

	public String getFromDeptId() {
		return fromDeptId;
	}

	public void setFromDeptId(String fromDeptId) {
		this.fromDeptId = fromDeptId;
	}

	public String getFromDeptName() {
		return fromDeptName;
	}

	public void setFromDeptName(String fromDeptName) {
		this.fromDeptName = fromDeptName;
	}

	public String getFromUserId() {
		return fromUserId;
	}

	public void setFromUserId(String fromUserId) {
		this.fromUserId = fromUserId;
	}

	public String getFromUserName() {
		return fromUserName;
	}

	public void setFromUserName(String fromUserName) {
		this.fromUserName = fromUserName;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public int getIsDisp() {
		return isDisp;
	}

	public void setIsDisp(int isDisp) {
		this.isDisp = isDisp;
	}

	public String getDispUnitId() {
		return dispUnitId;
	}

	public void setDispUnitId(String dispUnitId) {
		this.dispUnitId = dispUnitId;
	}

	public String getDispUnitName() {
		return dispUnitName;
	}

	public void setDispUnitName(String dispUnitName) {
		this.dispUnitName = dispUnitName;
	}

	public String getDispUserId() {
		return dispUserId;
	}

	public void setDispUserId(String dispUserId) {
		this.dispUserId = dispUserId;
	}

	public String getDispUserName() {
		return dispUserName;
	}

	public void setDispUserName(String dispUserName) {
		this.dispUserName = dispUserName;
	}

	public Date getDispDate() {
		return dispDate;
	}

	public void setDispDate(Date dispDate) {
		this.dispDate = dispDate;
	}

	public String getDispNodeName() {
		return dispNodeName;
	}

	public void setDispNodeName(String dispNodeName) {
		this.dispNodeName = dispNodeName;
	}

	public String getRemark() {
		return Remark;
	}

	public void setRemark(String remark) {
		Remark = remark;
	}

}
