/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:PlanUserInfo.java
 * @author:fanghailong
 * @time:2015-10-20 下午4:04:05
 */
package com.itouch.application.fda.biz.entity.dailycheck.plan;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo;

/**
 * @author:fanghailong 
 */
@Entity
@Table(name="DC_PLAN_USER")
public class PlanUserInfo implements IBusinessObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**主键Id*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**计划id*/
	@Column(name="PLAN_ID")
	private String planId;
	
	/**用户id*/
	@Column(name="USER_ID")
	private String userId;
	
	/**用户名*/
	@Column(name="USER_NAME")
	private String userName;
	
	/**部门id*/
	@Column(name="DEPT_ID")
	private String deptId;
	
	/**部门名称*/
	@Column(name="DEPT_NAME")
	private String DeptName;
	
	/**单位id*/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/**单位名称*/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/**是否完成*/
	@Column(name="IS_COMPLETED")
	private Integer isCompleted;
	
	/**附件组号*/
	@Column(name="ATTACHMENT_CODE")
	private String acttachmentCode;
	
	/**检查id*/
	@Column(name="CHECK_ID")
	private String checkId;
	
	/**备注*/
	@Column(name="REMARK")
	private String remark;	
	
	@Transient
	private CheckInfo checkInfo;
	
	/**
	 * @Description:获取{note}
	 * @return:checkInfo
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:49:26
	 */
	public CheckInfo getCheckInfo() {
		return checkInfo;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkInfo
	 * @author:fanghailong
	 * @time:2015-10-29 下午3:49:26
	 */
	public void setCheckInfo(CheckInfo checkInfo) {
		this.checkInfo = checkInfo;
	}

	/**
	 * @Description:获取{note}
	 * @return:id
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getId() {
		return id;
	}

	/**
	 * @Description:设置{note}
	 * @param：id
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description:获取{note}
	 * @return:planId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getPlanId() {
		return planId;
	}

	/**
	 * @Description:设置{note}
	 * @param：planId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setPlanId(String planId) {
		this.planId = planId;
	}

	/**
	 * @Description:获取{note}
	 * @return:userId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @Description:设置{note}
	 * @param：userId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @Description:获取{note}
	 * @return:userName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @Description:设置{note}
	 * @param：userName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @Description:获取{note}
	 * @return:deptId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getDeptId() {
		return deptId;
	}

	/**
	 * @Description:设置{note}
	 * @param：deptId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	/**
	 * @Description:获取{note}
	 * @return:DeptName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getDeptName() {
		return DeptName;
	}

	/**
	 * @Description:设置{note}
	 * @param：deptName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setDeptName(String deptName) {
		DeptName = deptName;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description:获取{note}
	 * @return:unitName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description:设置{note}
	 * @param：unitName
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description:获取{note}
	 * @return:isCompleted
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public Integer getIsCompleted() {
		return isCompleted;
	}

	/**
	 * @Description:设置{note}
	 * @param：isCompleted
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setIsCompleted(Integer isCompleted) {
		this.isCompleted = isCompleted;
	}

	/**
	 * @Description:获取{note}
	 * @return:acttachmentCode
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getActtachmentCode() {
		return acttachmentCode;
	}

	/**
	 * @Description:设置{note}
	 * @param：acttachmentCode
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setActtachmentCode(String acttachmentCode) {
		this.acttachmentCode = acttachmentCode;
	}

	/**
	 * @Description:获取{note}
	 * @return:checkId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getCheckId() {
		return checkId;
	}

	/**
	 * @Description:设置{note}
	 * @param：checkId
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * @Description:获取{note}
	 * @return:remark
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description:设置{note}
	 * @param：remark
	 * @author:fanghailong
	 * @time:2015-10-20 下午4:10:50
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}
