package com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author qiuy
 * 年度评定限制实体
 */
@Entity
@Table(name="DC_CREDIT_LIMIT_YEAR")
public class CreditLimitYearInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	//主键Id
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="ID")
	private String id;

	//评定体系编号
	@Column(name="CRITERION_ID")
	private String criterionId;

	//评定体系名称
	@Column(name="CRITERION_NAME")
	private String criterionName;
	
	//去年等级编号
	@Column(name="LAST_YEAR_RANK_ID")
	private String lastYearRankId;

	//去年等级名称
	@Column(name="LAST_YEAR_RANK_NAME")
	private String lastYearRankName;
	
	//今年等级编号
	@Column(name="THIS_YEAR_RANK_ID")
	private String thisYearRankId;

	//今年等级名称
	@Column(name="THIS_YEAR_RANK_NAME")
	private String thisYearRankName;
	
	//允许等级编号
	@Column(name="ALLOWABLE_RANK_ID")
	private String allowableRankId;

	//允许等级名称
	@Column(name="ALLOWABLE_RANK_NAME")
	private String allowableRankName;

	//是否启用
	@Column(name="IS_ENABLED")
	private Integer isEnabled;

	//排序号
	@Column(name="ORDER_ID")
	private Integer orderId;

	//备注
	@Column(name="REMARK")
	private String remark;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAllowableRankId() {
		return this.allowableRankId;
	}

	public void setAllowableRankId(String allowableRankId) {
		this.allowableRankId = allowableRankId;
	}

	public String getAllowableRankName() {
		return this.allowableRankName;
	}

	public void setAllowableRankName(String allowableRankName) {
		this.allowableRankName = allowableRankName;
	}

	public String getCriterionId() {
		return this.criterionId;
	}

	public void setCriterionId(String criterionId) {
		this.criterionId = criterionId;
	}

	public String getCriterionName() {
		return this.criterionName;
	}

	public void setCriterionName(String criterionName) {
		this.criterionName = criterionName;
	}

	public Integer getIsEnabled() {
		return this.isEnabled;
	}

	public void setIsEnabled(Integer isEnabled) {
		this.isEnabled = isEnabled;
	}

	public String getLastYearRankId() {
		return this.lastYearRankId;
	}

	public void setLastYearRankId(String lastYearRankId) {
		this.lastYearRankId = lastYearRankId;
	}

	public String getLastYearRankName() {
		return this.lastYearRankName;
	}

	public void setLastYearRankName(String lastYearRankName) {
		this.lastYearRankName = lastYearRankName;
	}

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getThisYearRankId() {
		return this.thisYearRankId;
	}

	public void setThisYearRankId(String thisYearRankId) {
		this.thisYearRankId = thisYearRankId;
	}

	public String getThisYearRankName() {
		return this.thisYearRankName;
	}

	public void setThisYearRankName(String thisYearRankName) {
		this.thisYearRankName = thisYearRankName;
	}
}
