package com.itouch.application.fda.biz.entity.dailycheck.report;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description: 餐饮企业日常检查统计表 
 * @ClassName: RepCateringDailycheck 
 * @author: wangk
 * @date: 2016-3-22 下午1:55:54  
 */
@Entity
@Table(name="DC_REP_CATERING_DAILYCHECK")
public class RepCateringDailyCheckInfo implements IBusinessObject{
	
	/**主键Id*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**报表Id*/
	@Column(name="REPORT_ID")
	private String reportId;
	
	/**单位类别Id*/
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/**单位类别名称*/
	@Column(name="ENT_TYPE_Name")
	private String entTypeName;
	
	/** 总数 **/
	@Column(name="TOTAL_COUNT")
	private Integer totalCount;
	
	/** 其中农村地区 **/
	@Column(name="VILLAGE_AREA_COUNT")
	private Double villageAreaCount;
	
	/** 其中学校食堂 **/
	@Column(name="SCHOOL_CANTEEN_COUNT")
	private Double schoolCanteenCount;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:05 
	 */
	public String getId() {
		return id;
	}

	/**   
	 * @Description: 设置 主键Id   
	 * @param: id 
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:05 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 报表Id
	 * @return: reportId
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:05 
	 */
	public String getReportId() {
		return reportId;
	}

	/**   
	 * @Description: 设置 报表Id   
	 * @param: reportId 
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:05 
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	/**
	 * @Description: 获取 单位类别Id
	 * @return: entTypeId
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:05 
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**   
	 * @Description: 设置 单位类别Id   
	 * @param: entTypeId 
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:05 
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 单位类别名称
	 * @return: entTypeName
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:05 
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**   
	 * @Description: 设置 单位类别名称   
	 * @param: entTypeName 
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:06 
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description: 获取 总数
	 * @return: totalCount
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:06 
	 */
	public Integer getTotalCount() {
		return totalCount;
	}

	/**   
	 * @Description: 设置 总数   
	 * @param: totalCount 
	 * @author: wangk
	 * @date: 2016-3-22 下午2:00:06 
	 */
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @Description: 获取 其中农村地区
	 * @return: villageAreaCount
	 * @author xh
	 * @date 2016-3-23 下午2:00:11 
	 */
	public Double getVillageAreaCount() {
		return villageAreaCount;
	}

	/**   
	 * @Description: 设置 其中农村地区   
	 * @param: villageAreaCount 
	 * @author xh
	 * @date 2016-3-23 下午2:00:11 
	 */
	public void setVillageAreaCount(Double villageAreaCount) {
		this.villageAreaCount = villageAreaCount;
	}

	/**
	 * @Description: 获取 其中学校食堂
	 * @return: schoolCanteenCount
	 * @author xh
	 * @date 2016-3-23 下午2:00:11 
	 */
	public Double getSchoolCanteenCount() {
		return schoolCanteenCount;
	}

	/**   
	 * @Description: 设置 其中学校食堂   
	 * @param: schoolCanteenCount 
	 * @author xh
	 * @date 2016-3-23 下午2:00:11 
	 */
	public void setSchoolCanteenCount(Double schoolCanteenCount) {
		this.schoolCanteenCount = schoolCanteenCount;
	}

	
}
