/**  
* @Title: Check.java 
* @Package com.itouch.application.fda.biz.entity.dailycheck.check 
* @author wangk    
* @date 2015-10-20 下午2:40:57  
*/
package com.itouch.application.fda.biz.entity.dailycheck.check;

import iTouch.framework.data.operation.IBusinessObject;
import iTouch.framework.environment.user.User;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.itouch.application.ent.entity.basic.EntBasic;
import com.itouch.application.fda.biz.entity.dailycheck.check.upload.UploadInfo;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.AbstractTable;

/**
 * @author wangk
 * @Description: 检查记录表
 * @date 2015-10-20 下午2:40:57
 */
@Entity
@Table(name = "DC_CHECK")
public class CheckInfo implements IBusinessObject {

	/**
	 * @Fields checkId :检查记录Id
	 **/
	@Id
	@Column(name = "CHECK_ID")
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String checkId;

	/**
	 * @Fields checkTypeId : 检查类别Id
	 **/
	@Column(name = "CHECK_TYPE_ID")
	private String checkTypeId;

	/**
	 * @Fields checkTypeName : 检查类别Id
	 **/
	@Column(name = "CHECK_TYPE_NAME")
	private String checkTypeName;

	/**
	 * @Fields checkLeaderId : 实际检查带队人Id
	 **/
	@Column(name = "CHECK_LEADER_ID")
	private String checkLeaderId;

	/**
	 * @Fields checkLeaderName : 实际检查带队人姓名
	 **/
	@Column(name = "CHECK_LEADER_NAME")
	private String checkLeaderName;

	
	
	/**
	 * @Fields accompUsers : 陪同检查人员
	 */
	@Column(name = "ACCOMP_USERS")
	private String accompUsers;
	

	/**
	 * @Fields accompUsersTel : 陪同检查人员电话
	 **/
	@Column(name = "ACCOMP_USERS_TEL")
	private String accompUsersTel;

	/**
	 * @Fields checkUserIds : 检查人Ids
	 **/
	@Column(name = "CHECK_USER_IDS")
	private String checkUserIds;

	/**
	 * @Fields checkUserNames : 检查人姓名
	 **/
	@Column(name = "CHECK_USER_NAMES")
	private String checkUserNames;

	/**
	 * @Fields checkBeginDate : 检查开始日期
	 **/
	@Column(name = "CHECK_BEGIN_DATE")
	private Date checkBeginDate;

	/**
	 * @Fields checkEndDate : 检查结束日期
	 **/
	@Column(name = "CHECK_END_DATE")
	private Date checkEndDate;

	/**
	 * @Fields tableId : 表Id
	 **/
	@Column(name = "TABLE_ID")
	private String tableId;

	/**
	 * @Fields unitId : 监管单位编号
	 **/
	@Column(name = "UNIT_ID")
	private String unitId;
	/**
	 * @Fields unitId : 任务计划
	 **/
	@Column(name = "IS_COMPLETED")
	private String isCompleted;

	/**
	 * @Fields unitName : 监管单位名称
	 **/
	@Column(name = "UNIT_NAME")
	private String unitName;

	/**
	 * @Fields creatorId : 创建人Id
	 **/
	@Column(name = "CREATOR_ID", updatable = false)
	private String creatorId;

	/**
	 * @Fields creatorName : 创建人姓名
	 **/
	@Column(name = "CREATOR_NAME", updatable = false)
	private String creatorName;

	/**
	 * @Fields createTime : 创建时间
	 **/

	@Column(name = "CREATE_TIME", updatable = false)
	private Date createTime;

	/**
	 * @Fields updateUserId : 更新人Id
	 **/
	@Column(name = "UPDATE_USER_ID")
	private String updateUserId;

	/**
	 * @Fields updateUserName : 更新人
	 **/
	@Column(name = "UPDATE_USER_NAME")
	private String updateUserName;

	/**
	 * @Fields updateTime : 更新时间
	 **/
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	/**
	 * @Fields isArchived : 是否归档
	 **/
	@Column(name = "IS_ARCHIVED")
	private Integer isArchived = 0;

	/**
	 * @Fields isTemp : 是否暂存
	 **/
	@Column(name = "IS_TEMP")
	private Integer isTemp = 0;

	/**
	 * @Fields isDelete : 是否已删除
	 **/
	@Column(name = "IS_DELETE")
	private Integer isDelete = 0;
	/**
	 * @Fields isTerminal 是终端下发还是自建
	 */
	@Column(name = "IS_TERMINAL")
	private String isTerminal;

	/**
	 * @Fields grade : 等级
	 **/
	@Column(name = "GRADE")
	private String grade;

	/**
	 * @Fields flowKey : 流程编号
	 **/
	@Column(name = "FLOW_KEY")
	private String flowKey;

	/**
	 * @Fields resultVerdictId : 检查结论Id
	 **/
	@Column(name = "RESULT_VERDICT_ID")
	private Integer resultVerdictId;

	/**
	 * @Fields resultVerdictName : 检查结论
	 **/
	@Column(name = "RESULT_VERDICT_NAME")
	private String resultVerdictName;

	/**
	 * @Fields RESULT_MEMO : 检查结果信息
	 **/
	@Column(name = "RESULT_MEMO")
	private String resultMemo;

	/**
	 * @Fields resultIdea : 检查意见
	 **/
	@Column(name = "RESULT_IDEA")
	private String resultIdea;

	/**
	 * @Fields isHasScore : 是否得分
	 **/
	@Column(name = "IS_HAS_SCORE")
	private Integer isHasScore;

	/**
	 * @Fields resultScore : 检查结果得分
	 **/
	@Column(name = "RESULT_SCORE")
	private Integer resultScore;

	/**
	 * @Fields attachmentCode : 附件组号
	 **/
	@Column(name = "ATTACHMENT_CODE")
	private String attachmentCode;

	/**
	 * @Fields remark : 备注
	 **/
	@Column(name = "REMARK")
	private String remark;

	/**
	 * @Fields TASK_ID : 任务Id
	 **/
	@Column(name = "TASK_ID", updatable = false)
	private String taskId;

	/**
	 * @Fields taskName : 任务名称
	 **/
	@Column(name = "TASK_NAME", updatable = false)
	private String taskName;

	/**
	 * @Fields unitTaskId : 单位任务Id
	 **/
	@Column(name = "UNIT_TASK_ID")
	private String unitTaskId;

	/**
	 * @Fields dailytable_code : 检查表附件组号
	 **/
	@Column(name = "DAILYTABLE_CODE")
	private String dailyTableCode;
	@Transient
	private List<EntBasic> entBasic;

	@Transient
	private List<User> users;

	@Transient
	private List<PlanInfo> plan;

	@Transient
	private String chkToSync;

	public String getChkToSync() {
		return chkToSync;
	}

	public void setChkToSync(String chkToSync) {
		this.chkToSync = chkToSync;
	}

	public List<PlanInfo> getPlan() {
		return plan;
	}

	public void setPlan(List<PlanInfo> plan) {
		this.plan = plan;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public List<EntBasic> getEntBasic() {
		return entBasic;
	}

	public void setEntBasic(List<EntBasic> entBasic) {
		this.entBasic = entBasic;
	}

	/**
	 * @Fields isFromMobile : 检查是否来自移动端
	 **/
	@Column(name = "IS_FROM_MOBILE")
	private int isFromMobile = 0;

	/** 检查企业表 **/
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "check")
	// @JSONField(serialize = false)
	private CheckEntInfo checkEnt;

	/**
	 * 检查表信息
	 */
	@Transient
	private AbstractTable tableInfo;

	/**
	 * 附件信息
	 */
	@Transient
	private UploadInfo uploadInfo;

	public UploadInfo getUploadInfo() {
		return uploadInfo;
	}

	public void setUploadInfo(UploadInfo uploadInfo) {
		this.uploadInfo = uploadInfo;
	}

	public AbstractTable getTableInfo() {
		return tableInfo;
	}

	public void setTableInfo(AbstractTable tableInfo) {
		this.tableInfo = tableInfo;
	}

	public CheckInfo() {
	}

	public CheckInfo(CheckInfo info) {
		this.createTime = info.createTime;
		this.resultVerdictName = info.resultVerdictName;
	}

	/**
	 * 获取checkId
	 * 
	 * @return checkId
	 */
	public String getCheckId() {
		return checkId;
	}

	/**
	 * 设置checkId
	 * 
	 * @param checkId
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * 获取checkLeaderId
	 * 
	 * @return checkLeaderId
	 */
	public String getCheckLeaderId() {
		return checkLeaderId;
	}

	/**
	 * 设置checkLeaderId
	 * 
	 * @param checkLeaderId
	 */
	public void setCheckLeaderId(String checkLeaderId) {
		this.checkLeaderId = checkLeaderId;
	}

	/**
	 * 获取checkLeaderName
	 * 
	 * @return checkLeaderName
	 */
	public String getCheckLeaderName() {
		return checkLeaderName;
	}

	/**
	 * 设置checkLeaderName
	 * 
	 * @param checkLeaderName
	 */
	public void setCheckLeaderName(String checkLeaderName) {
		this.checkLeaderName = checkLeaderName;
	}

	
	public String getAccompUsers() {
		return accompUsers;
	}

	public void setAccompUsers(String accompUsers) {
		this.accompUsers = accompUsers;
	}
	
	/**
	 * 获取accompUsersTel
	 * 
	 * @return accompUsersTel
	 */
	public String getAccompUsersTel() {
		return accompUsersTel;
	}

	/**
	 * 设置accompUsersTel
	 * 
	 * @param accompUsersTel
	 */
	public void setAccompUsersTel(String accompUsersTel) {
		this.accompUsersTel = accompUsersTel;
	}

	/**
	 * 获取checkUserIds
	 * 
	 * @return checkUserIds
	 */
	public String getCheckUserIds() {
		return checkUserIds;
	}

	/**
	 * 设置checkUserIds
	 * 
	 * @param checkUserIds
	 */
	public void setCheckUserIds(String checkUserIds) {
		this.checkUserIds = checkUserIds;
	}

	/**
	 * 获取checkUserNames
	 * 
	 * @return checkUserNames
	 */
	public String getCheckUserNames() {
		return checkUserNames;
	}

	/**
	 * 设置checkUserNames
	 * 
	 * @param checkUserNames
	 */
	public void setCheckUserNames(String checkUserNames) {
		this.checkUserNames = checkUserNames;
	}

	/**
	 * 获取tableId
	 * 
	 * @return tableId
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * 设置tableId
	 * 
	 * @param tableId
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * 获取unitId
	 * 
	 * @return unitId
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * 设置unitId
	 * 
	 * @param unitId
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * 获取unitName
	 * 
	 * @return unitName
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * 设置unitName
	 * 
	 * @param unitName
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * 获取creatorId
	 * 
	 * @return creatorId
	 */
	public String getCreatorId() {
		return creatorId;
	}

	/**
	 * 设置creatorId
	 * 
	 * @param creatorId
	 */
	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	/**
	 * 获取creatorName
	 * 
	 * @return creatorName
	 */
	public String getCreatorName() {
		return creatorName;
	}

	/**
	 * 设置creatorName
	 * 
	 * @param creatorName
	 */
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	/**
	 * 获取updateUserId
	 * 
	 * @return updateUserId
	 */
	public String getUpdateUserId() {
		return updateUserId;
	}

	/**
	 * 设置updateUserId
	 * 
	 * @param updateUserId
	 */
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	/**
	 * 获取updateUserName
	 * 
	 * @return updateUserName
	 */
	public String getUpdateUserName() {
		return updateUserName;
	}

	/**
	 * 设置updateUserName
	 * 
	 * @param updateUserName
	 */
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	/**
	 * 获取isArchived
	 * 
	 * @return isArchived
	 */
	public Integer getIsArchived() {
		return isArchived;
	}

	/**
	 * 设置isArchived
	 * 
	 * @param isArchived
	 */
	public void setIsArchived(Integer isArchived) {
		this.isArchived = isArchived;
	}

	/**
	 * 获取isTemp
	 * 
	 * @return isTemp
	 */
	public Integer getIsTemp() {
		return isTemp;
	}

	/**
	 * 设置isTemp
	 * 
	 * @param isTemp
	 */
	public void setIsTemp(Integer isTemp) {
		this.isTemp = isTemp;
	}

	/**
	 * 获取isDelete
	 * 
	 * @return isDelete
	 */
	public Integer getIsDelete() {
		return isDelete;
	}

	/**
	 * 设置isDelete
	 * 
	 * @param isDelete
	 */
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	/**
	 * 获取grade
	 * 
	 * @return grade
	 */
	public String getGrade() {
		return grade;
	}

	/**
	 * 设置grade
	 * 
	 * @param grade
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}

	/**
	 * 获取flowKey
	 * 
	 * @return flowKey
	 */
	public String getFlowKey() {
		return flowKey;
	}

	/**
	 * 设置flowKey
	 * 
	 * @param flowKey
	 */
	public void setFlowKey(String flowKey) {
		this.flowKey = flowKey;
	}

	/**
	 * 获取resultVerdictId
	 * 
	 * @return resultVerdictId
	 */
	public Integer getResultVerdictId() {
		return resultVerdictId;
	}

	/**
	 * 设置resultVerdictId
	 * 
	 * @param resultVerdictId
	 */
	public void setResultVerdictId(Integer resultVerdictId) {
		this.resultVerdictId = resultVerdictId;
	}

	/**
	 * 获取resultVerdictName
	 * 
	 * @return resultVerdictName
	 */
	public String getResultVerdictName() {
		return resultVerdictName;
	}

	/**
	 * 设置resultVerdictName
	 * 
	 * @param resultVerdictName
	 */
	public void setResultVerdictName(String resultVerdictName) {
		this.resultVerdictName = resultVerdictName;
	}

	/**
	 * 获取resultMemo
	 * 
	 * @return resultMemo
	 */
	public String getResultMemo() {
		return resultMemo;
	}

	/**
	 * 设置resultMemo
	 * 
	 * @param resultMemo
	 */
	public void setResultMemo(String resultMemo) {
		this.resultMemo = resultMemo;
	}

	/**
	 * 获取resultIdea
	 * 
	 * @return resultIdea
	 */
	public String getResultIdea() {
		return resultIdea;
	}

	/**
	 * 设置resultIdea
	 * 
	 * @param resultIdea
	 */
	public void setResultIdea(String resultIdea) {
		this.resultIdea = resultIdea;
	}

	/**
	 * 获取isHasScore
	 * 
	 * @return isHasScore
	 */
	public Integer getIsHasScore() {
		return isHasScore;
	}

	/**
	 * 设置isHasScore
	 * 
	 * @param isHasScore
	 */
	public void setIsHasScore(Integer isHasScore) {
		this.isHasScore = isHasScore;
	}

	/**
	 * 获取resultScore
	 * 
	 * @return resultScore
	 */
	public Integer getResultScore() {
		return resultScore;
	}

	/**
	 * 设置resultScore
	 * 
	 * @param resultScore
	 */
	public void setResultScore(Integer resultScore) {
		this.resultScore = resultScore;
	}

	/**
	 * 获取attachmentCode
	 * 
	 * @return attachmentCode
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**
	 * 设置attachmentCode
	 * 
	 * @param attachmentCode
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * 获取remark
	 * 
	 * @return remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * 设置remark
	 * 
	 * @param remark
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * 获取checkEnt
	 * 
	 * @return checkEnt
	 */
	public CheckEntInfo getCheckEnt() {
		return checkEnt;
	}

	/**
	 * 设置checkEnt
	 * 
	 * @param checkEnt
	 */
	public void setCheckEnt(CheckEntInfo checkEnt) {
		this.checkEnt = checkEnt;
	}

	/**
	 * 获取checkBeginDate
	 * 
	 * @return checkBeginDate
	 */
	public Date getCheckBeginDate() {
		return checkBeginDate;
	}

	/**
	 * 设置checkBeginDate
	 * 
	 * @param checkBeginDate
	 */
	public void setCheckBeginDate(Date checkBeginDate) {
		this.checkBeginDate = checkBeginDate;
	}

	/**
	 * 获取checkEndDate
	 * 
	 * @return checkEndDate
	 */
	public Date getCheckEndDate() {
		return checkEndDate;
	}

	/**
	 * 设置checkEndDate
	 * 
	 * @param checkEndDate
	 */
	public void setCheckEndDate(Date checkEndDate) {
		this.checkEndDate = checkEndDate;
	}

	/**
	 * 获取createTime
	 * 
	 * @return createTime
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * 设置createTime
	 * 
	 * @param createTime
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * 获取updateTime
	 * 
	 * @return updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * 设置updateTime
	 * 
	 * @param updateTime
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * 获取checkTypeId
	 * 
	 * @return checkTypeId
	 */
	public String getCheckTypeId() {
		return checkTypeId;
	}

	/**
	 * 设置checkTypeId
	 * 
	 * @param checkTypeId
	 */
	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	/**
	 * 获取checkTypeName
	 * 
	 * @return checkTypeName
	 */
	public String getCheckTypeName() {
		return checkTypeName;
	}

	/**
	 * 设置checkTypeName
	 * 
	 * @param checkTypeName
	 */
	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getUnitTaskId() {
		return unitTaskId;
	}

	public void setUnitTaskId(String unitTaskId) {
		this.unitTaskId = unitTaskId;
	}

	public String getDailyTableCode() {
		return dailyTableCode;
	}

	public void setDailyTableCode(String dailyTableCode) {
		this.dailyTableCode = dailyTableCode;
	}

	public int getIsFromMobile() {
		return isFromMobile;
	}

	public void setIsFromMobile(int isFromMobile) {
		this.isFromMobile = isFromMobile;
	}

	public String getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(String isCompleted) {
		this.isCompleted = isCompleted;
	}
	
	public String getIsTerminal() {
		return isTerminal;
	}

	public void setIsTerminal(String isTerminal) {
		this.isTerminal = isTerminal;
	}
}
