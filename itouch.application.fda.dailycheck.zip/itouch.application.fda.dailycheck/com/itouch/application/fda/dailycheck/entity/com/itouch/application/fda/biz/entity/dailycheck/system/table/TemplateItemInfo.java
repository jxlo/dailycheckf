/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:DcTemplateItem
 * @author:fanghailong
 * @time:2015-10-10 下午2:56:07
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * @author:fanghailong 
 * 模板条款
 */
@Entity
@Table(name="DC_TEMPLATE_ITEM")
public class TemplateItemInfo implements IBusinessObject {
	
	/**条款Id */
	@Id
	@Column(name="ITEM_ID")
	private String itemId;
	
	/**小项Id */
	@Column(name="SMALL_SUBJECT_ID")
	private String smallSubjectId;
	
	/**标识符 */
	@Column(name="SUBJECT_ID")
	private String subjectId;
	
	/**模板Id */
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**是否重点项*/
	@Column(name="IS_EMPHASIS")
	private Integer isEmphasis;
	
	/**是否否决项*/
	@Column(name="IS_VETO")
	private Integer isVeto;
	
	/**编号 */
	@Column(name="NO")
	private String no;
	
	@Transient
	public List<TemplateDetailInfo> templateDetailInfoList = new ArrayList<TemplateDetailInfo>();

	/**得分*/
	@Transient
	private String scoring = "0";
	
	/**标准分*/
	@Transient
	private String standardscore = "0";
	
	/**扣分理由*/
	@Transient
	private String memo = "";
	
	/**选中项*/
	@Transient
	private String selection;
	
	public String getScoring() {
		return scoring;
	}

	public void setScoring(String scoring) {
		this.scoring = scoring;
	}

	public String getStandardscore() {
		return standardscore;
	}

	public void setStandardscore(String standardscore) {
		this.standardscore = standardscore;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getSelection() {
		return selection;
	}

	public void setSelection(String selection) {
		this.selection = selection;
	}

	/**
	 * @Description:获取条款Id
	 * @return:itemId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public String getItemId() {
		return itemId;
	}

	/**
	 * @Description:设置条款Id
	 * @param：itemId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	/**
	 * @Description:获取小项Id 
	 * @return:smallSubjectId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public String getSmallSubjectId() {
		return smallSubjectId;
	}

	/**
	 * @Description:设置小项Id 
	 * @param：smallSubjectId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public void setSmallSubjectId(String smallSubjectId) {
		this.smallSubjectId = smallSubjectId;
	}

	/**
	 * @Description:获取标识符
	 * @return:subjectId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public String getSubjectId() {
		return subjectId;
	}

	/**
	 * @Description:设置标识符
	 * @param：subjectId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	/**
	 * @Description:获取是否重点项
	 * @return:templateId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @Description:设置是否重点项
	 * @param：templateId
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @Description:获取是否否决项
	 * @return:isEmphasis
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public Integer getIsEmphasis() {
		return isEmphasis;
	}

	/**
	 * @Description:设置是否否决项
	 * @param：isEmphasis
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public void setIsEmphasis(Integer isEmphasis) {
		this.isEmphasis = isEmphasis;
	}

	/**
	 * @Description:获取
	 * @return:isVeto
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public Integer getIsVeto() {
		return isVeto;
	}

	/**
	 * @Description:设置
	 * @param：isVeto
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public void setIsVeto(Integer isVeto) {
		this.isVeto = isVeto;
	}

	/**
	 * @Description:获取编号
	 * @return:no
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public String getNo() {
		return no;
	}

	/**
	 * @Description:设置编号
	 * @param：no
	 * @author:fanghailong
	 * @time:2015-10-10 下午3:22:33
	 */
	public void setNo(String no) {
		this.no = no;
	}
}
