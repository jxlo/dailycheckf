package com.itouch.application.fda.biz.entity.dailycheck.check;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author:zhangzt
 *
 */
@Entity
@Table(name = "V_DC_CHECK_TODO")
public class VCheckTodoInfo implements IBusinessObject {

	private static final long serialVersionUID = 1L;

	/* 待办Id */
	@Id
	@Column(name = "TODO_ID")
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String todoId;
	/* 检查记录id */
	@Column(name = "CHECK_ID")
	private String checkId;
	/* 业务外键 */
	@Column(name = "FROM_KEY")
	private String fromKey;
	/* 检查类型id */
	@Column(name = "CHECK_TYPE_ID")
	private String checkTypeId;
	/* 检查类型名称 */
	@Column(name = "CHECK_TYPE_NAME")
	private String checkTypeName;
	/* 转入应用编码 */
	@Column(name = "FROM_APP_CODE")
	private String fromAppCode;
	/* 转入应用名称 */
	@Column(name = "FROM_APP_NAME")
	private String fromAppName;
	/* 转入单位编号 */
	@Column(name = "FROM_UNIT_ID")
	private String fromUnitId;
	/* 转入单位名称 */
	@Column(name = "FROM_UNIT_NAME")
	private String fromUnitName;
	/* 转入部门编号 */
	@Column(name = "FROM_DEPT_ID")
	private String fromDeptId;
	/* 转入部门名称 */
	@Column(name = "FROM_DEPT_NAME")
	private String fromDeptName;
	/* 转入人id */
	@Column(name = "FROM_USER_ID")
	private String fromUserId;
	/* 转入人 */
	@Column(name = "FROM_USER_NAME")
	private String fromUserName;
	/* 转入时间 */
	@Column(name = "FROM_TIME")
	private Date fromTime;
	/* 承办单位id */
	@Column(name = "TO_UNIT_ID")
	private String toUnitId;
	/* 承办单位名称 */
	@Column(name = "TO_UNIT_NAME")
	private String toUnitName;
	/* 承办部门id */
	@Column(name = "TO_DEPT_ID")
	private String toDeptId;
	/* 承办部门名称 */
	@Column(name = "TO_DEPT_NAME")
	private String toDeptName;
	/* 承办人id */
	@Column(name = "TO_USER_ID")
	private String toUserId;
	/* 承办人 */
	@Column(name = "TO_USER_NAME")
	private String toUserName;
	/* 是否完成 */
	@Column(name = "IS_FINISHED")
	private int isFinished;
	/* 附件组号 */
	@Column(name = "ATTACHMENT_CODE")
	private String attachmentCode;
	/* 流程编码 */
	@Column(name = "FLOW_KEY")
	private String flowKey;
	/* 备注 */
	@Column(name = "REMARK")
	private String remark;

	@Column(name = "ENT_CODE")
	private String entCode;
	/** 企业名称 */
	@Column(name = "ENT_NAME")
	private String entName;

	/** @Fields entTypeId : 企业类型Id **/
	@Column(name = "ENT_TYPE_ID")
	private String entTypeId;

	/** @Fields entTypeName : 企业类型名称 **/
	@Column(name = "ENT_TYPE_NAME")
	private String entTypeName;

	/** @Fields entTypeGroupId : 企业类型分组Id **/
	@Column(name = "ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;

	/** @Fields entTypeGroupName : 企业类型分组名称 **/
	@Column(name = "ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;
	/* 单位Id */
	@Column(name = "Unit_Id")
	private String unitId;
	/* 单位名称 */
	@Column(name = "Unit_Name")
	private String unitName;
	/* 地区编码 */
	@Column(name = "Area_Code")
	private String areaCode;
	/* 地区名称 */
	@Column(name = "Area_Name")
	private String areaName;
	/* 企业注册地址 */
	@Column(name = "REG_ADDR")
	private String regAddr;
	/* 企业注册地址邮编 */
	@Column(name = "REG_ADDR_POSTAL_CODE")
	private String regAddrPostalCode;
	/* 企业电话 */
	@Column(name = "ENT_TEL")
	private String entTel;
	/* 企业负责人 */
	@Column(name = "ENT_PRINCIPAL")
	private String entPrincipal;

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	/**
	 * @Description: 获取{note}
	 * @return regAddr{note}
	 * @author:liss
	 * @time:2016年6月6日 上午10:07:50
	 */
	public String getRegAddr() {
		return regAddr;
	}

	/**
	 * @Description: 设置{note}
	 * @return regAddr{note}
	 * @author:liss
	 * @time:2016年6月6日 上午10:07:50
	 */
	public void setRegAddr(String regAddr) {
		this.regAddr = regAddr;
	}

	/**
	 * @Description: 获取{note}
	 * @return regAddrPostalCode{note}
	 * @author:liss
	 * @time:2016年6月7日 下午2:12:57
	 */
	public String getRegAddrPostalCode() {
		return regAddrPostalCode;
	}

	/**
	 * @Description: 设置{note}
	 * @return regAddrPostalCode{note}
	 * @author:liss
	 * @time:2016年6月7日 下午2:12:57
	 */
	public void setRegAddrPostalCode(String regAddrPostalCode) {
		this.regAddrPostalCode = regAddrPostalCode;
	}

	/**
	 * @Description: 获取{note}
	 * @return entTel{note}
	 * @author:liss
	 * @time:2016年6月7日 下午2:12:57
	 */
	public String getEntTel() {
		return entTel;
	}

	/**
	 * @Description: 设置{note}
	 * @return entTel{note}
	 * @author:liss
	 * @time:2016年6月7日 下午2:12:57
	 */
	public void setEntTel(String entTel) {
		this.entTel = entTel;
	}

	/**
	 * @Description: 获取{note}
	 * @return entPrincipal{note}
	 * @author:liss
	 * @time:2016年6月7日 下午2:12:57
	 */
	public String getEntPrincipal() {
		return entPrincipal;
	}

	/**
	 * @Description: 设置{note}
	 * @return entPrincipal{note}
	 * @author:liss
	 * @time:2016年6月7日 下午2:12:57
	 */
	public void setEntPrincipal(String entPrincipal) {
		this.entPrincipal = entPrincipal;
	}

	public String getTodoId() {
		return todoId;
	}

	public void setTodoId(String todoId) {
		this.todoId = todoId;
	}

	public String getCheckId() {
		return checkId;
	}

	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	public String getFromKey() {
		return fromKey;
	}

	public void setFromKey(String fromKey) {
		this.fromKey = fromKey;
	}

	public String getCheckTypeId() {
		return checkTypeId;
	}

	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	public String getCheckTypeName() {
		return checkTypeName;
	}

	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	public String getFromAppCode() {
		return fromAppCode;
	}

	public void setFromAppCode(String fromAppCode) {
		this.fromAppCode = fromAppCode;
	}

	public String getFromAppName() {
		return fromAppName;
	}

	public void setFromAppName(String fromAppName) {
		this.fromAppName = fromAppName;
	}

	public String getFromUnitId() {
		return fromUnitId;
	}

	public void setFromUnitId(String fromUnitId) {
		this.fromUnitId = fromUnitId;
	}

	public String getFromUnitName() {
		return fromUnitName;
	}

	public void setFromUnitName(String fromUnitName) {
		this.fromUnitName = fromUnitName;
	}

	public String getFromUserId() {
		return fromUserId;
	}

	public void setFromUserId(String fromUserId) {
		this.fromUserId = fromUserId;
	}

	public String getFromUserName() {
		return fromUserName;
	}

	public void setFromUserName(String fromUserName) {
		this.fromUserName = fromUserName;
	}

	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public String getToUnitId() {
		return toUnitId;
	}

	public void setToUnitId(String toUnitId) {
		this.toUnitId = toUnitId;
	}

	public String getToUnitName() {
		return toUnitName;
	}

	public void setToUnitName(String toUnitName) {
		this.toUnitName = toUnitName;
	}

	public String getToDeptId() {
		return toDeptId;
	}

	public void setToDeptId(String toDeptId) {
		this.toDeptId = toDeptId;
	}

	public String getToDeptName() {
		return toDeptName;
	}

	public void setToDeptName(String toDeptName) {
		this.toDeptName = toDeptName;
	}

	public String getToUserId() {
		return toUserId;
	}

	public void setToUserId(String toUserId) {
		this.toUserId = toUserId;
	}

	public String getToUserName() {
		return toUserName;
	}

	public void setToUserName(String toUserName) {
		this.toUserName = toUserName;
	}

	public int getIsFinished() {
		return isFinished;
	}

	public void setIsFinished(int isFinished) {
		this.isFinished = isFinished;
	}

	public String getAttachmentCode() {
		return attachmentCode;
	}

	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	public String getFlowKey() {
		return flowKey;
	}

	public void setFlowKey(String flowKey) {
		this.flowKey = flowKey;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getEntCode() {
		return entCode;
	}

	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getEntTypeId() {
		return entTypeId;
	}

	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	public String getEntTypeName() {
		return entTypeName;
	}

	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}

	public String getFromDeptId() {
		return fromDeptId;
	}

	public void setFromDeptId(String fromDeptId) {
		this.fromDeptId = fromDeptId;
	}

	public String getFromDeptName() {
		return fromDeptName;
	}

	public void setFromDeptName(String fromDeptName) {
		this.fromDeptName = fromDeptName;
	}

}
