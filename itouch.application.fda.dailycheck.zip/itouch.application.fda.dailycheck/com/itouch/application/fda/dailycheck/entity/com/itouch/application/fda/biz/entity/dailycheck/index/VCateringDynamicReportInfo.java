package com.itouch.application.fda.biz.entity.dailycheck.index;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: VCateringDynamicReport 
 * @author: wangk
 * @date: 2016-3-28 下午1:50:17  
 */
@Entity
@Table(name="V_DC_CATERING_DYNAMIC_REPORT")
public class VCateringDynamicReportInfo implements IBusinessObject{
	
	/** 监管单位编号 **/
	@Id
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** 监管单位名称 **/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** 评级年份 **/
	@Column(name="credit_year")
	private Integer creditYear;
	
	/** 优秀（A） **/
	@Column(name="CREDITVALUEA")
	private Integer creditValueA;
	
	/** 良好（A） **/
	@Column(name="CREDITVALUEB")
	private Integer creditValueB;
	
	/** 一般（C） **/
	@Column(name="CREDITVALUEC")
	private Integer creditValueC;

	/**
	 * @Description: 获取 监管单位编号
	 * @return: unitId
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public String getUnitId() {
		return unitId;
	}

	/**   
	 * @Description: 设置 监管单位编号   
	 * @param: unitId 
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description: 获取 监管单位名称
	 * @return: unitName
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public String getUnitName() {
		return unitName;
	}

	/**   
	 * @Description: 设置 监管单位名称   
	 * @param: unitName 
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description: 获取 优秀（A）
	 * @return: creditValueA
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public Integer getCreditValueA() {
		return creditValueA;
	}

	/**   
	 * @Description: 设置 优秀（A）   
	 * @param: creditValueA 
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public void setCreditValueA(Integer creditValueA) {
		this.creditValueA = creditValueA;
	}

	/**
	 * @Description: 获取 良好（A）
	 * @return: creditValueB
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public Integer getCreditValueB() {
		return creditValueB;
	}

	/**   
	 * @Description: 设置 良好（A）   
	 * @param: creditValueB 
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public void setCreditValueB(Integer creditValueB) {
		this.creditValueB = creditValueB;
	}

	/**
	 * @Description: 获取 一般（C）
	 * @return: creditValueC
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public Integer getCreditValueC() {
		return creditValueC;
	}

	/**   
	 * @Description: 设置 一般（C）   
	 * @param: creditValueC 
	 * @author: wangk
	 * @date: 2016-3-28 下午1:55:36 
	 */
	public void setCreditValueC(Integer creditValueC) {
		this.creditValueC = creditValueC;
	}

	/**
	 * @Description: 获取 评级年份
	 * @return: creditYear
	 * @author: wangk
	 * @date: 2016-3-28 下午5:44:04 
	 */
	public Integer getCreditYear() {
		return creditYear;
	}

	/**   
	 * @Description: 设置 评级年份   
	 * @param: creditYear 
	 * @author: wangk
	 * @date: 2016-3-28 下午5:44:04 
	 */
	public void setCreditYear(Integer creditYear) {
		this.creditYear = creditYear;
	}
}
