/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:DcTemplate.java
 * @author:xh
 * @time:2015-10-10 下午3:05:14
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


/**
 *
 * @author xh
 */
@Entity
@Table(name="DC_TEMPLATE")
public class TemplateInfo implements IBusinessObject {
	
	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = -7669278981445972376L;
	
	//默认构造函数
	public TemplateInfo(){
		this.templateId=UUID.randomUUID().toString().replace("-","");
	}

	/**模板Id*/
	@Id
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**模板名称*/
	@Column(name ="TEMPLATE_NAME")
	private String templateName;
	
	/**部门Id*/
	@Column(name ="DEPT_ID")
	private String deptId;
	
	/**部门名称*/
	@Column(name ="DEPT_NAME")
	private String deptName;
	
	/**单位Id*/
	@Column(name ="UNIT_ID")
	private String unitId;
	
	/**单位名称*/
	@Column(name ="UNIT_NAME")
	private String unitName;
	
	/**是否启用项目分数*/
	@Column(name ="IS_ENABLED_SCORE")
	private Integer isEnabledScore;
	
	/**是否启用项目*/
	@Column(name ="IS_ENABLED_SUBJECT")
	private String isEnabledSubject;
	
	/**是否启用小项*/
	@Column(name ="IS_ENABLED_SMALL_SUBJECT")
	private String isEnabledSmallSubject;
	
	/**是否是信用检查表*/
	@Column(name ="IS_CREDIT_TABLE")
	private Integer isCreditTable;
	
	/**停用日期*/
	@Column(name ="STOP_DATE")
	private Date stopDate;
	
	/**状态*/
	@Column(name ="STATE")
	private Integer state;
	
	/**创建日期*/
	@Column(name ="CREATE_DATE")
	private Date createDate;
	
	/**备注*/
	@Column(name ="REMARK")
	private String remark;
	
	/**检查**/
	@OneToMany(targetEntity=TemplateCheckTypeInfo.class,cascade={CascadeType.ALL},mappedBy="template")
	@Fetch(FetchMode.SUBSELECT)
	private List<TemplateCheckTypeInfo> templateCheckTypes = new ArrayList<TemplateCheckTypeInfo>();
	
	@Transient
	private List<TableInfo> tableList;

	public List<TableInfo> getTableList() {
		return tableList;
	}

	public void setTableList(List<TableInfo> tableList) {
		this.tableList = tableList;
	}

	/**
	 * 获取templateId
	 * @return templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**  
	 * 设置templateId  
	 * @param templateId
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * 获取templateName
	 * @return templateName
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**  
	 * 设置templateName  
	 * @param templateName
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * 获取deptId
	 * @return deptId
	 */
	public String getDeptId() {
		return deptId;
	}

	/**  
	 * 设置deptId  
	 * @param deptId
	 */
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	/**
	 * 获取deptName
	 * @return deptName
	 */
	public String getDeptName() {
		return deptName;
	}

	/**  
	 * 设置deptName  
	 * @param deptName
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/**
	 * 获取unitId
	 * @return unitId
	 */
	public String getUnitId() {
		return unitId;
	}

	/**  
	 * 设置unitId  
	 * @param unitId
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * 获取unitName
	 * @return unitName
	 */
	public String getUnitName() {
		return unitName;
	}

	/**  
	 * 设置unitName  
	 * @param unitName
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	
	/**
	 * 获取isEnabledScore
	 * @return isEnabledScore
	 */
	public Integer getIsEnabledScore() {
		return isEnabledScore;
	}

	/**  
	 * 设置isEnabledScore  
	 * @param isEnabledScore
	 */
	public void setIsEnabledScore(Integer isEnabledScore) {
		this.isEnabledScore = isEnabledScore;
	}

	/**
	 * 获取isCreditTable
	 * @return isCreditTable
	 */
	public Integer getIsCreditTable() {
		return isCreditTable;
	}

	/**  
	 * 设置isCreditTable  
	 * @param isCreditTable
	 */
	public void setIsCreditTable(Integer isCreditTable) {
		this.isCreditTable = isCreditTable;
	}

	/**
	 * 获取stopDate
	 * @return stopDate
	 */
	public Date getStopDate() {
		return stopDate;
	}

	/**  
	 * 设置stopDate  
	 * @param stopDate
	 */
	public void setStopDate(Date stopDate) {
		this.stopDate = stopDate;
	}

	/**
	 * 获取state
	 * @return state
	 */
	public Integer getState() {
		return state;
	}

	/**  
	 * 设置state  
	 * @param state
	 */
	public void setState(Integer state) {
		this.state = state;
	}

	/**
	 * 获取createDate
	 * @return createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**  
	 * 设置createDate  
	 * @param createDate
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
	 * 获取remark
	 * @return remark
	 */
	public String getRemark() {
		return remark;
	}

	/**  
	 * 设置remark  
	 * @param remark
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * 获取templateCheckTypes
	 * @return templateCheckTypes
	 */
	public List<TemplateCheckTypeInfo> getTemplateCheckTypes() {
		return templateCheckTypes;
	}

	/**  
	 * 设置templateCheckTypes  
	 * @param templateCheckTypes
	 */
	public void setTemplateCheckTypes(List<TemplateCheckTypeInfo> templateCheckTypes) {
		this.templateCheckTypes = templateCheckTypes;
	}

	public String getIsEnabledSubject() {
		return isEnabledSubject;
	}

	public void setIsEnabledSubject(String isEnabledSubject) {
		this.isEnabledSubject = isEnabledSubject;
	}

	public String getIsEnabledSmallSubject() {
		return isEnabledSmallSubject;
	}

	public void setIsEnabledSmallSubject(String isEnabledSmallSubject) {
		this.isEnabledSmallSubject = isEnabledSmallSubject;
	}

	
}
