/**  
* @Title: DcTemplateSubject.java 
* @Package com.itouch.application.fda.biz.entity.dailycheck.system.table 
* @author wangk    
* @date 2015-10-10 下午3:31:01  
*/ 
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author wangk
 * @Description: 检查模板项目 
 * @date 2015-10-10 下午3:31:01  
 */
@Entity
@Table(name="DC_TEMPLATE_SUBJECT")
public class TemplateSubjectInfo {
	
	/**标识符**/
	@Id
	@Column(name="SUBJECT_ID")
	private String subjectId;
	
	/**模板Id**/
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**文本**/
	@Column(name="TEXT")
	private String text;
	
	/**编号**/
	@Column(name="NO")
	private String no;
	
	/**项目分数**/
	@Column(name="SCORE")
	private String score;

	@Transient
	public List<TemplateSmallSubjectInfo> templateSmallSubjectInfoList = new ArrayList<TemplateSmallSubjectInfo>();
	
	@Transient
	public List<TemplateItemInfo> templateItemInfoList = new ArrayList<TemplateItemInfo>();
	
	/**
	 * 获取subjectId
	 * @return subjectId
	 */
	public String getSubjectId() {
		return subjectId;
	}

	/**  
	 * 设置subjectId  
	 * @param subjectId
	 */
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	/**
	 * 获取templateId
	 * @return templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**  
	 * 设置templateId  
	 * @param templateId
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * 获取text
	 * @return text
	 */
	public String getText() {
		return text;
	}

	/**  
	 * 设置text  
	 * @param text
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * 获取no
	 * @return no
	 */
	public String getNo() {
		return no;
	}

	/**  
	 * 设置no  
	 * @param no
	 */
	public void setNo(String no) {
		this.no = no;
	}

	/**
	 * 获取score
	 * @return score
	 */
	public String getScore() {
		return score;
	}

	/**  
	 * 设置score  
	 * @param score
	 */
	public void setScore(String score) {
		this.score = score;
	}
	
}
