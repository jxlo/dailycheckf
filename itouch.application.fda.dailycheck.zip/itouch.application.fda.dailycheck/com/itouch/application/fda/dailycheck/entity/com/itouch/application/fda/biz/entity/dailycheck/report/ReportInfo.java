package com.itouch.application.fda.biz.entity.dailycheck.report;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.itouch.application.fda.biz.entity.dailycheck.system.report.ReportFormInfo;
import com.itouch.application.fda.foundation.runtime.AppUser;
import com.itouch.application.fda.foundation.util.GlobalUtil;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: ReportInfo
 * @author: wangk
 * @date: 2016-3-16 下午1:50:02
 */
@Entity
@Table(name = "DC_REPORT")
public class ReportInfo implements IBusinessObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 默认构造函数
	 */
	public ReportInfo() {
		this.setReportId(GlobalUtil.createUUID());
	}

	/**
	 * 从报表表单构造报表信息
	 * 
	 * @param form
	 */
	public ReportInfo(ReportFormInfo form) {
		this();
		if (null != form) {
			this.setFormCode(form.getFormCode());
			this.setFormName(form.getFormName());
		}
	}

	/**
	 * 从报表表单构造报表信息
	 */
	public ReportInfo(ReportFormInfo form, AppUser user) {
		this(form);
		if (null != user) {

			this.setCreatorId(user.getUserId());
			this.setCreatorName(user.getUserName());
			this.setCreateTime(new Date());
			
			this.setUpdateUserId(user.getUserId());
			this.setUpdateUserName(user.getUserName());
			this.setUpdateTime(new Date());
			
			this.setUnitId(user.getUnitId());
			this.setUnitName(user.getUnitName());
		}
	}

	/** 报表Id **/
	@Id
	@Column(name = "REPORT_ID")
	private String reportId;

	/** 表单编码 **/
	@Column(name = "FORM_CODE")
	private String formCode;

	/** 表单名称 **/
	@Column(name = "FORM_NAME")
	private String formName;

	/** 报送单位Id **/
	@Column(name = "UNIT_ID",updatable=false)
	private String unitId;

	/** 报送单位名称 **/
	@Column(name = "UNIT_NAME",updatable=false)
	private String unitName;

	/** 创建人Id **/
	@Column(name = "CREATOR_ID",updatable=false)
	private String creatorId;

	/** 创建人姓名 **/
	@Column(name = "CREATOR_NAME",updatable=false)
	private String creatorName;

	/** 创建时间 **/
	@Column(name = "CREATE_TIME",updatable=false)
	private Date createTime;

	/** 更新人Id **/
	@Column(name = "UPDATE_USER_ID")
	private String updateUserId;

	/** 更新人 **/
	@Column(name = "UPDATE_USER_NAME")
	private String updateUserName;

	/** 更新时间 **/
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	/** 报表状态Id **/
	@Column(name = "REPORT_STATE_ID")
	private String reportStateId;

	/** 报表状态 **/
	@Column(name = "REPORT_STATE_NAME")
	private String reportStateName;

	/** 备注 **/
	@Column(name = "REMARK")
	private String remark;
	
	/** 附件组号 **/ 
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;

	/**
	 * @Description: 获取 报表Id
	 * @return: reportId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getReportId() {
		return reportId;
	}

	/**
	 * @Description: 设置 报表Id
	 * @param: reportId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	/**
	 * @Description: 获取 表单编码
	 * @return: formCode
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getFormCode() {
		return formCode;
	}

	/**
	 * @Description: 设置 表单编码
	 * @param: formCode
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setFormCode(String formCode) {
		this.formCode = formCode;
	}

	/**
	 * @Description: 获取 表单名称
	 * @return: formName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getFormName() {
		return formName;
	}

	/**
	 * @Description: 设置 表单名称
	 * @param: formName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setFormName(String formName) {
		this.formName = formName;
	}

	/**
	 * @Description: 获取 报送单位Id
	 * @return: unitId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description: 设置 报送单位Id
	 * @param: unitId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description: 获取 报送单位名称
	 * @return: unitName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description: 设置 报送单位名称
	 * @param: unitName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description: 获取 创建人Id
	 * @return: creatorId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getCreatorId() {
		return creatorId;
	}

	/**
	 * @Description: 设置 创建人Id
	 * @param: creatorId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	/**
	 * @Description: 获取 创建人姓名
	 * @return: creatorName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getCreatorName() {
		return creatorName;
	}

	/**
	 * @Description: 设置 创建人姓名
	 * @param: creatorName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	/**
	 * @Description: 获取 创建时间
	 * @return: createTime
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * @Description: 设置 创建时间
	 * @param: createTime
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * @Description: 获取 更新人Id
	 * @return: updateUserId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getUpdateUserId() {
		return updateUserId;
	}

	/**
	 * @Description: 设置 更新人Id
	 * @param: updateUserId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	/**
	 * @Description: 获取 更新人
	 * @return: updateUserName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getUpdateUserName() {
		return updateUserName;
	}

	/**
	 * @Description: 设置 更新人
	 * @param: updateUserName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setUpdateUserName(String updateUserName) {
		this.updateUserName = updateUserName;
	}

	/**
	 * @Description: 获取 更新时间
	 * @return: updateTime
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * @Description: 设置 更新时间
	 * @param: updateTime
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @Description: 获取 报表状态Id
	 * @return: reportStateId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getReportStateId() {
		return reportStateId;
	}

	/**
	 * @Description: 设置 报表状态Id
	 * @param: reportStateId
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setReportStateId(String reportStateId) {
		this.reportStateId = reportStateId;
	}

	/**
	 * @Description: 获取 报表状态
	 * @return: reportStateName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getReportStateName() {
		return reportStateName;
	}

	/**
	 * @Description: 设置 报表状态
	 * @param: reportStateName
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setReportStateName(String reportStateName) {
		this.reportStateName = reportStateName;
	}

	/**
	 * @Description: 获取 备注
	 * @return: remark
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description: 设置 备注
	 * @param: remark
	 * @author: wangk
	 * @date: 2016-3-16 下午1:54:33
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @Description: 获取 附件组号
	 * @return: attachmentCode
	 * @author: wangk
	 * @date: 2016-3-29 上午10:41:47 
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**   
	 * @Description: 设置 附件组号   
	 * @param: attachmentCode 
	 * @author: wangk
	 * @date: 2016-3-29 上午10:41:47 
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}
}
