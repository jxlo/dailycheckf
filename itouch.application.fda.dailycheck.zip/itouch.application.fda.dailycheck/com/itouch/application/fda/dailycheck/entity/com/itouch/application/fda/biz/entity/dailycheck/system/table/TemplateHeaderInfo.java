/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateHeader.java
 * @author:fanghailong
 * @time:2015-10-12 下午4:03:41
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author:fanghailong 
 */
@Entity
@Table(name="DC_TEMPLATE_Header")
public class TemplateHeaderInfo implements IBusinessObject{
	
	/**标题Id*/
	@Id
	@Column(name="HEADER_ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String headerId;
	
	/**模板Id*/
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**标题文本*/
	@Column(name="TEXT")
	private String text;
	
	/**排序号*/
	@Column(name="ORDER_NUMBER")
	private String orderNumber;

	/**
	 * @Description:获取{note}
	 * @return:headerId
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public String getHeaderId() {
		return headerId;
	}

	/**
	 * @Description:设置{note}
	 * @param：headerId
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}

	/**
	 * @Description:获取{note}
	 * @return:templateId
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @Description:设置{note}
	 * @param：templateId
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @Description:获取{note}
	 * @return:text
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public String getText() {
		return text;
	}

	/**
	 * @Description:设置{note}
	 * @param：text
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @Description:获取{note}
	 * @return:orderNumber
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public String getOrderNumber() {
		return orderNumber;
	}

	/**
	 * @Description:设置{note}
	 * @param：orderNumber
	 * @author:fanghailong
	 * @time:2015-10-12 下午4:09:56
	 */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	
}
