/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableHeader.java
 * @author:fanghailong
 * @time:2015-10-12 上午11:29:05
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author:fanghailong 
 */
@Entity
@Table(name="DC_Check_TABLE_Header")
public class TableHeaderInfo implements IBusinessObject{
	
	/**主键Id */
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**模板id */
	@Column(name="TEMPLATE")
	private String templateId;
	
	/**检查表id*/
	@Column(name="TABLE_ID")
	private String tableId;
	
	/**文本 */
	@Column(name="TEXT")
	private String text;
	
	/**单元格类型*/
	@Column(name="CELL_TYPE")
	private String cellType;

	/**
	 * @Description:获取主键Id
	 * @return:id
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public String getId() {
		return id;
	}

	/**
	 * @Description:设置主键Id     
	 * @param：id
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description:获取模板id 
	 * @return:templateId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @Description:设置模板id 
	 * @param：templateId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @Description:获取检查表id
	 * @return:tableId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * @Description:设置检查表id
	 * @param：tableId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * @Description:获取文本 
	 * @return:text
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public String getText() {
		return text;
	}

	/**
	 * @Description:设置文本 
	 * @param：text
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @Description:获取单元格类型
	 * @return:cellType
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public String getCellType() {
		return cellType;
	}

	/**
	 * @Description:设置单元格类型
	 * @param：cellType
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:32:33
	 */
	public void setCellType(String cellType) {
		this.cellType = cellType;
	}
	
	
}
