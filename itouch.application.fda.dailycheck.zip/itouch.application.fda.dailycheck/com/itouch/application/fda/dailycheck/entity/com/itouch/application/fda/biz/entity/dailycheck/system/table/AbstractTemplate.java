/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:AbstractTemplate.java
 * @author:zhangzt
 * @time:2015年10月10日 下午8:02:06
 */

package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import java.util.List;

/**
 * @author:zhangzt
 *
 */
public class AbstractTemplate {

	// 模板信息
	public TemplateInfo templateInfo;
	//模板列集合
	public List<TemplateHeaderInfo> templateHeaderInfoList;
	// 模板检查类型集合
	public List<TemplateCheckTypeInfo> templateCheckTypeInfoList;
	// 大项集合
	public List<TemplateSubjectInfo> templateSubjectInfoList;
	// 小项集合
	public List<TemplateSmallSubjectInfo> templateSmallSubjectInfoList;
	// 条款集合
	public List<TemplateItemInfo> templateItemInfoList;
	// 条款明细集合
	public List<TemplateDetailInfo> templateDetailInfoList;
	//选择题的答案
    public List<TableOptionInfo> choicequestionsolutionlist;
    
	//构造函数
	public AbstractTemplate(){
		this.setTemplateInfo(new TemplateInfo());
	}
	
	public List<TableOptionInfo> getChoicequestionsolutionlist() {
		return choicequestionsolutionlist;
	}

	public void setChoicequestionsolutionlist(
			List<TableOptionInfo> choicequestionsolutionlist) {
		this.choicequestionsolutionlist = choicequestionsolutionlist;
	}

	/**
	 * @Description: 获取{note}
	 * @return templateHeaderInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月12日 下午6:01:53
	 */
	public List<TemplateHeaderInfo> getTemplateHeaderInfoList() {
		return templateHeaderInfoList;
	}

	/**
	 * @Description: 设置 {note}
	 * @param templateHeaderInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月12日 下午6:01:53
	 */
	public void setTemplateHeaderInfoList(List<TemplateHeaderInfo> templateHeaderInfoList) {
		this.templateHeaderInfoList = templateHeaderInfoList;
	}

	/**
	 * @Description: 获取{note}
	 * @return templateInfo {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public TemplateInfo getTemplateInfo() {
		return templateInfo;
	}

	/**
	 * @Description: 设置 {note}
	 * @param templateInfo
	 *            {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public void setTemplateInfo(TemplateInfo templateInfo) {
		this.templateInfo = templateInfo;
	}

	/**
	 * @Description: 获取{note}
	 * @return templateCheckTypeInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public List<TemplateCheckTypeInfo> getTemplateCheckTypeInfoList() {
		return templateCheckTypeInfoList;
	}

	/**
	 * @Description: 设置 {note}
	 * @param templateCheckTypeInfoList
	 *            {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public void setTemplateCheckTypeInfoList(
			List<TemplateCheckTypeInfo> templateCheckTypeInfoList) {
		this.templateCheckTypeInfoList = templateCheckTypeInfoList;
	}

	/**
	 * @Description: 获取{note}
	 * @return templateSubjectInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public List<TemplateSubjectInfo> getTemplateSubjectInfoList() {
		return templateSubjectInfoList;
	}

	/**
	 * @Description: 设置 {note}
	 * @param templateSubjectInfoList
	 *            {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public void setTemplateSubjectInfoList(
			List<TemplateSubjectInfo> templateSubjectInfoList) {
		this.templateSubjectInfoList = templateSubjectInfoList;
	}

	/**
	 * @Description: 获取{note}
	 * @return templateSmallSubjectInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public List<TemplateSmallSubjectInfo> getTemplateSmallSubjectInfoList() {
		return templateSmallSubjectInfoList;
	}

	/**
	 * @Description: 设置 {note}
	 * @param templateSmallSubjectInfoList
	 *            {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public void setTemplateSmallSubjectInfoList(
			List<TemplateSmallSubjectInfo> templateSmallSubjectInfoList) {
		this.templateSmallSubjectInfoList = templateSmallSubjectInfoList;
	}

	/**
	 * @Description: 获取{note}
	 * @return templateItemInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public List<TemplateItemInfo> getTemplateItemInfoList() {
		return templateItemInfoList;
	}

	/**
	 * @Description: 设置 {note}
	 * @param templateItemInfoList
	 *            {note}
	 * @author:zhangzt
	 * @time:2015年10月10日 下午8:06:11
	 */
	public void setTemplateItemInfoList(
			List<TemplateItemInfo> templateItemInfoList) {
		this.templateItemInfoList = templateItemInfoList;
	}

	/**
	 * @Description: 获取{note}
	 * @return templateDetailInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:31:12
	 */
	public List<TemplateDetailInfo> getTemplateDetailInfoList() {
		return templateDetailInfoList;
	}

	/**
	 * @Description: 设置 {note}
	 * @param templateDetailInfoList {note}
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:31:12
	 */
	public void setTemplateDetailInfoList(
			List<TemplateDetailInfo> templateDetailInfoList) {
		this.templateDetailInfoList = templateDetailInfoList;
	}
}
