/**
 * @Description:TODO
 * @project:itouch.application.fda.dailycheck
 * @class:VFoodProdDailycheckStatisticsInfo.java
 * @author:fanghailong
 * @time:2016-1-9 下午3:41:01
 */
package com.itouch.application.fda.biz.entity.dailycheck.report;

import iTouch.framework.data.operation.IBusinessObject;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author:fanghailong 
 */
@Entity
@Table(name="V_FOOD_PROD_DAILYCHECK")
public class VFoodProdDailycheckStatisticsInfo implements IBusinessObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="CHECK_ID")
	private String checkId;

	/**企业id**/
	@Column(name="ENT_ID")
	private String entId;
	
	/**企业类型分组id**/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/**监管单位id*/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/**监管单位名称*/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/**检查开始时间*/
	@Column(name="CHECK_BEGIN_DATE")
	private Date checkBeginDate;
	
	/**检查结束时间*/
	@Column(name="CHECK_END_DATE")
	private Date checkEndDate;
	
	/**检查人员id*/
	@Column(name="CHECK_USER_Ids")
	private String checkUserIds;
	
	/**检查结果id*/
	@Column(name="RESULT_VERDICT_ID")
	private BigDecimal resultVerdictId;
	
	/**出动执法人次数*/
	@Transient
	private BigDecimal checkUsersCount;
	
	/**食品生产企业总数*/
	@Transient
	private BigDecimal totalFoodProduceEntCount;
	
	/**食品添加剂企业总数*/
	@Transient
	private BigDecimal totalFoodAdditiveProduceEntCount;
	
	/**加工小作坊企业总数*/
	@Transient
	private BigDecimal totalFoodWorkshopEntCount;
	
	/**食品生产企业数量小计*/
	@Transient
	private BigDecimal totalEntCount;
	
	/**被检查食品生产企业数量*/
	@Transient
	private BigDecimal checkedFoodProduceEntCount;
	
	/**被检查食品添加剂企业数量*/
	@Transient
	private BigDecimal checkedFoodAdditiveProduceEntCount;
	
	/**被检查加工小作坊企业数量*/
	@Transient
	private BigDecimal checkedFoodWorkshopEntCount;
	
	/**被检查企业数量小计*/
	@Transient
	private BigDecimal totalCheckedFoodWorkshopEntCount;
	
	/**发现问题企业*/
	@Transient
	private BigDecimal problemEntCount;
	
	/**问题数量*/
	@Transient
	private BigDecimal problemCount;
	
	/**平均每次检查发现问题数*/
	@Transient
	private BigDecimal averageProblemsPerCheck;
	
	/**平均每人检查企业次数*/
	@Transient
	private BigDecimal averageProblemsPerUser;
	
	/**责令整改*/
	@Transient
	private BigDecimal reviewEntCount;
	
	/**涉嫌违规违法*/
	@Transient
	private BigDecimal illegalEntCount;
	
	/**完成回访*/
	@Transient
	private BigDecimal completeReturnVisitEntCount;
	
	/**检查覆盖率*/
	@Transient
	private BigDecimal coverageRateOfCheck;

	/**
	 * @Description: 获取 checkId
	 * @return: checkId
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public String getCheckId() {
		return checkId;
	}

	/**   
	 * @Description: 设置 checkId   
	 * @param: checkId 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * @Description: 获取 企业id
	 * @return: entId
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public String getEntId() {
		return entId;
	}

	/**   
	 * @Description: 设置 企业id   
	 * @param: entId 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setEntId(String entId) {
		this.entId = entId;
	}

	/**
	 * @Description: 获取 企业类型分组id
	 * @return: entTypeGroupId
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**   
	 * @Description: 设置 企业类型分组id   
	 * @param: entTypeGroupId 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	/**
	 * @Description: 获取 监管单位id
	 * @return: unitId
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public String getUnitId() {
		return unitId;
	}

	/**   
	 * @Description: 设置 监管单位id   
	 * @param: unitId 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description: 获取 监管单位名称
	 * @return: unitName
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public String getUnitName() {
		return unitName;
	}

	/**   
	 * @Description: 设置 监管单位名称   
	 * @param: unitName 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description: 获取 检查开始时间
	 * @return: checkBeginDate
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public Date getCheckBeginDate() {
		return checkBeginDate;
	}

	/**   
	 * @Description: 设置 检查开始时间   
	 * @param: checkBeginDate 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckBeginDate(Date checkBeginDate) {
		this.checkBeginDate = checkBeginDate;
	}

	/**
	 * @Description: 获取 检查结束时间
	 * @return: checkEndDate
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public Date getCheckEndDate() {
		return checkEndDate;
	}

	/**   
	 * @Description: 设置 检查结束时间   
	 * @param: checkEndDate 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckEndDate(Date checkEndDate) {
		this.checkEndDate = checkEndDate;
	}

	/**
	 * @Description: 获取 检查人员id
	 * @return: checkUserIds
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public String getCheckUserIds() {
		return checkUserIds;
	}

	/**   
	 * @Description: 设置 检查人员id   
	 * @param: checkUserIds 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckUserIds(String checkUserIds) {
		this.checkUserIds = checkUserIds;
	}

	/**
	 * @Description: 获取 检查结果id
	 * @return: resultVerdictId
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getResultVerdictId() {
		return resultVerdictId;
	}

	/**   
	 * @Description: 设置 检查结果id   
	 * @param: resultVerdictId 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setResultVerdictId(BigDecimal resultVerdictId) {
		this.resultVerdictId = resultVerdictId;
	}

	/**
	 * @Description: 获取 出动执法人次数
	 * @return: checkUsersCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getCheckUsersCount() {
		return checkUsersCount;
	}

	/**   
	 * @Description: 设置 出动执法人次数   
	 * @param: checkUsersCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckUsersCount(BigDecimal checkUsersCount) {
		this.checkUsersCount = checkUsersCount;
	}

	/**
	 * @Description: 获取 食品生产企业总数
	 * @return: totalFoodProduceEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getTotalFoodProduceEntCount() {
		return totalFoodProduceEntCount;
	}

	/**   
	 * @Description: 设置 食品生产企业总数   
	 * @param: totalFoodProduceEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setTotalFoodProduceEntCount(BigDecimal totalFoodProduceEntCount) {
		this.totalFoodProduceEntCount = totalFoodProduceEntCount;
	}

	/**
	 * @Description: 获取 食品添加剂企业总数
	 * @return: totalFoodAdditiveProduceEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getTotalFoodAdditiveProduceEntCount() {
		return totalFoodAdditiveProduceEntCount;
	}

	/**   
	 * @Description: 设置 食品添加剂企业总数   
	 * @param: totalFoodAdditiveProduceEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setTotalFoodAdditiveProduceEntCount(
			BigDecimal totalFoodAdditiveProduceEntCount) {
		this.totalFoodAdditiveProduceEntCount = totalFoodAdditiveProduceEntCount;
	}

	/**
	 * @Description: 获取 加工小作坊企业总数
	 * @return: totalFoodWorkshopEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getTotalFoodWorkshopEntCount() {
		return totalFoodWorkshopEntCount;
	}

	/**   
	 * @Description: 设置 加工小作坊企业总数   
	 * @param: totalFoodWorkshopEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setTotalFoodWorkshopEntCount(BigDecimal totalFoodWorkshopEntCount) {
		this.totalFoodWorkshopEntCount = totalFoodWorkshopEntCount;
	}

	/**
	 * @Description: 获取 食品生产企业数量小计
	 * @return: totalEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getTotalEntCount() {
		return totalEntCount;
	}

	/**   
	 * @Description: 设置 食品生产企业数量小计   
	 * @param: totalEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setTotalEntCount(BigDecimal totalEntCount) {
		this.totalEntCount = totalEntCount;
	}

	/**
	 * @Description: 获取 被检查食品生产企业数量
	 * @return: checkedFoodProduceEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getCheckedFoodProduceEntCount() {
		return checkedFoodProduceEntCount;
	}

	/**   
	 * @Description: 设置 被检查食品生产企业数量   
	 * @param: checkedFoodProduceEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckedFoodProduceEntCount(BigDecimal checkedFoodProduceEntCount) {
		this.checkedFoodProduceEntCount = checkedFoodProduceEntCount;
	}

	/**
	 * @Description: 获取 被检查食品添加剂企业数量
	 * @return: checkedFoodAdditiveProduceEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getCheckedFoodAdditiveProduceEntCount() {
		return checkedFoodAdditiveProduceEntCount;
	}

	/**   
	 * @Description: 设置 被检查食品添加剂企业数量   
	 * @param: checkedFoodAdditiveProduceEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckedFoodAdditiveProduceEntCount(
			BigDecimal checkedFoodAdditiveProduceEntCount) {
		this.checkedFoodAdditiveProduceEntCount = checkedFoodAdditiveProduceEntCount;
	}

	/**
	 * @Description: 获取 被检查加工小作坊企业数量
	 * @return: checkedFoodWorkshopEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getCheckedFoodWorkshopEntCount() {
		return checkedFoodWorkshopEntCount;
	}

	/**   
	 * @Description: 设置 被检查加工小作坊企业数量   
	 * @param: checkedFoodWorkshopEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCheckedFoodWorkshopEntCount(
			BigDecimal checkedFoodWorkshopEntCount) {
		this.checkedFoodWorkshopEntCount = checkedFoodWorkshopEntCount;
	}

	/**
	 * @Description: 获取 被检查企业数量小计
	 * @return: totalCheckedFoodWorkshopEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getTotalCheckedFoodWorkshopEntCount() {
		return totalCheckedFoodWorkshopEntCount;
	}

	/**   
	 * @Description: 设置 被检查企业数量小计   
	 * @param: totalCheckedFoodWorkshopEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setTotalCheckedFoodWorkshopEntCount(
			BigDecimal totalCheckedFoodWorkshopEntCount) {
		this.totalCheckedFoodWorkshopEntCount = totalCheckedFoodWorkshopEntCount;
	}

	/**
	 * @Description: 获取 发现问题企业
	 * @return: problemEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getProblemEntCount() {
		return problemEntCount;
	}

	/**   
	 * @Description: 设置 发现问题企业   
	 * @param: problemEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setProblemEntCount(BigDecimal problemEntCount) {
		this.problemEntCount = problemEntCount;
	}

	/**
	 * @Description: 获取 问题数量
	 * @return: problemCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getProblemCount() {
		return problemCount;
	}

	/**   
	 * @Description: 设置 问题数量   
	 * @param: problemCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setProblemCount(BigDecimal problemCount) {
		this.problemCount = problemCount;
	}

	/**
	 * @Description: 获取 平均每次检查发现问题数
	 * @return: averageProblemsPerCheck
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getAverageProblemsPerCheck() {
		return averageProblemsPerCheck;
	}

	/**   
	 * @Description: 设置 平均每次检查发现问题数   
	 * @param: averageProblemsPerCheck 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setAverageProblemsPerCheck(BigDecimal averageProblemsPerCheck) {
		this.averageProblemsPerCheck = averageProblemsPerCheck;
	}

	/**
	 * @Description: 获取 平均每人检查企业次数
	 * @return: averageProblemsPerUser
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getAverageProblemsPerUser() {
		return averageProblemsPerUser;
	}

	/**   
	 * @Description: 设置 平均每人检查企业次数   
	 * @param: averageProblemsPerUser 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setAverageProblemsPerUser(BigDecimal averageProblemsPerUser) {
		this.averageProblemsPerUser = averageProblemsPerUser;
	}

	/**
	 * @Description: 获取 责令整改
	 * @return: reviewEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getReviewEntCount() {
		return reviewEntCount;
	}

	/**   
	 * @Description: 设置 责令整改   
	 * @param: reviewEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setReviewEntCount(BigDecimal reviewEntCount) {
		this.reviewEntCount = reviewEntCount;
	}

	/**
	 * @Description: 获取 涉嫌违规违法
	 * @return: illegalEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getIllegalEntCount() {
		return illegalEntCount;
	}

	/**   
	 * @Description: 设置 涉嫌违规违法   
	 * @param: illegalEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setIllegalEntCount(BigDecimal illegalEntCount) {
		this.illegalEntCount = illegalEntCount;
	}

	/**
	 * @Description: 获取 完成回访
	 * @return: completeReturnVisitEntCount
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getCompleteReturnVisitEntCount() {
		return completeReturnVisitEntCount;
	}

	/**   
	 * @Description: 设置 完成回访   
	 * @param: completeReturnVisitEntCount 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCompleteReturnVisitEntCount(
			BigDecimal completeReturnVisitEntCount) {
		this.completeReturnVisitEntCount = completeReturnVisitEntCount;
	}

	/**
	 * @Description: 获取 检查覆盖率
	 * @return: coverageRateOfCheck
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public BigDecimal getCoverageRateOfCheck() {
		return coverageRateOfCheck;
	}

	/**   
	 * @Description: 设置 检查覆盖率   
	 * @param: coverageRateOfCheck 
	 * @author xh
	 * @date 2016-1-12 上午9:51:30 
	 */
	public void setCoverageRateOfCheck(BigDecimal coverageRateOfCheck) {
		this.coverageRateOfCheck = coverageRateOfCheck;
	}

	
}
