/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTable.java
 * @author:fanghailong
 * @time:2015-10-12 上午10:50:08
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author:fanghailong 
 * 检查表
 */
@Entity
@Table(name="DC_TABLE")
public class TableInfo implements IBusinessObject{
	
	/**检查表Id */
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="TABLE_ID")
	private String tableId;
	
	/**检查表名称 */
	@Column(name="TABLE_NAME")
	private String tableName;
	
	/**检查表样式id */
	@Column(name="TABLE_STYLE_ID")
	private String tableStyleId;
	
	/**检查表样式名称*/
	@Column(name="TABLE_STYLE_NAME")
	private String tableStyleName;
	
	/**状态*/
	@Column(name="STATE")
	private Integer state;
	
	/**模板id*/
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**企业类型分组id*/
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/**企业类型分组名称 */
	@Column(name="ENT_TYPE_GROUP_Name")
	private String entTypeGroupName;
	
	/**创建时间 */
	@Column(name="CREATE_TIME")
	private Date createTime;
	
	/**合计行前缀词*/
	@Column(name="SUM_ROW_TITLE")
	private String sumRowTitle;
	
	/**报表样式 */
	@Column(name="REPORT_STYLE")
	private String reportStyle;
	
	/**部门id */
	@Column(name="DEPT_ID")
	private String deptId;
	
	/**部门名称 */
	@Column(name="DEPT_NAME")
	private String deptName;
	
	/**单位id*/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/**单位名称 */
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/**备注*/
	@Column(name="REMARK")
	private String remark;

	/**
	 * @Description:获取检查表Id
	 * @return:tableId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * @Description:设置检查表Id
	 * @param：tableId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * @Description:获取检查表名称
	 * @return:tableName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @Description:设置检查表名称
	 * @param：tableName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @Description:获取检查表样式id 
	 * @return:tableStyleId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getTableStyleId() {
		return tableStyleId;
	}

	/**
	 * @Description:设置检查表样式id 
	 * @param：tableStyleId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setTableStyleId(String tableStyleId) {
		this.tableStyleId = tableStyleId;
	}

	/**
	 * @Description:获取检查表样式名称
	 * @return:tableStyleName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getTableStyleName() {
		return tableStyleName;
	}

	/**
	 * @Description:设置检查表样式名称
	 * @param：tableStyleName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setTableStyleName(String tableStyleName) {
		this.tableStyleName = tableStyleName;
	}

	/**
	 * 获取state
	 * @return state
	 */
	public Integer getState() {
		return state;
	}

	/**  
	 * 设置state  
	 * @param state
	 */
	public void setState(Integer state) {
		this.state = state;
	}

	/**
	 * @Description:获取模板id
	 * @return:templateId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @Description:设置模板id
	 * @param：templateId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @Description:获取企业类型id
	 * @return:entTypeGroupId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**
	 * @Description:设置企业类型id
	 * @param：entTypeGroupId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	/**
	 * @Description:获取企业类型名称
	 * @return:entTypeGroupName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	/**
	 * @Description:设置企业类型名称
	 * @param：entTypeGroupName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}

	/**
	 * @Description:获取创建时间
	 * @return:createTime
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * @Description:设置创建时间
	 * @param：createTime
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * @Description:获取合计行前缀词
	 * @return:sumRowTitle
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getSumRowTitle() {
		return sumRowTitle;
	}

	/**
	 * @Description:设置合计行前缀词
	 * @param：sumRowTitle
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setSumRowTitle(String sumRowTitle) {
		this.sumRowTitle = sumRowTitle;
	}

	/**
	 * @Description:获取报表样式
	 * @return:reportStyle
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getReportStyle() {
		return reportStyle;
	}

	/**
	 * @Description:设置报表样式
	 * @param：reportStyle
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setReportStyle(String reportStyle) {
		this.reportStyle = reportStyle;
	}

	/**
	 * @Description:获取部门id
	 * @return:deptId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getDeptId() {
		return deptId;
	}

	/**
	 * @Description:设置部门id
	 * @param：deptId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	/**
	 * @Description:获取部门名称 
	 * @return:deptName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getDeptName() {
		return deptName;
	}

	/**
	 * @Description:设置部门名称 
	 * @param：deptName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/**
	 * @Description:获取单位id
	 * @return:unitId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getUnitId() {
		return unitId;
	}

	/**
	 * @Description:设置单位id
	 * @param：unitId
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description:获取单位名称
	 * @return:unitName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getUnitName() {
		return unitName;
	}

	/**
	 * @Description:设置单位名称
	 * @param：unitName
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description:获取备注
	 * @return:remark
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description:设置备注
	 * @param：remark
	 * @author:fanghailong
	 * @time:2015-10-12 上午11:17:58
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "TableInfo [tableId=" + tableId + ", tableName=" + tableName + ", tableStyleId=" + tableStyleId
				+ ", tableStyleName=" + tableStyleName + ", state=" + state + ", templateId=" + templateId
				+ ", entTypeGroupId=" + entTypeGroupId + ", entTypeGroupName=" + entTypeGroupName + ", createTime="
				+ createTime + ", sumRowTitle=" + sumRowTitle + ", reportStyle=" + reportStyle + ", deptId=" + deptId
				+ ", deptName=" + deptName + ", unitId=" + unitId + ", unitName=" + unitName + ", remark=" + remark
				+ "]";
	}
}
