package com.itouch.application.fda.biz.entity.dailycheck.check.upload;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.csource.manager.FileData;
import org.csource.manager.FileManager;
import org.csource.manager.FileOperateEntity;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.itouch.application.fda.foundation.util.DateUtil;
import com.itouch.application.fda.foundation.util.GlobalUtil;
import com.itouch.application.fda.foundation.util.StringUtil;

/**
 * 上传附件帮助类
 */
public class UploadHelper {
	
	private static final String upload_File = "/upload-temp";
	
	private static final FileManager manager = FileManager.getFileManager();
	
	private HttpServletRequest request;
	
	private String uploadPath;
	
	/**
	 * 初始化临时文件路径
	 * @param request
	 */
	public UploadHelper(HttpServletRequest request) {
		this.request = request;
		uploadPath = request.getSession().getServletContext().getRealPath(upload_File);
		File up = new File(uploadPath);
		if (!up.exists()) {
			up.mkdir();
		}
	}
	
	/**
	 * 保存文件
	 * @return
	 */
	public List<UploadResult> FileUpload() {
		
		//返回结果
		List<UploadResult> uploadResultList = new ArrayList<UploadResult>();
		
		try {
			//上传信息json
			String fileJson = request.getParameter("fileJson");
			if(!StringUtils.isEmpty(fileJson)) {
				
				//上传信息
				UploadInfo uploadInfo = JSON.parseObject(fileJson, UploadInfo.class);
				if(uploadInfo != null) {
					
					//附件信息集合
					List<UploadFileInfo> uploadFileList = uploadInfo.getUploadFileList();
					if(uploadFileList != null && uploadFileList.size() > 0) {
						for (UploadFileInfo uploadFileInfo : uploadFileList) {
							if(!StringUtils.isEmpty(uploadFileInfo.getUploadFileDateInfo())) {
								
								//保存临时文件
						        File file = new File(uploadPath, GlobalUtil.createUUID());
						        FileOutputStream fstream = new FileOutputStream(file);
						        BufferedOutputStream stream = new BufferedOutputStream(fstream);
						        stream.write(StringUtil.hex2byte(uploadFileInfo.getUploadFileDateInfo()));
						        stream.close();
						        
						        //附件信息
						        FileOperateEntity fileEntity = new  FileOperateEntity();
						        fileEntity.setAttachment_code(uploadFileInfo.getAttachmentCode());
						        fileEntity.setFile_name(uploadFileInfo.getFileName());
						        fileEntity.setFile_ext(uploadFileInfo.getFileExtension());
						        fileEntity.setFile_size(uploadFileInfo.getFileSize());
						        fileEntity.setUnit_id(uploadFileInfo.getUnitId());
						        fileEntity.setUnit_name(uploadFileInfo.getUnitName());
						        fileEntity.setUser_id(uploadFileInfo.getUserId());
						        fileEntity.setUser_name(uploadFileInfo.getUserName());
						        if(!StringUtils.isEmpty(uploadFileInfo.getUploadTime())) {
						        	fileEntity.setUpload_time(DateUtil.toDate(uploadFileInfo.getUploadTime(), "yyyy-MM-dd HH:mm:ss"));
						        }
						        
						        //附件内容
						        FileData fileData = new FileData(fileEntity.getFile_name(), fileEntity.getFile_ext(), null, file.getPath());
						        
						        //保存附件
						        String[] url = manager.upload(fileData, fileEntity);
						        
						        //删除临时文件
								if(url !=null && url.length==3) {
									UploadResult uploadResult = new UploadResult();
									uploadResult.setName(uploadFileInfo.getFileName());
									uploadResult.setUrl(url[2]);
									uploadResult.setFileId(fileEntity.getFile_id());
									uploadResultList.add(uploadResult);
									file.delete();
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return uploadResultList;
	}
	
	/**
	 * 获得文件信息
	 * @return
	 */
	public List<UploadFileInfo> GetFileList() {
		return GetFileList("");
	}
	
	/**
	 * 获得文件信息
	 * @return
	 */
	public List<UploadFileInfo> GetFileList(String attachmentCode) {
		
		//返回结果
		List<UploadFileInfo> uploadFileList = new ArrayList<UploadFileInfo>();
		
		try {
			//附件Id
			String fileId = request.getParameter("fileId");
			
			//附件标识
			if(StringUtils.isEmpty(attachmentCode)) {
				attachmentCode = request.getParameter("attachmentCode");
			}
			if(!StringUtils.isEmpty(attachmentCode)) {
				
				//得到结果集合
				List<Map<String, Object>> m = manager.queryFile(attachmentCode);
				
				if(m != null && m.size() > 0) {
					for (Map<String, Object> map : m) {
						
						//如果有附件Id，就只取那个附件
						if(!StringUtils.isEmpty(fileId) && !fileId.equals(String.valueOf(map.get("FILE_ID")))) {
							break;
						}
						UploadFileInfo uploadFileInfo = new UploadFileInfo();
						uploadFileInfo.setAttachmentCode(String.valueOf(map.get("ATTACHMENT_CODE")));
						uploadFileInfo.setFileExtension(String.valueOf(map.get("FILE_EXT")));
						uploadFileInfo.setFileId(String.valueOf(map.get("FILE_ID")));
						uploadFileInfo.setFileName(String.valueOf(map.get("FILE_NAME")));
						uploadFileInfo.setFileSize(String.valueOf(map.get("FILE_SIZE")));
						uploadFileInfo.setFileType(String.valueOf(map.get("FILE_TYPE")));
						uploadFileInfo.setUnitId(String.valueOf(map.get("UNIT_ID")));
						uploadFileInfo.setUnitName(String.valueOf(map.get("UNIT_NAME")));
						uploadFileInfo.setUserId(String.valueOf(map.get("USER_ID")));
						uploadFileInfo.setUserName(String.valueOf(map.get("USER_NAME")));
						uploadFileInfo.setUploadFileUrl(String.valueOf(map.get("FILE_URL")));
						uploadFileInfo.setUploadTime(String.valueOf(map.get("UPLOAD_TIME")));
						uploadFileList.add(uploadFileInfo);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return uploadFileList;
	}
	
	/**
	 * 删除单个文件
	 * @param fileId
	 * @return
	 */
	public boolean DeleteFile(String fileId) {
		try {
			//如果没有fileId，就从request里取
			if(StringUtils.isEmpty(fileId)) {
				fileId = request.getParameter("fileId");
			}
			
			if(!StringUtils.isEmpty(fileId)) {
				//删除附件
				return manager.delete(fileId) >= 0;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * 删除单个文件
	 * @return
	 */
	public boolean DeleteFile() {
		return DeleteFile("");
	}
	
	/**
	 * 删除多个文件
	 * @return
	 */
	public boolean DeleteFileList() {
		try {
			//附件标识
			String attachmentCode = request.getParameter("attachmentCode");
			if(!StringUtils.isEmpty(attachmentCode)) {
				
				//先获得附件信息集合
				List<UploadFileInfo> uploadFileList = GetFileList();
				if(uploadFileList != null && uploadFileList.size() > 0) {
					for (UploadFileInfo uploadFileInfo : uploadFileList) {
						
						//删除附件
						DeleteFile(uploadFileInfo.getFileId());
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
