package com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating;

import com.itouch.application.fda.biz.dailycheck.enums.EnumRatingResults;
import com.itouch.application.fda.biz.dailycheck.enums.EnumVerdictType;

/**
 * @author qiuy
 * 表达式信息
 */
public class ExpressionInfo implements Cloneable {
	
	/**
	 * 结论类型
	 */
	private EnumVerdictType verdictType;
	
	/**
	 * 内容
	 */
	private String content;
	
	/**
	 * 补充的内容
	 */
	private String contentSupply;
	
	/**
	 * 备注
	 */
	private String remark;
	
	/**
	 * 条件评定结果
	 */
	private EnumRatingResults result;
	
	/**
	 * 系数
	 */
	public Float coefficient;
	
	/**
	 * 返回浅复制对象
	 * @return
	 */
	public ExpressionInfo getClone() {
		try {
			return (ExpressionInfo) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return new ExpressionInfo();
	}

	public EnumVerdictType getVerdictType() {
		return verdictType;
	}

	public void setVerdictType(EnumVerdictType verdictType) {
		this.verdictType = verdictType;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getContentSupply() {
		return contentSupply;
	}

	public void setContentSupply(String contentSupply) {
		this.contentSupply = contentSupply;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public EnumRatingResults getResult() {
		if(result == null) {
			return EnumRatingResults.Null;
		}
		return result;
	}

	public void setResult(EnumRatingResults result) {
		this.result = result;
	}

	public Float getCoefficient() {
		return coefficient;
	}

	public void setCoefficient(Float coefficient) {
		this.coefficient = coefficient;
	}
}
