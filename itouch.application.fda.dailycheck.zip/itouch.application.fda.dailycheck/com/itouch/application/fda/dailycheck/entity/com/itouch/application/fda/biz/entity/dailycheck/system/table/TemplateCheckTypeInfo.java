/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:DcTemplateCheckType.java
 * @author:xh
 * @time:2015-10-10 下午3:09:16
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author xh
 */
@Entity
@Table(name="DC_TEMPLATE_CHECK_TYPE")
public class TemplateCheckTypeInfo {
	/**ID*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**模板Id*/
	@Column(name ="TEMPLATE_ID",insertable=false,updatable=false)
	private String templateId;
	
	/**检查类型Id*/
	@Column(name ="CHECK_TYPE_ID")
	private String checkTypeId;
	
	/**检查类型名称*/
	@Column(name ="CHECK_TYPE_NAME")
	private String checkTypeName;
	
	/**备注*/
	@Column(name ="REMARK")
	private String remark;
	
	/**模板**/
	@ManyToOne
	@JoinColumn(name = "TEMPLATE_ID")
	private TemplateInfo template;

	/**
	 * 获取id
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**  
	 * 设置id  
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 获取templateId
	 * @return templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**  
	 * 设置templateId  
	 * @param templateId
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * 获取checkTypeId
	 * @return checkTypeId
	 */
	public String getCheckTypeId() {
		return checkTypeId;
	}

	/**  
	 * 设置checkTypeId  
	 * @param checkTypeId
	 */
	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	/**
	 * 获取checkTypeName
	 * @return checkTypeName
	 */
	public String getCheckTypeName() {
		return checkTypeName;
	}

	/**  
	 * 设置checkTypeName  
	 * @param checkTypeName
	 */
	public void setCheckTypeName(String checkTypeName) {
		this.checkTypeName = checkTypeName;
	}

	/**
	 * 获取remark
	 * @return remark
	 */
	public String getRemark() {
		return remark;
	}

	/**  
	 * 设置remark  
	 * @param remark
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * 获取template
	 * @return template
	 */
	public TemplateInfo getTemplate() {
		return template;
	}

	/**  
	 * 设置template  
	 * @param template
	 */
	public void setTemplate(TemplateInfo template) {
		this.template = template;
	}
}
