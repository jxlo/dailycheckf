package com.itouch.application.fda.biz.entity.dailycheck.report;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import iTouch.framework.data.operation.IBusinessObject;

@SuppressWarnings("serial")
@Entity
@Table(name = "DC_REP_DRUG_OPERATE")
public class RepDrugOperate implements IBusinessObject {

	/** 主键Id */
	@Id
	@Column(name = "ID")
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String id;

	/** 报表Id */
	@Column(name = "REPORT_ID")
	private String reportId;

	/** 单位类别Id */
	@Column(name = "ENT_TYPE_ID")
	private String entTypeId;

	/** 单位类别名称 */
	@Column(name = "ENT_TYPE_NAME")
	private String entTypeName;

	/** 数目（家） */
	@Column(name = "ENT_COUNT")
	private Integer entCount;

	/** 检查数（家次） */
	@Column(name = "ENT_CHECKED_COUNT")
	private Integer entCheckedCount;

	/** 出动检查人次 */
	@Column(name = "ENT_CHECKED_PER_COUNT")
	private Integer entCheckedPerCount;

	/** 责令整改（家次） */
	@Column(name = "ENT_REFORM_COUNT")
	private Integer entReformCount;

	/** 查办案件数目 */
	@Column(name = "ENT_CASE_COUNT")
	private Integer entCaseCount;

	/** 主要整改原因 */
	@Column(name = "REFORM_REASON")
	private String reformReason;

	/** 其他 */
	@Column(name = "REMARK")
	private String remark;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public String getId() {
		return id;
	}

	/**
	 * @Description: 设置 主键Id
	 * @param: id
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 报表Id
	 * @return: reportId
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public String getReportId() {
		return reportId;
	}

	/**
	 * @Description: 设置 报表Id
	 * @param: reportId
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	/**
	 * @Description: 获取 单位类别Id
	 * @return: entTypeId
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**
	 * @Description: 设置 单位类别Id
	 * @param: entTypeId
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 数目（家）
	 * @return: entCount
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public Integer getEntCount() {
		return entCount;
	}

	/**
	 * @Description: 设置 数目（家）
	 * @param: entCount
	 * @author xh
	 * @date 2016-3-16 上午11:21:53
	 */
	public void setEntCount(Integer entCount) {
		this.entCount = entCount;
	}

	/**
	 * @Description: 获取 检查数（家次）
	 * @return: entCheckedCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public Integer getEntCheckedCount() {
		return entCheckedCount;
	}

	/**
	 * @Description: 设置 检查数（家次）
	 * @param: entCheckedCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public void setEntCheckedCount(Integer entCheckedCount) {
		this.entCheckedCount = entCheckedCount;
	}

	/**
	 * @Description: 获取 出动检查人次
	 * @return: entCheckedPerCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public Integer getEntCheckedPerCount() {
		return entCheckedPerCount;
	}

	/**
	 * @Description: 设置 出动检查人次
	 * @param: entCheckedPerCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public void setEntCheckedPerCount(Integer entCheckedPerCount) {
		this.entCheckedPerCount = entCheckedPerCount;
	}

	/**
	 * @Description: 获取 责令整改（家次）
	 * @return: entReformCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public Integer getEntReformCount() {
		return entReformCount;
	}

	/**
	 * @Description: 设置 责令整改（家次）
	 * @param: entReformCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public void setEntReformCount(Integer entReformCount) {
		this.entReformCount = entReformCount;
	}

	/**
	 * @Description: 获取 查办案件数目
	 * @return: entCaseCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public Integer getEntCaseCount() {
		return entCaseCount;
	}

	/**
	 * @Description: 设置 查办案件数目
	 * @param: entCaseCount
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public void setEntCaseCount(Integer entCaseCount) {
		this.entCaseCount = entCaseCount;
	}

	/**
	 * @Description: 获取 主要整改原因
	 * @return: reformReason
	 * @author: wangk
	 * @date: 2016-3-18 上午10:08:55
	 */
	public String getReformReason() {
		return reformReason;
	}

	/**
	 * @Description: 设置 主要整改原因
	 * @param: reformReason
	 * @author: wangk
	 * @date: 2016-3-18 上午10:08:55
	 */
	public void setReformReason(String reformReason) {
		this.reformReason = reformReason;
	}

	/**
	 * @Description: 获取 其他
	 * @return: remark
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @Description: 设置 其他
	 * @param: remark
	 * @author xh
	 * @date 2016-3-16 上午11:28:51
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @Description: 获取 单位类别名称
	 * @return: entTypeName
	 * @author xh
	 * @date 2016-3-16 下午1:38:45
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**
	 * @Description: 设置 单位类别名称
	 * @param: entTypeName
	 * @author xh
	 * @date 2016-3-16 下午1:38:45
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

}
