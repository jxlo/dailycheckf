/**     
  * @Title: VTaskUnitCheck.java   
  * @Package com.itouch.application.fda.biz.entity.dailycheck.task   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-4 下午5:26:54     
  */ 
package com.itouch.application.fda.biz.entity.dailycheck.task;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**   
 * @ClassName: VTaskUnitCheck   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-4 下午5:26:54      
 */
@Entity
@Table(name="V_DC_TASK_UNIT_CHECK")
public class VTaskUnitCheckInfo implements IBusinessObject{
		
	/** 检查记录Id **/ 
	@Id
	@Column(name="CHECK_ID")
	private String checkId;
	/** 单位任务Id **/ 
	@Column(name="UNIT_TASK_ID")
	private String 	unitTaskId;

	/** 检查表Id **/ 
	@Column(name="TABLE_ID")
	private String tableId;
	
	/** 检查类别Id **/ 
	@Column(name="CHECK_TYPE_ID")
	private String checkTypeId;
	
	/** 企业名称 **/ 
	@Column(name="ENT_NAME")
	private String entName;
	
	/** 检查人姓名 **/ 
	@Column(name="CHECK_USER_NAMES")
	private String checkUserNames;
	
	/** 检查开始日期 **/ 
	@Column(name="CHECK_BEGIN_DATE")
	private Date checkBeginDate;
	
	/** 检查结束日期 **/ 
	@Column(name="CHECK_END_DATE")
	private Date checkEndDate;
	
	/** 检查结论 **/ 
	@Column(name="RESULT_VERDICT_NAME")
	private String resultVerdictName;

	/**
	 * @Description: 获取 单位任务Id
	 * @return: unitTaskId 单位任务Id
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public String getUnitTaskId() {
		return unitTaskId;
	}

	/**   
	 * @Description: 设置 单位任务Id   
	 * @param: unitTaskId 单位任务Id 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setUnitTaskId(String unitTaskId) {
		this.unitTaskId = unitTaskId;
	}

	/**
	 * @Description: 获取 检查记录Id
	 * @return: checkId 检查记录Id
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public String getCheckId() {
		return checkId;
	}

	/**   
	 * @Description: 设置 检查记录Id   
	 * @param: checkId 检查记录Id 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * @Description: 获取 检查类别Id
	 * @return: checkTypeId 检查类别Id
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public String getCheckTypeId() {
		return checkTypeId;
	}

	/**   
	 * @Description: 设置 检查类别Id   
	 * @param: checkTypeId 检查类别Id 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setCheckTypeId(String checkTypeId) {
		this.checkTypeId = checkTypeId;
	}

	/**
	 * @Description: 获取 企业名称
	 * @return: entName 企业名称
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public String getEntName() {
		return entName;
	}

	/**   
	 * @Description: 设置 企业名称   
	 * @param: entName 企业名称 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}

	/**
	 * @Description: 获取 检查人姓名
	 * @return: checkUserNames 检查人姓名
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public String getCheckUserNames() {
		return checkUserNames;
	}

	/**   
	 * @Description: 设置 检查人姓名   
	 * @param: checkUserNames 检查人姓名 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setCheckUserNames(String checkUserNames) {
		this.checkUserNames = checkUserNames;
	}

	/**
	 * @Description: 获取 检查开始日期
	 * @return: checkBeginDate 检查开始日期
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public Date getCheckBeginDate() {
		return checkBeginDate;
	}

	/**   
	 * @Description: 设置 检查开始日期   
	 * @param: checkBeginDate 检查开始日期 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setCheckBeginDate(Date checkBeginDate) {
		this.checkBeginDate = checkBeginDate;
	}

	/**
	 * @Description: 获取 检查结束日期
	 * @return: checkEndDate 检查结束日期
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public Date getCheckEndDate() {
		return checkEndDate;
	}

	/**   
	 * @Description: 设置 检查结束日期   
	 * @param: checkEndDate 检查结束日期 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setCheckEndDate(Date checkEndDate) {
		this.checkEndDate = checkEndDate;
	}

	/**
	 * @Description: 获取 检查结论
	 * @return: resultVerdictName 检查结论
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public String getResultVerdictName() {
		return resultVerdictName;
	}

	/**   
	 * @Description: 设置 检查结论   
	 * @param: resultVerdictName 检查结论 
	 * @author wangk
	 * @date 2015-11-19 下午4:37:28 
	 */
	public void setResultVerdictName(String resultVerdictName) {
		this.resultVerdictName = resultVerdictName;
	}

	/**
	 * @Description: 获取 检查表Id
	 * @return: tableId
	 * @author wangk
	 * @date 2016-1-13 下午3:26:25 
	 */
	public String getTableId() {
		return tableId;
	}

	/**   
	 * @Description: 设置 检查表Id   
	 * @param: tableId 
	 * @author wangk
	 * @date 2016-1-13 下午3:26:25 
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}
}
