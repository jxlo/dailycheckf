/**  
  * @Description: TODO
  * @Title: RepFoodBizPermitInfo.java 
  * @Package: com.itouch.application.fda.biz.entity.dailycheck.report 
  * @author: xh
  * @date 2016-3-22 上午10:21:36 
  */ 
package com.itouch.application.fda.biz.entity.dailycheck.report;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description: TODO
 * @ClassName: RepFoodBizPermitInfo 
 * @author xh
 * @date 2016-3-22 上午10:21:36  
 */
@Entity
@Table(name="DC_REP_FOOD_BIZ_PERMIT")
public class RepFoodBizPermitInfo implements IBusinessObject {
	/**主键Id*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**报表Id*/
	@Column(name="REPORT_ID")
	private String reportId;
	
	/**单位类别Id*/
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/**单位类别名称*/
	@Column(name="ENT_TYPE_Name")
	private String entTypeName;
	
	/**上期末实有*/
	@Column(name="LAST_END_HAVE_COUNT")
	private Integer lastEndHaveCount;
	
	/**本期新增*/
	@Column(name="CUR_ADD_COUNT")
	private Integer curAddCount;
	
	/**本期减少*/
	@Column(name="CUR_REDUCE_COUNT")
	private Integer curReduceCount;
	
	/**期末实有*/
	@Column(name="CUR_END_COUNT")
	private Integer curEndCount;
	
	/**明厨亮灶*/
	@Column(name="DVR_KITCHEN_COUNT")
	private Integer dvrKitchenCount;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public String getId() {
		return id;
	}

	/**   
	 * @Description: 设置 主键Id   
	 * @param: id 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 报表Id
	 * @return: reportId
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public String getReportId() {
		return reportId;
	}

	/**   
	 * @Description: 设置 报表Id   
	 * @param: reportId 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	/**
	 * @Description: 获取 单位类别Id
	 * @return: entTypeId
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**   
	 * @Description: 设置 单位类别Id   
	 * @param: entTypeId 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 单位类别名称
	 * @return: entTypeName
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**   
	 * @Description: 设置 单位类别名称   
	 * @param: entTypeName 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description: 获取 上期末实有
	 * @return: lastEndHaveCount
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public Integer getLastEndHaveCount() {
		return lastEndHaveCount;
	}

	/**   
	 * @Description: 设置 上期末实有   
	 * @param: lastEndHaveCount 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setLastEndHaveCount(Integer lastEndHaveCount) {
		this.lastEndHaveCount = lastEndHaveCount;
	}

	/**
	 * @Description: 获取 本期新增
	 * @return: curAddCount
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public Integer getCurAddCount() {
		return curAddCount;
	}

	/**   
	 * @Description: 设置 本期新增   
	 * @param: curAddCount 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setCurAddCount(Integer curAddCount) {
		this.curAddCount = curAddCount;
	}

	/**
	 * @Description: 获取 本期减少
	 * @return: curReduceCount
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public Integer getCurReduceCount() {
		return curReduceCount;
	}

	/**   
	 * @Description: 设置 本期减少   
	 * @param: curReduceCount 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setCurReduceCount(Integer curReduceCount) {
		this.curReduceCount = curReduceCount;
	}

	/**
	 * @Description: 获取 期末实有
	 * @return: curEndCount
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public Integer getCurEndCount() {
		return curEndCount;
	}

	/**   
	 * @Description: 设置 期末实有   
	 * @param: curEndCount 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setCurEndCount(Integer curEndCount) {
		this.curEndCount = curEndCount;
	}

	/**
	 * @Description: 获取 明厨亮灶
	 * @return: dvrKitchenCount
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public Integer getDvrKitchenCount() {
		return dvrKitchenCount;
	}

	/**   
	 * @Description: 设置 明厨亮灶   
	 * @param: dvrKitchenCount 
	 * @author xh
	 * @date 2016-3-22 上午10:24:26 
	 */
	public void setDvrKitchenCount(Integer dvrKitchenCount) {
		this.dvrKitchenCount = dvrKitchenCount;
	}
	
	
	
}
