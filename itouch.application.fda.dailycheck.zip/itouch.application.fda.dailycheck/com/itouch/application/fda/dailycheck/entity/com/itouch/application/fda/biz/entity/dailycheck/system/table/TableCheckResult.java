/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TableCheckResult.java
 * @author:xh
 * @time:2015-10-26 下午6:56:26
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author xh
 */
@Entity
@Table(name="DC_TABLE_CHECK_RESULT")
public class TableCheckResult {

	/**检查表Id */
	@Id
	@Column(name="ID")
	private String id;
	
	/**检查记录Id */
	@Column(name="CHECK_ID")
	private String checkId;
	
	/**条款Id */
	@Column(name="ITEM_ID")
	private String itemId;
	
	/**模板Id */
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**表Id */
	@Column(name="TABLE_ID")
	private String tableId;
	
	/**标识符*/
	@Column(name="SUBJECT_ID")
	private String subjectId;
	
	/**小项Id*/
	@Column(name="SMALL_SUBJECT_ID")
	private String smallSubjectId;
	
	/**得分*/
	@Column(name="SCORE")
	private String score;
	
	/**标准分*/
	@Column(name="STANDARD_SCORE")
	private String standardScore;
	
	/**理由*/
	@Column(name="MEMO")
	private String memo;
	
	/**创建时间*/
	@Column(name="CREATE_TIME")
	private String createTime;
	
	/**是否重点项*/
	@Column(name="IS_EMPHASIS")
	private String isEmphasis;
	
	/**是否缺项*/
	@Column(name="IS_LACK")
	private String isLack;
	
	/**选项值*/
	@Column(name="OPTION_VALUE")
	private String optionValue;
	
	/**否决项*/
	@Column(name="IS_VETO")
	private String isVeto;
	
	/**单位Id*/
	@Column(name="UNIT_ID")
	private String unitId;
	
	/**系数*/
	@Column(name="COEFFICIENT")
	private String coefficient;
	
	/**缺陷项目*/
	@Column(name="LACK_ITEM")
	private String lackItem;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCheckId() {
		return checkId;
	}

	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getTableId() {
		return tableId;
	}

	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	public String getSmallSubjectId() {
		return smallSubjectId;
	}

	public void setSmallSubjectId(String smallSubjectId) {
		this.smallSubjectId = smallSubjectId;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getStandardScore() {
		return standardScore;
	}

	public void setStandardScore(String standardScore) {
		this.standardScore = standardScore;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getIsEmphasis() {
		return isEmphasis;
	}

	public void setIsEmphasis(String isEmphasis) {
		this.isEmphasis = isEmphasis;
	}

	public String getIsLack() {
		return isLack;
	}

	public void setIsLack(String isLack) {
		this.isLack = isLack;
	}

	public String getOptionValue() {
		return optionValue;
	}

	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}

	public String getIsVeto() {
		return isVeto;
	}

	public void setIsVeto(String isVeto) {
		this.isVeto = isVeto;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getCoefficient() {
		return coefficient;
	}

	public void setCoefficient(String coefficient) {
		this.coefficient = coefficient;
	}

	public String getLackItem() {
		return lackItem;
	}

	public void setLackItem(String lackItem) {
		this.lackItem = lackItem;
	}


	
	
}
