/**  
* @Title: TaskUnitInfo.java 
* @Package com.itouch.application.fda.biz.entity.dailycheck.task 
* @author wangk    
* @date 2015-10-26 下午1:41:59  
*/ 
package com.itouch.application.fda.biz.entity.dailycheck.task;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


/**
 * @author wangk
 * @Description:  专项检查单位任务分配
 * @date 2015-10-26 下午1:41:59  
 */
@Entity
@Table(name="DC_TASK_UNIT")
public class TaskUnitInfo implements IBusinessObject{
	
	/** 单位任务Id **/ 
	@Id
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	@Column(name="UNIT_TASK_ID")
	private String 	unitTaskId;
	
	/** 任务Id **/ 
	@Column(name="TASK_ID")
	private String taskId;
	
	/** 用户Id **/ 
	@Column(name="USER_ID")
	private String userId;
	
	/** 用户名 **/ 
	@Column(name="USER_NAME")
	private String userName;
	
	/** 部门Id **/ 
	@Column(name="DEPT_ID")
	private String deptId;

	/** 部门名称 **/ 
	@Column(name="DEPT_NAME")
	private String deptName;
	
	/** 单位Id **/ 
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** 单位名称 **/ 
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** 是否完成 **/ 
	@Column(name="IS_COMPLETED")
	private Integer isCompleted;
	
	/** 待接收、已下发、已接收、待上报、已上报 **/ 
	@Column(name="TASK_STATE")
	private Integer taskState;
	
	/** 附件组号 **/ 
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;
	
	/** 备注 **/ 
	@Column(name="REMARK")
	private String remark;
	
	/** 任务来源单位ID **/
	@Column(name="FROM_UNIT_ID")
	private String fromUnitId;
	
	/** 任务来源单位名称 **/
	@Column(name="FROM_UNIT_NAME")
	private String fromUnitName;
	
	/** 上报内容 **/
	@Column(name="REPORT")
	private String report;

	/**
	 * @Description: 获取 unitTaskId
	 * @return: unitTaskId unitTaskId
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getUnitTaskId() {
		return unitTaskId;
	}

	/**   
	 * @Description: 设置 unitTaskId   
	 * @param: unitTaskId unitTaskId 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setUnitTaskId(String unitTaskId) {
		this.unitTaskId = unitTaskId;
	}

	/**
	 * @Description: 获取 taskId
	 * @return: taskId taskId
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getTaskId() {
		return taskId;
	}

	/**   
	 * @Description: 设置 taskId   
	 * @param: taskId taskId 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @Description: 获取 userId
	 * @return: userId userId
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getUserId() {
		return userId;
	}

	/**   
	 * @Description: 设置 userId   
	 * @param: userId userId 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @Description: 获取 userName
	 * @return: userName userName
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getUserName() {
		return userName;
	}

	/**   
	 * @Description: 设置 userName   
	 * @param: userName userName 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @Description: 获取 deptId
	 * @return: deptId deptId
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getDeptId() {
		return deptId;
	}

	/**   
	 * @Description: 设置 deptId   
	 * @param: deptId deptId 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	/**
	 * @Description: 获取 deptName
	 * @return: deptName deptName
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getDeptName() {
		return deptName;
	}

	/**   
	 * @Description: 设置 deptName   
	 * @param: deptName deptName 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/**
	 * @Description: 获取 unitId
	 * @return: unitId unitId
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getUnitId() {
		return unitId;
	}

	/**   
	 * @Description: 设置 unitId   
	 * @param: unitId unitId 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @Description: 获取 unitName
	 * @return: unitName unitName
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getUnitName() {
		return unitName;
	}

	/**   
	 * @Description: 设置 unitName   
	 * @param: unitName unitName 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @Description: 获取 isCompleted
	 * @return: isCompleted isCompleted
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public Integer getIsCompleted() {
		return isCompleted;
	}

	/**   
	 * @Description: 设置 isCompleted   
	 * @param: isCompleted isCompleted 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setIsCompleted(Integer isCompleted) {
		this.isCompleted = isCompleted;
	}

	/**
	 * @Description: 获取 taskState
	 * @return: taskState taskState
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public Integer getTaskState() {
		return taskState;
	}

	/**   
	 * @Description: 设置 taskState   
	 * @param: taskState taskState 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setTaskState(Integer taskState) {
		this.taskState = taskState;
	}

	/**
	 * @Description: 获取 attachmentCode
	 * @return: attachmentCode attachmentCode
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**   
	 * @Description: 设置 attachmentCode   
	 * @param: attachmentCode attachmentCode 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * @Description: 获取 remark
	 * @return: remark remark
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getRemark() {
		return remark;
	}

	/**   
	 * @Description: 设置 remark   
	 * @param: remark remark 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @Description: 获取 fromUnitId
	 * @return: fromUnitId fromUnitId
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getFromUnitId() {
		return fromUnitId;
	}

	/**   
	 * @Description: 设置 fromUnitId   
	 * @param: fromUnitId fromUnitId 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setFromUnitId(String fromUnitId) {
		this.fromUnitId = fromUnitId;
	}

	/**
	 * @Description: 获取 fromUnitName
	 * @return: fromUnitName fromUnitName
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getFromUnitName() {
		return fromUnitName;
	}

	/**   
	 * @Description: 设置 fromUnitName   
	 * @param: fromUnitName fromUnitName 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setFromUnitName(String fromUnitName) {
		this.fromUnitName = fromUnitName;
	}

	/**
	 * @Description: 获取 report
	 * @return: report report
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public String getReport() {
		return report;
	}

	/**   
	 * @Description: 设置 report   
	 * @param: report report 
	 * @author wangk
	 * @date 2015-12-2 下午3:45:56 
	 */
	public void setReport(String report) {
		this.report = report;
	}
}
