package com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 检查结果表
 */
@Entity
@Table(name = "DC_HZ_RCJC_JCJG")
public class CheckResultInfo implements IBusinessObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 序号
	 */
	@Id
	@Column(name = "CHECKID")
	private String checkId;
	/**
	 * 企业名称
	 */
	@Column(name = "ENTNAME")
	private String entName;

	/**
	 * 检查表序号
	 */
	@Column(name = "TEMPLATEID")
	private String templateId;

	/**
	 * 模板名称
	 */
	@Column(name = "TEMPLATENAME")
	private String templateName;

	/**
	 * 检查结果
	 */
	@Column(name = "CHECKRESULT")
	private String checkResult;

	/**
	 * 检查情况备注
	 */
	@Column(name = "CHECKNOTE")
	private String checkNote;

	/**
	 * 检查日期
	 */
	@Column(name = "CHECKDATE")
	private Date checkdate;

	/**
	 * 检查人员
	 */
	@Column(name = "CHECKPERSONS")
	private String checkPersons;
	

	/**
	 * 录入人员
	 */
	@Column(name = "USERNAME")
	private String userName;

	/**
	 * 录入时间
	 */
	@Column(name = "INPUTTIME")
	private Date inputTime;

	/**
	 * 处理状态
	 */
	@Column(name = "STATE")
	private String state;

	/**
	 * 评定等级
	 */
	@Column(name = "CREDLEVEL")
	private String credLevel;

	/**
	 * 实得分数
	 */
	@Column(name = "SCORE")
	private Integer score;

	public String getCheckId() {
		return checkId;
	}

	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getCheckResult() {
		return checkResult.equals("1")?"合格":"不合格";
	}

	public void setCheckResult(String checkResult) {
		this.checkResult = checkResult;
	}

	public String getCheckNote() {
		return checkNote;
	}

	public void setCheckNote(String checkNote) {
		this.checkNote = checkNote;
	}

	public Date getCheckdate() {
		return checkdate;
	}

	public void setCheckdate(Date checkdate) {
		this.checkdate = checkdate;
	}

	public String getCheckPersons() {
		return checkPersons;
	}

	public void setCheckPersons(String checkPersons) {
		this.checkPersons = checkPersons;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getInputTime() {
		return inputTime;
	}

	public void setInputTime(Date inputTime) {
		this.inputTime = inputTime;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCredLevel() {
		return credLevel;
	}

	public void setCredLevel(String credLevel) {
		this.credLevel = credLevel;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}


	
}