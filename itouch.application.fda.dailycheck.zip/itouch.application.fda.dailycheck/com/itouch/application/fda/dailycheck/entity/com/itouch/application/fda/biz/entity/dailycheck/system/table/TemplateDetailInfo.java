/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:DcTemplateItemDetail
 * @author:fanghailong
 * @time:2015-10-10 下午3:27:00
 */
package com.itouch.application.fda.biz.entity.dailycheck.system.table;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author:fanghailong 
 * 模板条款明细
 */
@Entity
@Table(name="DC_TEMPLATE_DETAIL")
public class TemplateDetailInfo implements IBusinessObject{
	
	/**
	 * @author:zhangzt
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**标识符 */
	@Id
	@Column(name="DETAIL_ID")
	private String detailId;	
	
	/**条款Id */
	@Column(name="ITEM_ID")
	private String itemId;
	
	/**标题Id */
	@Column(name="HEADER_ID")
	private String headerId;
	
	/**模板Id */
	@Column(name="TEMPLATE_ID")
	private String templateId;
	
	/**文本 */
	@Column(name="TEXT")
	private String text;
	
	
	/**
	 * @Description: 获取标识符 
	 * @return detailId 标识符 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public String getDetailId() {
		return detailId;
	}

	/**
	 * @Description: 设置 标识符 
	 * @param detailId 标识符 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public void setDetailId(String detailId) {
		this.detailId = detailId;
	}

	/**
	 * @Description: 获取条款Id 
	 * @return itemId 条款Id 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public String getItemId() {
		return itemId;
	}

	/**
	 * @Description: 设置 条款Id 
	 * @param itemId 条款Id 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	/**
	 * @Description: 获取标题Id 
	 * @return headerId 标题Id 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public String getHeaderId() {
		return headerId;
	}

	/**
	 * @Description: 设置 标题Id 
	 * @param headerId 标题Id 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}

	/**
	 * @Description: 获取模板Id 
	 * @return templateId 模板Id 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @Description: 设置 模板Id 
	 * @param templateId 模板Id 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @Description: 获取文本 
	 * @return text 文本 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public String getText() {
		return text;
	}

	/**
	 * @Description: 设置 文本 
	 * @param text 文本 
	 * @author:zhangzt
	 * @time:2015年10月16日 下午3:28:29
	 */
	public void setText(String text) {
		this.text = text;
	}

	
	
}
