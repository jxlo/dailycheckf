/**  
* @Title: CheckEnt.java 
* @Package com.itouch.application.fda.biz.entity.dailycheck.check 
* @author wangk    
* @date 2015-10-20 下午3:20:30  
*/ 
package com.itouch.application.fda.biz.entity.dailycheck.check;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.itouch.application.ent.entity.basic.VEntBasicEntity;


/**
 * @author wangk
 * @Description: 检查企业表
 * @date 2015-10-20 下午3:20:30  
 */
@Entity
@Table(name="DC_CHECK_ENT")
public class CheckEntInfo2 implements IBusinessObject{

	public CheckEntInfo2(){}
	public CheckEntInfo2(Object entId)
	{
		this.entId=(String)entId;
	}
	public CheckEntInfo2(VEntBasicEntity entBasic){
		this.setEntId(entBasic.getEntId());
		this.setParentEntCode(entBasic.getParentEntCode());
		this.setParentNntName(entBasic.getParentEntName());
		this.setOrgCode(entBasic.getOrgCode());
		this.setBizLicNo(entBasic.getBizLicNo());
		this.setTaxRegNo(entBasic.getTaxRegNo());
		this.setLegalRepRegNo(entBasic.getLegalRepRegNo());
		this.setUniteCreditNo(entBasic.getUniteCreditNo());
		this.setCorpRegNo(entBasic.getCorpRegNo());
		this.setEntPropertyId(entBasic.getEntPropertyId());
		this.setEntPropertyName(entBasic.getEntPropertyName());
		this.setAccountTypeId(entBasic.getAccountTypeId());
		this.setAccountTypeName(entBasic.getAccountTypeName());
		//this.setRegAddr(entBasic.getRegAddr());
		this.setRegAddrPostalCode(entBasic.getRegAddrPostalCode());
		this.setEntLegalRepId(entBasic.getEntLegalRepId());
		this.setEntLegalRep(entBasic.getEntLegalRep());
		this.setEntPrincipalId(entBasic.getEntPrincipalId());
		//this.setEntPrincipal(entBasic.getEntPrincipal());
		this.setEntLinkmanId(entBasic.getEntLinkmanId());
		this.setEntLinkman(entBasic.getEntLinkman());
		//this.setEntTel(entBasic.getEntTel());
		this.setEntFax(entBasic.getEntFax());
		this.setEntEmail(entBasic.getEntEmail());
		this.setEstDate(entBasic.getEstDate());
		this.setRegCap(entBasic.getRegCap());
		this.setUnitId(entBasic.getUnitId());
		this.setUnitName(entBasic.getUnitName());
		this.setAreaCode(entBasic.getAreaCode());
		this.setAreaName(entBasic.getAreaName());
		this.setAreaTypeId(entBasic.getAreaTypeId());
		this.setAreaTypeName(entBasic.getAreaTypeName());
//		this.setLongitude(entBasic.getLongitude());
//		this.setLatitude(entBasic.getLatitude());
		this.setEntState(entBasic.getEntState());
		this.setWorkScope(entBasic.getWorkScope());
		this.setEntTypeGroupId(entBasic.getEntTypeGroupId());
	}
	
	/** @Fields id :主键Id **/ 
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/** @Fields checkId : 检查Id **/ 
	@Column(name="CHECK_ID",insertable=false,updatable=false)
	private String checkId;
	
	/** @Fields entId : 企业Id **/ 
	@Column(name="ENT_ID")
	private String entId;
	
	/** @Fields entCode : 企业编号 **/ 
	@Column(name="ENT_CODE")
	private String entCode;
	
	/** @Fields entName : 企业名称 **/ 
	@Column(name="ENT_NAME")
	private String entName;
	
	/** @Fields parentEntCode : 隶属企业编号 **/ 
	@Column(name="PARENT_ENT_CODE")
	private String parentEntCode;
	
	/** @Fields parentNntName : 隶属企业名称 **/ 
	@Column(name="PARENT_ENT_NAME")
	private String parentNntName;
	
	/** @Fields orgCode : 组织机构代码 CA03 **/ 
	@Column(name="ORG_CODE")
	private String orgCode;
	
	/** @Fields bizLicNo : 营业执照注册号 **/ 
	@Column(name="BIZ_LIC_NO")
	private String bizLicNo;
	
	/** @Fields taxRegNo : 纳税人识别号 **/ 
	@Column(name="TAX_REG_NO")
	private String taxRegNo;
	
	/** @Fields legalRepRegNo : 法人登记证号 **/ 
	@Column(name="LEGAL_REP_REG_NO")
	private String legalRepRegNo;
	
	/** @Fields uniteCreditNo : 统一社会信用代码 **/ 
	@Column(name="UNITE_CREDIT_NO")
	private String uniteCreditNo;
	
	/** @Fields corpRegNo : 社团登记证号 **/ 
	@Column(name="CORP_REG_NO")
	private String corpRegNo;
	
	/** @Fields entPropertyId : 经济性质编号 CA06 **/ 
	@Column(name="ENT_PROPERTY_ID")
	private String entPropertyId;
	
	/** @Fields entPropertyName : 经济性质名称 **/ 
	@Column(name="ENT_PROPERTY_NAME")
	private String entPropertyName;
	
	/** @Fields accountTypeId : 企业核算形式编号 CA07 **/ 
	@Column(name="ACCOUNT_TYPE_ID")
	private String accountTypeId;
	
	/** @Fields accountTypeName : 企业核算形式名称 **/ 
	@Column(name="ACCOUNT_TYPE_NAME")
	private String accountTypeName;
	
	/** @Fields regAddr : 企业注册地址 **/ 
	@Column(name="REG_ADDR")
	private String regAddr;
	
	/** @Fields regAddrPostalCode : 企业注册地址邮编 **/ 
	@Column(name="REG_ADDR_POSTAL_CODE")
	private String regAddrPostalCode;
	
	/** @Fields entLegalRepId : 企业法定代表人Id **/ 
	@Column(name="ENT_LEGAL_REP_ID")
	private String entLegalRepId;
	
	/** @Fields ent_legal_rep : 企业法定代表人 **/ 
	@Column(name="ENT_LEGAL_REP")
	private String entLegalRep;
	
	/** @Fields ent_principal_id : 企业负责人Id **/ 
	@Column(name="ENT_PRINCIPAL_ID")
	private String entPrincipalId;
	
	/** @Fields entPrincipal : 企业负责人 **/ 
	@Column(name="ENT_PRINCIPAL")
	private String entPrincipal;
	
	/** @Fields entLinkmanId : 企业联系人Id **/ 
	@Column(name="ENT_LINKMAN_ID")
	private String entLinkmanId;
	
	/** @Fields entLinkman : 企业联系人 **/ 
	@Column(name="ENT_LINKMAN")
	private String entLinkman;
	
	/** @Fields entTel : 企业电话 **/ 
	@Column(name="ENT_TEL")
	private String entTel;
	
	/** @Fields entFax : 企业传真 **/ 
	@Column(name="ENT_FAX")
	private String entFax;
	
	/** @Fields entEmail : 企业电子邮箱地址 **/ 
	@Column(name="ENT_EMAIL")
	private String entEmail;
	
	/** @Fields estDate : 企业成立时间 **/ 
	@Column(name="EST_DATE")
	private Date estDate;
	
	/** @Fields regCap : 企业注册资本 **/ 
	@Column(name="REG_CAP")
	private Double regCap;
	
	/** @Fields unitId : 监管单位编号 **/ 
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** @Fields unitName : 监管单位名称 **/ 
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** @Fields areaCode : 地区街道编号 CA09 **/ 
	@Column(name="AREA_CODE")
	private String areaCode;
	
	/** @Fields areaName : 地区街道 **/ 
	@Column(name="AREA_NAME")
	private String areaName;
	
	/** @Fields areaTypeId : 区域类型编号（1 区内、2 区外、3 海岛） **/ 
	@Column(name="AREA_TYPE_ID")
	private String areaTypeId;
	
	/** @Fields areaTypeName : 区域类型名称 **/ 
	@Column(name="AREA_TYPE_NAME")
	private String areaTypeName;
	
	/** @Fields longitude : 企业地理位置经度 **/ 
	@Column(name="LONGITUDE")
	private String longitude;
	
	/** @Fields latitude : 维度 **/ 
	@Column(name="LATITUDE")
	private String latitude;
	
	/** @Fields entState : 企业状态 **/ 
	@Column(name="ENT_STATE")
	private Integer entState = 1;
	
	/** @Fields workScope : 经营范围 **/ 
	@Column(name="WORK_SCOPE")
	private String workScope;
	
	/** @Fields entTypeId : 企业类型Id **/ 
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/** @Fields entTypeName : 企业类型名称 **/ 
	@Column(name="ENT_TYPE_NAME")
	private String entTypeName;
	
	/** @Fields entTypeGroupId : 企业类型分组Id **/ 
	@Column(name="ENT_TYPE_GROUP_ID")
	private String entTypeGroupId;
	
	/** @Fields entTypeGroupName : 企业类型分组名称 **/ 
	@Column(name="ENT_TYPE_GROUP_NAME")
	private String entTypeGroupName;
	
	/** @Fields isUnlicensed : 是否无证企业 **/ 
	@Column(name="IS_UNLICENSED",updatable=false)
	private Integer isUnlicensed;
	
	/**检查记录表**/
	@OneToOne
	@JoinColumn(name="CHECK_ID")
	private CheckInfo2 check;

	/**
	 * 获取id
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**  
	 * 设置id  
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 获取checkId
	 * @return checkId
	 */
	public String getCheckId() {
		return checkId;
	}

	/**  
	 * 设置checkId  
	 * @param checkId
	 */
	public void setCheckId(String checkId) {
		this.checkId = checkId;
	}

	/**
	 * 获取entId
	 * @return entId
	 */
	public String getEntId() {
		return entId;
	}

	/**  
	 * 设置entId  
	 * @param entId
	 */
	public void setEntId(String entId) {
		this.entId = entId;
	}

	/**
	 * 获取entCode
	 * @return entCode
	 */
	public String getEntCode() {
		return entCode;
	}

	/**  
	 * 设置entCode  
	 * @param entCode
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}

	/**
	 * 获取entName
	 * @return entName
	 */
	public String getEntName() {
		return entName;
	}

	/**  
	 * 设置entName  
	 * @param entName
	 */
	public void setEntName(String entName) {
		this.entName = entName;
	}

	/**
	 * 获取parentEntCode
	 * @return parentEntCode
	 */
	public String getParentEntCode() {
		return parentEntCode;
	}

	/**  
	 * 设置parentEntCode  
	 * @param parentEntCode
	 */
	public void setParentEntCode(String parentEntCode) {
		this.parentEntCode = parentEntCode;
	}

	/**
	 * 获取parentNntName
	 * @return parentNntName
	 */
	public String getParentNntName() {
		return parentNntName;
	}

	/**  
	 * 设置parentNntName  
	 * @param parentNntName
	 */
	public void setParentNntName(String parentNntName) {
		this.parentNntName = parentNntName;
	}

	/**
	 * 获取orgCode
	 * @return orgCode
	 */
	public String getOrgCode() {
		return orgCode;
	}

	/**  
	 * 设置orgCode  
	 * @param orgCode
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * 获取bizLicNo
	 * @return bizLicNo
	 */
	public String getBizLicNo() {
		return bizLicNo;
	}

	/**  
	 * 设置bizLicNo  
	 * @param bizLicNo
	 */
	public void setBizLicNo(String bizLicNo) {
		this.bizLicNo = bizLicNo;
	}

	/**
	 * 获取taxRegNo
	 * @return taxRegNo
	 */
	public String getTaxRegNo() {
		return taxRegNo;
	}

	/**  
	 * 设置taxRegNo  
	 * @param taxRegNo
	 */
	public void setTaxRegNo(String taxRegNo) {
		this.taxRegNo = taxRegNo;
	}

	/**
	 * 获取legalRepRegNo
	 * @return legalRepRegNo
	 */
	public String getLegalRepRegNo() {
		return legalRepRegNo;
	}

	/**  
	 * 设置legalRepRegNo  
	 * @param legalRepRegNo
	 */
	public void setLegalRepRegNo(String legalRepRegNo) {
		this.legalRepRegNo = legalRepRegNo;
	}

	/**
	 * 获取uniteCreditNo
	 * @return uniteCreditNo
	 */
	public String getUniteCreditNo() {
		return uniteCreditNo;
	}

	/**  
	 * 设置uniteCreditNo  
	 * @param uniteCreditNo
	 */
	public void setUniteCreditNo(String uniteCreditNo) {
		this.uniteCreditNo = uniteCreditNo;
	}

	/**
	 * 获取corpRegNo
	 * @return corpRegNo
	 */
	public String getCorpRegNo() {
		return corpRegNo;
	}

	/**  
	 * 设置corpRegNo  
	 * @param corpRegNo
	 */
	public void setCorpRegNo(String corpRegNo) {
		this.corpRegNo = corpRegNo;
	}

	/**
	 * 获取entPropertyId
	 * @return entPropertyId
	 */
	public String getEntPropertyId() {
		return entPropertyId;
	}

	/**  
	 * 设置entPropertyId  
	 * @param entPropertyId
	 */
	public void setEntPropertyId(String entPropertyId) {
		this.entPropertyId = entPropertyId;
	}

	/**
	 * 获取entPropertyName
	 * @return entPropertyName
	 */
	public String getEntPropertyName() {
		return entPropertyName;
	}

	/**  
	 * 设置entPropertyName  
	 * @param entPropertyName
	 */
	public void setEntPropertyName(String entPropertyName) {
		this.entPropertyName = entPropertyName;
	}

	/**
	 * 获取accountTypeId
	 * @return accountTypeId
	 */
	public String getAccountTypeId() {
		return accountTypeId;
	}

	/**  
	 * 设置accountTypeId  
	 * @param accountTypeId
	 */
	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	/**
	 * 获取accountTypeName
	 * @return accountTypeName
	 */
	public String getAccountTypeName() {
		return accountTypeName;
	}

	/**  
	 * 设置accountTypeName  
	 * @param accountTypeName
	 */
	public void setAccountTypeName(String accountTypeName) {
		this.accountTypeName = accountTypeName;
	}

	/**
	 * 获取regAddr
	 * @return regAddr
	 */
	public String getRegAddr() {
		return regAddr;
	}

	/**  
	 * 设置regAddr  
	 * @param regAddr
	 */
	public void setRegAddr(String regAddr) {
		this.regAddr = regAddr;
	}

	/**
	 * 获取regAddrPostalCode
	 * @return regAddrPostalCode
	 */
	public String getRegAddrPostalCode() {
		return regAddrPostalCode;
	}

	/**  
	 * 设置regAddrPostalCode  
	 * @param regAddrPostalCode
	 */
	public void setRegAddrPostalCode(String regAddrPostalCode) {
		this.regAddrPostalCode = regAddrPostalCode;
	}

	/**
	 * 获取entLegalRepId
	 * @return entLegalRepId
	 */
	public String getEntLegalRepId() {
		return entLegalRepId;
	}

	/**  
	 * 设置entLegalRepId  
	 * @param entLegalRepId
	 */
	public void setEntLegalRepId(String entLegalRepId) {
		this.entLegalRepId = entLegalRepId;
	}


	/**
	 * 获取entLegalRep
	 * @return entLegalRep
	 */
	public String getEntLegalRep() {
		return entLegalRep;
	}

	/**  
	 * 设置entLegalRep  
	 * @param entLegalRep
	 */
	public void setEntLegalRep(String entLegalRep) {
		this.entLegalRep = entLegalRep;
	}

	/**
	 * 获取entPrincipalId
	 * @return entPrincipalId
	 */
	public String getEntPrincipalId() {
		return entPrincipalId;
	}

	/**  
	 * 设置entPrincipalId  
	 * @param entPrincipalId
	 */
	public void setEntPrincipalId(String entPrincipalId) {
		this.entPrincipalId = entPrincipalId;
	}

	/**
	 * 获取entPrincipal
	 * @return entPrincipal
	 */
	public String getEntPrincipal() {
		return entPrincipal;
	}

	/**  
	 * 设置entPrincipal  
	 * @param entPrincipal
	 */
	public void setEntPrincipal(String entPrincipal) {
		this.entPrincipal = entPrincipal;
	}

	/**
	 * 获取entLinkmanId
	 * @return entLinkmanId
	 */
	public String getEntLinkmanId() {
		return entLinkmanId;
	}

	/**  
	 * 设置entLinkmanId  
	 * @param entLinkmanId
	 */
	public void setEntLinkmanId(String entLinkmanId) {
		this.entLinkmanId = entLinkmanId;
	}

	/**
	 * 获取entLinkman
	 * @return entLinkman
	 */
	public String getEntLinkman() {
		return entLinkman;
	}

	/**  
	 * 设置entLinkman  
	 * @param entLinkman
	 */
	public void setEntLinkman(String entLinkman) {
		this.entLinkman = entLinkman;
	}

	/**
	 * 获取entTel
	 * @return entTel
	 */
	public String getEntTel() {
		return entTel;
	}

	/**  
	 * 设置entTel  
	 * @param entTel
	 */
	public void setEntTel(String entTel) {
		this.entTel = entTel;
	}

	/**
	 * 获取entFax
	 * @return entFax
	 */
	public String getEntFax() {
		return entFax;
	}

	/**  
	 * 设置entFax  
	 * @param entFax
	 */
	public void setEntFax(String entFax) {
		this.entFax = entFax;
	}

	/**
	 * 获取entEmail
	 * @return entEmail
	 */
	public String getEntEmail() {
		return entEmail;
	}

	/**  
	 * 设置entEmail  
	 * @param entEmail
	 */
	public void setEntEmail(String entEmail) {
		this.entEmail = entEmail;
	}

	/**
	 * 获取estDate
	 * @return estDate
	 */
	public Date getEstDate() {
		return estDate;
	}

	/**  
	 * 设置estDate  
	 * @param estDate
	 */
	public void setEstDate(Date estDate) {
		this.estDate = estDate;
	}

	/**
	 * 获取regCap
	 * @return regCap
	 */
	public Double getRegCap() {
		return regCap;
	}

	/**  
	 * 设置regCap  
	 * @param regCap
	 */
	public void setRegCap(Double regCap) {
		this.regCap = regCap;
	}

	/**
	 * 获取unitId
	 * @return unitId
	 */
	public String getUnitId() {
		return unitId;
	}

	/**  
	 * 设置unitId  
	 * @param unitId
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * 获取unitName
	 * @return unitName
	 */
	public String getUnitName() {
		return unitName;
	}

	/**  
	 * 设置unitName  
	 * @param unitName
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * 获取areaCode
	 * @return areaCode
	 */
	public String getAreaCode() {
		return areaCode;
	}

	/**  
	 * 设置areaCode  
	 * @param areaCode
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	/**
	 * 获取areaName
	 * @return areaName
	 */
	public String getAreaName() {
		return areaName;
	}

	/**  
	 * 设置areaName  
	 * @param areaName
	 */
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	/**
	 * 获取areaTypeId
	 * @return areaTypeId
	 */
	public String getAreaTypeId() {
		return areaTypeId;
	}

	/**  
	 * 设置areaTypeId  
	 * @param areaTypeId
	 */
	public void setAreaTypeId(String areaTypeId) {
		this.areaTypeId = areaTypeId;
	}

	/**
	 * 获取areaTypeName
	 * @return areaTypeName
	 */
	public String getAreaTypeName() {
		return areaTypeName;
	}

	/**  
	 * 设置areaTypeName  
	 * @param areaTypeName
	 */
	public void setAreaTypeName(String areaTypeName) {
		this.areaTypeName = areaTypeName;
	}

	/**
	 * 获取longitude
	 * @return longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**  
	 * 设置longitude  
	 * @param longitude
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	/**
	 * 获取latitude
	 * @return latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**  
	 * 设置latitude  
	 * @param latitude
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * 获取entState
	 * @return entState
	 */
	public Integer getEntState() {
		return entState;
	}

	/**  
	 * 设置entState  
	 * @param entState
	 */
	public void setEntState(Integer entState) {
		this.entState = entState;
	}

	/**
	 * 获取workScope
	 * @return workScope
	 */
	public String getWorkScope() {
		return workScope;
	}

	/**  
	 * 设置workScope  
	 * @param workScope
	 */
	public void setWorkScope(String workScope) {
		this.workScope = workScope;
	}

	/**
	 * 获取entTypeId
	 * @return entTypeId
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**  
	 * 设置entTypeId  
	 * @param entTypeId
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * 获取entTypeName
	 * @return entTypeName
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**  
	 * 设置entTypeName  
	 * @param entTypeName
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * 获取entTypeGroupId
	 * @return entTypeGroupId
	 */
	public String getEntTypeGroupId() {
		return entTypeGroupId;
	}

	/**  
	 * 设置entTypeGroupId  
	 * @param entTypeGroupId
	 */
	public void setEntTypeGroupId(String entTypeGroupId) {
		this.entTypeGroupId = entTypeGroupId;
	}

	/**
	 * 获取entTypeGroupName
	 * @return entTypeGroupName
	 */
	public String getEntTypeGroupName() {
		return entTypeGroupName;
	}

	/**  
	 * 设置entTypeGroupName  
	 * @param entTypeGroupName
	 */
	public void setEntTypeGroupName(String entTypeGroupName) {
		this.entTypeGroupName = entTypeGroupName;
	}

	/**
	 * 获取isUnlicensed
	 * @return isUnlicensed
	 */
	public Integer getIsUnlicensed() {
		return isUnlicensed;
	}

	/**  
	 * 设置isUnlicensed  
	 * @param isUnlicensed
	 */
	public void setIsUnlicensed(Integer isUnlicensed) {
		this.isUnlicensed = isUnlicensed;
	}

	/**
	 * 获取check
	 * @return check
	 */
	public CheckInfo2 getCheck() {
		return check;
	}

	/**  
	 * 设置check  
	 * @param check
	 */
	public void setCheck(CheckInfo2 check) {
		this.check = check;
	}
}
