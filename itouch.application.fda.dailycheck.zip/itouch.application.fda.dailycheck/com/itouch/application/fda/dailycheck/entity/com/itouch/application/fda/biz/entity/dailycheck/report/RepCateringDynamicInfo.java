package com.itouch.application.fda.biz.entity.dailycheck.report;

import iTouch.framework.data.operation.IBusinessObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/** 
 * @Description: 餐饮企业量化分级统计表
 * @ClassName: RepCateringDynamic 
 * @author: wangk
 * @date: 2016-3-22 上午10:35:57  
 */
@Entity
@Table(name="DC_REP_CATERING_DYNAMIC")
public class RepCateringDynamicInfo implements IBusinessObject{
	
	/**主键Id*/
	@Id
	@Column(name="ID")
	@GeneratedValue(generator="system-uuid") 
	@GenericGenerator(name="system-uuid", strategy="uuid")
	private String id;
	
	/**报表Id*/
	@Column(name="REPORT_ID")
	private String reportId;
	
	/**单位类别Id*/
	@Column(name="ENT_TYPE_ID")
	private String entTypeId;
	
	/**单位类别名称*/
	@Column(name="ENT_TYPE_Name")
	private String entTypeName;
	
	/** 总数 **/
	@Column(name="TOTAL_COUNT")
	private Integer totalCount;
	
	/** 年度等级A **/
	@Column(name="ANNUAL_CREDIT_A")
	private Integer annualCreditA;
	
	/** 年度等级B **/
	@Column(name="ANNUAL_CREDIT_B")
	private Integer annualCreditB;
	
	/** 年度等级C **/
	@Column(name="ANNUAL_CREDIT_C")
	private Integer annualCreditC;
	
	/** 动态等级A **/
	@Column(name="DYNAMIC_CREDIT_A")
	private Integer dynamicCreditA;
	
	/** 动态等级B **/
	@Column(name="DYNAMIC_CREDIT_B")
	private Integer dynamicCreditB;
	
	/** 动态等级C **/
	@Column(name="DYNAMIC_CREDIT_C")
	private Integer dynamicCreditC;
	
	/** 待评定 **/
	@Column(name="TO_BE_CREDIT_COUNT")
	private Integer toBeCreditCount;
	
	/** 新办证3个月内 **/
	@Column(name="NEW_APPLY_COUNT")
	private Integer newApplyCount;
	
	/** 责令整改 **/
	@Column(name="REFORM_COUNT")
	private Integer reformCount;

	/**
	 * @Description: 获取 主键Id
	 * @return: id
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public String getId() {
		return id;
	}

	/**   
	 * @Description: 设置 主键Id   
	 * @param: id 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @Description: 获取 报表Id
	 * @return: reportId
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public String getReportId() {
		return reportId;
	}

	/**   
	 * @Description: 设置 报表Id   
	 * @param: reportId 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	/**
	 * @Description: 获取 单位类别Id
	 * @return: entTypeId
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public String getEntTypeId() {
		return entTypeId;
	}

	/**   
	 * @Description: 设置 单位类别Id   
	 * @param: entTypeId 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public void setEntTypeId(String entTypeId) {
		this.entTypeId = entTypeId;
	}

	/**
	 * @Description: 获取 单位类别名称
	 * @return: entTypeName
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public String getEntTypeName() {
		return entTypeName;
	}

	/**   
	 * @Description: 设置 单位类别名称   
	 * @param: entTypeName 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:56:59 
	 */
	public void setEntTypeName(String entTypeName) {
		this.entTypeName = entTypeName;
	}

	/**
	 * @Description: 获取 总数
	 * @return: totalCount
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getTotalCount() {
		return totalCount;
	}

	/**   
	 * @Description: 设置 总数   
	 * @param: totalCount 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @Description: 获取 年度等级A
	 * @return: annualCreditA
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getAnnualCreditA() {
		return annualCreditA;
	}

	/**   
	 * @Description: 设置 年度等级A   
	 * @param: annualCreditA 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setAnnualCreditA(Integer annualCreditA) {
		this.annualCreditA = annualCreditA;
	}

	/**
	 * @Description: 获取 年度等级B
	 * @return: annualCreditB
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getAnnualCreditB() {
		return annualCreditB;
	}

	/**   
	 * @Description: 设置 年度等级B   
	 * @param: annualCreditB 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setAnnualCreditB(Integer annualCreditB) {
		this.annualCreditB = annualCreditB;
	}

	/**
	 * @Description: 获取 年度等级C
	 * @return: annualCreditC
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getAnnualCreditC() {
		return annualCreditC;
	}

	/**   
	 * @Description: 设置 年度等级C   
	 * @param: annualCreditC 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setAnnualCreditC(Integer annualCreditC) {
		this.annualCreditC = annualCreditC;
	}

	/**
	 * @Description: 获取 动态等级A
	 * @return: dynamicCreditA
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getDynamicCreditA() {
		return dynamicCreditA;
	}

	/**   
	 * @Description: 设置 动态等级A   
	 * @param: dynamicCreditA 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setDynamicCreditA(Integer dynamicCreditA) {
		this.dynamicCreditA = dynamicCreditA;
	}

	/**
	 * @Description: 获取 动态等级B
	 * @return: dynamicCreditB
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getDynamicCreditB() {
		return dynamicCreditB;
	}

	/**   
	 * @Description: 设置 动态等级B   
	 * @param: dynamicCreditB 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setDynamicCreditB(Integer dynamicCreditB) {
		this.dynamicCreditB = dynamicCreditB;
	}

	/**
	 * @Description: 获取 动态等级C
	 * @return: dynamicCreditC
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getDynamicCreditC() {
		return dynamicCreditC;
	}

	/**   
	 * @Description: 设置 动态等级C   
	 * @param: dynamicCreditC 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setDynamicCreditC(Integer dynamicCreditC) {
		this.dynamicCreditC = dynamicCreditC;
	}

	/**
	 * @Description: 获取 待评定
	 * @return: toBeCreditCount
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getToBeCreditCount() {
		return toBeCreditCount;
	}

	/**   
	 * @Description: 设置 待评定   
	 * @param: toBeCreditCount 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setToBeCreditCount(Integer toBeCreditCount) {
		this.toBeCreditCount = toBeCreditCount;
	}

	/**
	 * @Description: 获取 新办证3个月内
	 * @return: newApplyCount
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getNewApplyCount() {
		return newApplyCount;
	}

	/**   
	 * @Description: 设置 新办证3个月内   
	 * @param: newApplyCount 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setNewApplyCount(Integer newApplyCount) {
		this.newApplyCount = newApplyCount;
	}

	/**
	 * @Description: 获取 责令整改
	 * @return: reformCount
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public Integer getReformCount() {
		return reformCount;
	}

	/**   
	 * @Description: 设置 责令整改   
	 * @param: reformCount 
	 * @author: wangk
	 * @date: 2016-3-22 上午10:57:00 
	 */
	public void setReformCount(Integer reformCount) {
		this.reformCount = reformCount;
	}
}
