/**  
* @Title: VTaskUnitTaskInfo.java 
* @Package com.itouch.application.fda.biz.entity.dailycheck.task 
* @author wangk    
* @date 2015-10-30 下午2:30:46  
*/ 
package com.itouch.application.fda.biz.entity.dailycheck.task;

import iTouch.framework.data.operation.IBusinessObject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-11-2 上午9:40:22  
 */
@Entity
@Table(name="V_DC_TASKUNIT_TASK")
public class VTaskUnitTaskInfo  implements IBusinessObject{

	/** @Fields unitTaskId : 单位任务Id **/ 
	@Id
	@Column(name="UNIT_TASK_ID")
	private String 	unitTaskId;
	
	/** @Fields taskName : 任务名称 **/ 
	@Column(name="TASK_NAME")
	private String taskName;
	
	/** @Fields taskId : 任务Id **/
	@Column(name="TASK_Id")
	private String taskId;
	
	/** @Fields taskCreateOrg : 任务制定单位 **/ 
	@Column(name="TASK_CREATE_ORG")
	private String taskCreateOrg;
	
	/** @Fields taskBeginDate : 任务时间自 **/ 
	@Column(name="TASK_BEGIN_DATE")
	private Date taskBeginDate;
	
	/** @Fields taskEndDate : 计划时间至 **/ 
	@Column(name="TASK_END_DATE")
	private Date taskEndDate;
	
	/** @Fields taskState : 待接收、已下发、已接收、待上报、已上报 **/ 
	@Column(name="TASK_STATE")
	private Integer taskState;
	
	/** @Fields completedDate : 完成时间 **/ 
	@Column(name="COMPLETED_DATE")
	private Date completedDate;
	
	/** @Fields unitId : 单位Id **/ 
	@Column(name="UNIT_ID")
	private String unitId;
	
	/** @Fields unitName : 单位名称 **/
	@Column(name="UNIT_NAME")
	private String unitName;
	
	/** @Fields remark : 备注 **/ 
	@Column(name="REMARK")
	private String remark;
	
	/** @Fields attachmentCode : 附件组号 **/ 
	@Column(name="ATTACHMENT_CODE")
	private String attachmentCode;
	
	/** @Fields taskCreatorName : 任务发布人 **/ 
	@Column(name="TASK_CREATOR_NAME")
	private String taskCreatorName;
	
	/** @Fields taskCreateTime : 任务发布时间 **/ 
	@Column(name="TASK_CREATE_TIME")
	private Date taskCreateTime;
	
	/** 检查表Id **/ 
	@Column(name="TABLE_ID")
	private String tableId;
	
	/** @Fields tableName : 检查表名称 **/ 
	@Column(name="TABLE_NAME")
	private String tableName;
	
	/** 任务来源 **/
	@Column(name="TASK_SOURCE")
	private String taskSource;
	
	/** 任务来源单位ID **/
	@Column(name="FROM_UNIT_ID")
	private String fromUnitId;
	
	/** 上报内容 **/
	@Column(name="REPORT")
	private String report;
	
	/**
	 * 获取taskName
	 * @return taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**  
	 * 设置taskName  
	 * @param taskName
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * @return 获取 attachmentCode
	 */
	public String getAttachmentCode() {
		return attachmentCode;
	}

	/**   
	 * @param attachmentCode 
	 * 要设置的 attachmentCode   
	 */
	public void setAttachmentCode(String attachmentCode) {
		this.attachmentCode = attachmentCode;
	}

	/**
	 * 获取taskCreateOrg
	 * @return taskCreateOrg
	 */
	public String getTaskCreateOrg() {
		return taskCreateOrg;
	}

	/**  
	 * 设置taskCreateOrg  
	 * @param taskCreateOrg
	 */
	public void setTaskCreateOrg(String taskCreateOrg) {
		this.taskCreateOrg = taskCreateOrg;
	}

	/**
	 * 获取taskBeginDate
	 * @return taskBeginDate
	 */
	public Date getTaskBeginDate() {
		return taskBeginDate;
	}

	/**  
	 * 设置taskBeginDate  
	 * @param taskBeginDate
	 */
	public void setTaskBeginDate(Date taskBeginDate) {
		this.taskBeginDate = taskBeginDate;
	}

	/**
	 * 获取taskEndDate
	 * @return taskEndDate
	 */
	public Date getTaskEndDate() {
		return taskEndDate;
	}

	/**  
	 * 设置taskEndDate  
	 * @param taskEndDate
	 */
	public void setTaskEndDate(Date taskEndDate) {
		this.taskEndDate = taskEndDate;
	}

	/**
	 * 获取taskState
	 * @return taskState
	 */
	public Integer getTaskState() {
		return taskState;
	}

	/**  
	 * 设置taskState  
	 * @param taskState
	 */
	public void setTaskState(Integer taskState) {
		this.taskState = taskState;
	}

	/**
	 * 获取unitTaskId
	 * @return unitTaskId
	 */
	public String getUnitTaskId() {
		return unitTaskId;
	}

	/**  
	 * 设置unitTaskId  
	 * @param unitTaskId
	 */
	public void setUnitTaskId(String unitTaskId) {
		this.unitTaskId = unitTaskId;
	}

	/**
	 * 获取unitId
	 * @return unitId
	 */
	public String getUnitId() {
		return unitId;
	}

	/**  
	 * 设置unitId  
	 * @param unitId
	 */
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	/**
	 * @return 获取 taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**   
	 * @param taskId 
	 * 要设置的 taskId   
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return 获取 completedDate
	 */
	public Date getCompletedDate() {
		return completedDate;
	}

	/**   
	 * @param completedDate 
	 * 要设置的 completedDate   
	 */
	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	/**
	 * @return 获取 unitName
	 */
	public String getUnitName() {
		return unitName;
	}

	/**   
	 * @param unitName 
	 * 要设置的 unitName   
	 */
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/**
	 * @return 获取 remark
	 */
	public String getRemark() {
		return remark;
	}

	/**   
	 * @param remark 
	 * 要设置的 remark   
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return 获取 taskCreatorName
	 */
	public String getTaskCreatorName() {
		return taskCreatorName;
	}

	/**   
	 * @param taskCreatorName 
	 * 要设置的 taskCreatorName   
	 */
	public void setTaskCreatorName(String taskCreatorName) {
		this.taskCreatorName = taskCreatorName;
	}

	/**
	 * @return 获取 taskCreateTime
	 */
	public Date getTaskCreateTime() {
		return taskCreateTime;
	}

	/**   
	 * @param taskCreateTime 
	 * 要设置的 taskCreateTime   
	 */
	public void setTaskCreateTime(Date taskCreateTime) {
		this.taskCreateTime = taskCreateTime;
	}

	/**
	 * @return 获取 tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**   
	 * @param tableName 
	 * 要设置的 tableName
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @Description: 获取 检查表Id
	 * @return: tableId 检查表Id
	 * @author wangk
	 * @date 2015-11-27 下午5:53:08 
	 */
	public String getTableId() {
		return tableId;
	}

	/**   
	 * @Description: 设置 检查表Id   
	 * @param: tableId 检查表Id 
	 * @author wangk
	 * @date 2015-11-27 下午5:53:08 
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * @Description: 获取 任务来源
	 * @return: taskSource 任务来源
	 * @author wangk
	 * @date 2015-11-30 下午1:04:07 
	 */
	public String getTaskSource() {
		return taskSource;
	}

	/**   
	 * @Description: 设置 任务来源   
	 * @param: taskSource 任务来源 
	 * @author wangk
	 * @date 2015-11-30 下午1:04:07 
	 */
	public void setTaskSource(String taskSource) {
		this.taskSource = taskSource;
	}

	/**
	 * @Description: 获取 fromUnitId
	 * @return: fromUnitId fromUnitId
	 * @author wangk
	 * @date 2015-12-2 下午5:38:51 
	 */
	public String getFromUnitId() {
		return fromUnitId;
	}

	/**   
	 * @Description: 设置 fromUnitId   
	 * @param: fromUnitId fromUnitId 
	 * @author wangk
	 * @date 2015-12-2 下午5:38:51 
	 */
	public void setFromUnitId(String fromUnitId) {
		this.fromUnitId = fromUnitId;
	}

	/**
	 * @Description: 获取 report
	 * @return: report report
	 * @author wangk
	 * @date 2015-12-2 下午5:40:29 
	 */
	public String getReport() {
		return report;
	}

	/**   
	 * @Description: 设置 report   
	 * @param: report report 
	 * @author wangk
	 * @date 2015-12-2 下午5:40:29 
	 */
	public void setReport(String report) {
		this.report = report;
	}
}
