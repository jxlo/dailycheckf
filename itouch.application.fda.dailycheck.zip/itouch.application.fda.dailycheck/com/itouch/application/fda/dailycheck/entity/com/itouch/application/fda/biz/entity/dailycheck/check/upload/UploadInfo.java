package com.itouch.application.fda.biz.entity.dailycheck.check.upload;

import java.util.List;

/**
 * 上传信息
 */
public class UploadInfo {
	
	/**
	 * 附件列表
	 */
	public List<UploadFileInfo> uploadFileList;

	public List<UploadFileInfo> getUploadFileList() {
		return uploadFileList;
	}

	public void setUploadFileList(List<UploadFileInfo> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}
}
