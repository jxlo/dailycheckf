package com.itouch.application.fda.dailycheck.service;

import iTouch.framework.data.model.PageResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itouch.application.fda.biz.bll.dailycheck.check.IVCheckManager;
import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckInfo;
import com.itouch.application.fda.foundation.component.ControllerBase;

/**
 * @author:zhangzt 检查记录服务
 */
@Controller
@RequestMapping("/dailycheck/service/check")
public class CheckRecordService extends ControllerBase {

	/**
	 * @Description:TODO
	 * @param request
	 * @param response
	 * @author:zhangzt
	 * @time:2016年5月29日 下午7:17:09
	 */
	@RequestMapping("/getCheckRecordList")
	public void getCheckRecordList(VCheckInfo vCheckInfo, HttpServletRequest request, HttpServletResponse response) {
		IVCheckManager bllVCheck = mappers.getMapper(IVCheckManager.class);
		PageResultSet pageResultSet = null;
		// TODO 可以添加单位过滤条件

		try {
			pageResultSet = bllVCheck.getListByPage(getPageSize(request), getPageIndex(request), vCheckInfo);
			toDatatable(response, pageResultSet);
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
