/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:DcSysCheckTypeDao.java
 * @author:xh
 * @time:2015-10-10 下午4:46:25
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.param.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.param.ICheckTypeDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.param.CheckTypeInfo;

/**
 *
 * @author xh
 */
@Repository
public class CheckTypeDao extends BaseCommonDao<CheckTypeInfo> implements ICheckTypeDao{

}
