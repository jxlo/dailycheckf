package com.itouch.application.fda.biz.dao.dailycheck.check;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckTodoInfo;

public interface ICheckTodoDao extends IBaseCommonDao<CheckTodoInfo>{

}
