package com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.ICreditConditionDetailDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditConditionDetailInfo;

@Repository
public class CreditConditionDetailDao extends BaseCommonDao<CreditConditionDetailInfo> implements ICreditConditionDetailDao  {

}
