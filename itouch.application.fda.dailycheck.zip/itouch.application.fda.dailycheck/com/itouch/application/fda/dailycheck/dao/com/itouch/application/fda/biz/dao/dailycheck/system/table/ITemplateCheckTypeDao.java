/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITemplateCheckTypeInfoDao.java
 * @author:xh
 * @time:2015-10-10 下午5:48:59
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateCheckTypeInfo;

/**
 *
 * @author xh
 */
public interface ITemplateCheckTypeDao  extends IBaseCommonDao<TemplateCheckTypeInfo>{

}
