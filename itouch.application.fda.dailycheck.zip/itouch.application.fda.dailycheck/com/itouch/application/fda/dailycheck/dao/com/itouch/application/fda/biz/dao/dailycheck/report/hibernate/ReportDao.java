package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IReportDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.ReportInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: ReportDao 
 * @author: wangk
 * @date: 2016-3-16 下午1:57:00  
 */
@Repository
public class ReportDao extends BaseCommonDao<ReportInfo> implements IReportDao{

}
