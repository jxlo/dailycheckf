package com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.ICreditRankDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditRankInfo;

@Repository
public class CreditRankDao extends BaseCommonDao<CreditRankInfo> implements ICreditRankDao  {

}
