/**     
  * @Title: TaskSourceDao.java   
  * @Package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-12 下午4:28:35     
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskSourceDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskSourceInfo;

/**   
 * @ClassName: TaskSourceDao   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-12 下午4:28:35      
 */
@Repository
public class TaskSourceDao extends BaseCommonDao<TaskSourceInfo> implements ITaskSourceDao{

}
