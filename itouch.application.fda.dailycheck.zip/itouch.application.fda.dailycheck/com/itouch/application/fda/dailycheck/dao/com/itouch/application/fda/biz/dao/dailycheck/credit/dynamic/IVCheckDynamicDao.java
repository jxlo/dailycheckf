/**  
 * @Description: TODO
 * @Title: IVCheckDynamicDao.java 
 * @Package: com.itouch.application.fda.biz.dao.dailycheck.credit.food.catering.dynamic 
 * @author: wangk
 * @date 2016-2-24 下午4:37:16 
 */ 
package com.itouch.application.fda.biz.dao.dailycheck.credit.dynamic;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic.VCheckDynamicInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: IVCheckDynamicDao 
 * @author wangk
 * @date 2016-2-24 下午4:37:16  
 */
public interface IVCheckDynamicDao extends IBaseCommonDao<VCheckDynamicInfo>{

}
