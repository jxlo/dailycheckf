/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:PlanUserDao.java
 * @author:fanghailong
 * @time:2015-10-20 下午4:11:44
 */
package com.itouch.application.fda.biz.dao.dailycheck.plan.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.plan.IPlanUserDao;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanUserInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class PlanUserDao extends BaseCommonDao<PlanUserInfo> implements IPlanUserDao{

}
