package com.itouch.application.fda.biz.dao.dailycheck.check.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckTodoDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckTodoInfo;

@Repository
public class CheckTodoDao extends BaseCommonDao<CheckTodoInfo> implements ICheckTodoDao{

}
