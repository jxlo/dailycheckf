/**     
  * @Title: ITaskSourceDao.java   
  * @Package com.itouch.application.fda.biz.dao.dailycheck.task   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-12 下午4:26:32     
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.task;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.task.TaskSourceInfo;

/**   
 * @ClassName: ITaskSourceDao   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-12 下午4:26:32      
 */
public interface ITaskSourceDao extends IBaseCommonDao<TaskSourceInfo>{

}
