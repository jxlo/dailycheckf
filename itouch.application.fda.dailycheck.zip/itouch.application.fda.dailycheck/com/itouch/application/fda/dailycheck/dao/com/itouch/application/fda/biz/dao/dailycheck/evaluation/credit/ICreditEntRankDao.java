package com.itouch.application.fda.biz.dao.dailycheck.evaluation.credit;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.CreditEntRankInfo;

public interface ICreditEntRankDao extends IBaseCommonDao<CreditEntRankInfo>{

}
