/**  
  * @Description: TODO
  * @Title: IRepFoodBizPermitDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report 
  * @author: xh
  * @date 2016-3-22 上午10:28:59 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodBizPermitInfo;

/** 
 * @Description: TODO
 * @ClassName: IRepFoodBizPermitDao 
 * @author xh
 * @date 2016-3-22 上午10:28:59  
 */
public interface IRepFoodBizPermitDao extends IBaseCommonDao<RepFoodBizPermitInfo> {

}
