package com.itouch.application.fda.biz.dao.dailycheck.check;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckTodoInfo;

public interface IVCheckTodoDao extends IBaseCommonDao<VCheckTodoInfo>{

}
