package com.itouch.application.fda.biz.dao.dailycheck.index;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.index.VCateringDynamicReportInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: IVCateringDynamicReportDao 
 * @author: wangk
 * @date: 2016-3-28 下午1:58:46  
 */
public interface IVCateringDynamicReportDao extends IBaseCommonDao<VCateringDynamicReportInfo>{

}
