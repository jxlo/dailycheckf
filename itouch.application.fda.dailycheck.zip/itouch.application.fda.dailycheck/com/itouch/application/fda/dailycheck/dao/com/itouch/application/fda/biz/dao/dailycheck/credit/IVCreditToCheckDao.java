package com.itouch.application.fda.biz.dao.dailycheck.credit;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.credit.VCreditToCheckInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: IVCreditToCheckDao 
 * @author: wangk
 * @date: 2016-3-15 上午10:33:21  
 */
public interface IVCreditToCheckDao extends IBaseCommonDao<VCreditToCheckInfo>{

}
