/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITalkDao.java
 * @author:fanghailong
 * @time:2015-10-13 下午2:58:28
 */
package com.itouch.application.fda.biz.dao.dailycheck.talk;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.talk.TalkInfo;

/**
 * @author:fanghailong 
 */
public interface ITalkDao extends IBaseCommonDao<TalkInfo>{

}
