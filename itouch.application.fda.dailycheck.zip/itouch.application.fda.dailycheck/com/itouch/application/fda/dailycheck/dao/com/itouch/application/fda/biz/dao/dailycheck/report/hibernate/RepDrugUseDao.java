package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;


import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepDrugUseDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugUse;

@Repository
public class RepDrugUseDao extends BaseCommonDao<RepDrugUse> implements
		IRepDrugUseDao {

}
