/**  
  * @Description: TODO
  * @Title: RepCosmDailyCheckDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report.hibernate 
  * @author: xh
  * @date 2016-3-16 上午11:30:46 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepCosmDailyCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepCosmDailyCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: RepCosmDailyCheckDao 
 * @author xh
 * @date 2016-3-16 上午11:30:46  
 */
@Repository
public class RepCosmDailyCheckDao extends BaseCommonDao<RepCosmDailyCheckInfo> implements IRepCosmDailyCheckDao {

}
