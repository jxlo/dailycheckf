/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableHeaderDao.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:12:50
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableHeaderDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableHeaderInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class TableHeaderDao extends BaseCommonDao<TableHeaderInfo> implements ITableHeaderDao{

}
