/**  
* @Title: TaskUnitDao.java 
* @Package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate 
* @author wangk    
* @date 2015-10-27 下午4:43:56  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskUnitDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskUnitInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-27 下午4:43:56  
 */
@Repository
public class TaskUnitDao extends BaseCommonDao<TaskUnitInfo> implements ITaskUnitDao{

}
