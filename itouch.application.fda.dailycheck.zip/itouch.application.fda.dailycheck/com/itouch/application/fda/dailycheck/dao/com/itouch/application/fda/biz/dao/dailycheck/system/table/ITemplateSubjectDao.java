/**  
* @Title: DcTemplateSubjectDao.java 
* @Package com.itouch.application.fda.biz.dao.system.table 
* @author wangk    
* @date 2015-10-10 下午4:27:43  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSubjectInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-10 下午4:27:43  
 */
public interface ITemplateSubjectDao extends IBaseCommonDao<TemplateSubjectInfo> {

}
