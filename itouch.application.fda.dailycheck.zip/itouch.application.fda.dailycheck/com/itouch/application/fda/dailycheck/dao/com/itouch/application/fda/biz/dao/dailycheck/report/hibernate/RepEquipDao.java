package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;


import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepEquipDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepEquip;

@Repository
public class RepEquipDao extends BaseCommonDao<RepEquip> implements
		IRepEquipDao {

}
