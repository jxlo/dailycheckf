/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:VCheckReviewDao.java
 * @author:fanghailong
 * @time:2015-11-2 下午3:11:55
 */
package com.itouch.application.fda.biz.dao.dailycheck.check.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.check.IVCheckReviewDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckReviewInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class VCheckReviewDao extends BaseCommonDao<VCheckReviewInfo> implements IVCheckReviewDao{

}
