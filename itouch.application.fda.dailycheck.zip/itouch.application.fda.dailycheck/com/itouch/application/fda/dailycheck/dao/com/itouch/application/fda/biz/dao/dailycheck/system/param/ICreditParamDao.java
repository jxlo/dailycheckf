/**  
  * @Description: TODO
  * @Title: ICreditParamInfoDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.system.param 
  * @author: xh
  * @date 2016-2-19 下午2:32:00 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.system.param;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.param.CreditParamInfo;

/** 
 * @Description: TODO
 * @ClassName: ICreditParamInfoDao 
 * @author xh
 * @date 2016-2-19 下午2:32:00  
 */
public interface ICreditParamDao extends IBaseCommonDao<CreditParamInfo> {

}
