package com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood.ICreditHfoodProdCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood.CreditHfoodProdCheckInfo;

@Repository
public class CreditHfoodProdCheckDao extends BaseCommonDao<CreditHfoodProdCheckInfo> implements ICreditHfoodProdCheckDao{

}
