package com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou.CheckResultInfo;

/**
 * 检查结果
 */
public interface ICheckResultDao extends IBaseCommonDao<CheckResultInfo>{
}
