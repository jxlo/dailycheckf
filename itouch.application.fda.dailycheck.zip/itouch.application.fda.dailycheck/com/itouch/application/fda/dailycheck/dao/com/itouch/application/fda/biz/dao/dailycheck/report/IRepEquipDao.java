package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepEquip;

/** 
 * @Description:  医疗器械企业情况统计表
 * @ClassName: IRepDrugUseDao 
 */
public interface IRepEquipDao extends IBaseCommonDao<RepEquip> {

}
