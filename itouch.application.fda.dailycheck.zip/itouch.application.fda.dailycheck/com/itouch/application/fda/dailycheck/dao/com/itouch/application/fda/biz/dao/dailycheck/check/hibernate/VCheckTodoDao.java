package com.itouch.application.fda.biz.dao.dailycheck.check.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.check.IVCheckTodoDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckTodoInfo;

@Repository
public class VCheckTodoDao extends BaseCommonDao<VCheckTodoInfo> implements IVCheckTodoDao{

}
