/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:IPlanDao.java
 * @author:fanghailong
 * @time:2015-10-20 下午3:30:08
 */
package com.itouch.application.fda.biz.dao.dailycheck.plan;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanInfo;

/**
 * @author:fanghailong 
 */
public interface IPlanDao extends IBaseCommonDao<PlanInfo>{

}
