/**  
* @Title: VTaskUnitTaskDao.java 
* @Package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate 
* @author wangk    
* @date 2015-10-30 下午2:40:42  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.task.IVTaskUnitTaskDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.VTaskUnitTaskInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-30 下午2:40:42  
 */
@Repository
public class VTaskUnitTaskDao extends BaseCommonDao<VTaskUnitTaskInfo> implements IVTaskUnitTaskDao{

}
