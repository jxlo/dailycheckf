/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:IVCheckReviewDao.java
 * @author:fanghailong
 * @time:2015-11-2 下午3:11:10
 */
package com.itouch.application.fda.biz.dao.dailycheck.check;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckReviewInfo;

/**
 * @author:fanghailong 
 */
public interface IVCheckReviewDao extends IBaseCommonDao<VCheckReviewInfo>{

}
