/**  
  * @Description: TODO
  * @Title: IRepHfoodDailyCheckInfoDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report 
  * @author: xh
  * @date 2016-3-16 下午1:41:07 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepHfoodDailyCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: IRepHfoodDailyCheckInfoDao 
 * @author xh
 * @date 2016-3-16 下午1:41:07  
 */
public interface IRepHfoodDailyCheckDao extends IBaseCommonDao<RepHfoodDailyCheckInfo>{

}
