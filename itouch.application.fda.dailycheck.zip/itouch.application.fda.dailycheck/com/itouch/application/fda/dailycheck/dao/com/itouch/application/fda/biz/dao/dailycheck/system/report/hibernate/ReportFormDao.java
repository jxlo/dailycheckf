package com.itouch.application.fda.biz.dao.dailycheck.system.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.report.IReportFormDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.report.ReportFormInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: ReportFromDao 
 * @author: wangk
 * @date: 2016-3-16 下午1:56:43  
 */
@Repository
public class ReportFormDao extends BaseCommonDao<ReportFormInfo> implements IReportFormDao{

}
