/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TableCheckResultDao.java
 * @author:xh
 * @time:2015-10-26 下午7:08:09
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableCheckResultDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableCheckResult;

/**
 *
 * @author xh
 */
@Repository
public class TableCheckResultDao extends BaseCommonDao<TableCheckResult> implements ITableCheckResultDao {

}
