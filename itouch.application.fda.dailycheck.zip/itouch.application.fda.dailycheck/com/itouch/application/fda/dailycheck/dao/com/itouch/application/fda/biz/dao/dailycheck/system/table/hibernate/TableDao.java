/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableDao.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:11:18
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.MapperSQLException;
import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class TableDao extends BaseCommonDao<TableInfo> implements ITableDao{

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableDao#sizeBysql(java.lang.String, java.lang.Object)
	 */
	@Override
	public int sizeBysql(String command, Object[] propertyValues) throws MapperSQLException {
		Session session = getSession();

		Query query = session.createQuery(command);
		if (propertyValues != null && propertyValues.length > 0) {
			for (int i = 0; i < propertyValues.length; i++) {
				query.setParameter(Integer.toString(i + 1), propertyValues[i]);
			}
		}
		Long lg = (Long) query.uniqueResult();
		int size = lg == null ? 0 : lg.intValue();
		return size;
	}

}
