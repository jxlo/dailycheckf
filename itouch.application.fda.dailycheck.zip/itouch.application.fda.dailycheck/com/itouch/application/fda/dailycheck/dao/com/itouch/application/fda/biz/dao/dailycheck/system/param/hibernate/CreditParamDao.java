/**  
  * @Description: TODO
  * @Title: CreditParamDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.system.param.hibernate 
  * @author: xh
  * @date 2016-2-19 下午2:32:14 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.system.param.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.param.ICreditParamDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.param.CreditParamInfo;

/** 
 * @Description: TODO
 * @ClassName: CreditParamDao 
 * @author xh
 * @date 2016-2-19 下午2:32:14  
 */
@Repository
public class CreditParamDao  extends BaseCommonDao<CreditParamInfo> implements ICreditParamDao{

}
