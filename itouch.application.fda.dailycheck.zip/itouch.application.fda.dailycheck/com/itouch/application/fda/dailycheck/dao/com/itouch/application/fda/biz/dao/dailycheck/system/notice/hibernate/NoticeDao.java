package com.itouch.application.fda.biz.dao.dailycheck.system.notice.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.notice.INoticeDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.notice.NoticeInfo;

/**   
 * @ClassName: NoticeDao   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author jx  
 */
@Repository
public class NoticeDao extends BaseCommonDao<NoticeInfo> implements INoticeDao{

}
