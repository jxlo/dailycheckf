package com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou.ICheckTemplateDetailDao;
import com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou.CheckTemplateDetailInfo;

/**
 * 检查模板明细
 */
@Repository
public class CheckTemplateDetailDao extends BaseCommonDao<CheckTemplateDetailInfo> implements ICheckTemplateDetailDao  {

}
