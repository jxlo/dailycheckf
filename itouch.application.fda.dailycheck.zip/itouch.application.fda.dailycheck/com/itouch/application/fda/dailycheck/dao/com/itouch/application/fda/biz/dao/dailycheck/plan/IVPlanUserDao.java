/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:IVPlanUserDao.java
 * @author:fanghailong
 * @time:2015-10-28 下午4:57:32
 */
package com.itouch.application.fda.biz.dao.dailycheck.plan;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.plan.VPlanUserInfo;

/**
 * @author:fanghailong 
 */
public interface IVPlanUserDao extends IBaseCommonDao<VPlanUserInfo>{

}
