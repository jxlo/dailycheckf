/**  
 * @Description: TODO
 * @Title: ICreditAnnual.java 
 * @Package: com.itouch.application.fda.biz.dao.dailycheck.credit.food.catering.annual 
 * @author: wangk
 * @date 2016-2-24 下午4:15:04 
 */ 
package com.itouch.application.fda.biz.dao.dailycheck.credit.annual;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.CreditAnnualInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: ICreditAnnual 
 * @author wangk
 * @date 2016-2-24 下午4:15:04  
 */
public interface ICreditAnnualDao extends IBaseCommonDao<CreditAnnualInfo>{

}
