package com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou.CheckTemplateDetailInfo;

/**
 * 检查模板明细
 */
public interface ICheckTemplateDetailDao extends IBaseCommonDao<CheckTemplateDetailInfo>{
}
