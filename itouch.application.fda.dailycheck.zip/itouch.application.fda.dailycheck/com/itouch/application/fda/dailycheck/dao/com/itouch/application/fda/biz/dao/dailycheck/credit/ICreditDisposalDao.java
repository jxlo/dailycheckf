package com.itouch.application.fda.biz.dao.dailycheck.credit;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.credit.CreditDisposalInfo;

public interface ICreditDisposalDao extends IBaseCommonDao<CreditDisposalInfo>{

}
