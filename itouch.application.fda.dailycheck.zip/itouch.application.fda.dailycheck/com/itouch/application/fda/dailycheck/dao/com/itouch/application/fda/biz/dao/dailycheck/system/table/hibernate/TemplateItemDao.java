/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateItemDao.java
 * @author:fanghailong
 * @time:2015-10-10 下午4:13:36
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateItemDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateItemInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class TemplateItemDao extends BaseCommonDao<TemplateItemInfo> implements ITemplateItemDao{

}
