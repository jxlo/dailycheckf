/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ICheckTableOptionDao.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:06:13
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableOptionInfo;

/**
 * @author:fanghailong 
 */
public interface ITableOptionDao extends IBaseCommonDao<TableOptionInfo>{

}
