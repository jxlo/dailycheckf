/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckEntDao.java
 * @author:fanghailong
 * @time:2015-10-23 下午2:21:40
 */
package com.itouch.application.fda.biz.dao.dailycheck.check.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckEntDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckEntInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class CheckEntDao extends BaseCommonDao<CheckEntInfo> implements ICheckEntDao{

}
