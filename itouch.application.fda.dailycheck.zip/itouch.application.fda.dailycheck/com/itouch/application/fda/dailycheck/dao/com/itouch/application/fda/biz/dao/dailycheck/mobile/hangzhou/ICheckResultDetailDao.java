package com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou.CheckResultDetailInfo;

/**
 * 检查结果明细
 */
public interface ICheckResultDetailDao extends IBaseCommonDao<CheckResultDetailInfo>{
}
