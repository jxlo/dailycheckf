/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITemplateHeaderDao.java
 * @author:fanghailong
 * @time:2015-10-12 下午4:13:13
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateHeaderInfo;

/**
 * @author:fanghailong 
 */
public interface ITemplateHeaderDao extends IBaseCommonDao<TemplateHeaderInfo>{

}
