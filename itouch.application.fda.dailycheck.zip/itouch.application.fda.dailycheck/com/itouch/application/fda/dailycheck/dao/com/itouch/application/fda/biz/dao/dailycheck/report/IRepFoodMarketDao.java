/**  
  * @Description: TODO
  * @Title: IRepFoodMarketDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report 
  * @author: xh
  * @date 2016-3-24 上午11:32:15 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodMarketInfo;

/** 
 * @Description: TODO
 * @ClassName: IRepFoodMarketDao 
 * @author xh
 * @date 2016-3-24 上午11:32:15  
 */
public interface IRepFoodMarketDao  extends IBaseCommonDao<RepFoodMarketInfo>{

}
