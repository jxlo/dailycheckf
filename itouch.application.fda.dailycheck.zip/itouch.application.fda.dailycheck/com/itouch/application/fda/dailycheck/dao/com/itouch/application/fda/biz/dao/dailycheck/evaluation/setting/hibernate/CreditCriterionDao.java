package com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.ICreditCriterionDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditCriterionInfo;

@Repository
public class CreditCriterionDao extends BaseCommonDao<CreditCriterionInfo> implements ICreditCriterionDao  {

}
