/**  
  * @Description: TODO
  * @Title: RepHfoodDailyCheckDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report.hibernate 
  * @author: xh
  * @date 2016-3-16 下午1:41:56 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepHfoodDailyCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepHfoodDailyCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: RepHfoodDailyCheckDao 
 * @author xh
 * @date 2016-3-16 下午1:41:56  
 */
@Repository
public class RepHfoodDailyCheckDao  extends BaseCommonDao<RepHfoodDailyCheckInfo> implements IRepHfoodDailyCheckDao{

}
