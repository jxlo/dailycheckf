package com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood.CreditHfoodProdCheckInfo;

public interface ICreditHfoodProdCheckDao extends IBaseCommonDao<CreditHfoodProdCheckInfo>{

}
