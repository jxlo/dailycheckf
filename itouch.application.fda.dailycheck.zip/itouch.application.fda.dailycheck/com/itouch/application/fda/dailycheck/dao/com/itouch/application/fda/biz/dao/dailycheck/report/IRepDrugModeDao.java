package com.itouch.application.fda.biz.dao.dailycheck.report;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugMode;

import iTouch.framework.application.dao.IBaseCommonDao;

/** 
 * @Description:  药品生产企业情况统计表
 * @ClassName: IRepDrugModeDao 
 */
public interface IRepDrugModeDao extends IBaseCommonDao<RepDrugMode> {

}
