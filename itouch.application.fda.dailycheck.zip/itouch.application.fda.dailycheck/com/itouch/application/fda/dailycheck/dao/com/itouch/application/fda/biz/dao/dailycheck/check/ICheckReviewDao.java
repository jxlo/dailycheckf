/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ICheckReviewDao.java
 * @author:fanghailong
 * @time:2015-10-20 下午5:03:00
 */
package com.itouch.application.fda.biz.dao.dailycheck.check;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckReviewInfo;

/**
 * @author:fanghailong 
 */
public interface ICheckReviewDao extends IBaseCommonDao<CheckReviewInfo>{

}
