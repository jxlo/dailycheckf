/**  
 * @Description: TODO
 * @Title: CreditDynamicDao.java 
 * @Package: com.itouch.application.fda.biz.dao.dailycheck.credit.food.catering.dynamic.hibernate 
 * @author: wangk
 * @date 2016-2-24 下午4:20:04 
 */ 
package com.itouch.application.fda.biz.dao.dailycheck.credit.dynamic.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.credit.dynamic.ICreditDynamicDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic.CreditDynamicInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: CreditDynamicDao 
 * @author wangk
 * @date 2016-2-24 下午4:20:04  
 */
@Repository
public class CreditDynamicDao extends BaseCommonDao<CreditDynamicInfo> implements ICreditDynamicDao{

}
