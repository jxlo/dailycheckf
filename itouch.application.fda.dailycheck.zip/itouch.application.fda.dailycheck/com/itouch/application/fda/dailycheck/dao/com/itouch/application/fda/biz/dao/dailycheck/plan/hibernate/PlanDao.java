/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:PlanDao.java
 * @author:fanghailong
 * @time:2015-10-20 下午3:30:34
 */
package com.itouch.application.fda.biz.dao.dailycheck.plan.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.plan.IPlanDao;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class PlanDao extends BaseCommonDao<PlanInfo> implements IPlanDao{

}
