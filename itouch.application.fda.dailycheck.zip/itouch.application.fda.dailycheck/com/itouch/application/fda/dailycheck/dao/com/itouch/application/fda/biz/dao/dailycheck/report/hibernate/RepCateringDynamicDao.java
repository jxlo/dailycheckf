package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepCateringDynamicDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepCateringDynamicInfo;

/** 
 * @Description: 餐饮企业量化分级统计表 
 * @ClassName: RepCateringDynamicDao 
 * @author: wangk
 * @date: 2016-3-22 上午10:59:11  
 */
@Repository
public class RepCateringDynamicDao extends BaseCommonDao<RepCateringDynamicInfo> implements IRepCateringDynamicDao{
	
}
