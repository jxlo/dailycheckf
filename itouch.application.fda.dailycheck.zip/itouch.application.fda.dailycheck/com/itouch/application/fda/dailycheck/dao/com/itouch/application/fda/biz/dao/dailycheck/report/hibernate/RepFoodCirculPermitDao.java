package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepFoodCirculPermitDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodCirculPermitInfo;

/** 
 * @Description: 食品经营许可（流通）情况统计表 
 * @ClassName: RepFoodCirculPermitDao 
 * @author: wangk
 * @date: 2016-3-24 下午1:39:58  
 */
@Repository
public class RepFoodCirculPermitDao extends BaseCommonDao<RepFoodCirculPermitInfo> implements IRepFoodCirculPermitDao{

}
