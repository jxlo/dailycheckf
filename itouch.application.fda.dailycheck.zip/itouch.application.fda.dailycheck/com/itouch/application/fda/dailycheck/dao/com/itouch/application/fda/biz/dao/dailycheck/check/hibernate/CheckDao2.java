/**  
* @Title: CheckDao.java 
* @Package com.itouch.application.fda.biz.dao.dailycheck.check.hibernate 
* @author wangk    
* @date 2015-10-20 下午4:07:52  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.check.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckDao2;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo2;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-20 下午4:07:52  
 */
@Repository
public class CheckDao2 extends BaseCommonDao<CheckInfo2> implements ICheckDao2 {

}
