package com.itouch.application.fda.biz.dao.dailycheck.credit.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.credit.IVCreditToCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.VCreditToCheckInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: VCreditToCheckDao 
 * @author: wangk
 * @date: 2016-3-15 上午10:34:42  
 */
@Repository
public class VCreditToCheckDao extends BaseCommonDao<VCreditToCheckInfo> implements IVCreditToCheckDao{

}
