package com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou.ICheckResultDetailDao;
import com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou.CheckResultDetailInfo;

/**
 * 检查结果明细
 */
@Repository
public class CheckResultDetailDao extends BaseCommonDao<CheckResultDetailInfo> implements ICheckResultDetailDao  {

}
