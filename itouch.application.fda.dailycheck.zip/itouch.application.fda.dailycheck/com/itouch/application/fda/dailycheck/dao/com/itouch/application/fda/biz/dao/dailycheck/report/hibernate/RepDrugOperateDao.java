package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;


import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepDrugOperateDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugOperate;

@Repository
public class RepDrugOperateDao extends BaseCommonDao<RepDrugOperate> implements
		IRepDrugOperateDao {

}
