/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableOptionDao.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:12:31
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableOptionDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableOptionInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class TableOptionDao extends BaseCommonDao<TableOptionInfo> implements ITableOptionDao{

}
