/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TalkDao.java
 * @author:fanghailong
 * @time:2015-10-13 下午2:59:48
 */
package com.itouch.application.fda.biz.dao.dailycheck.talk.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.talk.ITalkDao;
import com.itouch.application.fda.biz.entity.dailycheck.talk.TalkInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class TalkDao extends BaseCommonDao<TalkInfo> implements ITalkDao{

}
