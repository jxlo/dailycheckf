/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITemplateInfoDao.java
 * @author:xh
 * @time:2015-10-10 下午5:35:07
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateInfo;

/**
 *
 * @author xh
 */
public interface ITemplateDao extends IBaseCommonDao<TemplateInfo> {
}
