/**  
  * @Description: TODO
  * @Title: RepFoodBizPermitDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report.hibernate 
  * @author: xh
  * @date 2016-3-22 上午10:29:56 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepFoodBizPermitDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodBizPermitInfo;

/** 
 * @Description: TODO
 * @ClassName: RepFoodBizPermitDao 
 * @author xh
 * @date 2016-3-22 上午10:29:56  
 */
@Repository
public class RepFoodBizPermitDao extends BaseCommonDao<RepFoodBizPermitInfo> implements IRepFoodBizPermitDao {

}
