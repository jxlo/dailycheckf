/**     
  * @Title: IVTaskUnitCheckDao.java   
  * @Package com.itouch.application.fda.biz.dao.dailycheck.task   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-4 下午5:43:21     
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.task;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.task.VTaskUnitCheckInfo;

/**   
 * @ClassName: IVTaskUnitCheckDao   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-4 下午5:43:21      
 */
public interface IVTaskUnitCheckDao extends IBaseCommonDao<VTaskUnitCheckInfo>{

}
