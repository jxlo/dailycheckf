/**  
* @Title: TemplateSmallSubjectDao.java 
* @Package com.itouch.application.fda.biz.dao.system.table.hibernate 
* @author wangk    
* @date 2015-10-10 下午5:23:01  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateSmallSubjectDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSmallSubjectInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-10 下午5:23:01  
 */
@Repository
public class TemplateSmallSubjectDao extends BaseCommonDao<TemplateSmallSubjectInfo> implements ITemplateSmallSubjectDao{

}
