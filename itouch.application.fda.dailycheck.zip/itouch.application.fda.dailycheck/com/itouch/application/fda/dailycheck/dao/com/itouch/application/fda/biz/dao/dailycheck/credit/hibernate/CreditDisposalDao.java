package com.itouch.application.fda.biz.dao.dailycheck.credit.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.credit.ICreditDisposalDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.CreditDisposalInfo;

@Repository
public class CreditDisposalDao extends BaseCommonDao<CreditDisposalInfo> implements ICreditDisposalDao{

}
