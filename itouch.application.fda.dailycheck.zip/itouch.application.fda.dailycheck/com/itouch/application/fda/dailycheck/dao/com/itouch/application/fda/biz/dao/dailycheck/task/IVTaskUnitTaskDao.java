/**  
* @Title: IVTaskUnitTaskDao.java 
* @Package com.itouch.application.fda.biz.dao.dailycheck.task 
* @author wangk    
* @date 2015-10-30 下午2:39:38  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.task;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.task.VTaskUnitTaskInfo;


/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-30 下午2:39:38  
 */
public interface IVTaskUnitTaskDao extends IBaseCommonDao<VTaskUnitTaskInfo>{

}
