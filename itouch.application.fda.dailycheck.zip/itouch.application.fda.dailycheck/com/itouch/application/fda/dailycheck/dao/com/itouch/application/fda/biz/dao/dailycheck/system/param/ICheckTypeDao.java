/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:DcSysCheckTypeDao.java
 * @author:xh
 * @time:2015-10-10 下午4:45:00
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.param;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.param.CheckTypeInfo;

/**
 *
 * @author xh
 */
public interface ICheckTypeDao extends IBaseCommonDao<CheckTypeInfo>{

}
