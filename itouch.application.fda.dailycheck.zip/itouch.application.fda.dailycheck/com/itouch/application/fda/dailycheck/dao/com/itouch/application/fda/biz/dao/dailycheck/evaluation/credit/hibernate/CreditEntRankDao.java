package com.itouch.application.fda.biz.dao.dailycheck.evaluation.credit.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.evaluation.credit.ICreditEntRankDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.CreditEntRankInfo;

@Repository
public class CreditEntRankDao extends BaseCommonDao<CreditEntRankInfo> implements ICreditEntRankDao  {

}
