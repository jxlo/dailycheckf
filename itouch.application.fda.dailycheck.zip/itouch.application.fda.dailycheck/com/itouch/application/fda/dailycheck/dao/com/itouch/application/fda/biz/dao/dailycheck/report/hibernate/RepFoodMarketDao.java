/**  
  * @Description: TODO
  * @Title: RepFoodMarketDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report.hibernate 
  * @author: xh
  * @date 2016-3-24 上午11:32:47 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepFoodMarketDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodMarketInfo;

/** 
 * @Description: TODO
 * @ClassName: RepFoodMarketDao 
 * @author xh
 * @date 2016-3-24 上午11:32:47  
 */
@Repository
public class RepFoodMarketDao extends BaseCommonDao<RepFoodMarketInfo> implements IRepFoodMarketDao  {

}
