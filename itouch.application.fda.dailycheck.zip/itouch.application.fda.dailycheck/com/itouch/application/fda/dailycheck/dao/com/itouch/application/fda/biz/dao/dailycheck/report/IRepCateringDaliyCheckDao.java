package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepCateringDailyCheckInfo;

/** 
 * @Description: 餐饮企业日常检查统计表 
 * @ClassName: IRepCateringDaliyCheckDao 
 * @author: wangk
 * @date: 2016-3-22 下午2:02:08  
 */
public interface IRepCateringDaliyCheckDao extends IBaseCommonDao<RepCateringDailyCheckInfo>{

}
