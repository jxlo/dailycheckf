/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ICheckEntDao.java
 * @author:fanghailong
 * @time:2015-10-23 下午2:20:36
 */
package com.itouch.application.fda.biz.dao.dailycheck.check;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckEntInfo;

/**
 * @author:fanghailong 
 */
public interface ICheckEntDao extends IBaseCommonDao<CheckEntInfo>{

}
