/**  
  * @Description: TODO
  * @Title: IRepCosmDailyCheckManager.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report 
  * @author: xh
  * @date 2016-3-16 上午11:29:55 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepCosmDailyCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: IRepCosmDailyCheckManager 
 * @author xh
 * @date 2016-3-16 上午11:29:55  
 */
public interface IRepCosmDailyCheckDao extends IBaseCommonDao<RepCosmDailyCheckInfo>{

}
