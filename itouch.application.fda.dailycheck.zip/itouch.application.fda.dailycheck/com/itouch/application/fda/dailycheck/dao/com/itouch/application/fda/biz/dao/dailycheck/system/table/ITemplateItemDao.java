/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITemplateItemDao.java
 * @author:fanghailong
 * @time:2015-10-10 下午4:11:06
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateItemInfo;



/**
 * @author:fanghailong 
 */
public interface ITemplateItemDao extends IBaseCommonDao<TemplateItemInfo>{

}
