/**  
* @Title: TaskDao.java 
* @Package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate 
* @author wangk    
* @date 2015-10-26 下午2:10:41  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-26 下午2:10:41  
 */
@Repository
public class TaskDao extends BaseCommonDao<TaskInfo> implements ITaskDao{

}
