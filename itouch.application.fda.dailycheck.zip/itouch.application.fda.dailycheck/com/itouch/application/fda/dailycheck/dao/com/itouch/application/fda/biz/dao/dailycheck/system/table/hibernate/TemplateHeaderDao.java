/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateHeaderDao.java
 * @author:fanghailong
 * @time:2015-10-12 下午4:15:22
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateHeaderDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateHeaderInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class TemplateHeaderDao extends BaseCommonDao<TemplateHeaderInfo> implements ITemplateHeaderDao{

}
