/**  
 * @Description: TODO
 * @Title: CreditAnnualDao.java 
 * @Package: com.itouch.application.fda.biz.dao.dailycheck.credit.food.catering.annual.hibernate 
 * @author: wangk
 * @date 2016-2-24 下午4:19:08 
 */ 
package com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.ICreditAnnualDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.CreditAnnualInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: CreditAnnualDao 
 * @author wangk
 * @date 2016-2-24 下午4:19:08  
 */
@Repository
public class CreditAnnualDao extends BaseCommonDao<CreditAnnualInfo> implements ICreditAnnualDao{

}
