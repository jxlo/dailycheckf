package com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood.ICreditHfoodProdPreviewDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood.CreditHfoodProdPreviewInfo;

@Repository
public class CreditHfoodProdPreviewDao extends BaseCommonDao<CreditHfoodProdPreviewInfo> implements ICreditHfoodProdPreviewDao{

}
