package com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditRankInfo;

public interface ICreditRankDao extends IBaseCommonDao<CreditRankInfo>{

}
