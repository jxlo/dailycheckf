/**
 * @Description:TODO
 * @project:itouch.application.fda.dailycheck
 * @class:VFoodProdDailycheckStatisticsDao.java
 * @author:xh
 * @time:2016-1-9 下午4:23:15
 */
package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IVFoodProdDailycheckStatisticsDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.VFoodProdDailycheckStatisticsInfo;

/**
 * 食品生产日常监督检查统计
 * @author xh
 */
@Repository
public class VFoodProdDailycheckStatisticsDao extends BaseCommonDao<VFoodProdDailycheckStatisticsInfo> implements IVFoodProdDailycheckStatisticsDao {

}
