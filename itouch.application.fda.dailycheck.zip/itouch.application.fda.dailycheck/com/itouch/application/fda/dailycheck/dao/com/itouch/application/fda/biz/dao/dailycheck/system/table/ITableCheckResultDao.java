/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITableCheckResultDao.java
 * @author:xh
 * @time:2015-10-26 下午7:08:02
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableCheckResult;


/**
 *
 * @author xh
 */
public interface ITableCheckResultDao  extends IBaseCommonDao<TableCheckResult>{

}
