package com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.ICreditLimitYearDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditLimitYearInfo;

@Repository
public class CreditLimitYearDao extends BaseCommonDao<CreditLimitYearInfo> implements ICreditLimitYearDao  {

}
