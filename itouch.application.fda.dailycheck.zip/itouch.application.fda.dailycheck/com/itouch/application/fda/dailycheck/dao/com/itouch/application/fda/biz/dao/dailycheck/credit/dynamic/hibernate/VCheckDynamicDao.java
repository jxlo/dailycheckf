/**  
 * @Description: TODO
 * @Title: VCheckDynamicDao.java 
 * @Package: com.itouch.application.fda.biz.dao.dailycheck.credit.food.catering.dynamic.hibernate 
 * @author: wangk
 * @date 2016-2-24 下午4:37:46 
 */ 
package com.itouch.application.fda.biz.dao.dailycheck.credit.dynamic.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.credit.dynamic.IVCheckDynamicDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic.VCheckDynamicInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: VCheckDynamicDao 
 * @author wangk
 * @date 2016-2-24 下午4:37:46  
 */
@Repository
public class VCheckDynamicDao extends BaseCommonDao<VCheckDynamicInfo> implements IVCheckDynamicDao{

}
