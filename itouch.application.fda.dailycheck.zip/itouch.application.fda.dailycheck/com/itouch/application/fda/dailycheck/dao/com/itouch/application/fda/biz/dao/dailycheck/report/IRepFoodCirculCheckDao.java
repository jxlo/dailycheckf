/**  
  * @Description: TODO
  * @Title: IRepFoodCirculCheckDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report 
  * @author: xh
  * @date 2016-3-24 下午4:13:01 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodCirculCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: IRepFoodCirculCheckDao 
 * @author xh
 * @date 2016-3-24 下午4:13:01  
 */
public interface IRepFoodCirculCheckDao  extends IBaseCommonDao<RepFoodCirculCheckInfo>{

}
