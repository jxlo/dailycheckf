/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateInfoDao.java
 * @author:xh
 * @time:2015-10-10 下午5:35:16
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateInfo;

/**
 *
 * @author xh
 */
@Repository("bizTemplateDao")
public class TemplateDao extends BaseCommonDao<TemplateInfo> implements ITemplateDao{

}
