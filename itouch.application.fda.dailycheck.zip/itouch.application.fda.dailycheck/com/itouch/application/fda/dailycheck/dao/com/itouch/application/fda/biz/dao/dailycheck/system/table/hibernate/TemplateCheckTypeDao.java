/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateCheckTypeInfoDao.java
 * @author:xh
 * @time:2015-10-10 下午5:48:51
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateCheckTypeDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateCheckTypeInfo;

/**
 *
 * @author xh
 */
@Repository
public class TemplateCheckTypeDao extends BaseCommonDao<TemplateCheckTypeInfo> implements ITemplateCheckTypeDao{

}
