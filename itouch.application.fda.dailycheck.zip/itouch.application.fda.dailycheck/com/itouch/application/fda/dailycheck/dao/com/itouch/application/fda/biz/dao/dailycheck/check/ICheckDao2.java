/**  
* @Title: ICheckDao.java 
* @Package com.itouch.application.fda.biz.dao.dailycheck.check 
* @author wangk    
* @date 2015-10-20 下午4:07:18  
*/ 
package com.itouch.application.fda.biz.dao.dailycheck.check;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo2;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-20 下午4:07:18  
 */
public interface ICheckDao2 extends IBaseCommonDao<CheckInfo2> {

}
