/**  
  * @Description: TODO
  * @Title: RepFoodCirculCheckDao.java 
  * @Package: com.itouch.application.fda.biz.dao.dailycheck.report.hibernate 
  * @author: xh
  * @date 2016-3-24 下午4:13:34 
  */ 
package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepFoodCirculCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodCirculCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: RepFoodCirculCheckDao 
 * @author xh
 * @date 2016-3-24 下午4:13:34  
 */
@Repository
public class RepFoodCirculCheckDao extends BaseCommonDao<RepFoodCirculCheckInfo> implements IRepFoodCirculCheckDao  {

}
