package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;


import org.springframework.stereotype.Repository;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepDrugModeDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugMode;

@Repository
public class RepDrugModeDao extends BaseCommonDao<RepDrugMode> implements
		IRepDrugModeDao {

}
