/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ICheckTableDao.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:02:18
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table;

import iTouch.framework.application.dao.IBaseCommonDao;
import iTouch.framework.application.dao.MapperSQLException;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableInfo;

/**
 * @author:fanghailong 
 */
public interface ITableDao extends IBaseCommonDao<TableInfo>{

	/** 
	 * @Description:TODO 
	 * @param command
	 * @param propertyValues
	 * @return
	 * @throws MapperSQLException 
	 * @author:liss 
	 * @time:2016年5月30日 下午3:14:54 
	 */
	int sizeBysql(String command, Object[] propertyValues) throws MapperSQLException;

}
