package com.itouch.application.fda.biz.dao.dailycheck.report.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.report.IRepCateringDaliyCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepCateringDailyCheckInfo;

/** 
 * @Description: 餐饮企业日常检查统计表 
 * @ClassName: RepCateringDaliyCheckDao 
 * @author: wangk
 * @date: 2016-3-22 下午2:04:15  
 */
@Repository
public class RepCateringDaliyCheckDao extends BaseCommonDao<RepCateringDailyCheckInfo> implements IRepCateringDaliyCheckDao{

}
