package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodCirculPermitInfo;

/** 
 * @Description:  食品经营许可（流通）情况统计表
 * @ClassName: IRepFoodCirculPermitDao 
 * @author: wangk
 * @date: 2016-3-24 下午1:39:10  
 */
public interface IRepFoodCirculPermitDao extends IBaseCommonDao<RepFoodCirculPermitInfo>{

}
