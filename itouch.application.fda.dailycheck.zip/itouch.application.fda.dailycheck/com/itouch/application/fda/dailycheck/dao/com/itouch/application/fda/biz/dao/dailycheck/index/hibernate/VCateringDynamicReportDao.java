package com.itouch.application.fda.biz.dao.dailycheck.index.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.index.IVCateringDynamicReportDao;
import com.itouch.application.fda.biz.entity.dailycheck.index.VCateringDynamicReportInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: VCateringDynamicReportDao 
 * @author: wangk
 * @date: 2016-3-28 下午1:59:50  
 */
@Repository
public class VCateringDynamicReportDao extends BaseCommonDao<VCateringDynamicReportInfo> implements IVCateringDynamicReportDao{

}
