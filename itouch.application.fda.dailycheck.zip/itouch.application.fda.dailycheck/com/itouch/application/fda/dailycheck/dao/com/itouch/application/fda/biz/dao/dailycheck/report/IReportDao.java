package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.ReportInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: IReportDao 
 * @author: wangk
 * @date: 2016-3-16 下午1:56:09  
 */
public interface IReportDao  extends IBaseCommonDao<ReportInfo>{

}
