package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugCheck;

/** 
 * @Description:  药品检测单位情况统计表
 * @ClassName: IRepDrugCheckDao 
 */
public interface IRepDrugCheckDao extends IBaseCommonDao<RepDrugCheck> {

}
