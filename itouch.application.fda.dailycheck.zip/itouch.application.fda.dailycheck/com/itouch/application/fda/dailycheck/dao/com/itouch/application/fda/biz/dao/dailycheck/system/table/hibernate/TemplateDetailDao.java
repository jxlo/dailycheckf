/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateItemDetailDao.java
 * @author:fanghailong
 * @time:2015-10-10 下午4:18:41
 */
package com.itouch.application.fda.biz.dao.dailycheck.system.table.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateDetailDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateDetailInfo;


/**
 * @author:fanghailong 
 */
@Repository
public class TemplateDetailDao extends BaseCommonDao<TemplateDetailInfo> implements ITemplateDetailDao{

}
