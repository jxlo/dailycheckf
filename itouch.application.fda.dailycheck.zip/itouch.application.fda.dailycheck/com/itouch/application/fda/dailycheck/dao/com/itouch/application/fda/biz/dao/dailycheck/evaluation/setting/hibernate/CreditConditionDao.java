package com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.ICreditConditionDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditConditionInfo;

@Repository
public class CreditConditionDao extends BaseCommonDao<CreditConditionInfo> implements ICreditConditionDao  {

}
