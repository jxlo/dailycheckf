/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckReview.java
 * @author:fanghailong
 * @time:2015-10-20 下午5:02:27
 */
package com.itouch.application.fda.biz.dao.dailycheck.check.hibernate;

import iTouch.framework.application.dao.hibernate.BaseCommonDao;

import org.springframework.stereotype.Repository;

import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckReviewDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckReviewInfo;

/**
 * @author:fanghailong 
 */
@Repository
public class CheckReviewDao extends BaseCommonDao<CheckReviewInfo> implements ICheckReviewDao{

}
