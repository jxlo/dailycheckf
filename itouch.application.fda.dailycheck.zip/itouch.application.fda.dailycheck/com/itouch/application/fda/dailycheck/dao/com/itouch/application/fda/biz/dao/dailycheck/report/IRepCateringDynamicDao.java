package com.itouch.application.fda.biz.dao.dailycheck.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepCateringDynamicInfo;

/** 
 * @Description: 餐饮企业量化分级统计表 
 * @ClassName: IRepCateringDynamicDao 
 * @author: wangk
 * @date: 2016-3-22 上午10:57:55  
 */
public interface IRepCateringDynamicDao extends IBaseCommonDao<RepCateringDynamicInfo>{

}
