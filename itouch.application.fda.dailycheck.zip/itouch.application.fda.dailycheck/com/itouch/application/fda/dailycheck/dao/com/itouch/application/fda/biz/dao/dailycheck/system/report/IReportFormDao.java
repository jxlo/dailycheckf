package com.itouch.application.fda.biz.dao.dailycheck.system.report;

import iTouch.framework.application.dao.IBaseCommonDao;

import com.itouch.application.fda.biz.entity.dailycheck.system.report.ReportFormInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: IReportFromDao 
 * @author: wangk
 * @date: 2016-3-16 下午1:55:51  
 */
public interface IReportFormDao extends IBaseCommonDao<ReportFormInfo>{

}
