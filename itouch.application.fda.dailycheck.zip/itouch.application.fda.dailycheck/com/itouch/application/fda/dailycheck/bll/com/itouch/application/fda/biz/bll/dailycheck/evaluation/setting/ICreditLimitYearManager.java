package com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditLimitYearInfo;

/**
 * @author qiuy
 * 年度评定限制接口
 */
public interface ICreditLimitYearManager extends IAppBusinessManager {
	
	/**
	 * 新增
	 * @param 受理类型实体
	 * @return 实体id
	 */
	public Object add(CreditLimitYearInfo info) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditLimitYearInfo> list) ;
	
	/**
	 * 更新
	 * @param 受理类型实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CreditLimitYearInfo info)  ;
	
	/**
	 * 新增/修改
	 * @param 受理类型实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CreditLimitYearInfo info) ;
	
	/**
	 * 删除
	 * @param Id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String Id)  ;
	
	/**
	 * 删除
	 * @param 实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CreditLimitYearInfo info) ;
	
	/**
	 * 获取实体
	 * @param Id  主键Id
	 * @return 实体
	 */
	public CreditLimitYearInfo getEntity(String Id) ;

	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<CreditLimitYearInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<CreditLimitYearInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
}
