/**  
* @Title: ITemplateSubjectManager.java 
* @Package com.itouch.application.fda.biz.bll.system.table 
* @author wangk    
* @date 2015-10-10 下午6:01:40  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.system.table;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSubjectInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-10 下午6:01:40  
 */
public interface ITemplateSubjectManager extends IAppBusinessManager{
	/**
	 * @Description:新增
	 * @param dcTemplateSmallSubject
	 * @time:2015-10-10 下午4:32:29
	 */
	public Object add(TemplateSubjectInfo templateSubjectInfo);
	
	/**
	 * @Description:新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TemplateSubjectInfo> list) ;
	
	/**
	 * @Description:更新
	 * @param ArticleInfo 受理类型实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(TemplateSubjectInfo templateSubjectInfo)  ;
	
	/**
	 * @Description:新增/修改
	 * @param dcTemplateSmallSubject
	 * @time:2015-10-10 下午4:35:18
	 */
	public Object addOrUpdate(TemplateSubjectInfo templateSubjectInfo);
	
	/**
	 * @Description:删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * @Description:删除
	 * @param ArticleInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(TemplateSubjectInfo templateSubjectInfo) ;
	
	/**
	 * @Description:获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public TemplateSubjectInfo getEntity(String id) ;
	
	/**
	 * @Description:获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateSubjectInfo> getList() ;
	
	/**
	 * @Description:获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateSubjectInfo> getListByTemplateId(String templateId) ;
	
	/**
	 * @Description:根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<TemplateSubjectInfo> getList(Map<String,Object> map) ;
	
	/**
	 * @Description:获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
}
