package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.application.service.MapperNotFoundException;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.itouch.application.ent.bll.basic.IEntCreditManager;
import com.itouch.application.ent.entity.basic.EntCredit;
import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.ICreditEntRankManager;
import com.itouch.application.fda.biz.dao.dailycheck.evaluation.credit.ICreditEntRankDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.CreditEntRankInfo;

/**
 * @author qiuy
 * 企业年度信用评级业务层
 */
@Service("CreditEntRank")
@Lazy
public class CreditEntRankManager extends AppBusinessManager implements ICreditEntRankManager {

	Logger logger = LoggerFactory.getLogger(CreditEntRankManager.class);

	@Autowired
	private ICommonManager commonManager;

	private ICreditEntRankDao dao;
	
	/**
	 * 新增
	 * @param 受理类型实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public String add(CreditEntRankInfo info) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			dao.add(info);
			return info.getCreditId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditEntRankInfo> list) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			dao.add(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(CreditEntRankInfo info) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			dao.update(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(CreditEntRankInfo info) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			dao.save(info);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 删除
	 * @param Id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * @param 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(CreditEntRankInfo info) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			dao.delete(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 获取实体
	 * @param Id 主键ID
	 * @return 实体
	 * @throws Throwable
	 */
	@SuppressWarnings("deprecation")
	public CreditEntRankInfo getEntity(String id) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据年份、企业获取主键
	 * @param year
	 * @param entCode
	 * @param entTypeGroupId
	 * @return
	 */
	public String getKeyByYearEnt(String year, String entCode, String entTypeGroupId) {
		try{
			dao = this.getMapper(ICreditEntRankDao.class);
			ArrayList<Object> param = new ArrayList<>();
			String sql = " select CREDIT_ID, ENT_CODE from DC_CREDIT_ENT_RANK where CREDIT_YEAR = ? and ENT_CODE = ? and ENT_TYPE_GROUP_ID = ? ";
			param.add(year);
			param.add(entCode);
			param.add(entTypeGroupId);
			Object[] objects = dao.getObjectBySql(sql, param.toArray());
			if(objects != null && objects.length > 0) {
				if(!StringUtils.isEmpty(objects[0].toString())) {
					return objects[0].toString();
				}
			}
			return "";
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return "";
		}
	}
	
	/**
	 * 获取列表
	 * @return list 列表集合
	 * @throws Throwable
	 */
	public List<CreditEntRankInfo> getList() {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			return dao.find();
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map查询参数
	 * @return 受理类型列表
	 */
	public List<CreditEntRankInfo> getList(Map<String, Object> map) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			return dao.findAnd(null, map);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			return commonManager.datagrid(ICreditEntRankDao.class, pageIndex, pageSize, map, dao);
		} catch (Throwable e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获得企业评定记录列表
	 * @param vEntBasic
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public List<CreditEntRankInfo> getEntRankList(CreditEntRankInfo creditEntRankInfo) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			return dao.queryListByCommand(getEntQueryHql(creditEntRankInfo), null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获得企业评定记录列表分页
	 * @param pageSize
	 * @param pageIndex
	 * @param vEntBasic
	 * @return
	 */
	public PageResultSet getEntRankListPage(int pageSize, int pageIndex, CreditEntRankInfo creditEntRankInfo) {
		try {
			dao = this.getMapper(ICreditEntRankDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);
			
			PageResultSet pageResultSet = new PageResultSet();
			pageResultSet.setList(dao.find(getEntQueryHql(creditEntRankInfo) , null , page));
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 更新企业信用
	 * @param list
	 */
	public void AllUpdateCredit(List<CreditEntRankInfo> list) {
		try {
			IEntCreditManager entdao = this.getMapper(IEntCreditManager.class);
			for (CreditEntRankInfo info : list) {
				EntCredit entCreditInfo = new EntCredit();
				entCreditInfo.setCreateTime(new Date());
				entCreditInfo.setCreatorId(info.getCreditUserId());
				entCreditInfo.setCreatorName(info.getCreditUserName());
				entCreditInfo.setCreditName(info.getCreditValue());
				entCreditInfo.setCreditTime(info.getCreditTime());
				entCreditInfo.setCreditValue(info.getCreditValue());
				entCreditInfo.setCreditYear(info.getCreditYear());
				entCreditInfo.setEntCode(info.getEntCode());
				entCreditInfo.setEntName(info.getEntName());
				entCreditInfo.setEntTypeGroupId(info.getEntTypeGroupId());
				entCreditInfo.setEntTypeGroupName(info.getEntTypeGroupName());
				entCreditInfo.setEntTypeId(info.getEntTypeId());
				entCreditInfo.setEntTypeName(info.getEntTypeName());
				entCreditInfo.setRemark(info.getRemark());
				entCreditInfo.setUnitId(info.getUnitId());
				entCreditInfo.setUnitName(info.getUnitName());
				//如果存在记录就更新，不存在就新增
				String entRankKey = entdao.getEntKeyByYearEnt(entCreditInfo.getCreditYear().toString(), entCreditInfo.getEntCode(), entCreditInfo.getEntTypeGroupId());
				if(!StringUtils.isEmpty(entRankKey)) {
					entCreditInfo.setCreditId(entRankKey);
				}
				entdao.addOrUpdate(entCreditInfo);
			}
		} catch (MapperNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 获得企业查询hql
	 * @param vEntBasic
	 * @return
	 */
	private String getEntQueryHql(CreditEntRankInfo creditEntRankInfo) {
		
		String hql = " select t from CreditEntRankInfo t  where 1=1 ";
		
		//监管单位
		if(creditEntRankInfo.getUnitId() != null && !creditEntRankInfo.getUnitId().equals("")){
			hql += " and t.unitId like '" + creditEntRankInfo.getUnitId() + "%'";
		}
		
		//监管单位
		if(creditEntRankInfo.getAreaCode() != null && !creditEntRankInfo.getAreaCode().equals("")){
			hql += " and t.areaCode like '" + creditEntRankInfo.getAreaCode() + "%'";
		}
		
		//企业类型
		if(creditEntRankInfo.getEntTypeId() != null && !creditEntRankInfo.getEntTypeId().equals("")){
			hql += " and t.entTypeId like '" + creditEntRankInfo.getEntTypeId() + "%'";
		}
		
		//企业类型分组
		if(creditEntRankInfo.getEntTypeGroupId() != null && !creditEntRankInfo.getEntTypeGroupId().equals("")){
			hql += " and t.entTypeGroupId = " + creditEntRankInfo.getEntTypeGroupId();
		}
		
		//评定体系
		if(creditEntRankInfo.getCriterionId() != null && !creditEntRankInfo.getCriterionId().equals("")){
			hql += " and t.criterionId = '" + creditEntRankInfo.getCriterionId() + "'";
		}
		
		//评定年份
		if(creditEntRankInfo.getCreditYear() != null && !creditEntRankInfo.getCreditYear().equals("")){
			hql += " and t.creditYear = " + creditEntRankInfo.getCreditYear();
		}
		
		return hql;
	}
}
