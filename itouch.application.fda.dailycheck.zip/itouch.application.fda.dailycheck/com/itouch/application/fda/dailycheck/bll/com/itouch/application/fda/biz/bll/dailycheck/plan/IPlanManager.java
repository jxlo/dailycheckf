/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:IPlanManager.java
 * @author:fanghailong
 * @time:2015-10-20 下午3:47:09
 */
package com.itouch.application.fda.biz.bll.dailycheck.plan;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.ent.entity.grid.VEntGridCollarInfo;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanInfo;

/**
 * @author:fanghailong 
 */
public interface IPlanManager extends IAppBusinessManager{
	
	/**
	 * 新增
	 * @param planInfo 实体
	 * @return 实体id
	 */
	public Object add(PlanInfo planInfo) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<PlanInfo> list) ;
	
	/**
	 * 更新
	 * @param PlanInfo 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(PlanInfo planInfo)  ;
	
	/**
	 * 批量更新或保存
	 * @param PlanInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<PlanInfo> planInfoList)  ;
	/**
	 * 新增/修改
	 * @param PlanInfo 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(PlanInfo planInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param PlanInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(PlanInfo planInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public PlanInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<PlanInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<PlanInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;	
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getPlanInfoList(int pageSize, int pageIndex, PlanInfo planInfo,String userId) ;
	

	/**
	 * 根据计划名称查询计划是否存在
	 * @param name
	 * @return
	 */
	public List<PlanInfo> getPlanByName(String name);

	/**
	 * @param unit_ID
	 * @return
	 */
	List<VEntGridCollarInfo> getEntCount(String unit_ID);
}
