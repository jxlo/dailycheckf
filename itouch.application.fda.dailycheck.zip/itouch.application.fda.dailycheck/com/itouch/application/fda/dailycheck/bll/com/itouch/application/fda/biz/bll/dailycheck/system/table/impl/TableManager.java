/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableManager.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:29:09
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.dao.MapperSQLException;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.application.service.MapperNotFoundException;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckDao;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableDao;
import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableInfo;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskInfo;

/**
 * @author:fanghailong 
 */
@Service("checkTableManager")
public class TableManager extends AppBusinessManager implements ITableManager {

	Logger logger = LoggerFactory.getLogger(TableManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * 新增
	 * 
	 * @param TableInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(TableInfo checkTableInfo) {
		try {
			ITableDao dao = this.getMapper(ITableDao.class);
			dao.add(checkTableInfo);
			return checkTableInfo.getTableId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TableInfo> list) {
		try {
			ITableDao dao = this.getMapper(ITableDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param TableInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(TableInfo checkTableInfo) {
		try {
			ITableDao dao = this.getMapper(ITableDao.class);
			dao.update(checkTableInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * 
	 * @param TableInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(TableInfo checkTableInfo) {
		try {
			ITableDao dao = this.getMapper(ITableDao.class);
			dao.save(checkTableInfo);
			return checkTableInfo.getTableId();
		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try {
			ITableDao dao = this.getMapper(ITableDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * 
	 * @param TableInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(TableInfo checkTableInfo) {
		try {
			ITableDao dao = this.getMapper(ITableDao.class);
			dao.delete(checkTableInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public TableInfo getEntity(String id) {
		try {
			ITableDao dao = this.getMapper(ITableDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<CheckTableInfo> 列表集合
	 * @throws Throwable
	 */
	public List<TableInfo> getList() {
		ITableDao dao;
		try {
			dao = this.getMapper(ITableDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<TableInfo> getList(Map<String, Object> map) {
		ITableDao dao;
		try {
			dao = this.getMapper(ITableDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		ITableDao dao;
		try {
			dao = this.getMapper(ITableDao.class);
			pageResultSet = bizCommonManager.datagrid(ITableDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:根据条件查询出列表
	 * @pram：ITemplateManager
	 * @return:  
	 * @time:2015-10-14 下午2:20:45
	 */
	@Override
	public PageResultSet findListBySearch(int number, int pageIndex, String templateId, String tableName, String unitId, String deptId, String entTypeGroupId, String checkTypeId, Map<String, Object> map) {

		ITableDao dao;
		List<TableInfo> list = new ArrayList<TableInfo>();
		PageResultSet pageResultSet = new PageResultSet();

		try {
			dao = this.getMapper(ITableDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);

			String sql = "select t from TableInfo t where t.state = 1";
			if (templateId != null) {
				sql += " and templateId = '" + templateId + "'";
			}
			if (tableName != null) {
				sql += " and tableName like '%" + tableName + "%'";
			}
			if (unitId != null) {
				sql += " and unitId = '" + unitId + "'";
			}
			if (deptId != null) {
				sql += " and deptId = '" + deptId + "'";
			}
			if (entTypeGroupId != null) {
				sql += " and entTypeGroupId = '" + entTypeGroupId + "'";
			}

			list = dao.find(sql, null, page);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;

		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:根据条件查询出列表
	 * @pram：ITemplateManager
	 * @return:  
	 * @time:2015-10-14 下午2:20:45
	 */
	@Override
	public PageResultSet findListByTableSelect(int number, int pageIndex, String entTypeGroupId, String checkTypeId, String tableName) {

		ITableDao dao;
		List<TableInfo> list = new ArrayList<TableInfo>();
		PageResultSet pageResultSet = new PageResultSet();

		try {
			dao = this.getMapper(ITableDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);

			String sql = "select distinct t from TableInfo t,TemplateCheckTypeInfo t2 where t.state = 1 and t.templateId=t2.templateId";
			if (entTypeGroupId != null) {
				sql += " and t.entTypeGroupId = '" + entTypeGroupId + "'";
			}
			if (checkTypeId != null && !"null".equals(checkTypeId) && !"".equals(checkTypeId)) {
				sql += " and t2.checkTypeId='" + checkTypeId + "'";
			}
			if (tableName != null && !"null".equals(tableName) && !"".equals(tableName)) {
				sql += " and t.tableName like'%" + tableName + "%'";
			}

			list = dao.find(sql, null, page);
			// 获取数量
			int index = sql.indexOf("from");
			sql = "select COUNT(DISTINCT t.tableId) " + sql.substring(index, sql.length());
			Object[] propertyValue = new Object[0];
			int siz = dao.sizeBysql(sql, null);
			page.setTotalNumber(siz);
			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;

		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:根据条件查询出列表
	 * @pram：ITemplateManager
	 * @return:  
	 * @time:2015-10-14 下午2:20:45
	 */
	@Override
	public List<TableInfo> findList(String templateId, String entType) {

		ITableDao dao;
		List<TableInfo> list = new ArrayList<TableInfo>();

		try {
			dao = this.getMapper(ITableDao.class);

			String sql = "select distinct t from TableInfo t,TemplateCheckTypeInfo t2 where t.state = 1 and t.templateId=t2.templateId";
			if (!StringUtils.isEmpty(templateId)) {
				sql += " and t.templateId = '" + templateId + "'";
			}
			if (!StringUtils.isEmpty(entType)) {
				sql += " and t.entTypeGroupId like '" + entType + "%'";
			}

			list = dao.find(sql, null, null);
			return list;

		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	public List<TableInfo> findListByCheckTypeId(String checkTypeId, String entType) {

		ITableDao dao;
		List<TableInfo> list = new ArrayList<TableInfo>();

		try {
			dao = this.getMapper(ITableDao.class);

			String sql = "select distinct t from TableInfo t,TemplateCheckTypeInfo t2 where t.state = 1 and t.templateId=t2.templateId";
			if (!StringUtils.isEmpty(checkTypeId)) {
				sql += " and t2.checkTypeId = " + checkTypeId + "";
			}
			if (!StringUtils.isEmpty(entType)) {
				sql += " and t.entTypeGroupId like '" + entType + "%'";
			}

			list = dao.find(sql, null, null);
			return list;

		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:TODO
	 * @pram：ICheckTableManager
	 * @return:  
	 * @time:2015-10-16 上午11:04:17
	 */
	@Override
	public List<TableInfo> findListByTemplateId(String templateId) throws Throwable {
		ITableDao dao;
		List<TableInfo> list = new ArrayList<TableInfo>();
		;

		try {
			dao = this.getMapper(ITableDao.class);

			String sql = "select t from TableInfo t where 1=1";
			if (templateId != null) {
				sql += " and templateId = '" + templateId + "'";
			}

			list = dao.find(sql, null, null);

			return list;
		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:根据条件查询出列表
	 * @pram：ITemplateManager
	 * @return:  
	 * @time:2015-10-14 下午2:20:45
	 */
	@Override
	public PageResultSet findListBySearchT(int number, int pageIndex, String templateId, String tableName, Map<String, Object> map) {

		ITableDao dao;
		List<TableInfo> list = new ArrayList<TableInfo>();
		;
		PageResultSet pageResultSet = new PageResultSet();

		try {
			dao = this.getMapper(ITableDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);

			String hql = "select t from TableInfo t where 1=1";
			if (templateId != null) {
				hql += " and templateId = '" + templateId + "'";
			}
			if (tableName != null) {
				hql += " and tableName like '%" + tableName + "%'";
			}

			if (!map.isEmpty()) {
				hql += " and (";
				for (String key : map.keySet()) {
					hql += "  unitId = '" + key + "' or";
				}
				hql = hql.substring(0, hql.length() - 2);
				hql += ")";
			}

			list = dao.find(hql, null, page);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;

		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableManager#checkIsUse(java.lang.String)
	 */
	@Override
	public boolean checkIsUse(String tableId) throws MapperNotFoundException, MapperSQLException {
		// TODO Auto-generated method stub
		ICheckDao checkDao = this.getMapper(ICheckDao.class);
		ITaskDao taskDao = this.getMapper(ITaskDao.class);
		String hql = "select t from CheckInfo t where t.tableId='" + tableId + "'";

		List<CheckInfo> checkList = checkDao.queryListByCommand(hql, null);
		if (checkList != null && checkList.size() > 0) {
			return true;
		}

		hql = "select t from TaskInfo t where t.tableId='" + tableId + "'";
		List<TaskInfo> taskList = taskDao.queryListByCommand(hql, null);
		if (taskList != null && taskList.size() > 0) {
			return true;
		}

		return false;
	}
}
