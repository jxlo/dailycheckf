/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateInfoManager.java
 * @author:xh
 * @time:2015-10-10 下午5:30:28
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateInfo;

/**
 *
 * @author xh
 */
@Service("dcTemplateManager")
public class TemplateManager extends AppBusinessManager implements ITemplateManager {
	Logger logger = LoggerFactory.getLogger(TemplateManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}


	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateInfoManager#getEntity(java.lang.String)
	 */
	@Override
	public TemplateInfo getEntity(String id) {
		try {
			ITemplateDao dao = this.getMapper(ITemplateDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateInfoManager#addOrUpdate(com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateInfo)
	 */
	@Override
	public void addOrUpdate(TemplateInfo templateInfo) {
		try{
			ITemplateDao dao = this.getMapper(ITemplateDao.class);
			dao.save(templateInfo);
		}catch(Exception ex){
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateInfoManager#delete(java.lang.String)
	 */
	@Override
	public boolean delete(String id) {
		try{
			ITemplateDao dao = this.getMapper(ITemplateDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * @Description:TODO
	 * @pram：ITemplateInfoManager
	 * @return:  
	 * @time:2015-10-12 上午9:57:49
	 */
	@Override
	public <E> PageResultSet templateGrid(int index, int number,Map<String, Object> map) throws Throwable {
		PageResultSet pageResultSet =  new PageResultSet();
		ITemplateDao dao = this.getMapper(ITemplateDao.class);
		pageResultSet = bizCommonManager.datagrid(ITemplateDao.class, index, number, map, dao);
		return pageResultSet;
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateInfoManager#getListByPage(int, int, java.util.Map)
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		ITemplateDao dao;
		try {
			dao = this.getMapper(ITemplateDao.class);
			pageResultSet = bizCommonManager.datagrid(ITemplateDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:根据条件查询出列表
	 * @pram：ITemplateManager
	 * @return:  
	 * @time:2015-10-14 下午2:20:45
	 */
	@Override
	public PageResultSet findListBySearch(int number, int pageIndex,String templateName,String unitId){
		
		ITemplateDao dao;
		List<TemplateInfo> list = new ArrayList<TemplateInfo>();;
		PageResultSet pageResultSet = new PageResultSet();
		
		try {
			dao = this.getMapper(ITemplateDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);
			
			String hql = "select t from TemplateInfo t where 1=1";
			if(templateName != null && !"".equals(templateName)){
				hql += " and t.templateName like '%"+templateName+"%'";
			}
			if(unitId != null && !"".equals(unitId)){
				hql += " and t.unitId = '"+unitId+"'";
			}
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
			
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:根据条件查询出列表
	 * @pram：ITemplateManager
	 * @return:  
	 * @time:2015-10-14 下午2:20:45
	 */
	@Override
	public List<TemplateInfo> findList(String templateName,String unitId){
		
		ITemplateDao dao;
		List<TemplateInfo> list = new ArrayList<TemplateInfo>();
		
		try {
			dao = this.getMapper(ITemplateDao.class);
			
			String hql = "select t from TemplateInfo t where 1=1";
			if(templateName != null && !"".equals(templateName)){
				hql += " and t.templateName like '%"+templateName+"%'";
			}
			if(unitId != null && !"".equals(unitId)){
				hql += " and t.unitId = '"+unitId+"'";
			}
			
			list = dao.queryListByCommand(hql, null);
			
			return list;
			
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
}
