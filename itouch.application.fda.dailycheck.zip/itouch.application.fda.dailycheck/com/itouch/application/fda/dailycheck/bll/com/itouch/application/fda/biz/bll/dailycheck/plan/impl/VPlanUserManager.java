/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:VPlanUserManager.java
 * @author:fanghailong
 * @time:2015-10-28 下午5:00:56
 */
package com.itouch.application.fda.biz.bll.dailycheck.plan.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.plan.IVPlanUserManager;
import com.itouch.application.fda.biz.dao.dailycheck.plan.IVPlanUserDao;
import com.itouch.application.fda.biz.entity.dailycheck.plan.VPlanUserInfo;

/**
 * @author:fanghailong 
 */
@Service("vPlanUserManager")
public class VPlanUserManager extends AppBusinessManager implements IVPlanUserManager{
	
	Logger logger = LoggerFactory.getLogger(VPlanUserManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public VPlanUserInfo getEntity(String id)  {
		try {
			IVPlanUserDao dao = this.getMapper(IVPlanUserDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<VPlanUserInfo> 列表集合
	 * @throws Throwable
	 */
	public List<VPlanUserInfo> getList() {
		IVPlanUserDao dao;
		try {
			dao = this.getMapper(IVPlanUserDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<VPlanUserInfo> getList(Map<String,Object> map){
		IVPlanUserDao dao;
		try {
			dao = this.getMapper(IVPlanUserDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		IVPlanUserDao dao;
		try {
			dao = this.getMapper(IVPlanUserDao.class);
			pageResultSet = bizCommonManager.datagrid(IVPlanUserDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getVPlanUserInfoList(int pageSize, int pageIndex, VPlanUserInfo vPlanUserInfo){
		PageResultSet pageResultSet = new PageResultSet();
		IVPlanUserDao dao = null;
		PageQueryParam page = new PageQueryParam();
		page.setPageIndex(pageIndex);
		page.setNumber(pageSize);
		try {
			dao = this.getMapper(IVPlanUserDao.class);
			// dao.setDataSourceName(DbConfig.online);
			String hql = "select t from VPlanUserInfo t where 1=1 ";
			if (vPlanUserInfo != null) {	
				if(vPlanUserInfo.getUserId()!=null
						&&vPlanUserInfo.getUserId()!=""){
					hql += " and t.userId ='" + vPlanUserInfo.getUserId()+"'";
				}
				if(vPlanUserInfo.getIsCompleted()!=null
						&&vPlanUserInfo.getIsCompleted().toString()!=""){
					hql += " and t.isCompleted =" + vPlanUserInfo.getIsCompleted();
				}
				if(vPlanUserInfo.getUnitId()!=null
						&&vPlanUserInfo.getUnitId()!=""){
					hql += " and t.unitId =" + vPlanUserInfo.getUnitId();
				}

				/*if(vPlanUserInfo.getOrgId()!=null
						&&vPlanUserInfo.getOrgId()!=""){
					if(!"1500000000".equals(vPlanUserInfo.getOrgId())){
						hql += " and t.orgId =" + vPlanUserInfo.getOrgId() + "or t.orgId ='1500000000'";
					}
				}*/

				if(vPlanUserInfo.getPlanBeginDate()!=null
						&&vPlanUserInfo.getPlanBeginDate().getYear()>0){
					hql += " and TO_CHAR(t.planBeginDate,'yyyy-mm-dd')>='" + new SimpleDateFormat("yyyy-MM-dd").format(vPlanUserInfo.getPlanBeginDate())
							+"'";
				}
				if(vPlanUserInfo.getPlanEndDate()!=null
						&&vPlanUserInfo.getPlanEndDate().getYear()>0){
					hql += " and TO_CHAR(t.planEndDate,'yyyy-mm-dd')<='" +  new SimpleDateFormat("yyyy-MM-dd").format(vPlanUserInfo.getPlanEndDate())
							+"'";
				}
				if(vPlanUserInfo.getPlanName()!=null
						&&vPlanUserInfo.getPlanName()!=""){
					hql += " and t.planName like '%" + vPlanUserInfo.getPlanName()
								+ "%'";
				}
			}
			 hql += " order by t.planBeginDate desc";
			List<VPlanUserInfo> vPlanUserInfoList = dao.find(hql, null, page);
			pageResultSet.setPage(page);
			pageResultSet.setList(vPlanUserInfoList);
			// pageResultSet = commonManager.datagrid(IVAccBasicDao.class,
			// pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		} finally {
			// dao.setDataSourceName(DbConfig.enterprises);
		}
	}
	

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param vPlanUserInfo 查询参数
	 * @param sign 标识
	 * @return 分页列表集合
	 */
	public PageResultSet getVPlanUserInfoList(int pageSize, int pageIndex, VPlanUserInfo vPlanUserInfo, String sign){
		PageResultSet pageResultSet = new PageResultSet();
		IVPlanUserDao dao = null;
		PageQueryParam page = new PageQueryParam();
		page.setPageIndex(pageIndex);
		page.setNumber(pageSize);
		try {
			dao = this.getMapper(IVPlanUserDao.class);
			// dao.setDataSourceName(DbConfig.online);
			String hql = "select t from VPlanUserInfo t where 1=1 ";
			if (vPlanUserInfo != null) {	
				/*if("0".equals(sign)){
					if(vPlanUserInfo.getOrgId()!=null
							&&vPlanUserInfo.getOrgId()!=""){
						vPlanUserInfo.setUserId(null);
						//1500000000代表的是自治区局，所有盟市局的上级
						if(!"1500000000".equals(vPlanUserInfo.getOrgId())){
							hql += " and t.orgId =" + vPlanUserInfo.getOrgId() + "or t.orgId ='1500000000'";
						}
					}
				}*/
				if(vPlanUserInfo.getUserId()!=null
						&&vPlanUserInfo.getUserId()!=""){
					hql += " and t.userId ='" + vPlanUserInfo.getUserId()+"'";
				}
				if(vPlanUserInfo.getIsCompleted()!=null
						&&vPlanUserInfo.getIsCompleted().toString()!=""){
					hql += " and t.isCompleted =" + vPlanUserInfo.getIsCompleted();
				}
				if(vPlanUserInfo.getUnitId()!=null
						&&vPlanUserInfo.getUnitId()!=""){
					hql += " and t.unitId =" + vPlanUserInfo.getUnitId();
				}
				if(vPlanUserInfo.getPlanBeginDate()!=null
						&&vPlanUserInfo.getPlanBeginDate().getYear()>0){
					hql += " and TO_CHAR(t.planBeginDate,'yyyy-mm-dd')>='" + new SimpleDateFormat("yyyy-MM-dd").format(vPlanUserInfo.getPlanBeginDate())
							+"'";
				}
				if(vPlanUserInfo.getPlanEndDate()!=null
						&&vPlanUserInfo.getPlanEndDate().getYear()>0){
					hql += " and TO_CHAR(t.planEndDate,'yyyy-mm-dd')<='" +  new SimpleDateFormat("yyyy-MM-dd").format(vPlanUserInfo.getPlanEndDate())
							+"'";
				}
				if(vPlanUserInfo.getPlanName()!=null
						&&vPlanUserInfo.getPlanName()!=""){
					hql += " and t.planName like '%" + vPlanUserInfo.getPlanName()
								+ "%'";
				}
			}
			 hql += " order by t.planBeginDate desc";
			List<VPlanUserInfo> vPlanUserInfoList = dao.find(hql, null, page);
			pageResultSet.setPage(page);
			pageResultSet.setList(vPlanUserInfoList);
			// pageResultSet = commonManager.datagrid(IVAccBasicDao.class,
			// pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		} finally {
			// dao.setDataSourceName(DbConfig.enterprises);
		}
	}
	

}
