/**
 * @Description:TODO
 * @project:itouch.application.fda.dailycheck
 * @class:IVFoodProdDailycheckStatisticsManager.java
 * @author:xh
 * @time:2016-1-9 下午4:28:05
 */
package com.itouch.application.fda.biz.bll.dailycheck.report;

import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

/**
 * 食品生产日常监督检查统计
 * @author xh
 */
public interface IVFoodProdDailycheckStatisticsManager extends IAppBusinessManager{
	
	public List<Object[]> getList(String unitId,String entTypeGroupId,String checkBeginDate,String checkEndDate);
	
	/**
	 * 获取被检查企业不重复的entIds 
	 * @param 
	 * @return 
	 */
	public String getDistinctEntId(String unitId,String entTypeGroupIds,String resultVerdictIds);
}
