package com.itouch.application.fda.biz.bll.dailycheck.check;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckTodoInfo;

public interface ICheckTodoManager extends IAppBusinessManager{

	/**
	 * 新增
	 * @param CheckTodoInfo 实体
	 * @return 实体id
	 */
	public Object add(CheckTodoInfo checkTodoInfo) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CheckTodoInfo> list) ;
	
	/**
	 * 更新
	 * @param CheckTodoInfo 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CheckTodoInfo checkTodoInfo)  ;
	
	/**
	 * 批量更新或保存
	 * @param CheckTodoInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CheckTodoInfo> checkTodoInfoList)  ;
	/**
	 * 新增/修改
	 * @param CheckTodoInfo 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CheckTodoInfo checkTodoInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param CheckTodoInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CheckTodoInfo checkTodoInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public CheckTodoInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<CheckTodoInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<CheckTodoInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;

	/** 
	 * @Description:TODO 
	 * @param checkId 
	 * @author:liss 
	 * @return 
	 * @time:2016年6月6日 下午1:08:08 
	 */
	public CheckTodoInfo getEntityByCheckId(String checkId);
}
