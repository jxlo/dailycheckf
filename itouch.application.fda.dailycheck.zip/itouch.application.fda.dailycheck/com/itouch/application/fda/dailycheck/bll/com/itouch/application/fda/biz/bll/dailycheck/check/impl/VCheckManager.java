package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.IVCheckManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.IVCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckInfo;

@Service("DC_VCheckManager")
@Transactional
public class VCheckManager extends AppBusinessManager implements IVCheckManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		IVCheckDao dao;
		try {
			dao = this.getMapper(IVCheckDao.class);
			pageResultSet = bizCommonManager.datagrid(IVCheckDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, VCheckInfo vCheckInfo) {
		PageResultSet pageResultSet = new PageResultSet();
		IVCheckDao dao = null;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		PageQueryParam page = new PageQueryParam();
		page.setPageIndex(pageIndex);
		page.setNumber(pageSize);
		try {
			dao = this.getMapper(IVCheckDao.class);
			String hql = "select t from VCheckInfo t where 1=1 ";
			if (vCheckInfo != null) {

				if (StringUtil.isNotEmpty(vCheckInfo.getEntCode())) {
					hql += " and t.entCode ='" + vCheckInfo.getEntCode().trim() + "'";
				}

				if (StringUtil.isNotEmpty(vCheckInfo.getEntName())) {
					hql += " and t.entName like '%" + vCheckInfo.getEntName().trim() + "%'";
				}

				//TODO 需要修改起止日期查询参数拼接方式
				
				if (vCheckInfo.getCheckBeginDate() != null && !"".equals(vCheckInfo.getCheckBeginDate())) {
					hql += " and to_char(t.checkBeginDate,'yyyy-MM-dd') >= '" + sdf.format(vCheckInfo.getCheckBeginDate()) + "'";
				}
				if (vCheckInfo.getCheckEndDate() != null && !"".equals(vCheckInfo.getCheckEndDate())) {
					hql += " and to_char(t.checkEndDate,'yyyy-MM-dd') <= '" + sdf.format(vCheckInfo.getCheckEndDate()) + "'";
				}
			}
			hql += " order by t.checkBeginDate desc";
			List<VCheckInfo> list = dao.find(hql, null, page);
			pageResultSet.setPage(page);
			pageResultSet.setList(list);
			return pageResultSet;
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		} finally {
		}
	}
		
		
	/** 
	 * @Description:获取列表
	 * @param vCheckInfo
	 * @return 
	 * @author:nihh 
	 * @time:2016年5月31日 上午10:33:07 
	 */
	public List<VCheckInfo> getList(Map<String, Object> map) {
		IVCheckDao dao = null;
		try {
			dao = this.getMapper(IVCheckDao.class);
			return dao.findAnd(null, map);
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		} finally {
		}
	}
}
