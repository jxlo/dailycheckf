/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:PlanUserManager.java
 * @author:fanghailong
 * @time:2015-10-20 下午4:28:53
 */
package com.itouch.application.fda.biz.bll.dailycheck.plan.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.plan.IPlanUserManager;
import com.itouch.application.fda.biz.dao.dailycheck.plan.IPlanUserDao;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanUserInfo;

/**
 * @author:fanghailong 
 */
@Service("planUserManager")
public class PlanUserManager extends AppBusinessManager implements IPlanUserManager{
	
	Logger logger = LoggerFactory.getLogger(PlanUserManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 新增
	 * 
	 * @param planUserInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(PlanUserInfo planUserInfo)  {
		try{
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			dao.add(planUserInfo);
			return planUserInfo.getPlanId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<PlanUserInfo> list) {
		try{
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param PlanUserInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(PlanUserInfo planUserInfo) {
		try{
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			dao.update(planUserInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	
	/**
	 * 批量更新
	 * @param PlanUserInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<PlanUserInfo> planUserInfoList){
		try{
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			dao.save(planUserInfoList);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * 新增/修改
	 * 
	 * @param PlanUserInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(PlanUserInfo planUserInfo) {
		try{
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			dao.save(planUserInfo);
			return planUserInfo.getPlanId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try{
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 删除
	 * 
	 * @param PlanUserInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(PlanUserInfo planUserInfo) {
		try{
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			dao.delete(planUserInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public PlanUserInfo getEntity(String id)  {
		try {
			IPlanUserDao dao = this.getMapper(IPlanUserDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<PlanUserInfo> 列表集合
	 * @throws Throwable
	 */
	public List<PlanUserInfo> getList() {
		IPlanUserDao dao;
		try {
			dao = this.getMapper(IPlanUserDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<PlanUserInfo> getList(Map<String,Object> map){
		IPlanUserDao dao;
		try {
			dao = this.getMapper(IPlanUserDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		IPlanUserDao dao;
		try {
			dao = this.getMapper(IPlanUserDao.class);
			pageResultSet = bizCommonManager.datagrid(IPlanUserDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
