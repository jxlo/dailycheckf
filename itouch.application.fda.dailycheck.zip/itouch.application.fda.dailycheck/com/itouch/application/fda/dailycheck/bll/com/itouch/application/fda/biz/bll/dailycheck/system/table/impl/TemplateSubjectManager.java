/**  
* @Title: TemplateSubjectManager.java 
* @Package com.itouch.application.fda.biz.bll.system.table.impl 
* @author wangk    
* @date 2015-10-10 下午6:07:00  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateSubjectManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateSubjectDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSubjectInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-10 下午6:07:00  
 */
@Service("templateSubjectManager")
public class TemplateSubjectManager extends AppBusinessManager implements ITemplateSubjectManager{

	Logger logger = LoggerFactory.getLogger(TemplateSubjectManager.class);
	
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:新增
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public Object add(TemplateSubjectInfo templateSubjectInfo) {
		try {
			ITemplateSubjectDao dao = this.getMapper(ITemplateSubjectDao.class);
			dao.add(templateSubjectInfo);
			return templateSubjectInfo.getSubjectId();
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			return null;
		}
	}

	/**
	 * @Description:新增
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public boolean add(List<TemplateSubjectInfo> list) {
		try{
			ITemplateSubjectDao dao = this.getMapper(ITemplateSubjectDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description:更新
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public boolean update(TemplateSubjectInfo templateSubjectInfo) {
		try{
			ITemplateSubjectDao dao = this.getMapper(ITemplateSubjectDao.class);
			dao.update(templateSubjectInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description:新增/修改
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public Object addOrUpdate(TemplateSubjectInfo templateSubjectInfo) {
		try{
			ITemplateSubjectDao dao = this.getMapper(ITemplateSubjectDao.class);
			dao.save(templateSubjectInfo);
			return templateSubjectInfo.getSubjectId();
		}catch(Exception ex){
			return null;
		}
	}

	/**
	 * @Description:删除
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public boolean delete(String id) {
		try{
			ITemplateSubjectDao dao = this.getMapper(ITemplateSubjectDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * @Description:删除
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public boolean delete(TemplateSubjectInfo templateSubjectInfo) {
		try{
			ITemplateSubjectDao dao = this.getMapper(ITemplateSubjectDao.class);
			dao.delete(templateSubjectInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * @Description:获取实体
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public TemplateSubjectInfo getEntity(String id) {
		try {
			ITemplateSubjectDao dao = this.getMapper(ITemplateSubjectDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:获取列表
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public List<TemplateSubjectInfo> getList() {
		ITemplateSubjectDao dao;
		try {
			dao = this.getMapper(ITemplateSubjectDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:获取列表
	 * @return 受理类型列表
	 */
	@Override
	public List<TemplateSubjectInfo> getListByTemplateId(String templateId){
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("templateId", templateId);
		return getList(map);
	}

	/**
	 * @Description:根据map参数获取列表
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public List<TemplateSubjectInfo> getList(Map<String, Object> map) {
		ITemplateSubjectDao dao;
		try {
			dao = this.getMapper(ITemplateSubjectDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:获取分页列表
	 * @pram：ITemplateSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午6:07:56
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		ITemplateSubjectDao dao;
		try {
			dao = this.getMapper(ITemplateSubjectDao.class);
			pageResultSet = bizCommonManager.datagrid(ITemplateSubjectDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

}
