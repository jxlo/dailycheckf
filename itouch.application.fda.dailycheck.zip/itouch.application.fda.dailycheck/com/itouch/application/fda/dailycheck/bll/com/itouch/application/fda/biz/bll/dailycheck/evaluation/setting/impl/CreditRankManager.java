package com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.impl;

import iTouch.framework.application.dao.OrderType;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.ICreditRankManager;
import com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.ICreditRankDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditRankInfo;

/**
 * @author qiuy
 * 信用评定等级业务层
 */
@Service("CreditRank")
@Lazy
public class CreditRankManager extends AppBusinessManager implements ICreditRankManager {
	
	Logger logger = LoggerFactory.getLogger(CreditRankManager.class);

	@Autowired
	private ICommonManager commonManager;

	private ICreditRankDao dao;
	
	/**
	 * 新增
	 * @param 受理类型实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public String add(CreditRankInfo info) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			dao.add(info);
			return info.getRankId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditRankInfo> list) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			dao.add(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(CreditRankInfo info) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			dao.update(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(CreditRankInfo info) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			dao.save(info);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 删除
	 * @param Id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * @param 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(CreditRankInfo info) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			dao.delete(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 获取实体
	 * @param Id 主键ID
	 * @return 实体
	 * @throws Throwable
	 */
	@SuppressWarnings("deprecation")
	public CreditRankInfo getEntity(String id) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * @return list 列表集合
	 * @throws Throwable
	 */
	public List<CreditRankInfo> getList() {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			return dao.find("orderId", OrderType.asc);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map查询参数
	 * @return 受理类型列表
	 */
	public List<CreditRankInfo> getList(Map<String, Object> map) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			return dao.findAnd(null, map, "orderId", OrderType.asc);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 根据体系id获得等级列表
	 * @param CriterionId
	 * @return
	 */
	public List<CreditRankInfo> getEnListByCriterionId(String criterionId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("criterionId", criterionId);
		map.put("isEnabled", 1);
		return getList(map);
	}
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		try {
			dao = this.getMapper(ICreditRankDao.class);
			return commonManager.datagrid(ICreditRankDao.class, pageIndex, pageSize, map, dao, "orderId", OrderType.asc);
		} catch (Throwable e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
}
