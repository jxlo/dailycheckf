package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.ICheckTodoManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckTodoDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckTodoInfo;

@Service("DC_CheckTodoManager")
@Transactional
public class CheckTodoManager extends AppBusinessManager implements ICheckTodoManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 新增
	 * 
	 * @param CheckTodoInfo
	 *            实体
	 * @return 实体id
	 */
	public Object add(CheckTodoInfo checkTodoInfo) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			dao.add(checkTodoInfo);
			return checkTodoInfo.getTodoId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 新增
	 * 
	 * @param list
	 *            实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CheckTodoInfo> list) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			dao.add(list);
			return true;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
	}

	/**
	 * 更新
	 * 
	 * @param CheckTodoInfo
	 *            实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CheckTodoInfo checkTodoInfo) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			dao.update(checkTodoInfo);
			return true;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
	}

	/**
	 * 批量更新或保存
	 * 
	 * @param CheckTodoInfoList
	 *            实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CheckTodoInfo> checkTodoInfoList) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			dao.save(checkTodoInfoList);
			return true;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
	}

	/**
	 * 新增/修改
	 * 
	 * @param CheckTodoInfo
	 *            实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CheckTodoInfo checkTodoInfo) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			dao.save(checkTodoInfo);
			return true;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id
	 *            主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			dao.delete(id);
			return true;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
	}

	/**
	 * 删除
	 * 
	 * @param CheckTodoInfo
	 *            实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CheckTodoInfo checkTodoInfo) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			dao.delete(checkTodoInfo);
			return true;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
	}

	/**
	 * 获取实体
	 * 
	 * @param id
	 *            主键Id
	 * @return 实体
	 */
	public CheckTodoInfo getEntity(String id) {
		try {
			ICheckTodoDao dao = this.getMapper(ICheckTodoDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return 受理类型列表
	 */
	public List<CheckTodoInfo> getList() {
		ICheckTodoDao dao;
		try {
			dao = this.getMapper(ICheckTodoDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * 
	 * @param map
	 *            map查询参数
	 * @return 受理类型列表
	 */
	public List<CheckTodoInfo> getList(Map<String, Object> map) {
		ICheckTodoDao dao;
		try {
			dao = this.getMapper(ICheckTodoDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		ICheckTodoDao dao;
		try {
			dao = this.getMapper(ICheckTodoDao.class);
			pageResultSet = bizCommonManager.datagrid(ICheckTodoDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.check.ICheckTodoManager#getEntityByCheckId(java.lang.String)
	 */
	@Override
	public CheckTodoInfo getEntityByCheckId(String checkId) {
		ICheckTodoDao dao;
		try {
			dao = this.getMapper(ICheckTodoDao.class);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("checkId", checkId);
			return dao.uniqueResult(map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
