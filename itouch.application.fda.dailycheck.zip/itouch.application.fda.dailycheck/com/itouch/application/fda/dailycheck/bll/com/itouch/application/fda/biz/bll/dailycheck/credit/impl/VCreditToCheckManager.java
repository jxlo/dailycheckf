package com.itouch.application.fda.biz.bll.dailycheck.credit.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.IVCreditToCheckManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.credit.IVCreditToCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.VCreditToCheckInfo;
import com.itouch.application.fda.foundation.util.StringUtil;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: VCreditToCheckManager
 * @author: wangk
 * @date: 2016-3-15 上午10:41:27
 */
@Service("vCreditToCheckManager")
public class VCreditToCheckManager extends AppBusinessManager implements IVCreditToCheckManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description: 添加日志
	 * @Title: addLogger
	 * @param msg
	 *            void 返回类型
	 * @author: wangk
	 * @date: 2016-3-15 上午10:43:15
	 * @throws
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: TODO(这里用一句话描述这个方法的作用)
	 * @Title: getListBy
	 * @author: wangk
	 * @date: 2016-3-15 上午10:42:49
	 * @throws
	 */
	@Override
	public List<VCreditToCheckInfo> getListBy(String entTypeGroupId, String unitId, String entTypeId) {

		List<VCreditToCheckInfo> list = new ArrayList<VCreditToCheckInfo>();

		try {

			IVCreditToCheckDao dao = this.getMapper(IVCreditToCheckDao.class);

			String hql = " select t from VCreditToCheckInfo t where 1=1";

			if (StringUtil.isNotEmpty(entTypeGroupId)) {
				hql += " and t.entTypeGroupId = '" + entTypeGroupId + "'";
			}
			if (StringUtil.isNotEmpty(unitId)) {
				hql += " and t.unitId = '" + unitId + "'";
			}
			if (StringUtil.isNotEmpty(entTypeId)) {
				hql += " and t.entTypeId like '" + entTypeId + "%'";
			}

			hql += " and t.checkedTimes<t.toCheckedTimes ";

			list = dao.find(hql, null, null);

			return list;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取无评定等级的列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getTodoListByPage(int pageSize, int pageIndex, VCreditToCheckInfo vCreditToCheckInfo) {
		PageResultSet pageResultSet = new PageResultSet();
		List<VCreditToCheckInfo> list = new ArrayList<VCreditToCheckInfo>();

		try {
			IVCreditToCheckDao dao = this.getMapper(IVCreditToCheckDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);

			String hql = "select t from VCreditToCheckInfo t where 1=1 ";

			if (vCreditToCheckInfo != null) {

				if (StringUtil.isNotEmpty(vCreditToCheckInfo.getEntTypeId())) {
					hql += " and t.entTypeId like '" + vCreditToCheckInfo.getEntTypeId() + "%' ";
				}

				if (StringUtil.isNotEmpty(vCreditToCheckInfo.getEntTypeGroupId())) {
					hql += " and t.entTypeGroupId = '" + vCreditToCheckInfo.getEntTypeGroupId() + "'";
				}

				if (StringUtil.isNotEmpty(vCreditToCheckInfo.getEntName())) {
					hql += " and t.entName like '%" + vCreditToCheckInfo.getEntName() + "%' ";
				}

				if (StringUtil.isNotEmpty(vCreditToCheckInfo.getLastCreditValue())) {
					hql += " and t.lastCreditValue='" + vCreditToCheckInfo.getLastCreditValue() + "'";
				}

				if (StringUtil.isNotEmpty(vCreditToCheckInfo.getUnitId())) {
					hql += " and t.unitId = '" + vCreditToCheckInfo.getUnitId() + "'";
				}

				if (StringUtil.isNotEmpty(vCreditToCheckInfo.getLicCode())) {
					hql += " and t.licCode like '%" + vCreditToCheckInfo.getLicCode() + "%'";
				}

				if (vCreditToCheckInfo.getFirstCreditYear() == 0) {
					hql += " and t.firstCreditYear = '" + vCreditToCheckInfo.getFirstCreditYear() + "'";
				} else {
					hql += " and t.firstCreditYear >0 ";
				}

				if (vCreditToCheckInfo.getLastCreditYear() > 0) {
					hql += " and t.lastCreditYear < " + vCreditToCheckInfo.getLastCreditYear() + " ";
				}
			}

			hql += " and t.lastAnnualCreditYear = 0 and (t.checkedTimes>=t.toCheckedTimes) ";

			list = dao.find(hql, null, page);
			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据条件获取分页列表
	 * @Title: findListBySearch
	 * @author: wangk
	 * @date: 2016-3-15 上午10:42:49
	 * @throws
	 */
	@Override
	public PageResultSet findListBySearch(int pageSize, int pageIndex, VCreditToCheckInfo vCreditToCheck, String flag, String param) {

		PageResultSet pageResultSet = new PageResultSet();
		List<VCreditToCheckInfo> list = new ArrayList<VCreditToCheckInfo>();

		// 当前时间
		Calendar calendar = Calendar.getInstance();
		Integer thisYear = calendar.get(Calendar.YEAR);

		try {
			IVCreditToCheckDao dao = this.getMapper(IVCreditToCheckDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);

			String hql = "select t from VCreditToCheckInfo t where 1=1 ";

			if (vCreditToCheck != null) {
				if (StringUtil.isNotEmpty(vCreditToCheck.getEntTypeId())) {
					hql += " and t.entTypeId like '" + vCreditToCheck.getEntTypeId() + "%' ";
				}
				if (StringUtil.isNotEmpty(vCreditToCheck.getEntTypeGroupId())) {
					hql += " and t.entTypeGroupId = '" + vCreditToCheck.getEntTypeGroupId() + "'";
				}
				if (StringUtil.isNotEmpty(vCreditToCheck.getEntName())) {
					hql += " and t.entName like '%" + vCreditToCheck.getEntName() + "%' ";
				}
				if (StringUtil.isNotEmpty(vCreditToCheck.getLastCreditValue())) {
					hql += " and t.lastCreditValue='" + vCreditToCheck.getLastCreditValue() + "'";
				}
				if (StringUtil.isNotEmpty(vCreditToCheck.getUnitId())) {
					hql += " and t.unitId = '" + vCreditToCheck.getUnitId() + "'";
				}
				if (StringUtil.isNotEmpty(vCreditToCheck.getLicCode())) {
					hql += " and t.licCode like '%" + vCreditToCheck.getLicCode() + "%'";
				}
				if (StringUtil.isNotEmpty(vCreditToCheck.getId())) {
					hql += " and t.id in (" + vCreditToCheck.getId() + ")";
				}
			}
			if ("1".equals(flag)) {
				hql += " and t.checkedTimes<t.toCheckedTimes ";
			} else if ("0".equals(flag)) {
				hql += " and t.checkedTimes>=t.toCheckedTimes ";
			}
			if ("1".equals(param)) {
				hql += " and t.lastAnnualCreditYear < " + thisYear;
			} else if ("0".equals(param)) {
				hql += " and t.lastAnnualCreditYear = " + thisYear;
			}

			list = dao.find(hql, null, page);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

}
