/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITemplateItemManager.java
 * @author:fanghailong
 * @time:2015-10-10 下午4:30:52
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateItemInfo;

/**
 * @author:fanghailong 
 */
public interface ITemplateItemManager extends IAppBusinessManager{
	
	/**
	 * 新增
	 * @param TemplateItemInfo 模板实体
	 * @return 实体id
	 */
	public Object add(TemplateItemInfo templateItemInfo) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TemplateItemInfo> list) ;
	
	/**
	 * 更新
	 * @param TemplateItemInfo 模板实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(TemplateItemInfo templateItemInfo)  ;
	
	/**
	 * 新增/修改
	 * @param TemplateItemInfo 模板实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(TemplateItemInfo templateItemInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param TemplateItemInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(TemplateItemInfo templateItemInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public TemplateItemInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateItemInfo> getList() ;
	
	/**
	 * @Description:根据模板获取获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateItemInfo> getListByTemplateId(String templateId);
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<TemplateItemInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	
	/**
	 * 根据大项删除条款
	 */
	public void delBySubjectId(String subjectId) ;
	
	/**
	 * 根据小项删除条款
	 */
	public void delBySmallId(String smallId) ;
}
