/**  
 * @Description: TODO
 * @Title: CreditAnnualManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.annual.impl 
 * @author: wangk
 * @date 2016-2-24 下午5:08:45 
 */
package com.itouch.application.fda.biz.bll.dailycheck.credit.annual.impl;

import iTouch.framework.application.dao.MapperSQLException;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.application.service.MapperNotFoundException;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.annual.ICreditAnnualManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dailycheck.enums.EnumCreditAnnualStates;
import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.ICreditAnnualDao;
import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood.ICreditHfoodProdPreviewDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.CreditAnnualInfo;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood.CreditHfoodProdPreviewInfo;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: CreditAnnualManager
 * @author wangk
 * @date 2016-2-24 下午5:08:45
 */
@Service("creditAnnualManager")
public class CreditAnnualManager extends AppBusinessManager implements ICreditAnnualManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: 新增
	 * @Title: add
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object add(CreditAnnualInfo creditAnnualInfo) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			dao.add(creditAnnualInfo);
			return creditAnnualInfo.getCreditId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 新增
	 * @param list
	 *            实体集合
	 * @Title: add
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean add(List<CreditAnnualInfo> list) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 更新
	 * @Title: update
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean update(CreditAnnualInfo creditAnnualInfo) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			dao.update(creditAnnualInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 批量更新
	 * @Title: save
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean save(List<CreditAnnualInfo> creditAnnualList) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			dao.save(creditAnnualList);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 新增/修改
	 * @Title: addOrUpdate
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object addOrUpdate(CreditAnnualInfo creditAnnualInfo) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			dao.save(creditAnnualInfo);
			return creditAnnualInfo.getCreditId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(String id) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(CreditAnnualInfo creditAnnualInfo) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			dao.delete(creditAnnualInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @Title: getEntity
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public CreditAnnualInfo getEntity(String creditId) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			return dao.getEntity(creditId);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取列表
	 * @Title: getList
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<CreditAnnualInfo> getList() {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据map参数获取列表
	 * @Title: getList
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<CreditAnnualInfo> getList(Map<String, Object> map) {
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取分页列表
	 * @Title: getListByPage
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex, CreditAnnualInfo creditAnnualInfo, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			pageResultSet = bizCommonManager.datagrid(ICreditAnnualDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表（上报）
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListReportByPage(int pageSize, int pageIndex, CreditAnnualInfo creditAnnualInfo, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		List<CreditAnnualInfo> list = new ArrayList<CreditAnnualInfo>();

		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);

			String hql = "select t from CreditAnnualInfo t where 1=1 ";

			if (creditAnnualInfo != null) {

				if (StringUtil.isNotEmpty(creditAnnualInfo.getEntTypeId())) {
					hql += " and t.entTypeId like '" + creditAnnualInfo.getEntTypeId() + "%'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getEntTypeGroupId())) {
					hql += " and t.entTypeGroupId = '" + creditAnnualInfo.getEntTypeGroupId() + "'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getEntName())) {
					hql += " and t.entName like '%" + creditAnnualInfo.getEntName() + "%'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getCreditValue())) {
					hql += " and t.creditValue = '" + creditAnnualInfo.getCreditValue() + "'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getUnitId())) {
					hql += " and t.unitId = '" + creditAnnualInfo.getUnitId() + "'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getCreditUnitId())) {
					hql += " and t.creditUnitId = '" + creditAnnualInfo.getCreditUnitId() + "'";
				}

				if (StringUtil.isNotEmpty(creditAnnualInfo.getCreditCategoryId())) {
					hql += " and t.creditCategoryId = '" + creditAnnualInfo.getCreditCategoryId() + "'";
				}

				if (creditAnnualInfo.getCreditStateId() == (Integer.valueOf(EnumCreditAnnualStates.ToReport.getValue()))) {
					hql += " and t.creditStateId > " + EnumCreditAnnualStates.ToReport.getValue() + " ";
				} else {
					hql += " and t.creditStateId = " + EnumCreditAnnualStates.ToReport.getValue() + " ";
				}
			}

			list = dao.find(hql, null, page);
			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据条件获取分页列表
	 * @Title: findListBySearch
	 * @author wangk
	 * @date 2016-3-2 上午9:24:43
	 * @throws
	 */
	@Override
	public PageResultSet findListBySearch(int pageSize, int pageIndex, CreditAnnualInfo creditAnnualInfo, Integer flag) {

		PageResultSet pageResultSet = new PageResultSet();
		List<CreditAnnualInfo> list = new ArrayList<CreditAnnualInfo>();

		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);

			String hql = "select t from CreditAnnualInfo t where 1=1 ";

			if (creditAnnualInfo != null) {
				if (StringUtil.isNotEmpty(creditAnnualInfo.getEntTypeId())) {
					hql += " and t.entTypeId like '" + creditAnnualInfo.getEntTypeId() + "%'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getEntTypeGroupId())) {
					hql += " and t.entTypeGroupId = '" + creditAnnualInfo.getEntTypeGroupId() + "'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getEntName())) {
					hql += " and t.entName like '%" + creditAnnualInfo.getEntName() + "%'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getCreditValue())) {
					hql += " and t.creditValue = '" + creditAnnualInfo.getCreditValue() + "'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getUnitId())) {
					hql += " and t.unitId = '" + creditAnnualInfo.getUnitId() + "'";
				}
				if (flag == 1) {
					hql += " and t.creditStateId <> '" + EnumCreditAnnualStates.ToReport.getValue() + "'";
				} else if (flag == 0) {
					hql += " and t.creditStateId = '" + EnumCreditAnnualStates.ToReport.getValue() + "'";
				}
				if (StringUtil.isNotEmpty(creditAnnualInfo.getCreditId())) {
					hql += " and t.creditId in (" + creditAnnualInfo.getCreditId() + ")";
				}
			}

			list = dao.find(hql, null, page);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: TODO
	 * @Title: setMergeState
	 * @author xh
	 * @date 2016-3-8 上午11:17:32
	 * @throws
	 */
	@Override
	public void setArchiveState(String ids) {
		ICreditAnnualDao dao = null;
		try {
			dao = this.getMapper(ICreditAnnualDao.class);
			String hql = "update CreditAnnualInfo t set t.creditStateId = '" + EnumCreditAnnualStates.Archived.getValue() + "',t.creditStateName='已归档' where t.id in (" + ids + ") and t.creditStateId='" + EnumCreditAnnualStates.Checked.getValue() + "'";
			dao.executeByCommand(hql, null);
		} catch (MapperNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MapperSQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @Description: TODO
	 * @Title: setChecked
	 * @author xh
	 * @date 2016-3-8 下午1:42:48
	 * @throws
	 */
	@Override
	public void setChecked(String id) {
		// TODO Auto-generated method stub
		ICreditAnnualDao dao = null;
		try {
			dao = this.getMapper(ICreditAnnualDao.class);
			String hql = "update CreditAnnualInfo t set t.creditStateId = '" + EnumCreditAnnualStates.Checked.getValue() + "',t.creditStateName='已检查' where t.id in (" + id + ") and t.creditStateId='" + EnumCreditAnnualStates.ToCheck.getValue() + "'";
			dao.executeByCommand(hql, null);
		} catch (MapperNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MapperSQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @Description: 根据条件获取列表
	 * @Title: getListBy
	 * @author: wangk
	 * @date: 2016-3-8 上午9:57:33
	 * @throws
	 */
	@Override
	public List<CreditAnnualInfo> getListBy(CreditAnnualInfo creditAnnualInfo) {
		List<CreditAnnualInfo> list = new ArrayList<CreditAnnualInfo>();

		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);

			String hql = "select t from CreditAnnualInfo t where 1=1 ";

			if (creditAnnualInfo != null) {
				if (StringUtil.isNotEmpty(creditAnnualInfo.getCreditId())) {
					hql += " and t.id in (" + creditAnnualInfo.getCreditId() + ")";
				}
			}

			list = dao.find(hql, null, null);

			return list;
		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: TODO
	 * @Title: getHfoodList
	 * @author xh
	 * @date 2016-3-15 下午3:30:02
	 * @throws
	 */
	@Override
	public PageResultSet getHfoodList(int pageSize, int pageIndex, CreditHfoodProdPreviewInfo creditHfoodProdForm, String entTypeId, String entTypeGroupId, String creditStateId, Integer year) {
		PageQueryParam page = new PageQueryParam();
		PageResultSet pageResultSet = new PageResultSet();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		page.setNumber(pageSize);
		page.setPageIndex(pageIndex);
		String hql = "";
		try {
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			/*
			 * ; String hql=
			 * "select new CreditHfoodProdFormInfo(t1,t2,t3) from CreditHfoodProdFormInfo t1,CreditHfoodGmpInfo t2,CreditAnnualInfo t3 where t1.creditAnnualId=t3.id and t1.creditAnnualId=t2.creditAnnualId and t3.entTypeGroupId='"
			 * +entTypeGroupId+"' and t3.entTypeId='"+entTypeId+
			 * "' and (t3.creditStateId='"
			 * +creditStateId+"' or t3.creditStateId='"
			 * +EnumCreditAnnualStates.Archived
			 * .getValue()+"' ) and t3.creditYear='"+year+"'";
			 * 
			 * if(creditHfoodProdForm!=null){
			 * if(StringUtil.isNotEmpty(creditHfoodProdForm.getCreditValue())){
			 * hql +=
			 * " and t1.creditValue = '"+creditHfoodProdForm.getCreditValue
			 * ()+"' "; }
			 * if(StringUtil.isNotEmpty(creditHfoodProdForm.getEntName())){ hql
			 * +=
			 * " and t1.entName like '%"+creditHfoodProdForm.getEntName()+"%' ";
			 * }
			 * if(StringUtil.isNotEmpty(creditHfoodProdForm.getCreditDateFrom()
			 * )){
			 * hql+=" and to_char(t1.creditDateFrom,'yyyy-MM-dd') >= '"+sdf.format
			 * (creditHfoodProdForm.getCreditDateFrom())+"' "; }
			 * if(StringUtil.isNotEmpty(creditHfoodProdForm.getCreditDateTo())){
			 * hql
			 * +=" and to_char(t1.creditDateTo,'yyyy-MM-dd') <= '"+sdf.format(
			 * creditHfoodProdForm.getCreditDateTo())+"' "; } }
			 */

			hql += " order by t1.creditDateFrom desc";

			List<CreditHfoodProdPreviewInfo> list = dao.queryByPageCommand(page, hql, null);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: TODO
	 * @Title: setArchiveState
	 * @author xh
	 * @date 2016-3-28 下午4:21:07
	 * @throws
	 */
	@Override
	public List<CreditAnnualInfo> calIndexCreditCount(String orgIds, String CreditAnnualStates) {
		// TODO Auto-generated method stub
		List<CreditAnnualInfo> list = new ArrayList<CreditAnnualInfo>();

		try {
			ICreditAnnualDao dao = this.getMapper(ICreditAnnualDao.class);
			String hql = "select new CreditAnnualInfo(t.unitId,count(t.unitId)) from CreditAnnualInfo t where t.unitId in (" + orgIds + ") and t.creditStateId='" + CreditAnnualStates + "' group by t.unitId";
			list = dao.queryListByCommand(hql, null);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return list;
	}

}
