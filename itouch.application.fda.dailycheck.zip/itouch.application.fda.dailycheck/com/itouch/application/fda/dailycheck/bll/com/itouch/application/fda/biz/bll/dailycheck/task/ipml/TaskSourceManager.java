/**     
  * @Title: TaskSourceManager.java   
  * @Package com.itouch.application.fda.biz.bll.dailycheck.task.ipml   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-12 下午4:32:18     
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.task.ipml;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.bll.dailycheck.task.ITaskSourceManager;
import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskSourceDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskSourceInfo;

/**   
 * @ClassName: TaskSourceManager   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-12 下午4:32:18      
 */
@Service("TaskSourceManager")
public class TaskSourceManager extends AppBusinessManager implements ITaskSourceManager{

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:新增/修改
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time 2015-11-12 下午4:33:32
	 */
	@Override
	public Object addOrUpdate(TaskSourceInfo taskSourceInfo) {
		try {
			ITaskSourceDao dao = this.getMapper(ITaskSourceDao.class);
			dao.save(taskSourceInfo);
			return taskSourceInfo.getId();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @Description: 根据Id删除
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time 2015-11-12 下午4:33:32
	 */
	@Override
	public boolean delete(String id) {
		try {
			ITaskSourceDao dao = this.getMapper(ITaskSourceDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time 2015-11-12 下午4:33:32
	 */
	@Override
	public TaskSourceInfo getEntity(String id) {
		try {
			ITaskSourceDao dao = this.getMapper(ITaskSourceDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * @Description:TODO
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time 2015-11-12 下午4:33:32
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
	
		try {
			ITaskSourceDao dao = this.getMapper(ITaskSourceDao.class);
			pageResultSet = bizCommonManager.datagrid(ITaskSourceDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取List
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time 2015-11-12 下午4:30:50
	 */
	@Override
	public List<TaskSourceInfo> getList(String unitId) {
		ITaskSourceDao dao;
		List<TaskSourceInfo> list = new ArrayList<TaskSourceInfo>();
		
		try {
			dao = this.getMapper(ITaskSourceDao.class);
			
			String hql = "select t from TaskSourceInfo t where 1=1 ";
			if(unitId != null && !"".equals(unitId)){
				hql += " and t.unitId = '"+unitId+"'";
			}
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: TODO(这里用一句话描述这个方法的作用)  
	  * @Title: findListBySearch 
	  * @author wangk
	  * @date 2015-11-26 下午3:06:05 
	  * @throws 
	  */ 
	@Override
	public PageResultSet findListBySearch(int pageSize,int pageIndex,String name,String unitId)throws Throwable {
		ITaskSourceDao dao ;
		PageResultSet pageResultSet = new PageResultSet();
		List<TaskSourceInfo> list = new ArrayList<TaskSourceInfo>();
		
		try {
			dao = this.getMapper(ITaskSourceDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);
			
			String hql = "select t from TaskSourceInfo t where unitId = '"+unitId+"' ";
			if(name != null && !"".equals(name)){
				hql += " and t.name like '%"+name+"%'";
			}
			hql += " order by t.orderNumber";
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 根据任务来源名称查询是否存在
	 * @param name
	 * @return
	 */
	public List<TaskSourceInfo> getTaskByName(String name){
		ITaskSourceDao dao;
		List<TaskSourceInfo> list = new ArrayList<TaskSourceInfo>();
		
		try {
			dao = this.getMapper(ITaskSourceDao.class);
			String hql = "select t from TaskSourceInfo t where 1=1 and name='"+name+"' ";
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

}
