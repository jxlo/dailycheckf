/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TableCheckResultManager.java
 * @author:xh
 * @time:2015-10-26 下午7:16:26
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableCheckResultManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableCheckResultDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableCheckResult;

/**
 *
 * @author xh
 */
@Service("tableCheckResultManager")
public class TableCheckResultManager  extends AppBusinessManager implements ITableCheckResultManager{

	Logger logger = LoggerFactory.getLogger(TableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableCheckResultManager#getEntity(java.lang.String)
	 */
	@Override
	public TableCheckResult getEntity(String id) {
		try {
			ITableCheckResultDao dao = this.getMapper(ITableCheckResultDao.class);
			TableCheckResult e=new TableCheckResult();
			String hql="select t from TableCheckResult t where t.id='"+id+"'";
			List<TableCheckResult> list=dao.find(hql, null, null);
			if (list!=null && list.size()>0)
			{
				return list.get(0);
			}
			return null;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	public Object addOrUpdate(TableCheckResult tableCheckResult) {
		try{
			ITableCheckResultDao dao = this.getMapper(ITableCheckResultDao.class);
			dao.save(tableCheckResult);
			return tableCheckResult.getId();
		}catch(Exception ex){
			return null;
		}
	}
	
	public Object add(TableCheckResult tableCheckResult) {
		try{
			ITableCheckResultDao dao = this.getMapper(ITableCheckResultDao.class);
			dao.add(tableCheckResult);
			return tableCheckResult.getId();
		}catch(Exception ex){
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableCheckResultManager#getList(java.lang.String)
	 */
	@Override
	public List<TableCheckResult> getListByTableId(String tableId) {
		// TODO Auto-generated method stub
		try{
			ITableCheckResultDao dao = this.getMapper(ITableCheckResultDao.class);
			String hql="select t from TableCheckResult t where t.tableId='"+tableId+"'";
			List<TableCheckResult> list=dao.queryListByCommand(hql, null);
			return list;
		}catch(Exception ex){
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableCheckResultManager#getListByCheckId(java.lang.String)
	 */
	@Override
	public List<TableCheckResult> getListByCheckId(String checkId) {
		// TODO Auto-generated method stub
		try{
			ITableCheckResultDao dao = this.getMapper(ITableCheckResultDao.class);
			String hql="select t from TableCheckResult t where t.checkId='"+checkId+"'";
			List<TableCheckResult> list=dao.queryListByCommand(hql, null);
			return list;
		}catch(Exception ex){
			return null;
		}
	}
	
	@Override
	public void deleteByCheckId(String checkId) {
		try{
			ITableCheckResultDao dao = this.getMapper(ITableCheckResultDao.class);
			String hql="delete TableCheckResult t where t.checkId='"+checkId+"'";
			dao.executeByCommand(hql, null);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
