/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITalkManager.java
 * @author:fanghailong
 * @time:2015-10-13 下午3:01:33
 */
package com.itouch.application.fda.biz.bll.dailycheck.talk;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.talk.TalkInfo;

/**
 * @author:fanghailong 
 */
public interface ITalkManager extends IAppBusinessManager{
	
	/**
	 * 新增
	 * @param CheckItem 实体
	 * @return 实体id
	 */
	public Object add(TalkInfo talkInfo) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TalkInfo> list) ;
	
	/**
	 * 更新
	 * @param CheckItem 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(TalkInfo templateHeaderInfo)  ;
	
	/**
	 * 批量更新或保存
	 * @param TalkInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<TalkInfo> talkInfoList)  ;
	/**
	 * 新增/修改
	 * @param CheckItem 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(TalkInfo talkInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param CheckItem  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(TalkInfo talkInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public TalkInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<TalkInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<TalkInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getTalkInfoList(int pageSize, int pageIndex, TalkInfo talkInfo) ;
	/**
	 * 获取最大编号
	 * @param unitId 单位id
	 * @return 最大编号
	 */
	public int getMaxCode(String unitId,Date preTalkDate);
	
}
