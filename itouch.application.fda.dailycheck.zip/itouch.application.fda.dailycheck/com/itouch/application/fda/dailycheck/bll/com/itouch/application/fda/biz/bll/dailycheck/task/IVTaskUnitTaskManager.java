/**  
* @Title: IVTaskUnitTaskManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.task 
* @author wangk    
* @date 2015-10-30 下午2:41:42  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.task;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.task.VTaskUnitTaskInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-30 下午2:41:42  
 */
public interface IVTaskUnitTaskManager extends IAppBusinessManager{

	/**
	 * @param 获取列表
	 * @return 实体
	 * @author:wangk
	 * @time:2015-10-28 上午11:24:07
	 */
	public List<VTaskUnitTaskInfo> getList(String unitTaskId,String taskId,String fromUnitId);
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public VTaskUnitTaskInfo getEntity(String id) ;
	
	/**
	 * 根据条件查询出实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public VTaskUnitTaskInfo getEntityByTaskId(String taskId) ;
	
	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-30 下午2:43:43
	 */
	public PageResultSet findListBySearch(int number,int pageIndex,VTaskUnitTaskInfo vTaskUnitTaskInfo,String state,String states,String unitId) throws Throwable;
	public PageResultSet findListByUnit(int number,int pageIndex,String taskCreateOrg,String taskId,String fromUnitId) throws Throwable;
}
