package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepDrugCheckManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepDrugCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugCheck;

@Service("repDrugCheckManager")
public class RepDrugCheckManager extends AppBusinessManager 
		implements IRepDrugCheckManager {
	Logger logger = LoggerFactory.getLogger(RepDrugCheckManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 */
	@SuppressWarnings("unused")
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	@Override
	public Object add(RepDrugCheck repDrugCheckInfo) {
		try {
			IRepDrugCheckDao dao = this.getMapper(IRepDrugCheckDao.class);
			dao.add(repDrugCheckInfo);
			return repDrugCheckInfo.getId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public boolean save(List<RepDrugCheck> list) {
		try {
			IRepDrugCheckDao dao = this.getMapper(IRepDrugCheckDao.class);
			dao.save(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return false;
		}
		return false;
	}

	@Override
	public RepDrugCheck getEntity(String id) {
		try {
			IRepDrugCheckDao dao = this.getMapper(IRepDrugCheckDao.class);
			RepDrugCheck info = dao.getEntity(id);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public List<RepDrugCheck> getList(String reportId) {
		try {
			IRepDrugCheckDao dao = this.getMapper(IRepDrugCheckDao.class);
			String hql = "select t from RepDrugCheck t where 1=1 and t.reportId = '"+reportId+"' ";
			return dao.queryListByCommand(hql, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	
	
}
