package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepCateringDynamicManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepCateringDynamicDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepCateringDynamicInfo;
import com.itouch.application.fda.foundation.util.StringUtil;

/** 
 * @Description: 餐饮企业量化分级统计表
 * @ClassName: RepCateringDynamicManager 
 * @author: wangk
 * @date: 2016-3-22 上午11:06:38  
 */
@Service("repCateringDynamicManager")
public class RepCateringDynamicManager extends AppBusinessManager implements IRepCateringDynamicManager{
	
	Logger logger = LoggerFactory.getLogger(RepCateringDynamicManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: 新增
	 * @Title: add
	 * @author xh
	 * @date 2016-2repCateringDynamicInfohrows
	 */
	@Override
	public Object add(RepCateringDynamicInfo repCosmDailyCheckInfo) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			dao.add(repCosmDailyCheckInfo);
			return repCosmDailyCheckInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 新增
	 * @param list
	 *            实体集合
	 * @Title: add
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean add(List<RepCateringDynamicInfo> list) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 更新
	 * @Title: update
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean update(RepCateringDynamicInfo repCateringDynamicInfo) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			dao.update(repCateringDynamicInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 批量更新
	 * @Title: save
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean save(List<RepCateringDynamicInfo> list) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			dao.save(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 新增/修改
	 * @Title: addOrUpdate
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object addOrUpdate(RepCateringDynamicInfo repCateringDynamicInfo) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			dao.save(repCateringDynamicInfo);
			return repCateringDynamicInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(String id) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(RepCateringDynamicInfo repCateringDynamicInfo) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			dao.delete(repCateringDynamicInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * 
	 * @param reportId
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByReportId(String reportId) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			String sql = " delete RepCateringDynamicInfo t where t.reportId='"
					+ reportId + "'";
			dao.executeByCommand(sql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @Title: getEntity
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public RepCateringDynamicInfo getEntity(String id) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			RepCateringDynamicInfo info = dao.getEntity(id);
			return info;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepCateringDynamicInfo> getList(String reportId) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			String hql = "select t from RepCateringDynamicInfo t where t.reportId='"
					+ reportId + "'";
			return dao.queryListByCommand(hql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据条件获取列表
	 * @Title: getListBy
	 * @param reportId
	 * @return List<RepCosmDailyCheckInfo> 返回类型
	 * @author: wangk
	 * @date: 2016-3-17 下午4:13:51
	 * @throws
	 */
	public List<RepCateringDynamicInfo> getListByReportIds(String reportIds) {
		
		List<RepCateringDynamicInfo> list = new ArrayList<RepCateringDynamicInfo>();

		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);

			String hql = "select t from RepCateringDynamicInfo t where 1=1 ";

			if (StringUtil.isNotEmpty(reportIds)) {
				hql += " and t.reportId in(" + reportIds + ")";
			}

			list = dao.find(hql, null, null);

			return list;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据map参数获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepCateringDynamicInfo> getList(Map<String, Object> map) {
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取分页列表
	 * @Title: getListByPage
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			IRepCateringDynamicDao dao = this
					.getMapper(IRepCateringDynamicDao.class);
			pageResultSet = bizCommonManager.datagrid(
					IRepCateringDynamicDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
