package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepDrugModeManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepDrugModeDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugMode;

@Service("repDrugModeManager")
public class RepDrugModeManager extends AppBusinessManager 
		implements IRepDrugModeManager {
	Logger logger = LoggerFactory.getLogger(RepDrugModeManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 */
	@SuppressWarnings("unused")
	private void addLogger(String msg) {
		logger.error("" + msg);
	}
	
	/**
	 * @desc  新增
	 * @param repDrugModeInfo
	 */
	@Override
	public Object add(RepDrugMode repDrugModeInfo) {
		try {
			IRepDrugModeDao dao = this.getMapper(IRepDrugModeDao.class);
			dao.add(repDrugModeInfo);
			return repDrugModeInfo.getId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	/**
	 * @desc 新增
	 * @param list 实体集合
	 * @return true false
	 */
	@Override
	public boolean save(List<RepDrugMode> list) {
		try {
			IRepDrugModeDao dao = this.getMapper(IRepDrugModeDao.class);
			dao.save(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}

	@Override
	public RepDrugMode getEntity(String id) {
		IRepDrugModeDao dao;
		try {
			dao = this.getMapper(IRepDrugModeDao.class);
			RepDrugMode info = dao.getEntity(id);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	
	/**
	 * @desc 获取列表
	 * @param getList
	 */
	@Override
	public List<RepDrugMode> getList(String reportId) {
		try {
			IRepDrugModeDao dao = this.getMapper(IRepDrugModeDao.class);
			String hql = "select t from RepDrugMode t where 1=1 and t.reportId = '"+reportId+"' ";
			return dao.queryListByCommand(hql, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}


}
