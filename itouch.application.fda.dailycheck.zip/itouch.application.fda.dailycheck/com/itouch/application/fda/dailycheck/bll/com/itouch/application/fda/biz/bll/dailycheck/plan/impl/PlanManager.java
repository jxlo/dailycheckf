/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:PlanManager.java
 * @author:fanghailong
 * @time:2015-10-20 下午3:47:37
 */
package com.itouch.application.fda.biz.bll.dailycheck.plan.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.ent.dao.grid.IVEntGridCollarDao;
import com.itouch.application.ent.entity.grid.VEntGridCollarInfo;
import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.plan.IPlanManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.plan.IPlanDao;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanInfo;

/**
 * @author:fanghailong 
 */
@Service("planManager")
public class PlanManager extends AppBusinessManager implements IPlanManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 新增
	 * 
	 * @param planInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(PlanInfo planInfo) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			dao.add(planInfo);
			return planInfo.getPlanId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<PlanInfo> list) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param PlanInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(PlanInfo planInfo) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			dao.update(planInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 批量更新
	 * @param PlanInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<PlanInfo> planInfoList) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			dao.save(planInfoList);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * 
	 * @param PlanInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(PlanInfo planInfo) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			dao.save(planInfo);
			return planInfo.getPlanId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * 
	 * @param PlanInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(PlanInfo planInfo) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			dao.delete(planInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public PlanInfo getEntity(String id) {
		try {
			IPlanDao dao = this.getMapper(IPlanDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<PlanInfo> 列表集合
	 * @throws Throwable
	 */
	public List<PlanInfo> getList() {
		IPlanDao dao;
		try {
			dao = this.getMapper(IPlanDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<PlanInfo> getList(Map<String, Object> map) {
		IPlanDao dao;
		try {
			dao = this.getMapper(IPlanDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		IPlanDao dao;
		try {
			dao = this.getMapper(IPlanDao.class);
			pageResultSet = bizCommonManager.datagrid(IPlanDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getPlanInfoList(int pageSize, int pageIndex, PlanInfo planInfo, String planCreatorId) {
		PageResultSet pageResultSet = new PageResultSet();
		IPlanDao dao = null;
		PageQueryParam page = new PageQueryParam();
		page.setPageIndex(pageIndex);
		page.setNumber(pageSize);
		try {
			dao = this.getMapper(IPlanDao.class);
			// dao.setDataSourceName(DbConfig.online);
			String hql = "select t from PlanInfo t where 1=1 ";
			if (planCreatorId != null && planCreatorId != "") {
				hql += "and t.planCreatorId ='" + planCreatorId + "'";
			}
			if (planInfo != null) {
				if (planInfo.getIsCompleted() != null && planInfo.getIsCompleted().toString() != "") {
					hql += " and t.isCompleted =" + planInfo.getIsCompleted();
				}
				if (planInfo.getPlanName() != null && planInfo.getPlanName() != "") {
					hql += " and t.planName like '%" + planInfo.getPlanName() + "%'";
				}
				if (planInfo.getPlanBeginDate() != null && planInfo.getPlanBeginDate().getYear() > 0) {
					hql += " and TO_CHAR(t.planBeginDate,'yyyy-mm-dd')>='" + new SimpleDateFormat("yyyy-MM-dd").format(planInfo.getPlanBeginDate()) + "'";
				}
				if (planInfo.getPlanEndDate() != null && planInfo.getPlanEndDate().getYear() > 0) {
					hql += " and TO_CHAR(t.planEndDate,'yyyy-mm-dd')<='" + new SimpleDateFormat("yyyy-MM-dd").format(planInfo.getPlanEndDate()) + "'";
				}
			}
			hql += " order by t.planBeginDate desc";
			List<PlanInfo> planInfoList = dao.find(hql, null, page);
			pageResultSet.setPage(page);
			pageResultSet.setList(planInfoList);
			// pageResultSet = commonManager.datagrid(IVAccBasicDao.class,
			// pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		} finally {
			// dao.setDataSourceName(DbConfig.enterprises);
		}
	}
	
	@Override
	public List<PlanInfo> getPlanByName(String name) {
		IPlanDao dao;
		List<PlanInfo> list = new ArrayList<PlanInfo>();
		try {
			dao = this.getMapper(IPlanDao.class);
			String hql = "select p from PlanInfo p where 1=1 and planName='"+name+"' ";
			list = dao.find(hql, null, null);
			return list;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	@Override
	public List<VEntGridCollarInfo> getEntCount(String unit_ID) {
		IVEntGridCollarDao dao;
		List<VEntGridCollarInfo> list = new ArrayList<VEntGridCollarInfo>();
		try {
			dao = this.getMapper(IVEntGridCollarDao.class);
			String hql = "select ent_code, ent_name,reg_addr from itouch_fda_ent.V_ENT_GRID_COLLAR  where 1=1 and unit_ID='"+unit_ID+"' ";
			list = dao.find(hql, null, null);
			return list;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
