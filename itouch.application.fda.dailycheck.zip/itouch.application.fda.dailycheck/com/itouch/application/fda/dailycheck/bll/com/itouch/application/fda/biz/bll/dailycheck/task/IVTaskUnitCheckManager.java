/**     
  * @Title: IVTaskUnitCheckManager.java   
  * @Package com.itouch.application.fda.biz.bll.dailycheck.task   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-4 下午5:45:26     
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.task;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.task.VTaskUnitCheckInfo;

/**   
 * @ClassName: IVTaskUnitCheckManager   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-4 下午5:45:26      
 */
public interface IVTaskUnitCheckManager extends IAppBusinessManager {
	
	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-30 下午2:43:43
	 */
	public PageResultSet findListBySearch(int number,int pageIndex,String unitTaskId,String param) throws Throwable;

	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-30 下午2:43:43
	 */
	public List<VTaskUnitCheckInfo> getList(String unitTaskId);
}
