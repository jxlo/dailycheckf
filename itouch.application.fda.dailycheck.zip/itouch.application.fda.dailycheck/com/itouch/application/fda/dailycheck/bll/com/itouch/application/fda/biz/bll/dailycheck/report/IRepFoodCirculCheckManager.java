/**  
  * @Description: TODO
  * @Title: IRepFoodCirculCheckManager.java 
  * @Package: com.itouch.application.fda.biz.bll.dailycheck.report 
  * @author: xh
  * @date 2016-3-24 下午4:14:26 
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.report;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodCirculCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: IRepFoodCirculCheckManager 
 * @author xh
 * @date 2016-3-24 下午4:14:26  
 */
public interface IRepFoodCirculCheckManager extends IAppBusinessManager {
	/**
	 * @Description: 新增
	 * @Title: add
	 * @return Object    返回类型 
	 * @author xh
	 * @date 2016-2-24 下午5:05:44 
	 * @throws 
	 */ 
	public Object add(RepFoodCirculCheckInfo repFoodCirculCheckInfo);
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<RepFoodCirculCheckInfo> list) ;
	
	/**
	 * 更新
	 * @param CheckEntInfo 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(RepFoodCirculCheckInfo repFoodCirculCheckInfo)  ;
	
	/**
	 * 批量更新或保存
	 * @param CheckEntInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<RepFoodCirculCheckInfo> repFoodCirculCheckInfoList)  ;
	/**
	 * 新增/修改
	 * @param CheckEntInfo 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(RepFoodCirculCheckInfo repFoodCirculCheckInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param reportId  
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByReportId(String reportId) ;
	
	/**
	 * 删除
	 * @param CheckEntInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(RepFoodCirculCheckInfo repFoodCirculCheckInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public RepFoodCirculCheckInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 列表
	 */
	public List<RepFoodCirculCheckInfo> getList(String reportId) ;
	
	/**
	 * @Description: 根据条件获取列表  
	 * @Title: getListBy 
	 * @param reportId
	 * @return List<RepFoodCirculCheckInfo> 返回类型 
	 * @author: wangk
	 * @date: 2016-3-17 下午4:13:51 
	 * @throws 
	 */ 
	public List<RepFoodCirculCheckInfo> getListByReportIds(String reportId);
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<RepFoodCirculCheckInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
}
