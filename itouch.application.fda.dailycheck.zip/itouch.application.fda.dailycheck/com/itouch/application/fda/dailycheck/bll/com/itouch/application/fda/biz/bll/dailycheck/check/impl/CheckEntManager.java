/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckEnrManager.java
 * @author:fanghailong
 * @time:2015-10-23 下午2:16:33
 */
package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.dao.ConditionEnum;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.ICheckEntManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckEntDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckEntInfo;

/**
 * @author:fanghailong 
 */
@Service("checkEntManager")
@Transactional
public class CheckEntManager extends AppBusinessManager implements ICheckEntManager{
	
	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 新增
	 * 
	 * @param CheckEntInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(CheckEntInfo checkEntInfo)  {
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			dao.add(checkEntInfo);
			return checkEntInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CheckEntInfo> list) {
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param CheckEntInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(CheckEntInfo checkEntInfo) {
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			dao.update(checkEntInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	
	/**
	 * 批量更新
	 * @param CheckEntInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CheckEntInfo> checkEntInfoList){
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			dao.save(checkEntInfoList);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * 新增/修改
	 * 
	 * @param CheckEntInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(CheckEntInfo checkEntInfo) {
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			dao.save(checkEntInfo);
			return checkEntInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}
	
	/**
	 * 删除
	 * @param id checkId
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByCheckId(String checkId){
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			String hql=" delete from CheckEntInfo t where t.checkId='"+checkId+"'";
			dao.executeByCommand(hql, null);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 删除
	 * 
	 * @param CheckEntInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(CheckEntInfo checkEntInfo) {
		try{
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			dao.delete(checkEntInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public CheckEntInfo getEntity(String id)  {
		try {
			ICheckEntDao dao = this.getMapper(ICheckEntDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<CheckEntInfo> 列表集合
	 * @throws Throwable
	 */
	public List<CheckEntInfo> getList() {
		ICheckEntDao dao;
		try {
			dao = this.getMapper(ICheckEntDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<CheckEntInfo> getList(Map<String,Object> map){
		ICheckEntDao dao;
		try {
			dao = this.getMapper(ICheckEntDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		ICheckEntDao dao;
		try {
			dao = this.getMapper(ICheckEntDao.class);
			pageResultSet = bizCommonManager.datagrid(ICheckEntDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map,List<ConditionEnum> relations)  {
		PageResultSet pageResultSet = new PageResultSet();
		ICheckEntDao dao;
		try {
			dao = this.getMapper(ICheckEntDao.class);
			pageResultSet = bizCommonManager.datagrid(ICheckEntDao.class, pageIndex, pageSize, map,relations, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPageAndRealation(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		ICheckEntDao dao;
		try {
			dao = this.getMapper(ICheckEntDao.class);
			pageResultSet = bizCommonManager.datagrid(ICheckEntDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	
	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.check.ICheckEntManager#getEntityByCheckId(java.lang.String)
	 */
	@Override
	public CheckEntInfo getEntityByCheckId(String checkId) {
		ICheckEntDao dao;
		try {
			dao = this.getMapper(ICheckEntDao.class);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("checkId", checkId);
			return dao.uniqueResult(map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
