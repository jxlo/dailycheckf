package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators.IOperators;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators.LogicalOperators;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators.RelationalOperators;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;
import com.itouch.application.fda.foundation.util.GlobalUtil;
import com.itouch.application.fda.foundation.util.ParamUtil;

/**
 * @author qiuy
 * 表达式转换
 */
public class ExpressionConverter {
	
	private static List<IOperators> _operatorList = new ArrayList<IOperators>();
	private static LinkedList<ExpressionInfo> _postfixExpressionQueue;
	private static Stack<ExpressionInfo> _operatorStack;
	
	static {
		_operatorList.add(new LogicalOperators());
		_operatorList.add(new RelationalOperators());
	}
	
	/**
	 * 转换为后缀表达式
	 * @param expressionInfoList
	 * @return
	 */
	public static LinkedList<ExpressionInfo> ToPostfix(List<ExpressionInfo> expressionList) {
		
		_postfixExpressionQueue = new LinkedList<ExpressionInfo>();
		_operatorStack = new Stack<ExpressionInfo>();
		
		ExpressionInfo numberExpression = null;
        
        for (ExpressionInfo expressionInfo : expressionList) {
			
        	ExpressionInfo operatorExpression = null;
        	
        	String s = expressionInfo.getContent();
        	
        	//如果是数字
        	if(ParamUtil.isNumeric(s) || GlobalUtil.isUUID(s)) {
        		numberExpression = expressionInfo;
        	}
        	
        	//如果是左括号
        	else if(s.equals("(")) {
        		_operatorStack.push(expressionInfo);
        	}
        	
        	//如果是右括号
        	else if(s.equals(")")) {
        		if (numberExpression != null)
                {
                    _postfixExpressionQueue.addLast(numberExpression);
                    numberExpression = null;
                }

                while (_operatorStack.size() > 0)
                {
                    ExpressionInfo top = _operatorStack.pop();
                    if (top.getContent().equals("(")) {
                    	break;
                    }
                    _postfixExpressionQueue.addLast(top);
                }
        	}
        	
        	//如果是操作符或者
        	else {
        		if (numberExpression != null)
                {
                    _postfixExpressionQueue.addLast(numberExpression);
                    numberExpression = null;
                }

                //如果是操作符
                for (IOperators oper : _operatorList)
                {
                    if (oper.IsTheOperator(expressionInfo.getContent()))
                    {
                        operatorExpression = expressionInfo;
                        break;
                    }
                }

                if (_operatorStack.size() == 0) {
                	_operatorStack.push(operatorExpression);
                }
                else
                {
                    while (_operatorStack.size() > 0)
                    {
                        ExpressionInfo top = _operatorStack.pop();
                        if (Power(top.getContent()) >= Power(operatorExpression.getContent())) {
                        	_postfixExpressionQueue.addLast(top);
                        }
                        else
                        {
                            _operatorStack.push(top);
                            break;
                        }
                    }
                    _operatorStack.push(operatorExpression);
                }
        	}
		}
        
        if (numberExpression != null)
        {
            _postfixExpressionQueue.addLast(numberExpression);
        }

        while (_operatorStack.size() > 0)
        {
            _postfixExpressionQueue.addLast(_operatorStack.pop());
        }

        return _postfixExpressionQueue;
	}
	
	/**
	 * 获得操作符的优先级
	 * @param o
	 * @return
	 */
	private static int Power(String o) {
		switch (o) {
			case "&&":
			case "||":
				return 1;
			case "==":
			case ">":
			case ">=":
			case "<":
			case "<=":
				return 2;
			default:
				return 0;
			}
	}
}
