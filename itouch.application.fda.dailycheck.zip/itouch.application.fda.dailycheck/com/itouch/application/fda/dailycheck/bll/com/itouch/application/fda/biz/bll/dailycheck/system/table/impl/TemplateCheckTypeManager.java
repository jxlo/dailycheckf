/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateCheckTypeInfoManager.java
 * @author:xh
 * @time:2015-10-10 下午5:51:42
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateCheckTypeManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateCheckTypeDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateCheckTypeInfo;

/**
 *
 * @author xh
 */
@Service("TemplateCheckTypeManager")
public class TemplateCheckTypeManager extends AppBusinessManager implements ITemplateCheckTypeManager{
	Logger logger = LoggerFactory.getLogger(TemplateCheckTypeManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateCheckTypeInfoManager#getListByPage(int, int, java.util.Map)
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		ITemplateCheckTypeDao dao;
		try {
			dao = this.getMapper(ITemplateCheckTypeDao.class);
			pageResultSet = bizCommonManager.datagrid(ITemplateCheckTypeDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateCheckTypeInfoManager#getEntity(java.lang.String)
	 */
	@Override
	public TemplateCheckTypeInfo getEntity(String id) {
		try {
			ITemplateCheckTypeDao dao = this.getMapper(ITemplateCheckTypeDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateCheckTypeInfoManager#addOrUpdate(com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateCheckTypeInfo)
	 */
	@Override
	public void addOrUpdate(TemplateCheckTypeInfo templateCheckTypeInfo) {
		// TODO Auto-generated method stub
		try{
			ITemplateCheckTypeDao dao = this.getMapper(ITemplateCheckTypeDao.class);
			dao.save(templateCheckTypeInfo);
		}catch(Exception ex){
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.system.table.ITemplateCheckTypeInfoManager#delete(java.lang.String)
	 */
	@Override
	public boolean delete(String id) {
		try{
			ITemplateCheckTypeDao dao = this.getMapper(ITemplateCheckTypeDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

}
