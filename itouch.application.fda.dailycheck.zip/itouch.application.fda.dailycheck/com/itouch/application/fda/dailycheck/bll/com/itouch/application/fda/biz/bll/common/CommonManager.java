/**
 * @Description:TODO
 * @project:itouch.application.fda.online
 * @class:CommonManager.java
 * @author:zhanglai
 * @time:2015年7月29日 下午4:17:26
 */

package com.itouch.application.fda.biz.bll.common;

import iTouch.framework.application.dao.ConditionEnum;
import iTouch.framework.application.dao.IBaseCommonDao;
import iTouch.framework.application.dao.OrderType;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

/**
 * @author  zhanglai
 *
 */
@Service("bizCommonManager")
public class CommonManager  extends AppBusinessManager implements ICommonManager{

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.online.bll.ICommonManager#datagrid(java.lang.Class, int, int, java.util.Map, iTouch.framework.application.dao.IBaseCommonDao)
	 */
	@Override
	public <E> PageResultSet datagrid(Class<E> entityClass, int index,
			int number, Map<String, Object> map, IBaseCommonDao dao)
			throws Throwable {
		return datagrid(entityClass,index,number,map,dao,null,null);
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.online.bll.ICommonManager#datagrid(java.lang.Class, int, int, java.util.Map, iTouch.framework.application.dao.IBaseCommonDao, java.lang.String, java.lang.String)
	 */
	@Override
	public <E> PageResultSet datagrid(Class<E> entityClass, int index,
			int number, Map<String, Object> map, IBaseCommonDao dao,
			String orderPropertyName,OrderType orderType) throws Throwable {
		PageResultSet pageResultSet =  new PageResultSet();
		int totalNumber = total(entityClass);
		int pageNum = getPageNum(totalNumber,number);
		PageQueryParam page = new PageQueryParam();
		page.setNumber(number);
		page.setPageIndex(index);
		page.setPageNum(pageNum);
		page.setTotalNumber(totalNumber);
		List list = dao.findAnd(page, map, orderPropertyName,orderType);
		pageResultSet.setList(list);
		pageResultSet.setPage(page);
		return pageResultSet;
	}
	@Override
	public <E> PageResultSet datagrid(Class<E> entityClass, int index,
			int number, Map<String, Object> map,List<ConditionEnum> relations, IBaseCommonDao dao)
			throws Throwable {
		
		
		return datagridRealation(entityClass,index,number,map,relations,dao,null,null);
	}
	
	@Override
	public <E> PageResultSet datagridRealation(Class<E> entityClass, int index,
			int number, Map<String, Object> map,List<ConditionEnum> relations,  IBaseCommonDao dao,
			String orderPropertyName,OrderType orderType) throws Throwable {
		PageResultSet pageResultSet =  new PageResultSet();
		int totalNumber = total(entityClass);
		int pageNum = getPageNum(totalNumber,number);
		PageQueryParam page = new PageQueryParam();
		page.setNumber(number);
		page.setPageIndex(index);
		page.setPageNum(pageNum);
		page.setTotalNumber(totalNumber);
		String[] propertyName = new String[map.size()];
		ConditionEnum[] conditionEnum = new ConditionEnum[map.size()];
		Object[] propertyValue = new Object[propertyName.length];
		int i = 0;
		for(String key:map.keySet()){
			propertyName[i] = key.split(",")[0];
			conditionEnum[i]= key.split(",").length>1?key.split(",")[1]!=null && "centerLike".equals(key.split(",")[1])?ConditionEnum.centerLike:ConditionEnum.eq: ConditionEnum.eq;
			propertyValue[i++] = map.get(key);
		}
		 
		List list = dao.findAnd(page,propertyName,conditionEnum,propertyValue, orderPropertyName,orderType);
		pageResultSet.setList(list);
		pageResultSet.setPage(page);
		return pageResultSet;
	} 
	public <E> PageResultSet datagridHql(String hql, int index,
			int number, Object[] array, IBaseCommonDao dao) throws Throwable {
		PageResultSet pageResultSet =  new PageResultSet();
		PageQueryParam page = new PageQueryParam();
		page.setNumber(number);
		page.setPageIndex(index);
		List list = dao.find(hql, array, page);
		pageResultSet.setList(list);
		pageResultSet.setPage(page);
		return pageResultSet;
	}
	
	private <E>int total(Class<E> entityClass) throws Throwable {
		IBaseCommonDao commonDao = this.getMapper(IBaseCommonDao.class);
		return commonDao.totalNum(entityClass, null);
	}
	
	private int getPageNum(int total,int number){
		int pageNum =1;
		if(total%number==0){
			pageNum = total/number;
		}else{
			pageNum = total/number+1;
		}
		return pageNum;
	}
	/* (non-Javadoc)
	 * @see iTouch.framework.data.operation.BusinessService#methodNames()
	 */


}
