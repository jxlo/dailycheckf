/**  
* @Title: TemplateSmallSubjectManager.java 
* @Package com.itouch.application.fda.biz.bll.system.table.impl 
* @author wangk    
* @date 2015-10-10 下午5:12:21  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateSmallSubjectManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateSmallSubjectDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSmallSubjectInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-10 下午5:12:21  
 */
@Service("templateSmallSubjectManager")
public class TemplateSmallSubjectManager extends AppBusinessManager implements ITemplateSmallSubjectManager {
	
	Logger logger = LoggerFactory.getLogger(TemplateSmallSubjectManager.class);
	
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:新增
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public Object add(TemplateSmallSubjectInfo templateSmallSubject) {
		try {
			ITemplateSmallSubjectDao dao = this.getMapper(ITemplateSmallSubjectDao.class);
			dao.add(templateSmallSubject);
			return templateSmallSubject.getSmallSubjectId();
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			return null;
		}
	}

	/**
	 * @Description:新增
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public boolean add(List<TemplateSmallSubjectInfo> list) {
		try{
			ITemplateSmallSubjectDao dao = this.getMapper(ITemplateSmallSubjectDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description:更新
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public boolean update(TemplateSmallSubjectInfo templateSmallSubject) {
		try{
			ITemplateSmallSubjectDao dao = this.getMapper(ITemplateSmallSubjectDao.class);
			dao.update(templateSmallSubject);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description:新增/修改
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public Object addOrUpdate(TemplateSmallSubjectInfo templateSmallSubject) {
		try{
			ITemplateSmallSubjectDao dao = this.getMapper(ITemplateSmallSubjectDao.class);
			dao.save(templateSmallSubject);
			return templateSmallSubject.getSmallSubjectId();
		}catch(Exception ex){
			return null;
		}
	}

	/**
	 * @Description:删除
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public boolean delete(String id) {
		try{
			ITemplateSmallSubjectDao dao = this.getMapper(ITemplateSmallSubjectDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * @Description:删除
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public boolean delete(TemplateSmallSubjectInfo templateSmallSubject) {
		try{
			ITemplateSmallSubjectDao dao = this.getMapper(ITemplateSmallSubjectDao.class);
			dao.delete(templateSmallSubject);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * @Description:获取实体
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public TemplateSmallSubjectInfo getEntity(String id) {
		try {
			ITemplateSmallSubjectDao dao = this.getMapper(ITemplateSmallSubjectDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:获取列表
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public List<TemplateSmallSubjectInfo> getList() {
		ITemplateSmallSubjectDao dao;
		try {
			dao = this.getMapper(ITemplateSmallSubjectDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:根据模板获取获取列表
	 * @return 受理类型列表
	 */
	@Override
	public List<TemplateSmallSubjectInfo> getListByTemplateId(String templateId){
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("templateId", templateId);
		return getList(map);
	}

	/**
	 * @Description:根据map参数获取列表
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public List<TemplateSmallSubjectInfo> getList(Map<String, Object> map) {
		ITemplateSmallSubjectDao dao;
		try {
			dao = this.getMapper(ITemplateSmallSubjectDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description:获取分页列表
	 * @pram：ITemplateSmallSubjectManager
	 * @return:  
	 * @time:2015-10-10 下午5:15:26
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		ITemplateSmallSubjectDao dao;
		try {
			dao = this.getMapper(ITemplateSmallSubjectDao.class);
			pageResultSet = bizCommonManager.datagrid(ITemplateSmallSubjectDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateSmallSubjectManager#delBySubjectId(java.lang.String)
	 */
	@Override
	public void delBySubjectId(String subjectId) {
		// TODO Auto-generated method stub
		
		String hql="delete from TemplateSmallSubjectInfo t where t.subjectId='"+subjectId+"'";
		ITemplateSmallSubjectDao dao;
		try {
			dao = this.getMapper(ITemplateSmallSubjectDao.class);
			dao.executeByCommand(hql, null);
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
		}
		
	}

}
