/**     
  * @Title: ITaskSourceDao.java   
  * @Package com.itouch.application.fda.biz.bll.dailycheck.check   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-12 下午4:19:39     
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.task;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.task.TaskSourceInfo;

/**   
 * @ClassName: ITaskSourceDao   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-12 下午4:19:39      
 */
public interface ITaskSourceManager extends IAppBusinessManager{
	
	/**
	 * @Description:新增/修改
	 * @param taskSourceInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time 2015-11-12 下午4:30:32
	 */
	public Object addOrUpdate(TaskSourceInfo taskSourceInfo);
	
	/**
	 * @Description:删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 * @author:wangk
	 * @time 2015-11-12 下午4:30:50
	 */
	public boolean delete(String id);
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time 2015-11-12 下午4:30:50
	 */
	public TaskSourceInfo getEntity(String id);
	
	/**
	 * 获取List
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time 2015-11-12 下午4:30:50
	 */
	public List<TaskSourceInfo> getList(String unitId);
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 * @author:wangk
	 * @time 2015-11-12 下午4:31:10
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;

	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time 2015-11-13 上午11:31:10
	 */
	public PageResultSet findListBySearch(int pageSize,int pageIndex,String name,String unitId) throws Throwable;
	
	/**
	 * 根据任务来源名称查询任务是否存在
	 * @param name
	 * @return
	 */
	public List<TaskSourceInfo> getTaskByName(String name);
}
