/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableHeaderManager.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:38:47
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableHeaderDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableHeaderInfo;

/**
 * @author:fanghailong 
 */
@Service("checkTableHeaderManager")
public class TableHeaderManager extends AppBusinessManager implements ITableHeaderManager {
	
	Logger logger = LoggerFactory.getLogger(TableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * 新增
	 * 
	 * @param CheckTableHearderInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(TableHeaderInfo checkTableHeaderInfo)  {
		try{
			ITableHeaderDao dao = this.getMapper(ITableHeaderDao.class);
			dao.add(checkTableHeaderInfo);
			return checkTableHeaderInfo.getTableId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TableHeaderInfo> list) {
		try{
			ITableHeaderDao dao = this.getMapper(ITableHeaderDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param TableHeaderInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(TableHeaderInfo checkTableHeaderInfo) {
		try{
			ITableHeaderDao dao = this.getMapper(ITableHeaderDao.class);
			dao.update(checkTableHeaderInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * 
	 * @param TableHeaderInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(TableHeaderInfo checkTableHeaderInfo) {
		try{
			ITableHeaderDao dao = this.getMapper(ITableHeaderDao.class);
			dao.save(checkTableHeaderInfo);
			return checkTableHeaderInfo.getTableId();
		}catch(Exception ex){
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try{
			ITableHeaderDao dao = this.getMapper(ITableHeaderDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 删除
	 * 
	 * @param TableHeaderInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(TableHeaderInfo checkTableHeaderInfo) {
		try{
			ITableHeaderDao dao = this.getMapper(ITableHeaderDao.class);
			dao.delete(checkTableHeaderInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public TableHeaderInfo getEntity(String id)  {
		try {
			ITableHeaderDao dao = this.getMapper(ITableHeaderDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<CheckTableHeaderInfo> 列表集合
	 * @throws Throwable
	 */
	public List<TableHeaderInfo> getList() {
		ITableHeaderDao dao;
		try {
			dao = this.getMapper(ITableHeaderDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<TableHeaderInfo> getList(Map<String,Object> map){
		ITableHeaderDao dao;
		try {
			dao = this.getMapper(ITableHeaderDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		ITableHeaderDao dao;
		try {
			dao = this.getMapper(ITableHeaderDao.class);
			pageResultSet = bizCommonManager.datagrid(ITableHeaderDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
