/**  
* @Title: VTaskUnitTaskManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.task.ipml 
* @author wangk    
* @date 2015-10-30 下午2:43:13  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.task.ipml;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.bll.dailycheck.task.IVTaskUnitTaskManager;
import com.itouch.application.fda.biz.dailycheck.enums.EnumTaskState;
import com.itouch.application.fda.biz.dao.dailycheck.task.IVTaskUnitTaskDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.VTaskUnitTaskInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-30 下午2:43:13  
 */
@Service("dcVTaskUnitTaskManager")
public class VTaskUnitTaskManager  extends AppBusinessManager implements IVTaskUnitTaskManager{

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time:2015-10-28 上午11:24:07
	 */
	@Override
	public List<VTaskUnitTaskInfo> getList(String unitTaskId,String taskId,String fromUnitId){
		IVTaskUnitTaskDao dao;
		List<VTaskUnitTaskInfo> list = new ArrayList<VTaskUnitTaskInfo>();
		try {
			dao = this.getMapper(IVTaskUnitTaskDao.class);
			
			String hql = "select t from VTaskUnitTaskInfo t where 1=1";
			if(unitTaskId != null && !"".equals(unitTaskId)){
				hql += " and t.unitTaskId = '"+unitTaskId+"'";
			}
			if(taskId != null && !"".equals(taskId)){
				hql += " and t.taskId = '"+taskId+"' ";
			}
			if(fromUnitId != null && !"".equals(fromUnitId)){
				hql += " and t.fromUnitId = '"+fromUnitId+"' ";
			}
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	@Override
	public VTaskUnitTaskInfo getEntity(String id) {
		try {
			IVTaskUnitTaskDao dao = this.getMapper(IVTaskUnitTaskDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:根据条件查询出列表
	 * @pram：IVTaskUnitTaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-30 下午2:43:43
	 */
	@Override
	public PageResultSet findListBySearch(int number, int pageIndex,VTaskUnitTaskInfo vTaskUnitTaskInfo, String state,String states,String unitId) throws Throwable {
		IVTaskUnitTaskDao dao;
		PageResultSet pageResultSet = new PageResultSet();
		List<VTaskUnitTaskInfo> list = new ArrayList<VTaskUnitTaskInfo>();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			dao = this.getMapper(IVTaskUnitTaskDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);
			//待接收
			Integer reception = Integer.parseInt(EnumTaskState.Reception.getValue());
			//已下发
			Integer alreadyIssued = Integer.parseInt(EnumTaskState.AlreadyIssued.getValue());
			//已接收
			Integer received = Integer.parseInt(EnumTaskState.Received.getValue());
			//待上报
			Integer toBeReported = Integer.parseInt(EnumTaskState.ToBeReported.getValue());
			//已上报
			Integer haveBeenReported = Integer.parseInt(EnumTaskState.HaveBeenReported.getValue());
			
			String hql = "select t from VTaskUnitTaskInfo t where t.unitId = '"+unitId+"' ";
			
			//状态
			if("Reception".equals(state)){
				//待接收
				hql += " and t.taskState = " + reception;
			}else if("Received".equals(state)){
				//已下发,已接受
				hql +=" and t.taskState = " + received;
			}else if("toBeReported".equals(state)){
				//待上报
				hql += " and (t.taskState = "+alreadyIssued+" or  t.taskState = " + toBeReported+")";
			}else if("haveBeenReported".equals(state)){
				//已上报
				hql += " and t.taskState = "+haveBeenReported;
			}
			if(vTaskUnitTaskInfo.getTaskName() != null && !"".equals(vTaskUnitTaskInfo.getTaskName())){
				hql +=" and t.taskName like '%"+vTaskUnitTaskInfo.getTaskName()+"%' ";
			}
			if(vTaskUnitTaskInfo.getTaskBeginDate() != null && !"".equals(vTaskUnitTaskInfo.getTaskBeginDate())){
				hql += " and to_char(t.taskBeginDate,'yyyy-MM-dd') >='"+sdf.format(vTaskUnitTaskInfo.getTaskBeginDate())+"'";
			}
			if(vTaskUnitTaskInfo.getTaskEndDate() != null && !"".equals(vTaskUnitTaskInfo.getTaskEndDate())){
				hql += " and to_char(t.taskEndDate,'yyyy-MM-dd') <='"+sdf.format(vTaskUnitTaskInfo.getTaskEndDate())+"'";
			}
			if(states != null && !"".equals(states)){
				hql +=" and t.taskState = "+ Integer.parseInt(states);
			}
			
			hql +=" order by t.taskBeginDate desc";//排序
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public PageResultSet findListByUnit(int number, int pageIndex,String taskCreateOrg,String taskId,String fromUnitId) throws Throwable {
		IVTaskUnitTaskDao dao;
		PageResultSet pageResultSet = new PageResultSet();
		List<VTaskUnitTaskInfo> list = new ArrayList<VTaskUnitTaskInfo>();
		try {
			dao = this.getMapper(IVTaskUnitTaskDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);
			
			String hql = "select t from VTaskUnitTaskInfo t where 1=1 ";
			
			if(fromUnitId != null && !"".equals(fromUnitId)){
				hql += " and t.fromUnitId = '"+fromUnitId+"' ";
			}
			if(taskCreateOrg != null && !"".equals(taskCreateOrg)){
				hql += " and t.taskCreateOrg = '"+taskCreateOrg+"' ";
			}
			if(taskId != null && !"".equals(taskId)){
				hql += " and t.taskId = '"+taskId+"' ";
			}
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据条件查询出实体
	 * @param id  主键Id
	 * @return 实体
	 */
	@Override
	public VTaskUnitTaskInfo getEntityByTaskId(String taskId) {
		try {
			IVTaskUnitTaskDao dao = this.getMapper(IVTaskUnitTaskDao.class);
			
			VTaskUnitTaskInfo vTaskUnitTaskInfo = new VTaskUnitTaskInfo();
			
			String hql = "select t from VTaskUnitTaskInfo t where t.taskId = '"+taskId+"'";
			
			List<VTaskUnitTaskInfo> list = dao.queryListByCommand(hql, null);
			
			if(!list.isEmpty()){
				vTaskUnitTaskInfo = list.get(0);
			}
			
			return vTaskUnitTaskInfo;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

}
