package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators;

import com.itouch.application.fda.biz.dailycheck.enums.EnumRatingResults;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;

/**
 * @author qiuy
 * 逻辑运算符
 */
public class LogicalOperators implements IOperators{

	/**
	 * 是否为本操作符
	 * @param input
	 * @return
	 */
	@Override
	public boolean IsTheOperator(String input) {
		return input.equals("&&") || input.equals("||");
	}

	/**
	 * 计算结果
	 * @param operand1 操作数1
	 * @param operand2 操作数2
	 * @param operator 操作符
	 * @return
	 */
	@Override
	public ExpressionInfo Calculate(ExpressionInfo operand1, ExpressionInfo operand2, String operator) {
		
		ExpressionInfo resultExpressionInfo = new ExpressionInfo();
		resultExpressionInfo.setContent("false");
		
		//如果操作数1和操作数2废弃
		if(operand1.getResult().equals(EnumRatingResults.Abandoned) && operand2.getResult().equals(EnumRatingResults.Abandoned)) {
			//废弃结果
			resultExpressionInfo.setResult(EnumRatingResults.Abandoned);
			return resultExpressionInfo;
		}
		
		//如果操作数1废弃
		if(operand1.getResult().equals(EnumRatingResults.Abandoned)) {
			//返回操作数2
			return operand2;
		}
		
		//如果操作数2废弃
		if(operand2.getResult().equals(EnumRatingResults.Abandoned)) {
			//返回操作数1
			return operand1;
		}
		
		boolean result = false;
		
		switch (operator) {
			case "&&":
				result = Boolean.parseBoolean(operand1.getContent()) && Boolean.parseBoolean(operand2.getContent());
				break;
			case "||":
				result = Boolean.parseBoolean(operand1.getContent()) || Boolean.parseBoolean(operand2.getContent());
				break;
		}
		
		//设置操作数1的评定结果
		if(result) {
			operand1.setResult(EnumRatingResults.Pass);
		} else {
			operand1.setResult(EnumRatingResults.NoPass);
		}
		
		//设置表达式的结果并返回
		resultExpressionInfo.setContent(Boolean.toString(result));
		return resultExpressionInfo;
	}

}
