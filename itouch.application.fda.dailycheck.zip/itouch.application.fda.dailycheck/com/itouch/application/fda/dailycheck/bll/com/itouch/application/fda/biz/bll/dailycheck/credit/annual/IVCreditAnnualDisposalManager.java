/**  
 * @Description: TODO
 * @Title: ICreditAnnualManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.annual 
 * @author: wangk
 * @date 2016-2-24 下午5:03:44 
 */
package com.itouch.application.fda.biz.bll.dailycheck.credit.annual;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.VCreditAnnualDisposalInfo;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: ICreditAnnualManager
 * @author wangk
 * @date 2016-2-24 下午5:03:44
 */
public interface IVCreditAnnualDisposalManager extends IAppBusinessManager {

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, VCreditAnnualDisposalInfo vCreditAnnualDisposalInfo, Map<String, Object> map);

}
