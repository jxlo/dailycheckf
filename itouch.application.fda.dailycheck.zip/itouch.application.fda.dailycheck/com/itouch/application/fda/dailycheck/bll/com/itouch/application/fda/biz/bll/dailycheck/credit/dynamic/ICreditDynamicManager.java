/**  
 * @Description: TODO
 * @Title: ICreditDynamicManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.dynamic 
 * @author: wangk
 * @date 2016-2-24 下午5:23:37 
 */ 
package com.itouch.application.fda.biz.bll.dailycheck.credit.dynamic;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic.CreditDynamicInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: ICreditDynamicManager 
 * @author wangk
 * @date 2016-2-24 下午5:23:37  
 */
public interface ICreditDynamicManager extends IAppBusinessManager{
	/**
	 * @Description: 新增
	 * @Title: add
	 * @return Object    返回类型 
	 * @author wangk
	 * @date 2016-2-24 下午5:05:44 
	 * @throws 
	 */ 
	public Object add(CreditDynamicInfo creditDynamicInfo);
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditDynamicInfo> list) ;
	
	/**
	 * 更新
	 * @param CheckEntInfo 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CreditDynamicInfo creditDynamicInfo)  ;
	
	/**
	 * 批量更新或保存
	 * @param CheckEntInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CreditDynamicInfo> creditDynamicList)  ;
	/**
	 * 新增/修改
	 * @param CheckEntInfo 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CreditDynamicInfo creditDynamicInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param CheckEntInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CreditDynamicInfo creditDynamicInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public CreditDynamicInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<CreditDynamicInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<CreditDynamicInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
}
