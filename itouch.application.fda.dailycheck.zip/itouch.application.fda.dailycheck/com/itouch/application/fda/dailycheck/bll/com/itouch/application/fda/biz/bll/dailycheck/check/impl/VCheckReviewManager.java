/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:VCheckReviewManager.java
 * @author:fanghailong
 * @time:2015-11-2 下午3:15:34
 */
package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.IVCheckReviewManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.IVCheckReviewDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckReviewInfo;

/**
 * @author:fanghailong
 */
@Service("vCheckReviewManager")
public class VCheckReviewManager extends AppBusinessManager implements IVCheckReviewManager {

	Logger logger = LoggerFactory.getLogger(VCheckReviewManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 获取实体
	 * 
	 * @param id
	 *            主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public VCheckReviewInfo getEntity(String id) {
		try {
			IVCheckReviewDao dao = this.getMapper(IVCheckReviewDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<VCheckReviewInfo> 列表集合
	 * @throws Throwable
	 */
	public List<VCheckReviewInfo> getList() {
		IVCheckReviewDao dao;
		try {
			dao = this.getMapper(IVCheckReviewDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * 
	 * @param map
	 *            map查询参数
	 * @return 列表
	 */
	public List<VCheckReviewInfo> getList(Map<String, Object> map) {
		IVCheckReviewDao dao;
		try {
			dao = this.getMapper(IVCheckReviewDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		IVCheckReviewDao dao;
		try {
			dao = this.getMapper(IVCheckReviewDao.class);
			pageResultSet = bizCommonManager.datagrid(IVCheckReviewDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getVCheckReviewListByPage(int pageSize, int pageIndex, VCheckReviewInfo vCheckReviewInfo, String flag) {
		PageResultSet pageResultSet = new PageResultSet();
		IVCheckReviewDao dao = null;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		PageQueryParam page = new PageQueryParam();
		page.setPageIndex(pageIndex);
		page.setNumber(pageSize);
		try {
			dao = this.getMapper(IVCheckReviewDao.class);
			String hql = "select t from VCheckReviewInfo t where 1=1 ";
			if (vCheckReviewInfo != null) {

				if (vCheckReviewInfo.getIsFinished() >= 0) {
					hql += " and t.isFinished =" + vCheckReviewInfo.getIsFinished();
				}

				if (StringUtil.isNotEmpty(vCheckReviewInfo.getEntTypeId())) {
					if ("FoodBusiness".equals(flag)) {
						hql += " and t.entTypeGroupId ='" + vCheckReviewInfo.getEntTypeId() + "'";
					} else {
						hql += " and t.entTypeId ='" + vCheckReviewInfo.getEntTypeId() + "'";
					}
				}
				if (vCheckReviewInfo.getEntName() != null && !"".equals(vCheckReviewInfo.getEntName())) {
					hql += " and t.entName like '%" + vCheckReviewInfo.getEntName() + "%'";
				}
				if (vCheckReviewInfo.getCheckTypeId() != null && !"".equals(vCheckReviewInfo.getCheckTypeId())) {
					hql += " and t.checkTypeId ='" + vCheckReviewInfo.getCheckTypeId() + "'";
				}
				if (vCheckReviewInfo.getUnitId() != null && !"".equals(vCheckReviewInfo.getUnitId())) {
					hql += " and t.unitId ='" + vCheckReviewInfo.getUnitId() + "'";
				}
				if (vCheckReviewInfo.getResult() != null) {
					if ("0".equals(vCheckReviewInfo.getResult())) {
						hql += " and t.resultVerdictId = 1";
					} else if ("-1".equals(vCheckReviewInfo.getResult())) {
						hql += " and (t.resultVerdictId = -1 or t.resultVerdictId = -2)";
					}
				}
				if (vCheckReviewInfo.getResultVerdictId() != null && !"".equals(vCheckReviewInfo.getResultVerdictId().toString())) {
					hql += " and t.resultVerdictId =" + vCheckReviewInfo.getResultVerdictId();
				}
				if (vCheckReviewInfo.getCheckBeginDate() != null && !"".equals(vCheckReviewInfo.getCheckBeginDate())) {
					hql += " and to_char(t.checkBeginDate,'yyyy-MM-dd') >= '" + sdf.format(vCheckReviewInfo.getCheckBeginDate()) + "'";
				}
				if (vCheckReviewInfo.getCheckEndDate() != null && !"".equals(vCheckReviewInfo.getCheckEndDate())) {
					hql += " and to_char(t.checkEndDate,'yyyy-MM-dd') <= '" + sdf.format(vCheckReviewInfo.getCheckEndDate()) + "'";
				}
			}
			hql += " order by t.checkBeginDate desc";
			List<VCheckReviewInfo> vCheckReiewInfo = dao.find(hql, null, page);
			pageResultSet.setPage(page);
			pageResultSet.setList(vCheckReiewInfo);
			return pageResultSet;
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		} finally {
		}
	}

	/**
	 * 用hql语句获取列表
	 * 
	 * @param hql语句
	 * @return 集合
	 */
	public List<VCheckReviewInfo> finListByHql(String hql) {
		IVCheckReviewDao dao;
		try {
			dao = this.getMapper(IVCheckReviewDao.class);
			List<VCheckReviewInfo> vCheckReviewInfoList = dao.find(hql, null, null);
			return vCheckReviewInfoList;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}

	}
}
