package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.IVCheckTodoManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.IVCheckTodoDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckTodoInfo;

@Service("DC_VCheckTodoManager")
public class VCheckTodoManager extends AppBusinessManager implements IVCheckTodoManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 获取实体
	 * 
	 * @param id
	 *            主键Id
	 * @return 实体
	 */
	public VCheckTodoInfo getEntity(String id) {
		try {
			IVCheckTodoDao dao = this.getMapper(IVCheckTodoDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return 受理类型列表
	 */
	public List<VCheckTodoInfo> getList() {
		IVCheckTodoDao dao;
		try {
			dao = this.getMapper(IVCheckTodoDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * 
	 * @param map
	 *            map查询参数
	 * @return 受理类型列表
	 */
	public List<VCheckTodoInfo> getList(Map<String, Object> map) {
		IVCheckTodoDao dao;
		try {
			dao = this.getMapper(IVCheckTodoDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		IVCheckTodoDao dao;
		try {
			dao = this.getMapper(IVCheckTodoDao.class);
			pageResultSet = bizCommonManager.datagrid(IVCheckTodoDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map, VCheckTodoInfo model) {
		IVCheckTodoDao dao;
		List<VCheckTodoInfo> list = new ArrayList<VCheckTodoInfo>();
		PageResultSet pageResultSet = new PageResultSet();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			dao = this.getMapper(IVCheckTodoDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);

			String hql = "select t from VCheckTodoInfo t  where 1=1 ";

			if (null != model) {
				// 企业类型分组
				if (StringUtil.isNotEmpty(model.getEntTypeGroupId())) {
					hql += " AND t.entTypeGroupId like '" + model.getEntTypeGroupId() + "%'";
				}
				// 检查类型
				if (StringUtil.isNotEmpty(model.getCheckTypeId())) {
					hql += " AND t.checkTypeId = '" + model.getCheckTypeId() + "'";
				}
				// 企业名称
				if (StringUtil.isNotEmpty(model.getEntName())) {
					hql += " AND t.entName LIKE '%" + model.getEntName() + "%'";
				}
				
				//是否完成
				if(StringUtil.isNotEmpty(model.getIsFinished())){
					hql += " AND t.isFinished = '" + model.getIsFinished() + "'";
				}
			}

			if (null != map) {
				if (StringUtil.isNotEmpty(map.get("beginDate"))) {
					hql += String.format(" AND to_char(t.fromTime,'yyyy-MM-dd') >= '%s'", map.get("beginDate"));
				}
				if (StringUtil.isNotEmpty(map.get("endDate"))) {
					hql += String.format(" AND to_char(t.fromTime,'yyyy-MM-dd') <= '%s'", map.get("endDate"));
				}
				//处理人
				if(StringUtil.isNotEmpty(map.get("toUnitId"))){
					hql += " AND t.toUnitId = '" + map.get("toUnitId") + "'";
				}
				if(StringUtil.isNotEmpty(map.get("toUserId"))){
					hql += " AND t.toUserId = '" + map.get("toUserId") + "'";
				}
			}

			hql += " order by  t.fromTime desc";

			list = dao.find(hql, null, page);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			return pageResultSet;

		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
}
