package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepDrugUseManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepDrugUseDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugUse;

@Service("repDrugUseManager")
public class RepDrugUseManager extends AppBusinessManager 
		implements IRepDrugUseManager {
	Logger logger = LoggerFactory.getLogger(RepDrugUseManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 */
	@SuppressWarnings("unused")
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	@Override
	public Object add(RepDrugUse repDrugUseInfo) {
		try {
			IRepDrugUseDao dao = this.getMapper(IRepDrugUseDao.class);
			dao.add(repDrugUseInfo);
			return repDrugUseInfo.getId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public boolean save(List<RepDrugUse> list) {
		try {
			IRepDrugUseDao dao = this.getMapper(IRepDrugUseDao.class);
			dao.save(list);
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return false;
		}
	}

	@Override
	public RepDrugUse getEntity(String id) {
		try {
			IRepDrugUseDao dao = this.getMapper(IRepDrugUseDao.class);
			RepDrugUse info = dao.getEntity(id);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public List<RepDrugUse> getList(String reportId) {
		try {
			IRepDrugUseDao dao = this.getMapper(IRepDrugUseDao.class);
			String hql = "select t from RepDrugUse t where 1=1 and t.reportId = '"+reportId+"' ";
			return dao.queryListByCommand(hql, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

}
