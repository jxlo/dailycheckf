/**  
* @Title: ICheckManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.check 
* @author wangk    
* @date 2015-10-20 下午4:11:13  
*/
package com.itouch.application.fda.biz.bll.dailycheck.check;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanUserInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-20 下午4:11:13  
 */
public interface ICheckManager extends IAppBusinessManager {

	/**
	 * @Description:新增/修改
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-20 下午4:21:02
	 */
	public Object add(CheckInfo checkInfo);
	
	/**
	 * @Description:新增/修改
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-20 下午4:21:02
	 */
	public Object addOrUpdate(CheckInfo checkInfo);

	/**
	 * @Description:删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-20 下午4:21:57
	 */
	public boolean delete(String id);

	/**
	 * @Description:删除
	 * @param checkInfo 实体
	 * @return 是否删除成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-20 下午4:22:36
	 */
	public boolean delete(CheckInfo checkInfo);

	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time:2015-10-20 下午4:23:25
	 */
	public CheckInfo getEntity(String id);

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 * @author:wangk
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map);

	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-26 下午7:37:26
	 */
	public PageResultSet findListBySearch(int number, int pageIndex, CheckInfo checkInfo, String param, Map<String, Object> map) throws Throwable;
	
	
	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-26 下午7:37:26
	 */
	public PageResultSet findListBySearchAndflightcheck(int number, int pageIndex, CheckInfo checkInfo, String param, Map<String, Object> map) throws Throwable;
	
	
	
	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-26 下午7:37:26
	 */
	public PageResultSet findListBySearch2(int number, int pageIndex, CheckInfo checkInfo, String param, Map<String, Object> map) throws Throwable;

	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-26 下午7:37:26
	 */
	public List<CheckInfo> getList(String tableId);

	/**
	 * @Description:根据检查类型统计检查
	 * @return
	 * @author:zhangzt
	 * @time:2016年1月28日 下午7:26:55
	 */
	public List<Object[]> countCheckByCheckType(String unitId);

	/**
	 * 获得一家企业某年某个监管结论出现的次数
	 * @param year
	 * @param entCode
	 * @param entTypeGroupId
	 * @param checkVerdictId 监管结论编号
	 * @param checkTypeId 监管类型编号
	 * @return
	 */
	public String getCheckVerdictCount(String year, String entCode, String entTypeGroupId, String checkVerdictId, String checkTypeId);
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<CheckInfo> getList(Map<String,Object> map) ;

	/**
	 * 获得一家企业某年某个监管类型的最差监管结果
	 * @param year
	 * @param entCode
	 * @param entTypeGroupId
	 * @param checkTypeId 监管类型编号
	 * @return
	 */
	public String getCheckVerdictResult(String year, String entCode, String entTypeGroupId, String checkTypeId);
}
