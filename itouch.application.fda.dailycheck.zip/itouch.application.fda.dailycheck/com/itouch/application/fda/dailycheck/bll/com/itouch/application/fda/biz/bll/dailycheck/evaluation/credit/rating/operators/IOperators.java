package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators;

import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;

/**
 * @author qiuy
 * 操作符
 */
public interface IOperators {
	
	/**
	 * 是否为本操作符
	 * @param input
	 * @return
	 */
	public boolean IsTheOperator(String input);
	
	/**
	 * 计算结果
	 * @param operand1 操作数1
	 * @param operand2 操作数2
	 * @param operator 操作符
	 * @return
	 */
	public ExpressionInfo Calculate(ExpressionInfo operand1, ExpressionInfo operand2, String operator);
}
