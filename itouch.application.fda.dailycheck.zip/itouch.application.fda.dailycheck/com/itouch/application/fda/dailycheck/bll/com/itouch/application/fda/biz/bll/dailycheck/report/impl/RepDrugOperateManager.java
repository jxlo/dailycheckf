package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepDrugOperateManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepDrugOperateDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugOperate;

@Service("repDrugOperateDailyCheckManager")
public class RepDrugOperateManager extends AppBusinessManager 
		implements IRepDrugOperateManager {
	Logger logger = LoggerFactory.getLogger(RepDrugOperateManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 */
	@SuppressWarnings("unused")
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @desc  新增
	 * @param repDrugOperateInfo
	 */
	@Override
	public Object add(RepDrugOperate repDrugOperateInfo) {
		try {
			IRepDrugOperateDao dao = this.getMapper(IRepDrugOperateDao.class);
			dao.add(repDrugOperateInfo);
			return repDrugOperateInfo.getId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	/**
	 * @desc 新增
	 * @param list 实体集合
	 * @return true false
	 */
	@Override
	public boolean save(List<RepDrugOperate> list) {
		try {
			IRepDrugOperateDao dao = this.getMapper(IRepDrugOperateDao.class);
			dao.save(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}

	@Override
	public RepDrugOperate getEntity(String id) {
		try {
			IRepDrugOperateDao dao = this.getMapper(IRepDrugOperateDao.class);
			RepDrugOperate info = dao.getEntity(id);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public List<RepDrugOperate> getList(String reportId) {
		try {
			IRepDrugOperateDao dao = this.getMapper(IRepDrugOperateDao.class);
			String hql = "select t from RepDrugOperate t where 1=1 and t.reportId = '"+reportId+"' ";
			return dao.queryListByCommand(hql, null);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	
}
