/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ICheckEntManager.java
 * @author:fanghailong
 * @time:2015-10-23 下午2:03:29
 */
package com.itouch.application.fda.biz.bll.dailycheck.check;

import iTouch.framework.application.dao.ConditionEnum;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckEntInfo;

/**
 * @author:fanghailong 
 */
public interface ICheckEntManager extends IAppBusinessManager{
	
	/**
	 * 新增
	 * @param CheckEntInfo 实体
	 * @return 实体id
	 */
	public Object add(CheckEntInfo checkEntInfo) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CheckEntInfo> list) ;
	
	/**
	 * 更新
	 * @param CheckEntInfo 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CheckEntInfo checkEntInfo)  ;
	
	/**
	 * 批量更新或保存
	 * @param CheckEntInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CheckEntInfo> checkEntInfoList)  ;
	/**
	 * 新增/修改
	 * @param CheckEntInfo 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CheckEntInfo checkEntInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param id checkId
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByCheckId(String checkId);
	
	/**
	 * 删除
	 * @param CheckEntInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CheckEntInfo checkEntInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public CheckEntInfo getEntity(String id) ;
	
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<CheckEntInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<CheckEntInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map,List<ConditionEnum> relations) ;

	
	
	/** 
	 * @Description:TODO 
	 * @param checkId
	 * @return 
	 * @author:liss 
	 * @time:2016年6月6日 下午4:26:30 
	 */
	public CheckEntInfo getEntityByCheckId(String checkId);
}
