/**  
 * @Description: TODO
 * @Title: IVCheckDynamicManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.dynamic 
 * @author: wangk
 * @date 2016-2-24 下午5:32:15 
 */ 
package com.itouch.application.fda.biz.bll.dailycheck.credit.dynamic;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic.VCheckDynamicInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: IVCheckDynamicManager 
 * @author wangk
 * @date 2016-2-24 下午5:32:15  
 */
public interface IVCheckDynamicManager extends IAppBusinessManager{
	
	/**
	 * 根据条件获取列表
	 */
	public List<VCheckDynamicInfo> getListBy(String entCode,String entTypeGroupId);
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;

	/**
	 * 根据条件获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet findListBySearch(int pageSize, int pageIndex, VCheckDynamicInfo vCheckDynamicInfo) ;
}
