package com.itouch.application.fda.biz.bll.dailycheck.report;

import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugCheck;


public interface IRepDrugCheckManager extends IAppBusinessManager {
	
	/**
	 * 新增
	 * @param repDrugCheckInfo
	 * @return Object
	 */
	public Object add(RepDrugCheck repDrugCheckInfo);
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean save(List<RepDrugCheck> list) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public RepDrugCheck getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 列表
	 */
	public List<RepDrugCheck> getList(String reportId) ;
	
}
