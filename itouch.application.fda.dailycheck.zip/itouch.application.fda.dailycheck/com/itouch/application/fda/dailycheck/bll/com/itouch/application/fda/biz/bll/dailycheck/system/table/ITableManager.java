/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:I.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:17:39
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table;

import iTouch.framework.application.dao.MapperSQLException;
import iTouch.framework.application.service.MapperNotFoundException;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableInfo;

/**
 * @author:fanghailong 
 */
public interface ITableManager extends IAppBusinessManager{
	
	/**
	 * 根据条件查询出列表
	 * @param accTableName,accProjectId,
	 * @return
	 * @throws Throwable
	 */
	public PageResultSet findListBySearch(int number,int pageIndex,String templateId,String tableName,String unitId,String deptId,String entTypeGroupId,String checkTypeId,Map<String, Object> map) throws Throwable;
	/**
	 * tableSelect页面专用
	 * */
	public PageResultSet findListByTableSelect(int number,int pageIndex,String entTypeGroupId,String checkTypeId,String tableName);
	public PageResultSet findListBySearchT(int number,int pageIndex,String templateId,String tableName,Map<String, Object> map) throws Throwable;
	public List<TableInfo> findListByTemplateId(String templateId) throws Throwable;
	public List<TableInfo> findList(String templateId, String entType);
	
	public List<TableInfo> findListByCheckTypeId(String checkTypeId, String entType);
	
	
	/**
	 * 新增
	 * @param TemplateItemInfo 模板实体
	 * @return 实体id
	 */
	public Object add(TableInfo checkTableInfo) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TableInfo> list) ;
	
	/**
	 * 更新
	 * @param TableInfo 模板实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(TableInfo checkTableInfo)  ;
	
	/**
	 * 新增/修改
	 * @param TableInfo 模板实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(TableInfo checkTableInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param TableInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(TableInfo checkTableInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public TableInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<TableInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<TableInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	
	/**
	 * 根据tableId检测是否在使用中
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public boolean checkIsUse(String tableId)  throws MapperNotFoundException , MapperSQLException ;
}
