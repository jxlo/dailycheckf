package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating;

import iTouch.framework.application.manager.IAppBusinessManagerMapper;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

import org.springframework.util.StringUtils;

import com.itouch.application.ent.bll.basic.IVEntBasicManager;
import com.itouch.application.ent.entity.basic.VEntBasic;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.ICreditEntRankManager;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.calculators.ICalculator;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.calculators.NumberCalculator;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.calculators.ResultCalculator;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators.IOperators;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators.LogicalOperators;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators.RelationalOperators;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.ICreditConditionDetailManager;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.ICreditConditionManager;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.ICreditCriterionManager;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.ICreditRankManager;
import com.itouch.application.fda.biz.dailycheck.enums.EnumRatingResults;
import com.itouch.application.fda.biz.dailycheck.enums.EnumVerdictType;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.CreditEntRankInfo;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditConditionDetailInfo;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditConditionInfo;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditCriterionInfo;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditRankInfo;
import com.itouch.application.fda.foundation.runtime.AppUser;
import com.itouch.application.fda.foundation.util.GlobalUtil;
import com.itouch.application.fda.foundation.util.ParamUtil;

/**
 * @author qiuy
 * 信用评定
 */
public class CreditRatingManager {
	
	private IAppBusinessManagerMapper mappers;
	private AppUser user;
	private IVEntBasicManager ventBasicManager;
	private ICreditCriterionManager criterionManager;
	private ICreditRankManager rankManager;
	private ICreditConditionManager conditionManager;
	private ICreditConditionDetailManager conditionDetailManager;
	private ICreditEntRankManager entRankManager;
	
	private List<IOperators> _operatorList = new ArrayList<IOperators>();
	private List<ICalculator> _calculatorList = new ArrayList<ICalculator>();
	
	public CreditRatingManager(IAppBusinessManagerMapper mappers, AppUser user) {
		this.mappers = mappers;
		this.user = user;
		ventBasicManager = mappers.getMapper(IVEntBasicManager.class);
		criterionManager = mappers.getMapper(ICreditCriterionManager.class);
		rankManager = mappers.getMapper(ICreditRankManager.class);
		conditionManager = mappers.getMapper(ICreditConditionManager.class);
		conditionDetailManager = mappers.getMapper(ICreditConditionDetailManager.class);
		entRankManager = mappers.getMapper(ICreditEntRankManager.class);
		
		_operatorList.add(new LogicalOperators());
		_operatorList.add(new RelationalOperators());
		
		_calculatorList.add(new NumberCalculator());
		_calculatorList.add(new ResultCalculator());
	}
	
	/**
	 * 全部评定
	 * @param criterionId
	 * @param creditYear
	 * @param vEntBasic
	 * @throws Exception
	 */
	public String AllRating(String criterionId, String creditYear, VEntBasic vEntBasic) throws Exception {
		
		//获取企业
		List<VEntBasic> entList = ventBasicManager.getEntList(vEntBasic);
		int entCount = entList.size();
		
		//进行信用评定
		List<CreditEntRankInfo> resultList = StartAllRating(criterionId, creditYear, entList);
		
		//进行年度影响
		
		//添加到信用记录
		AddEntRank(creditYear, resultList);
		
		return "对" + entCount + "家企业进行信用评定，共评出了" + resultList.size() + "家企业";
	}
	
	/**
	 * 进行信用评定
	 * @param criterionId
	 * @param creditYear
	 * @param entList
	 * @return
	 * @throws Exception
	 */
	private List<CreditEntRankInfo> StartAllRating(String criterionId, String creditYear, List<VEntBasic> entList) throws Exception {
		
		CreditCriterionInfo criterionInfo = criterionManager.getEntity(criterionId);
		List<CreditEntRankInfo> resultList = new ArrayList<CreditEntRankInfo>();
		
		//获得评定等级
		List<CreditRankInfo> rankList = rankManager.getEnListByCriterionId(criterionId);		
		for (CreditRankInfo rankInfo : rankList) {
			
			//获得后缀表达式集合
			LinkedList<ExpressionInfo> postfixExpressionQueue = GetPostfixExpressionQueue(rankInfo.getRankId());
			
			for(int i = entList.size() - 1; i >= 0; i--) {
				if(postfixExpressionQueue.size() > 0) {
					
					//得到评定结果
					ExpressionInfo resultExpressionInfo = GetRatingResult(postfixExpressionQueue, creditYear, entList.get(i));
					
					//如果匹配等级
					if(resultExpressionInfo.getContent() != null && resultExpressionInfo.getContent().equals("true")) {
						
						//添加到信用记录
						CreditEntRankInfo entRankInfo = new CreditEntRankInfo(entList.get(i));
						entRankInfo.setCreditTime(new Date());
						if(user != null) {
							entRankInfo.setCreditUnitId(user.getUnitId());
							entRankInfo.setCreditUnitName(user.getUnitName());
							entRankInfo.setCreditUserId(user.getUserId());
							entRankInfo.setCreditUserName(user.getUserName());
						}
						entRankInfo.setCreditValue(rankInfo.getRankName());
						entRankInfo.setCreditYear(Integer.parseInt(creditYear));
						entRankInfo.setCriterionId(criterionId);
						entRankInfo.setCriterionName(criterionInfo.getCriterionName());
						entRankInfo.setRemark(resultExpressionInfo.getRemark());
						resultList.add(entRankInfo);
						
						//移除这家企业
						entList.remove(i);
					}
				}
			}
		}
		return resultList;
	}
	
	/**
	 * 获得信用评定结果
	 * @param postfixExpressionQueue
	 * @param creditYear
	 * @param vEntBasic
	 * @return
	 * @throws Exception
	 */
	private ExpressionInfo GetRatingResult(LinkedList<ExpressionInfo> postfixExpressionQueue, String creditYear, VEntBasic vEntBasic) throws Exception {
		
		Stack<ExpressionInfo> operandStack = new Stack<ExpressionInfo>();
		for(int i = 0; i < postfixExpressionQueue.size(); i++) {
			ExpressionInfo s = postfixExpressionQueue.get(i).getClone();
			if(ParamUtil.isNumeric(s.getContent()) || GlobalUtil.isUUID(s.getContent())) {
				operandStack.push(s);
			}
			else {
				ExpressionInfo expInfo1;
                ExpressionInfo expInfo2;
                if (operandStack.size() > 1)
                {
                    expInfo1 = operandStack.pop();
                    expInfo2 = operandStack.pop();
                }
                else
                {
                    //小于2个退出循环。
                    break;
                }

                for(ICalculator oper : _calculatorList)
                {
                    if (oper.IsTheCalculator(expInfo1.getVerdictType()))
                    {
                        oper.Calculate(creditYear, vEntBasic, expInfo1, mappers);
                        break;
                    }

                    if (oper.IsTheCalculator(expInfo2.getVerdictType()))
                    {
                        oper.Calculate(creditYear, vEntBasic, expInfo2, mappers);
                        break;
                    }
                }

                //计算值
                for(IOperators oper : _operatorList)
                {
                    if (oper.IsTheOperator(s.getContent()))
                    {
                        ExpressionInfo result = oper.Calculate(expInfo2, expInfo1, s.getContent());
                        if (expInfo2.getResult().equals(EnumRatingResults.Pass) || expInfo2.getResult().equals(EnumRatingResults.NoPass)) {
                            result.setRemark(expInfo2.getRemark() + s.getContent() + expInfo1.getRemark());
                        }
                        operandStack.push(result);
                        break;
                    }
                }
			}
		}
		if (operandStack.size() > 0) {
            return operandStack.pop();
		}
		ExpressionInfo resultExpressionInfo = new ExpressionInfo();
		resultExpressionInfo.setContent("false");
		resultExpressionInfo.setRemark("无");
        return resultExpressionInfo;
	}
	
	/**
	 * 获得后缀表达式列表
	 * @param rankId
	 * @return
	 * @throws Exception
	 */
	private LinkedList<ExpressionInfo> GetPostfixExpressionQueue(String rankId) throws Exception {
		
		//获取条件集合
		List<CreditConditionInfo> conditionList = conditionManager.getEnListByRankId(rankId);
		List<ExpressionInfo> expressionList = new ArrayList<ExpressionInfo>();
		
		//组合表达式
		for (int i = 0; i < conditionList.size(); i++) {
			
			if(i > 0) {
				//增加条件组的连接词
				expressionList.add(GetExpressionInfo(EnumVerdictType.None, "&&", "并且"));
			}
			
			//条件组之间用括号分隔
			expressionList.add(GetExpressionInfo(EnumVerdictType.None, "(", "("));
			
			//构建条件组
			BuildDetailExpression(expressionList, conditionList.get(i));
			
			//条件组之间用括号分隔
			expressionList.add(GetExpressionInfo(EnumVerdictType.None, ")", ")"));
		}
		
		//转换为后缀表达式返回
		return ExpressionConverter.ToPostfix(expressionList);
	}
	
	/**
	 * 构建条件组
	 * @param expressionList
	 * @param conditionList
	 * @throws Exception
	 */
	private void BuildDetailExpression(List<ExpressionInfo> expressionList, CreditConditionInfo conditionInfo) throws Exception {
		
		//获取条件细项集合
		List<CreditConditionDetailInfo> conditionDetailList = conditionDetailManager.getEnListByConditionId(conditionInfo.getConditionId());
		for (CreditConditionDetailInfo conditionDetailInfo : conditionDetailList) {
			
			if(!StringUtils.isEmpty(conditionDetailInfo.getParenthesis())) {
				//加入括号
				expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getParenthesis(), conditionDetailInfo.getParenthesis()));
			}
			
			if(conditionDetailInfo.getVerdictTypeId() != null && !conditionDetailInfo.getVerdictTypeId().equals(EnumVerdictType.None.getValue())) {
				
				//次数条件组
				if(conditionDetailInfo.getVerdictTypeId().equals(EnumVerdictType.Number.getValue())) {
					//加入监管结论
					expressionList.add(GetExpressionInfo(EnumVerdictType.Number, conditionDetailInfo.getCheckVerdictId(), conditionDetailInfo.getCheckTypeId(), conditionDetailInfo.getCheckVerdictName()));
					//加入关系运算符
					expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getRelationalOperator(), conditionDetailInfo.getRelationalOperator()));
					//加入次数
					expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getVerdictValue().toString(), conditionDetailInfo.getVerdictValue().toString()));
				}
				
				//结果条件组
				else if(conditionDetailInfo.getVerdictTypeId().equals(EnumVerdictType.Result.getValue())) {
					//加入监管类型
					expressionList.add(GetExpressionInfo(EnumVerdictType.Result, conditionDetailInfo.getCheckTypeId(), conditionDetailInfo.getCheckTypeName()));
					//加入关系运算符
					expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getRelationalOperator(), conditionDetailInfo.getRelationalOperator()));
					//加入监管结论
					expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getCheckVerdictId(), conditionDetailInfo.getCheckVerdictName()));
				}
				
				//其他条件组（平均得分、平均得分×系数、总得分率、大项得分率）
				else {
					//加入监管类型
					ExpressionInfo expressionInfo = GetExpressionInfo(EnumVerdictType.None.getEnum(conditionDetailInfo.getVerdictTypeId()), conditionDetailInfo.getCheckTypeId(), conditionDetailInfo.getCheckTypeName());
					/*//如果是平均得分×系数条件组，需要加入系数
					if(conditionDetailInfo.getVerdictTypeId().equals(EnumVerdictType.Coefficient.getValue())) {
						expressionInfo.setCoefficient(conditionDetailInfo.getCoefficient());
					}*/
					expressionList.add(expressionInfo);
					//加入关系运算符
					expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getRelationalOperator(), conditionDetailInfo.getRelationalOperator()));
					//加入分值
					expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getVerdictValue().toString(), conditionDetailInfo.getVerdictValue().toString()));
				}
				
			}
			
			if(!StringUtils.isEmpty(conditionDetailInfo.getLogicalOperator())) {
				//加入逻辑运算符
				expressionList.add(GetExpressionInfo(EnumVerdictType.None, conditionDetailInfo.getLogicalOperator(), RatingCommonHelper.GetLogicalOperatorName(conditionDetailInfo.getLogicalOperator())));
			}
		}
	}
	
	/**
	 * 组合表达式信息
	 * @param type
	 * @param content
	 * @param remark
	 * @return
	 * @throws Exception
	 */
	private ExpressionInfo GetExpressionInfo(EnumVerdictType verdictType, String content, String remark) throws Exception {
		ExpressionInfo expressionInfo = new ExpressionInfo();
		expressionInfo.setVerdictType(verdictType);
		expressionInfo.setContent(content);
		expressionInfo.setRemark(remark);
		return expressionInfo;
	}
	
	/**
	 * 组合表达式信息
	 * @param type
	 * @param content
	 * @param contentSupply
	 * @param remark
	 * @return
	 * @throws Exception
	 */
	private ExpressionInfo GetExpressionInfo(EnumVerdictType verdictType, String content, String contentSupply, String remark) throws Exception {
		ExpressionInfo expressionInfo = GetExpressionInfo(verdictType, content, remark);
		expressionInfo.setContentSupply(contentSupply);
		return expressionInfo;
	}
	
	/**
	 * 添加信用记录
	 * @param creditYear
	 * @param entRankList
	 * @throws Exception
	 */
	private void AddEntRank(String creditYear, List<CreditEntRankInfo> entRankList) throws Exception {
		for (CreditEntRankInfo entRankInfo : entRankList) {
			//如果存在记录就更新，不存在就新增
			String entRankKey = entRankManager.getKeyByYearEnt(creditYear, entRankInfo.getEntCode(), entRankInfo.getEntTypeGroupId());
			if(!StringUtils.isEmpty(entRankKey)) {
				entRankInfo.setCreditId(entRankKey);
			}
			entRankManager.addOrUpdate(entRankInfo);
		}
	}
}
