/**  
 * @Description: TODO
 * @Title: ICreditAnnualManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.annual 
 * @author: wangk
 * @date 2016-2-24 下午5:03:44 
 */ 
package com.itouch.application.fda.biz.bll.dailycheck.credit.annual;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.CreditAnnualInfo;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood.CreditHfoodProdPreviewInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: ICreditAnnualManager 
 * @author wangk
 * @date 2016-2-24 下午5:03:44  
 */
public interface ICreditAnnualManager extends IAppBusinessManager{

	/**
	 * @Description: 新增
	 * @Title: add
	 * @return Object    返回类型 
	 * @author wangk
	 * @date 2016-2-24 下午5:05:44 
	 * @throws 
	 */ 
	public Object add(CreditAnnualInfo creditAnnualInfo);
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditAnnualInfo> list) ;
	
	/**
	 * 更新
	 * @param CheckEntInfo 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CreditAnnualInfo creditAnnualInfo)  ;
	
	/**
	 * 批量更新或保存
	 * @param CheckEntInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CreditAnnualInfo> creditAnnualList)  ;
	/**
	 * 新增/修改
	 * @param CheckEntInfo 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CreditAnnualInfo creditAnnualInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String creditId)  ;
	
	/**
	 * 删除
	 * @param CheckEntInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CreditAnnualInfo creditAnnualInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public CreditAnnualInfo getEntity(String creditId) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<CreditAnnualInfo> getList() ;
	
	/**
	 * 根据条件获取列表
	 * @return 受理类型列表
	 */
	public List<CreditAnnualInfo> getListBy(CreditAnnualInfo creditAnnualInfo) ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<CreditAnnualInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, CreditAnnualInfo creditAnnualInfo, Map<String, Object> map) ;
	
	
	/**
	 * 获取分页列表（上报）
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListReportByPage(int pageSize, int pageIndex, CreditAnnualInfo creditAnnualInfo, Map<String, Object> map) ;
	
	/**
	 * 根据条件获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet findListBySearch(int pageSize, int pageIndex,CreditAnnualInfo creditAnnualInfo,Integer flag);
	
	/**
	 * 修改归并状态
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public void setChecked(String id);

	/**
	 * 修改检查状态
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public void setArchiveState(String ids);

	/**
	 * 获取保健食品生产列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getHfoodList(int pageSize, int pageIndex,CreditHfoodProdPreviewInfo creditHfoodProdForm,String entTypeId,String entTypeGroupId,String creditStateId,Integer year);

	/**
	 * 统计首页数据
	 * @param orgIds 当前用户机构ID下属ID集合；CreditAnnualStates：状态(初评、首评)
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public List<CreditAnnualInfo> calIndexCreditCount(String orgIds,String CreditAnnualStates);
}
