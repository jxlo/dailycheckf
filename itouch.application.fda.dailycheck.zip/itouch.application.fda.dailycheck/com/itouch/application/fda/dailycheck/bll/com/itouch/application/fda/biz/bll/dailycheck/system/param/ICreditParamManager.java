/**  
  * @Description: TODO
  * @Title: ICreditParamManager.java 
  * @Package: com.itouch.application.fda.biz.bll.dailycheck.system.param 
  * @author: xh
  * @date 2016-2-19 下午2:36:49 
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.system.param;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.system.param.CreditParamInfo;

/** 
 * @Description: 信用评级
 * @ClassName: ICreditParamManager 
 * @author xh
 * @date 2016-2-19 下午2:36:49  
 */
public interface ICreditParamManager extends IAppBusinessManager{
	/**
	 * 获取列表 (不要分页)
	 * @author xh
	 * */
	public List<CreditParamInfo> getList();	
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, String entTypeGroupId) ;


	/**
	 * 删除
	 * @author xh
	 * */
	public boolean delete(String id);

	/**
	 * 新增/修改
	 * @author xh
	 */
	public void addOrUpdate(CreditParamInfo creditParamInfo) ;

	/**
	 * 新增/修改 跳转
	 * @author xh
	 */
	public CreditParamInfo getEntity(String id);
	
	/**
	  * @Description: 根据条件获取列表 
	  * @Title: getList 
	  * @author wangk
	  * @date 2016-2-25 下午2:15:19 
	  * @throws 
	  */ 
	public List<CreditParamInfo> getListBy(String entTypeGroupId,String creditTypeId);
	
}
