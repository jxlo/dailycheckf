package com.itouch.application.fda.biz.bll.dailycheck.system.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.report.IReportFormManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.report.IReportFormDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.report.ReportFormInfo;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: ReportFromManager
 * @author: wangk
 * @date: 2016-3-16 下午2:07:34
 */
@Service("reportFromManager")
public class ReportFormManager extends AppBusinessManager implements
		IReportFormManager {

	Logger logger = LoggerFactory.getLogger(ReportFormManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: 新增
	 * @Title: add
	 * @author: wangk
	 * @date: 2016-3-16 下午2:08:13
	 * @throws
	 */
	@Override
	public Object add(ReportFormInfo ReportFormInfo) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			dao.add(ReportFormInfo);
			return ReportFormInfo.getFormId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 新增
	 * @param list
	 *            实体集合
	 * @Title: add
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean add(List<ReportFormInfo> list) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 更新
	 * @Title: update
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean update(ReportFormInfo ReportFormInfo) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			dao.update(ReportFormInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 批量更新
	 * @Title: save
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean save(List<ReportFormInfo> reportFromList) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			dao.save(reportFromList);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 新增/修改
	 * @Title: addOrUpdate
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object addOrUpdate(ReportFormInfo ReportFormInfo) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			dao.save(ReportFormInfo);
			return ReportFormInfo.getFormId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(String id) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(ReportFormInfo ReportFormInfo) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			dao.delete(ReportFormInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @Title: getEntity
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public ReportFormInfo getEntity(String id) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据表单编号获取实体
	 * 
	 * @param formCode
	 *            表单编码
	 * @return 实体
	 */
	@Override
	public ReportFormInfo getEntityByFormCode(String formCode) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			String hql = String.format(" from ReportFormInfo t WHERE  t.formCode='%s'",
					formCode);
			return dao.uniqueResultByCommand(hql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取列表
	 * @Title: getList
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<ReportFormInfo> getList() {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据map参数获取列表
	 * @Title: getList
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<ReportFormInfo> getList(Map<String, Object> map) {
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取分页列表
	 * @Title: getListByPage
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			ReportFormInfo reportFrom) {
		PageResultSet pageResultSet = new PageResultSet();
		
		List<ReportFormInfo> list = new ArrayList<ReportFormInfo>();
		
		try {
			IReportFormDao dao = this.getMapper(IReportFormDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);
			
			String hql = " select t from ReportFormInfo t where 1=1 ";
			
			if(reportFrom != null){
				if(StringUtil.isNotEmpty(reportFrom.getFormCode())){
					hql += " and t.formCode like '%"+reportFrom.getFormCode()+"%'";
				}
				if(StringUtil.isNotEmpty(reportFrom.getFormName())){
					hql += " and t.formName like '%"+reportFrom.getFormName()+"%'";
				}
			}
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

}
