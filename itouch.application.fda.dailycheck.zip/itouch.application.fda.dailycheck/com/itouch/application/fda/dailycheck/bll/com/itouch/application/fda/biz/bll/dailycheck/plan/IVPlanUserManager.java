/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:IVPlanUserManager.java
 * @author:fanghailong
 * @time:2015-10-28 下午5:00:25
 */
package com.itouch.application.fda.biz.bll.dailycheck.plan;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.plan.VPlanUserInfo;

/**
 * @author:fanghailong 
 */
public interface IVPlanUserManager extends IAppBusinessManager{
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public VPlanUserInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<VPlanUserInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<VPlanUserInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getVPlanUserInfoList(int pageSize, int pageIndex, VPlanUserInfo vPlanUserInfo) ;
	
}
