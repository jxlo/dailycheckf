/**  
* @Title: ICheckManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.check 
* @author wangk    
* @date 2015-10-20 下午4:11:13  
*/
package com.itouch.application.fda.biz.bll.dailycheck.check;

import iTouch.framework.data.operation.IAppBusinessManager;

import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo2;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-20 下午4:11:13  
 */
public interface ICheckManager2 extends IAppBusinessManager {

	/**
	 * @Description:新增/修改
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-20 下午4:21:02
	 */
	public Object add(CheckInfo2 checkInfo);
}
