/**     
  * @Title: VTaskUnitCheckManager.java   
  * @Package com.itouch.application.fda.biz.dao.dailycheck.task.hibernate   
  * @Description: TODO(用一句话描述该文件做什么)   
  * @author wangk    
  * @date 2015-11-4 下午5:48:23     
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.task.ipml;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.bll.dailycheck.task.IVTaskUnitCheckManager;
import com.itouch.application.fda.biz.dao.dailycheck.task.IVTaskUnitCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.VTaskUnitCheckInfo;

/**   
 * @ClassName: VTaskUnitCheckManager   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-4 下午5:48:23      
 */
@Service("dcVTaskUnitCheckManager")
public class VTaskUnitCheckManager extends AppBusinessManager implements IVTaskUnitCheckManager {

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @date 2015-11-4 下午5:48:23  
	 */
	@Override
	public PageResultSet findListBySearch(int number, int pageIndex,String unitTaskId,String param) throws Throwable {
		IVTaskUnitCheckDao dao;
		PageResultSet pageResultSet = new PageResultSet();
		List<VTaskUnitCheckInfo> list = new ArrayList<VTaskUnitCheckInfo>();
		
		try {
			dao = this.getMapper(IVTaskUnitCheckDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);
			
/*			//日常检查
			String dailyCheck = EnumCheckTypes.DailyCheck.getValue();
			//专项检查
			String taskCheck = EnumCheckTypes.TaskCheck.getValue();
			//许可检查
			String accCheck = EnumCheckTypes.AccCheck.getValue();				
			//飞行检查
			String flightCheck = EnumCheckTypes.FlightCheck.getValue();
			//监督抽查
			String sampleCheck = EnumCheckTypes.SampleCheck.getValue();
			//其他
			String others = EnumCheckTypes.Others.getValue();*/
			
			String hql = " select t from VTaskUnitCheckInfo t where 1=1";
			
			if(unitTaskId != null && !"".equals(unitTaskId)){
				hql +=" and t.unitTaskId = '"+unitTaskId+"'";
			}
			/*if("DailyCheck".equals(param)){
				hql += " and t.checkTypeId = '"+dailyCheck+"'";
			}else if("TaskCheck".equals(param)){
				hql += " and t.checkTypeId = '"+taskCheck+"'";
			}else if("Others".equals(param)){
				hql += " and (t.checkTypeId = '"+accCheck+"' or t.checkTypeId = '"+sampleCheck+"' or t.checkTypeId = '"+others+"') ";
			}else if("FlightCheck".equals(param)){
				hql += " and t.checkTypeId = '"+flightCheck+"'";
			}*/
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: TODO(这里用一句话描述这个方法的作用)  
	  * @Title: getList 
	  * @author wangk
	  * @date 2015-12-3 下午1:48:00 
	  * @throws 
	  */ 
	@Override
	public List<VTaskUnitCheckInfo> getList(String unitTaskId) {
		IVTaskUnitCheckDao dao;
		List<VTaskUnitCheckInfo> list = new ArrayList<VTaskUnitCheckInfo>();
		try {
			dao = this.getMapper(IVTaskUnitCheckDao.class);
			
			String hql = " select t from VTaskUnitCheckInfo t where 1=1";
			
			if(unitTaskId != null && !"".equals(unitTaskId)){
				hql +=" and t.unitTaskId = '"+unitTaskId+"'";
			}
		
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

}
