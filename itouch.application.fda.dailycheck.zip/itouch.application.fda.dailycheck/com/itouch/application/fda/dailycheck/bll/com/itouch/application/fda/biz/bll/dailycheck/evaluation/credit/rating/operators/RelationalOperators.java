package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.operators;

import com.itouch.application.fda.biz.dailycheck.enums.EnumRatingResults;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;

/**
 * @author qiuy
 * 关系运算符
 */
public class RelationalOperators implements IOperators {

	/**
	 * 是否为本操作符
	 * @param input
	 * @return
	 */
	@Override
	public boolean IsTheOperator(String input) {
		return input.equals("==") || input.equals(">") || input.equals(">=") || input.equals("<") || input.equals("<=");
	}

	/**
	 * 计算结果
	 * @param operand1 操作数1
	 * @param operand2 操作数2
	 * @param operator 操作符
	 * @return
	 */
	@Override
	public ExpressionInfo Calculate(ExpressionInfo operand1, ExpressionInfo operand2, String operator) {
		
		ExpressionInfo resultExpressionInfo = new ExpressionInfo();
		resultExpressionInfo.setContent("false");
		
		boolean result = false;
		
		switch (operator) {
			case "==":
				result = Integer.parseInt(operand1.getContent()) == Integer.parseInt(operand2.getContent());
				break;
			case ">":
				result = Integer.parseInt(operand1.getContent()) > Integer.parseInt(operand2.getContent());
				break;
			case ">=":
				result = Integer.parseInt(operand1.getContent()) >= Integer.parseInt(operand2.getContent());
				break;
			case "<":
				result = Integer.parseInt(operand1.getContent()) < Integer.parseInt(operand2.getContent());
				break;
			case "<=":
				result = Integer.parseInt(operand1.getContent()) <= Integer.parseInt(operand2.getContent());
				break;
		}
		
		//设置操作数1的评定结果
		if(result) {
			operand1.setResult(EnumRatingResults.Pass);
		} else {
			operand1.setResult(EnumRatingResults.NoPass);
		}
		
		//设置表达式的结果并返回
		resultExpressionInfo.setContent(Boolean.toString(result));
		return resultExpressionInfo;
	}
	
	
}
