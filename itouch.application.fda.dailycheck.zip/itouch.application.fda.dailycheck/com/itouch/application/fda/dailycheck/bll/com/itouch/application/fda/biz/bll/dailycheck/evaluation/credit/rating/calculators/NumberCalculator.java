package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.calculators;

import iTouch.framework.application.manager.IAppBusinessManagerMapper;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.itouch.application.ent.entity.basic.VEntBasic;
import com.itouch.application.fda.biz.bll.dailycheck.check.ICheckManager;
import com.itouch.application.fda.biz.dailycheck.enums.EnumRatingResults;
import com.itouch.application.fda.biz.dailycheck.enums.EnumVerdictType;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;

/**
 * @author qiuy
 * 次数计算类
 */
public class NumberCalculator implements ICalculator {

	/**
	 * 检查结论次数
	 */
	Map<String, String> checkVerdictCountMap = new HashMap<String, String>();
	
	/**
	 * 是否为本计算类
	 * @param verdictType
	 * @return
	 */
	@Override
	public boolean IsTheCalculator(EnumVerdictType verdictType) {
		return EnumVerdictType.Number.equals(verdictType);
	}

	/**
	 * 计算指定企业的值
	 * @param year
	 * @param vEntBasic
	 * @param expInfo
	 */
	@Override
	public void Calculate(String year, VEntBasic vEntBasic, ExpressionInfo expInfo, IAppBusinessManagerMapper mapper) {
		
		ICheckManager checkManager = mapper.getMapper(ICheckManager.class);
		
		String key = year + "-" + vEntBasic.getEntCode() + "-" + vEntBasic.getEntTypeGroupId() + "-" + expInfo.getContent() + "-" + expInfo.getContentSupply();
		String count;
		
		//如果已经查询过
		if(checkVerdictCountMap.containsKey(key)) {
			count = checkVerdictCountMap.get(key);
		}
		
		//如果没有查询过
		else {
			count = checkManager.getCheckVerdictCount(year, vEntBasic.getEntCode(), vEntBasic.getEntTypeGroupId(), expInfo.getContent(), expInfo.getContentSupply());
			checkVerdictCountMap.put(key, count);
		}
		
		if(!StringUtils.isEmpty(count)) {
			expInfo.setContent(count);
		} else {
			expInfo.setContent("0");
			expInfo.setResult(EnumRatingResults.NoData);
		}
	}
}
