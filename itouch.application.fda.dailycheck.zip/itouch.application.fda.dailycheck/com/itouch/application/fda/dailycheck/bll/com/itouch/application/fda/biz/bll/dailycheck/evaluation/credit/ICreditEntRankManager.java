package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.CreditEntRankInfo;

/**
 * @author qiuy
 * 企业年度信用评级接口
 */
public interface ICreditEntRankManager extends IAppBusinessManager {
	
	/**
	 * 新增
	 * @param 受理类型实体
	 * @return 实体id
	 */
	public Object add(CreditEntRankInfo info) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditEntRankInfo> list) ;
	
	/**
	 * 更新
	 * @param 受理类型实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CreditEntRankInfo info)  ;
	
	/**
	 * 新增/修改
	 * @param 受理类型实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CreditEntRankInfo info) ;
	
	/**
	 * 删除
	 * @param Id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String Id)  ;
	
	/**
	 * 删除
	 * @param 实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CreditEntRankInfo info) ;
	
	/**
	 * 获取实体
	 * @param Id  主键Id
	 * @return 实体
	 */
	public CreditEntRankInfo getEntity(String Id) ;
	
	/**
	 * 根据年份、企业获取主键
	 * @param year
	 * @param entCode
	 * @param entTypeGroupId
	 * @return
	 */
	public String getKeyByYearEnt(String year, String entCode, String entTypeGroupId);
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<CreditEntRankInfo> getList() ;
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<CreditEntRankInfo> getList(Map<String,Object> map);

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map);
	
	/**
	 * 获得企业评定记录列表
	 * @param vEntBasic
	 * @return
	 */
	public List<CreditEntRankInfo> getEntRankList(CreditEntRankInfo creditEntRankInfo);
	
	/**
	 * 获得企业评定记录列表分页
	 * @param pageSize
	 * @param pageIndex
	 * @param creditEntRankInfo
	 * @return
	 */
	public PageResultSet getEntRankListPage(int pageSize, int pageIndex, CreditEntRankInfo creditEntRankInfo);
	
	/**
	 * 更新企业信用
	 * @param list
	 */
	public void AllUpdateCredit(List<CreditEntRankInfo> list);
}
