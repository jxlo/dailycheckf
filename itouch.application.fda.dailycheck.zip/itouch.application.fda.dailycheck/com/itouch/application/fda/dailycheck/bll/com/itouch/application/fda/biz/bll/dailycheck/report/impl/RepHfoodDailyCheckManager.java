/**  
  * @Description: TODO
  * @Title: RepHfoodDailyCheckManager.java 
  * @Package: com.itouch.application.fda.biz.bll.dailycheck.report.impl 
  * @author: xh
  * @date 2016-3-16 下午1:44:43 
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepHfoodDailyCheckManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepCosmDailyCheckDao;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepHfoodDailyCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepHfoodDailyCheckInfo;
import com.itouch.application.fda.foundation.util.StringUtil;

/** 
 * @Description: TODO
 * @ClassName: RepHfoodDailyCheckManager 
 * @author xh
 * @date 2016-3-16 下午1:44:43  
 */
@Service("repHfoodDailyCheckManager")
public class RepHfoodDailyCheckManager extends AppBusinessManager implements IRepHfoodDailyCheckManager {
	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}
	
	/**
	  * @Description: 新增
	  * @Title: add 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object add(RepHfoodDailyCheckInfo repHfoodDailyCheckInfo) {
		try{
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			dao.add(repHfoodDailyCheckInfo);
			return repHfoodDailyCheckInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 新增  
	  * @param list 实体集合
	  * @Title: add 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean add(List<RepHfoodDailyCheckInfo> list) {
		try{
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 更新 
	  * @Title: update 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean update(RepHfoodDailyCheckInfo repHfoodDailyCheckInfo) {
		try{
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			dao.update(repHfoodDailyCheckInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 批量更新 
	  * @Title: save 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean save(List<RepHfoodDailyCheckInfo> repHfoodDailyCheckInfo) {
		try{
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			dao.save(repHfoodDailyCheckInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 新增/修改
	  * @Title: addOrUpdate 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object addOrUpdate(RepHfoodDailyCheckInfo repHfoodDailyCheckInfo) {
		try{
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			dao.save(repHfoodDailyCheckInfo);
			return repHfoodDailyCheckInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 删除  
	  * @Title: delete 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(String id) {
		try{
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}
	
	/**
	 * 删除
	 * @param reportId  
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByReportId(String reportId){
		try{
			IRepCosmDailyCheckDao dao = this.getMapper(IRepCosmDailyCheckDao.class);
			String sql=" delete RepHfoodDailyCheckInfo t where t.reportId='"+reportId+"'";
			dao.executeByCommand(sql, null);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description:  删除 
	  * @Title: delete 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(RepHfoodDailyCheckInfo repHfoodDailyCheckInfo) {
		try{
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			dao.delete(repHfoodDailyCheckInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description: 获取实体
	  * @Title: getEntity 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public RepHfoodDailyCheckInfo getEntity(String id) {
		try {
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			RepHfoodDailyCheckInfo info=dao.getEntity(id);
			return info;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 获取列表
	  * @Title: getList 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<RepHfoodDailyCheckInfo> getList() {
		try {
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 根据map参数获取列表 
	  * @Title: getList 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<RepHfoodDailyCheckInfo> getList(Map<String, Object> map) {
		List<RepHfoodDailyCheckInfo> list = new ArrayList<RepHfoodDailyCheckInfo>();
		try {
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			
			list=dao.findAnd(null, map);
			
			return list;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}


	/**
	 * @see com.itouch.application.fda.biz.bll.dailycheck.report.IRepHfoodDailyCheckManager#getListByReportIds(java.lang.String)
	 * @Description:TODO
	 * @param reportIds
	 * @return
	 * @author:zhangzt
	 * @time:2016年3月20日 下午3:07:22
	 */
	@Override
	public List<RepHfoodDailyCheckInfo> getListByReportIds(String reportIds){
		
		List<RepHfoodDailyCheckInfo> list = new ArrayList<RepHfoodDailyCheckInfo>();
		
		try {
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			
			String hql ="select t from RepHfoodDailyCheckInfo t where 1=1 ";
			
			if(StringUtil.isNotEmpty(reportIds)){
				hql += " and t.reportId in("+reportIds+")";
			}
			
			list=dao.find(hql,null,null);
			
			return list;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description: 根据条件获取列表  
	 * @Title: getListBy 
	 * @param reportId
	 * @return List<RepHfoodDailyCheckInfo> 返回类型 
	 * @author: wangk
	 * @date: 2016-3-17 下午4:13:51 
	 * @throws 
	 */ 
	public List<RepHfoodDailyCheckInfo> getListByReportId(String reportId){
		
		List<RepHfoodDailyCheckInfo> list = new ArrayList<RepHfoodDailyCheckInfo>();
		
		try {
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			
			String hql ="select t from RepHfoodDailyCheckInfo t where 1=1 ";
			
			if(StringUtil.isNotEmpty(reportId)){
				hql += " and t.reportId ='"+reportId+"'";
			}
			
			list=dao.find(hql,null,null);
			
			return list;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	  * @Description: 获取分页列表 
	  * @Title: getListByPage 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			IRepHfoodDailyCheckDao dao = this.getMapper(IRepHfoodDailyCheckDao.class);
			pageResultSet = bizCommonManager.datagrid(IRepHfoodDailyCheckDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
}
