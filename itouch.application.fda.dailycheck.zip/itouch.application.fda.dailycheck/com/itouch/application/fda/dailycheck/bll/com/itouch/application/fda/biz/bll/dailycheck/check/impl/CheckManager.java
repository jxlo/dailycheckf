/**  
* @Title: CheckManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.check.impl 
* @author wangk    
* @date 2015-10-20 下午4:27:23  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.ICheckManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.dailycheck.enums.EnumCheckTypes;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckDao;
import com.itouch.application.fda.biz.dao.dailycheck.plan.IPlanUserDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanUserInfo;
import com.itouch.application.fda.foundation.runtime.AppRuntime;
import com.itouch.application.fda.foundation.runtime.AppUser;
import com.itouch.application.fda.foundation.util.ParamUtil;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-20 下午4:27:23  
 */
@Service("CheckManager2")
@Transactional
public class CheckManager extends AppBusinessManager implements ICheckManager{

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:新增/修改
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-20 下午4:21:02
	 */
	public Object add(CheckInfo checkInfo) {
		try {
			ICheckDao dao = this.getMapper(ICheckDao.class);
			dao.add(checkInfo);
			return checkInfo.getCheckId();
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * @Description:新增/修改
	 * @pram：CheckManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-20 下午4:30:09
	 */
	@Override
	public Object addOrUpdate(CheckInfo checkInfo) {
		try {
			ICheckDao dao = this.getMapper(ICheckDao.class);
			dao.save(checkInfo);
			return checkInfo.getCheckId();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @pram：id
	 * @author: wangk
	 * @return: 是否删除成功
	 * @time:2015-10-20 下午4:30:09
	 */
	@Override
	public boolean delete(String id) {
		try {
			ICheckDao dao = this.getMapper(ICheckDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @pram：ICheckManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-20 下午4:30:09
	 */
	@Override
	public boolean delete(CheckInfo checkInfo) {
		try{
			ICheckDao dao = this.getMapper(ICheckDao.class);
			dao.delete(checkInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * @Description: 获取实体
	 * @pram：ICheckManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-20 下午4:30:09
	 */
	@SuppressWarnings("deprecation")
	@Override
	public CheckInfo getEntity(String id) {
		
		try {
			ICheckDao dao = this.getMapper(ICheckDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
		
	}

	/**
	 * @Description: 获取分页列表
	 * @pram：ICheckManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-20 下午4:30:09
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		
		try {
			ICheckDao dao = this.getMapper(ICheckDao.class);
			pageResultSet = bizCommonManager.datagrid(ICheckDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}


	/**
	 * @Description:TODO
	 * @pram：ICheckManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-26 下午7:37:26
	 */
	@Override
	public PageResultSet findListBySearch(int number, int pageIndex,CheckInfo checkInfo,String param,Map<String, Object> map) throws Throwable {
		ICheckDao dao;
		List<CheckInfo> list = new ArrayList<CheckInfo>();
		PageResultSet pageResultSet = new PageResultSet();
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		
		try {
			dao = this.getMapper(ICheckDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);
			
			//日常检查
			String dailyCheck = EnumCheckTypes.DailyCheck.getValue();
			//专项检查
			String taskCheck = EnumCheckTypes.TaskCheck.getValue();
			//许可检查
			String accCheck = EnumCheckTypes.AccCheck.getValue();				
			//飞行检查
			String flightCheck = EnumCheckTypes.FlightCheck.getValue();
			//监督抽查
			String sampleCheck = EnumCheckTypes.SampleCheck.getValue();
			//其他
			String others = EnumCheckTypes.Others.getValue();
			
			String hql ="select t from CheckInfo t  where 1=1 and t.checkEnt.checkId is not null";
			
			if("DailyCheck".equals(param)){
				hql += " and t.checkTypeId = '"+dailyCheck+"'"+" and t.resultVerdictId is not null ";
			}else if("TaskCheck".equals(param)){
				hql += " and t.checkTypeId = '"+taskCheck+"'";
			}else if("Others".equals(param)){
				hql += " and (t.checkTypeId = '"+accCheck+"' or t.checkTypeId = '"+sampleCheck+"' or t.checkTypeId = '"+others+"') ";
			}else if("FlightCheck".equals(param)){
				hql += " and t.checkTypeId = '"+flightCheck+"'"; 
			}
			
			if(null!=checkInfo){
				
				if(StringUtil.isNotEmpty(checkInfo.getUnitId())){
					hql += String.format(" and t.unitId ='%s' ", checkInfo.getUnitId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckTypeId())){
					hql += String.format(" and t.checkTypeId ='%s' ", checkInfo.getCheckTypeId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getResultVerdictId())){
					hql += String.format(" and t.resultVerdictId ='%s' ", checkInfo.getResultVerdictId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckBeginDate())){
					hql += String.format(" and to_char(checkBeginDate,'yyyy-MM-dd') >= '%s'", sdf.format(checkInfo.getCheckBeginDate()));
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckEndDate())){
					hql += String.format(" and to_char(checkEndDate,'yyyy-MM-dd') <= '%s'", sdf.format(checkInfo.getCheckEndDate()));
				}
				
				
				if(null!=checkInfo.getCheckEnt()){
					if(StringUtil.isNotEmpty(checkInfo.getCheckEnt().getEntTypeId())){
						hql += String.format(" and t.checkEnt.entTypeId = '%s'",checkInfo.getCheckEnt().getEntTypeId());
					}
					if(StringUtil.isNotEmpty(checkInfo.getCheckEnt().getEntName())){
						hql += " and t.checkEnt.entName like '%"+checkInfo.getCheckEnt().getEntName().trim()+"%'";
					}
					if(ParamUtil.getInt(checkInfo.getCheckEnt().getIsUnlicensed())>=0){
						hql += String.format(" and t.checkEnt.isUnlicensed='%s'", checkInfo.getCheckEnt().getIsUnlicensed());
					}
				}
			}
			
			
			
			hql+=" order by  t.createTime desc";
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
			
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	public PageResultSet findListBySearchAndflightcheck(int number, int pageIndex, CheckInfo checkInfo, String param, Map<String, Object> map) throws Throwable{
		
		ICheckDao dao;
		List<CheckInfo> list = new ArrayList<CheckInfo>();
		PageResultSet pageResultSet = new PageResultSet();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		
		try {
			dao = this.getMapper(ICheckDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);
			
		 
			String hql ="select t from CheckInfo t  where 1=1 and t.checkEnt.checkId is not null";
		    hql += " and t.checkTypeId = '"+EnumCheckTypes.FlightCheck.getValue()+"'"; 
		 
			if(null!=checkInfo){
				
				if(StringUtil.isNotEmpty(checkInfo.getUnitId())){
					hql += String.format(" and t.unitId ='%s' ", checkInfo.getUnitId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckTypeId())){
					hql += String.format(" and t.checkTypeId ='%s' ", checkInfo.getCheckTypeId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getResultVerdictId())){
					hql += String.format(" and t.resultVerdictId ='%s' ", checkInfo.getResultVerdictId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckBeginDate())){
					hql += String.format(" and to_char(checkBeginDate,'yyyy-MM-dd') >= '%s'", sdf.format(checkInfo.getCheckBeginDate()));
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckEndDate())){
					hql += String.format(" and to_char(checkEndDate,'yyyy-MM-dd') <= '%s'", sdf.format(checkInfo.getCheckEndDate()));
				}
				
				
				if(null!=checkInfo.getCheckEnt()){
					if(StringUtil.isNotEmpty(checkInfo.getCheckEnt().getEntTypeId())){
						hql += String.format(" and t.checkEnt.entTypeId = '%s'",checkInfo.getCheckEnt().getEntTypeId());
					}
					if(StringUtil.isNotEmpty(checkInfo.getCheckEnt().getEntName())){
						hql += " and t.checkEnt.entName like '%"+checkInfo.getCheckEnt().getEntName().trim()+"%'";
					}
					if(ParamUtil.getInt(checkInfo.getCheckEnt().getIsUnlicensed())>=0){
						hql += String.format(" and t.checkEnt.isUnlicensed='%s'", checkInfo.getCheckEnt().getIsUnlicensed());
					}
				}
			}
			
			hql+=" order by  t.createTime desc";
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
			
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:TODO
	 * @pram：ICheckManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-26 下午7:37:26
	 */
	@Override
	public PageResultSet findListBySearch2(int number, int pageIndex,CheckInfo checkInfo,String param,Map<String, Object> map) throws Throwable {
		ICheckDao dao;
		List<CheckInfo> list = new ArrayList<CheckInfo>();
		PageResultSet pageResultSet = new PageResultSet();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		
		try {
			dao = this.getMapper(ICheckDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);
			
			//日常检查
			String dailyCheck = EnumCheckTypes.DailyCheck.getValue();
			//专项检查
			String taskCheck = EnumCheckTypes.TaskCheck.getValue();
			//许可检查
			String accCheck = EnumCheckTypes.AccCheck.getValue();				
			//飞行检查
			String flightCheck = EnumCheckTypes.FlightCheck.getValue();
			//监督抽查
			String sampleCheck = EnumCheckTypes.SampleCheck.getValue();
			//其他
			String others = EnumCheckTypes.Others.getValue();
			
			String hql ="select t from CheckInfo t  where 1=1 and t.checkEnt.checkId is not null";
			
			if("DailyCheck".equals(param)){
				hql += " and t.checkTypeId = '"+dailyCheck+"'"+" and t.resultVerdictId is not null";
			}else if("TaskCheck".equals(param)){
				hql += " and t.checkTypeId = '"+taskCheck+"'";
			}else if("Others".equals(param)){
				hql += " and (t.checkTypeId = '"+accCheck+"' or t.checkTypeId = '"+sampleCheck+"' or t.checkTypeId = '"+others+"') ";
			}else if("FlightCheck".equals(param)){
				hql += " and t.checkTypeId = '"+flightCheck+"'";
			} else {
				hql += " and t.checkTypeId is not null ";
			}
			
			if(null!=checkInfo){
				
				if(StringUtil.isNotEmpty(checkInfo.getUnitId())){
					hql += String.format(" and t.unitId ='%s' ", checkInfo.getUnitId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckTypeId())){
					hql += String.format(" and t.checkTypeId ='%s' ", checkInfo.getCheckTypeId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getResultVerdictId())){
					hql += String.format(" and t.resultVerdictId ='%s' ", checkInfo.getResultVerdictId());
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckBeginDate())){
					hql += String.format(" and to_char(checkBeginDate,'yyyy-MM-dd') >= '%s'", sdf.format(checkInfo.getCheckBeginDate()));
				}
				
				if(StringUtil.isNotEmpty(checkInfo.getCheckEndDate())){
					hql += String.format(" and to_char(checkEndDate,'yyyy-MM-dd') <= '%s'", sdf.format(checkInfo.getCheckEndDate()));
				}
				
				
				if(null!=checkInfo.getCheckEnt()){
					if(StringUtil.isNotEmpty(checkInfo.getCheckEnt().getEntTypeId())){
						hql += " and t.checkEnt.entTypeId like '" + checkInfo.getCheckEnt().getEntTypeId().trim() + "%' ";
					}
					if(StringUtil.isNotEmpty(checkInfo.getCheckEnt().getEntName())){
						hql += " and t.checkEnt.entName like '%"+checkInfo.getCheckEnt().getEntName().trim()+"%'";
					}
					if(ParamUtil.getInt(checkInfo.getCheckEnt().getIsUnlicensed())>=0){
						hql += String.format(" and t.checkEnt.isUnlicensed='%s'", checkInfo.getCheckEnt().getIsUnlicensed());
					}
				}
			}
			
			hql+=" order by  t.createTime desc";
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
			
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}


	/**
	  * @Description: TODO(这里用一句话描述这个方法的作用：酷)  
	  * @Title: getList 
	  * @author wangk
	  * @date 2015-12-1 上午10:34:20 
	  * @throws 
	  */ 
	@Override
	public List<CheckInfo> getList(String tableId) {
		ICheckDao dao;
		List<CheckInfo> list = new ArrayList<CheckInfo>();
		try {
			dao = this.getMapper(ICheckDao.class);
			String hql ="select t from CheckInfo t  where 1=1 ";
			if(tableId != null && !"".equals(tableId)){
				hql +=" and t.tableId = '"+tableId+"'";
			}
			list = dao.find(hql , null , null);
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
			
	}
	
	/**
	 * @Description:根据检查类型统计检查
	 * @return
	 * @author:zhangzt
	 * @time:2016年1月28日 下午7:26:55
	 */
	@Override
	public List<Object[]> countCheckByCheckType(String unitId){
		ICheckDao dao;
		try {
			dao = this.getMapper(ICheckDao.class);
			//根据受理类型统计检查记录数量
			String sql = String.format("select t.check_type_name,count(1) from DC_CHECK t where t.unit_id='%s' group by t.check_type_name ", unitId);
			List<Object[]> list = dao.getListObjectBySql(sql, null);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获得一家企业某年某个监管结论出现的次数
	 * @param year
	 * @param entCode
	 * @param entTypeGroupId
	 * @param checkVerdictId 监管结论编号
	 * @param checkTypeId 监管类型编号
	 * @return
	 */
	public String getCheckVerdictCount(String year, String entCode, String entTypeGroupId, String checkVerdictId, String checkTypeId) {
		try {
			ICheckDao dao = this.getMapper(ICheckDao.class);
			ArrayList<Object> param = new ArrayList<>();
			String sql = " select count(*) n1, count(*) n2 from ";
			sql += " DC_CHECK c inner join DC_CHECK_ENT e on c.CHECK_ID = e.CHECK_ID where ";
			sql += " to_char(c.CREATE_TIME,'yyyy') = ? and ";
			sql += " e.ENT_CODE = ? and ";
			sql += " e.ENT_TYPE_GROUP_ID = ? and ";
			sql += " c.RESULT_VERDICT_ID = ? and ";
			sql += " c.CHECK_TYPE_ID = ? and ";
			sql += " c.IS_TEMP = '0' and c.IS_DELETE = '0' ";
			param.add(year);
			param.add(entCode);
			param.add(entTypeGroupId);
			param.add(checkVerdictId);
			param.add(checkTypeId);
			
			Object[] objects = dao.getObjectBySql(sql, param.toArray());
			if(objects != null && objects.length > 0) {
				if(!StringUtils.isEmpty(objects[0].toString())) {
					return objects[0].toString();
				}
			}
			return "";
		} catch(Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return "";
		}
	}
	
	/**
	 * 获得一家企业某年某个监管类型的最差监管结果
	 * @param year
	 * @param entCode
	 * @param entTypeGroupId
	 * @param checkTypeId 监管类型编号
	 * @return
	 */
	public String getCheckVerdictResult(String year, String entCode, String entTypeGroupId, String checkTypeId) {
		try {
			ICheckDao dao = this.getMapper(ICheckDao.class);
			ArrayList<Object> param = new ArrayList<>();
			String sql = " select c.RESULT_VERDICT_ID, c.CHECK_TYPE_ID from ";
			sql += " DC_CHECK c inner join DC_CHECK_ENT e on c.CHECK_ID = e.CHECK_ID where ";
			sql += " to_char(c.CREATE_TIME,'yyyy') = ? and ";
			sql += " e.ENT_CODE = ? and ";
			sql += " e.ENT_TYPE_GROUP_ID = ? and ";
			sql += " c.CHECK_TYPE_ID = ? and ";
			sql += " c.IS_TEMP = '0' and c.IS_DELETE = '0' ";
			sql += " order by c.RESULT_VERDICT_ID asc ";
			param.add(year);
			param.add(entCode);
			param.add(entTypeGroupId);
			param.add(checkTypeId);
			
			Object[] objects = dao.getObjectBySql(sql, param.toArray());
			if(objects != null && objects.length > 0) {
				if(!StringUtils.isEmpty(objects[0].toString())) {
					return objects[0].toString();
				}
			}
			return "";
		} catch(Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return "";
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.check.ICheckManager#getList(java.util.Map)
	 */
	public List<CheckInfo> getList(Map<String,Object> map){
		ICheckDao dao;
		try {
			dao = this.getMapper(ICheckDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
