package com.itouch.application.fda.biz.bll.dailycheck.credit;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.credit.VCreditToCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: IVCreditToCheckManager 
 * @author: wangk
 * @date: 2016-3-15 上午10:36:40  
 */
public interface IVCreditToCheckManager extends IAppBusinessManager{
	
	/**
	 * 根据条件获取列表
	 */
	public List<VCreditToCheckInfo> getListBy(String entTypeGroupId,String unitId,String entTypeId);
	
	
	/**
	 * 获取待办评级列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getTodoListByPage(int pageSize,int pageIndex,VCreditToCheckInfo vCreditToCheckInfo);
	
	/**
	 * 根据条件获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet findListBySearch(int pageSize,int pageIndex,VCreditToCheckInfo vCreditToCheck,String flag,String param);
}
