/**  
 * @Description: TODO
 * @Title: VCheckDynamicManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.dynamic.impl 
 * @author: wangk
 * @date 2016-2-24 下午5:32:57 
 */ 
package com.itouch.application.fda.biz.bll.dailycheck.credit.dynamic.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.ent.enums.EnumEntTypeGroupGrade;
import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.dynamic.IVCheckDynamicManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.credit.dynamic.IVCheckDynamicDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic.VCheckDynamicInfo;
import com.itouch.application.fda.foundation.util.StringUtil;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: VCheckDynamicManager 
 * @author wangk
 * @date 2016-2-24 下午5:32:57  
 */
@Service("vCheckDynamicManager")
public class VCheckDynamicManager extends AppBusinessManager implements IVCheckDynamicManager{

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}
	
	/**
	  * @Description: 根据条件获取列表  
	  * @Title: getListBy 
	  * @author wangk
	  * @date 2016-3-2 上午10:04:08 
	  * @throws 
	  */ 
	@Override
	public List<VCheckDynamicInfo> getListBy(String entCode,
			String entTypeGroupId) {
		
		List<VCheckDynamicInfo> list = new ArrayList<VCheckDynamicInfo>();
		
		try {
			IVCheckDynamicDao dao = this.getMapper(IVCheckDynamicDao.class);
			
			String hql = "select t from VCheckDynamicInfo t where 1=1 ";
			
			if(entCode!=null&&!"".equals(entCode)){
				hql+=" and t.entCode = '"+entCode+"'";
			}
			if(entTypeGroupId!=null&&!"".equals(entTypeGroupId)){
				hql+=" and t.entTypeGroupId = '"+entTypeGroupId+"'";
			}
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	
	/**
	  * @Description:  获取分页列表  
	  * @Title: getListByPage 
	  * @author wangk
	  * @date 2016-2-24 下午5:33:32 
	  * @throws 
	  */ 
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		
		try {
			IVCheckDynamicDao dao = this.getMapper(IVCheckDynamicDao.class);
			pageResultSet = bizCommonManager.datagrid(IVCheckDynamicDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 根据条件获取分页列表 
	  * @Title: findListBySearch 
	  * @author wangk
	  * @date 2016-2-25 上午10:06:53 
	  * @throws 
	  */ 
	@Override
	public PageResultSet findListBySearch(int pageSize, int pageIndex,VCheckDynamicInfo vCheckDynamicInfo) {
		//食品经营企业
		String foodBusiness = EnumEntTypeGroupGrade.FoodBusiness.getValue();
		
		PageResultSet pageResultSet = new PageResultSet();
		List<VCheckDynamicInfo> list = new ArrayList<VCheckDynamicInfo>();
		
		try {
			IVCheckDynamicDao dao = this.getMapper(IVCheckDynamicDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);
			
			String hql = "select t from VCheckDynamicInfo t where t.entTypeGroupId = '"+foodBusiness+"' ";
			
			if(vCheckDynamicInfo != null){
				if(StringUtil.isNotEmpty(vCheckDynamicInfo.getEntTypeId())){
					hql+=" and t.entTypeId like '"+vCheckDynamicInfo.getEntTypeId()+"%'";
				}
				if(StringUtil.isNotEmpty(vCheckDynamicInfo.getEntName())){
					hql+=" and t.entName like '%"+vCheckDynamicInfo.getEntName()+"%'";
				}
				if(StringUtil.isNotEmpty(vCheckDynamicInfo.getCreditValue())){
					hql+=" and t.creditValue = '"+vCheckDynamicInfo.getCreditValue()+"'";
				}
				if(StringUtil.isNotEmpty(vCheckDynamicInfo.getUnitId())){
					hql+=" and t.unitId = '"+vCheckDynamicInfo.getUnitId()+"'";	
				}
				if(StringUtil.isNotEmpty(vCheckDynamicInfo.getResultVerdictId())){
					hql+=" and t.resultVerdictId = '"+vCheckDynamicInfo.getResultVerdictId()+"'";
				}
			}
			hql+=" order by t.creditTime desc";
			
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
}
