/**  
* @Title: ItemplateSmallSubjectManager.java 
* @Package com.itouch.application.fda.biz.bll.system.table 
* @author wangk    
* @date 2015-10-10 下午4:45:23  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.system.table;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateSmallSubjectInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-10 下午4:45:23  
 */
public interface ITemplateSmallSubjectManager extends IAppBusinessManager{
	/**
	 * @Description:新增
	 * @param templateSmallSubject
	 * @time:2015-10-10 下午4:32:29
	 */
	public Object add(TemplateSmallSubjectInfo templateSmallSubject);
	
	/**
	 * @Description:新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TemplateSmallSubjectInfo> list) ;
	
	/**
	 * @Description:更新
	 * @param ArticleInfo 受理类型实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(TemplateSmallSubjectInfo templateSmallSubject)  ;
	
	/**
	 * @Description:新增/修改
	 * @param templateSmallSubject
	 * @time:2015-10-10 下午4:35:18
	 */
	public Object addOrUpdate(TemplateSmallSubjectInfo templateSmallSubject);
	
	/**
	 * @Description:删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * @Description:删除
	 * @param ArticleInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(TemplateSmallSubjectInfo templateSmallSubject) ;
	
	/**
	 * @Description:获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public TemplateSmallSubjectInfo getEntity(String id) ;
	
	/**
	 * @Description:获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateSmallSubjectInfo> getList() ;
	
	/**
	 * @Description:根据模板获取获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateSmallSubjectInfo> getListByTemplateId(String templateId) ;
	
	/**
	 * @Description:根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<TemplateSmallSubjectInfo> getList(Map<String,Object> map) ;
	
	/**
	 * @Description:获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	
	/**
	 * @Description:根据大项ID删除小项
	 */
	public void delBySubjectId(String subjectId) ;

}
