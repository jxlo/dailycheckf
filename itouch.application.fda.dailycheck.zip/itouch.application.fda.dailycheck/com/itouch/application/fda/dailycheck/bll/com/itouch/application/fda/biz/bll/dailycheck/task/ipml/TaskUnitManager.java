/**  
* @Title: TaskUnitManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.task.ipml 
* @author wangk    
* @date 2015-10-27 下午4:49:28  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.task.ipml;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.bll.dailycheck.task.ITaskUnitManager;
import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskUnitDao;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskUnitInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-27 下午4:49:28  
 */
@Service("dcTaskUnitManager")
public class TaskUnitManager extends AppBusinessManager implements ITaskUnitManager{

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	
	/**
	 * @Description:TODO
	 * @pram：ITaskUnitManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-27 下午4:49:53
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		
		try {
			ITaskUnitDao dao = this.getMapper(ITaskUnitDao.class);
			pageResultSet = bizCommonManager.datagrid(ITaskUnitDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}


	/**
	 * @Description:新增/修改
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 上午11:22:46
	 */
	@Override
	public Object addOrUpdate(TaskUnitInfo taskUnitInfo) {
		try {
			ITaskUnitDao dao = this.getMapper(ITaskUnitDao.class);
			dao.save(taskUnitInfo);
			return taskUnitInfo.getUnitTaskId();
		} catch (Exception e) {
			return null;
		}
	}


	/**
	 * @Description: 获取实体
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-28 上午11:24:07
	 */
	@Override
	public TaskUnitInfo getEntity(String id) {
		try {
			ITaskUnitDao dao = this.getMapper(ITaskUnitDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}


	/**
	 * @Description:新增/修改list
	 * @pram：ITaskUnitManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-29 下午3:28:18
	 */
	@Override
	public Object addOrUpdateList(List<TaskUnitInfo> list) {
		try {
			ITaskUnitDao dao = this.getMapper(ITaskUnitDao.class);
			dao.save(list);
			return list;
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * @Description:根据条件获取列表
	 * @pram：ITaskUnitManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-29 下午4:08:58
	 */
	@Override
	public List<TaskUnitInfo> getList(String taskId,String fromUnitId) {
		ITaskUnitDao dao;
		List<TaskUnitInfo> list = new ArrayList<TaskUnitInfo>();
		
		try {
			dao = this.getMapper(ITaskUnitDao.class);
			
			String hql = "select t from TaskUnitInfo t where 1=1";
			
			if(taskId != null && !"".equals(taskId)){
				hql +=" and t.taskId = '"+taskId+"'";
			}
			if(fromUnitId != null && !"".equals(fromUnitId)){
				hql +=" and t.fromUnitId = '"+fromUnitId+"'";
			}
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}


	/**
	 * @Description:删除列表
	 * @pram：ITaskUnitManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-30 下午12:32:42
	 */
	@Override
	public boolean delete(List<TaskUnitInfo> list) {
		try {
			ITaskUnitDao dao = this.getMapper(ITaskUnitDao.class);
			dao.delete(list);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			return false;
		}
		return true;
	}

}
