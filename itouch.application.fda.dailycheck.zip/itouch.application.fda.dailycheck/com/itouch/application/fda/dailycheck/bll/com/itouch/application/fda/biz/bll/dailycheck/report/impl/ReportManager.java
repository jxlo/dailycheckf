package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IReportManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IReportDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.ReportInfo;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: ReportManager
 * @author: wangk
 * @date: 2016-3-16 下午2:15:07
 */
@Service("reportManager")
public class ReportManager extends AppBusinessManager implements IReportManager {

	Logger logger = LoggerFactory.getLogger(ReportManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: 新增
	 * @Title: add
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object add(ReportInfo reportInfo) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			dao.add(reportInfo);
			return reportInfo.getReportId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 新增
	 * @param list
	 *            实体集合
	 * @Title: add
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean add(List<ReportInfo> list) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 更新
	 * @Title: update
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean update(ReportInfo reportInfo) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			dao.update(reportInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 批量更新
	 * @Title: save
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean save(List<ReportInfo> reportList) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			dao.save(reportList);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 新增/修改
	 * @Title: addOrUpdate
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object addOrUpdate(ReportInfo reportInfo) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			dao.save(reportInfo);
			return reportInfo.getReportId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(String id) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(ReportInfo reportInfo) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			dao.delete(reportInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @Title: getEntity
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public ReportInfo getEntity(String id) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取列表
	 * @Title: getList
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<ReportInfo> getList() {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据map参数获取列表
	 * @Title: getList
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<ReportInfo> getList(Map<String, Object> map) {
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取分页列表
	 * @Title: getListByPage
	 * @author wangk
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {

		PageResultSet pageResultSet = new PageResultSet();

		List<ReportInfo> list = new ArrayList<ReportInfo>();
		try {
			IReportDao dao = this.getMapper(IReportDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);

			String hql = "select t from ReportInfo t where 1=1 ";

			if (null != map && !map.isEmpty()) {
				if (StringUtil.isNotEmpty(map.get("unitId"))) {
					hql += " and t.unitId =  '" + map.get("unitId") + "'";
				}
				if (StringUtil.isNotEmpty(map.get("formCode"))) {
					hql += " and t.formCode = '" + map.get("formCode") + "'";
				}
				if (StringUtil.isNotEmpty(map.get("formName"))) {
					hql += " and t.formName like '%" + map.get("formName")
							+ "%'";
				}
			}

			list = dao.find(hql, null, page);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表(map中是自定义查询条件)
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet findListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageQueryParam page = new PageQueryParam();
		PageResultSet pageResultSet = new PageResultSet();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		page.setNumber(pageSize);
		page.setPageIndex(pageIndex);
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			StringBuilder hql = new StringBuilder(
					" from ReportInfo t where 1=1");
			if (StringUtil.isNotEmpty(map.get("unitIds"))) {
				hql.append(" and t.unitId in (" + map.get("unitIds") + ")");
			}

			hql.append(" and t.formCode='" + map.get("formCode") + "'");

			List<ReportInfo> list = dao.queryByPageCommand(page,
					hql.toString(), null);
			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	
	public PageResultSet findListByPageLi(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageQueryParam page = new PageQueryParam();
		PageResultSet pageResultSet = new PageResultSet();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		page.setNumber(pageSize);
		page.setPageIndex(pageIndex);
		try {
			IReportDao dao = this.getMapper(IReportDao.class);
			StringBuilder hql = new StringBuilder(
					" from ReportInfo t where 1=1");
			if (StringUtil.isNotEmpty(map.get("unitIds"))) {
				hql.append(" and t.unitId like '" + map.get("unitIds") + "%'");
			}

			hql.append(" and t.formCode='" + map.get("formCode") + "'");

			List<ReportInfo> list = dao.queryByPageCommand(page,
					hql.toString(), null);
			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
