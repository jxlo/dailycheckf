package com.itouch.application.fda.biz.bll.dailycheck.report;

import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugUse;


public interface IRepDrugUseManager extends IAppBusinessManager {
	
	/**
	 * 新增
	 * @param repDrugUseInfo
	 * @return Object
	 */
	public Object add(RepDrugUse repDrugUseInfo);
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean save(List<RepDrugUse> list) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public RepDrugUse getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 列表
	 */
	public List<RepDrugUse> getList(String reportId) ;
	
}
