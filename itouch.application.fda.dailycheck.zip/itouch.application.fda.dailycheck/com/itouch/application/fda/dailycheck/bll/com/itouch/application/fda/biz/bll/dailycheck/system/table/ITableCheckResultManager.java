/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITableCheckResultManager.java
 * @author:xh
 * @time:2015-10-26 下午7:16:18
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table;

import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableCheckResult;

/**
 *
 * @author xh
 */
public interface ITableCheckResultManager extends IAppBusinessManager {
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public TableCheckResult getEntity(String id) ;
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public Object addOrUpdate(TableCheckResult tableCheckResult) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public Object add(TableCheckResult tableCheckResult) ;
	
	/**
	 * 根据表ID获取列表
	 * @param tableId  表Id
	 * @return 实体
	 */
	public List<TableCheckResult> getListByTableId(String tableId) ;
	/**
	 * 根据checkId获取列表
	 * @param tableId  表Id
	 * @return 实体
	 */
	public List<TableCheckResult> getListByCheckId(String checkId) ;
	
	public void deleteByCheckId(String checkId);
}
