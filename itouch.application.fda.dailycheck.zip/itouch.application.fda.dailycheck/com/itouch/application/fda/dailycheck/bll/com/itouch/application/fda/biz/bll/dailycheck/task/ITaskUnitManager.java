/**  
* @Title: ITaskUnitManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.task 
* @author wangk    
* @date 2015-10-27 下午4:45:39  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.task;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.task.TaskUnitInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-27 下午4:45:39  
 */
public interface ITaskUnitManager extends IAppBusinessManager{
	
	/**
	 * @Description:删除列表
	 * @param list
	 * @return 是否删除成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-30 下午12:32:42
	 */
	public boolean delete(List<TaskUnitInfo> list);
	
	/**
	 * @Description:新增/修改
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-28 上午11:22:46
	 */
	public Object addOrUpdate(TaskUnitInfo taskUnitInfo);
	
	/**
	 * @Description:新增/修改list
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-29 下午3:28:18
	 */
	public Object addOrUpdateList(List<TaskUnitInfo> list);
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time:2015-10-28 上午11:24:07
	 */
	public TaskUnitInfo getEntity(String id);
	
	/**
	 * 
	 * @param 根据条件获取列表
	 * @return 实体
	 * @author:wangk
	 * @time:2015-10-29 下午4:08:58
	 */
	public List<TaskUnitInfo> getList(String taskId,String fromUnitId);
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 * @author:wangk
	 * @time:2015-10-26 下午2:24:46
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	
}
