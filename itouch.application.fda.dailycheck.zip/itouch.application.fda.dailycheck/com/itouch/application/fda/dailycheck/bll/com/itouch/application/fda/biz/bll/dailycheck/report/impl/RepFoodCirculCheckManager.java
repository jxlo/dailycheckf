/**  
  * @Description: TODO
  * @Title: RepFoodCirculCheckManager.java 
  * @Package: com.itouch.application.fda.biz.bll.dailycheck.report.impl 
  * @author: xh
  * @date 2016-3-24 下午4:15:45 
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepFoodCirculCheckManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepFoodCirculCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodCirculCheckInfo;
import com.itouch.application.fda.foundation.util.StringUtil;

/** 
 * @Description: TODO
 * @ClassName: RepFoodCirculCheckManager 
 * @author xh
 * @date 2016-3-24 下午4:15:45  
 */
@Service("repFoodCirculCheckManager")
public class RepFoodCirculCheckManager extends AppBusinessManager implements IRepFoodCirculCheckManager{
	Logger logger = LoggerFactory.getLogger(RepFoodCirculCheckManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: 新增
	 * @Title: add
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object add(RepFoodCirculCheckInfo repFoodCirculCheckInfo) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			dao.add(repFoodCirculCheckInfo);
			return repFoodCirculCheckInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 新增
	 * @param list
	 *            实体集合
	 * @Title: add
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean add(List<RepFoodCirculCheckInfo> list) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 更新
	 * @Title: update
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean update(RepFoodCirculCheckInfo repFoodCirculCheckInfo) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			dao.update(repFoodCirculCheckInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 批量更新
	 * @Title: save
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean save(List<RepFoodCirculCheckInfo> repFoodCirculCheckInfo) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			dao.save(repFoodCirculCheckInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 新增/修改
	 * @Title: addOrUpdate
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object addOrUpdate(RepFoodCirculCheckInfo repFoodCirculCheckInfo) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			dao.save(repFoodCirculCheckInfo);
			return repFoodCirculCheckInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(String id) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(RepFoodCirculCheckInfo repFoodCirculCheckInfo) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			dao.delete(repFoodCirculCheckInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * 
	 * @param reportId
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByReportId(String reportId) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			String sql = " delete RepFoodCirculCheckInfo t where t.reportId='"
					+ reportId + "'";
			dao.executeByCommand(sql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @Title: getEntity
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public RepFoodCirculCheckInfo getEntity(String id) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			RepFoodCirculCheckInfo info = dao.getEntity(id);
			return info;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepFoodCirculCheckInfo> getList(String reportId) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			String hql = "select t from RepFoodCirculCheckInfo t where t.reportId='"
					+ reportId + "'";
			return dao.queryListByCommand(hql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据条件获取列表
	 * @Title: getListBy
	 * @param reportId
	 * @return List<RepFoodCirculCheckInfo> 返回类型
	 * @author: wangk
	 * @date: 2016-3-17 下午4:13:51
	 * @throws
	 */
	public List<RepFoodCirculCheckInfo> getListByReportIds(String reportIds) {
		
		List<RepFoodCirculCheckInfo> list = new ArrayList<RepFoodCirculCheckInfo>();

		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);

			String hql = "select t from RepFoodCirculCheckInfo t where 1=1 ";

			if (StringUtil.isNotEmpty(reportIds)) {
				hql += " and t.reportId in(" + reportIds + ")";
			}

			list = dao.find(hql, null, null);

			return list;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据map参数获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepFoodCirculCheckInfo> getList(Map<String, Object> map) {
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取分页列表
	 * @Title: getListByPage
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			IRepFoodCirculCheckDao dao = this
					.getMapper(IRepFoodCirculCheckDao.class);
			pageResultSet = bizCommonManager.datagrid(
					IRepFoodCirculCheckDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

}
