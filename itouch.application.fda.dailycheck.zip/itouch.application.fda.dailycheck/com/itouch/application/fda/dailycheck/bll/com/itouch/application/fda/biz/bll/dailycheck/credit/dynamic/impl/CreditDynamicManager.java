/**  
 * @Description: TODO
 * @Title: CreditDynamicManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.dynamic.impl 
 * @author: wangk
 * @date 2016-2-24 下午5:25:46 
 */ 
package com.itouch.application.fda.biz.bll.dailycheck.credit.dynamic.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.dynamic.ICreditDynamicManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.credit.dynamic.ICreditDynamicDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.dynamic.CreditDynamicInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: CreditDynamicManager 
 * @author wangk
 * @date 2016-2-24 下午5:25:46  
 */
@Service("creditDynamicManager")
public class CreditDynamicManager extends AppBusinessManager implements ICreditDynamicManager{
	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}
	
	/**
	  * @Description: 新增
	  * @Title: add 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object add(CreditDynamicInfo creditDynamicInfo) {
		try{
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			dao.add(creditDynamicInfo);
			return creditDynamicInfo.getCreditId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 新增  
	  * @param list 实体集合
	  * @Title: add 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean add(List<CreditDynamicInfo> list) {
		try{
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 更新 
	  * @Title: update 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean update(CreditDynamicInfo creditDynamicInfo) {
		try{
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			dao.update(creditDynamicInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 批量更新 
	  * @Title: save 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean save(List<CreditDynamicInfo> creditDynamicList) {
		try{
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			dao.save(creditDynamicList);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 新增/修改
	  * @Title: addOrUpdate 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object addOrUpdate(CreditDynamicInfo creditDynamicInfo) {
		try{
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			dao.save(creditDynamicInfo);
			return creditDynamicInfo.getCreditId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 删除  
	  * @Title: delete 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(String id) {
		try{
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description:  删除 
	  * @Title: delete 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(CreditDynamicInfo creditDynamicInfo) {
		try{
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			dao.delete(creditDynamicInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description: 获取实体
	  * @Title: getEntity 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public CreditDynamicInfo getEntity(String id) {
		try {
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 获取列表
	  * @Title: getList 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<CreditDynamicInfo> getList() {
		try {
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 根据map参数获取列表 
	  * @Title: getList 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<CreditDynamicInfo> getList(Map<String, Object> map) {
		try {
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 获取分页列表 
	  * @Title: getListByPage 
	  * @author wangk
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			ICreditDynamicDao dao = this.getMapper(ICreditDynamicDao.class);
			pageResultSet = bizCommonManager.datagrid(ICreditDynamicDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
