/**  
* @Title: ITaskManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.task 
* @author wangk    
* @date 2015-10-26 下午2:16:11  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.task;

import iTouch.framework.application.dao.ConditionEnum;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanUserInfo;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-26 下午2:16:11  
 */
public interface ITaskManager extends IAppBusinessManager{
	
	/**
	 * @Description:新增/修改
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-26 下午2:18:21
	 */
	public Object addOrUpdate(TaskInfo taskInfo);
	
	/**
	 * @Description:删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-26 下午2:21:38
	 */
	public boolean delete(String id);
	
	/**
	 * @Description:删除
	 * @param checkInfo 实体
	 * @return 是否删除成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-26 下午2:22:21
	 */
	public boolean delete(TaskInfo taskInfo);
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time:2015-10-26 下午2:23:31
	 */
	public TaskInfo getEntity(String id);
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 * @author:wangk
	 * @time:2015-10-26 下午2:24:46
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map,List<ConditionEnum> relations) ;
	
	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-26 下午4:41:45
	 */
	public PageResultSet findListBySearch(int number,int pageIndex,TaskInfo taskInfo,String taskCreateOrg,Map<String, Object> map) throws Throwable;

	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @date 2015-12-1 下午12:21:46 
	 */
	public List<TaskInfo> getList(String tableId);
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<TaskInfo> getList(Map<String,Object> map) ;
}
