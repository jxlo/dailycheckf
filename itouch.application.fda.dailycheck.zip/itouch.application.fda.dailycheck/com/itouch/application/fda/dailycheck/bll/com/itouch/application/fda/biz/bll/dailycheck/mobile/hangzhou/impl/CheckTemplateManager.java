package com.itouch.application.fda.biz.bll.dailycheck.mobile.hangzhou.impl;

import iTouch.framework.application.dao.OrderType;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.mobile.hangzhou.ICheckTemplateManager;
import com.itouch.application.fda.biz.dao.dailycheck.mobile.hangzhou.ICheckTemplateDao;
import com.itouch.application.fda.biz.entity.dailycheck.mobile.hangzhou.CheckTemplateInfo;

/**
 * 检查模板
 */
@Lazy
@Service("DC_CheckTemplateManager")
public class CheckTemplateManager extends AppBusinessManager implements ICheckTemplateManager {
	Logger logger = LoggerFactory.getLogger(CheckTemplateManager.class);

	@Autowired
	private ICommonManager commonManager;

	private ICheckTemplateDao dao;
	
	/**
	 * 新增
	 * @param 受理类型实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public String add(CheckTemplateInfo info) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			dao.add(info);
			return info.getId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CheckTemplateInfo> list) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			dao.add(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(CheckTemplateInfo info) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			dao.update(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(CheckTemplateInfo info) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			dao.save(info);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 删除
	 * @param Id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * @param 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(CheckTemplateInfo info) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			dao.delete(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 获取实体
	 * @param Id 主键ID
	 * @return 实体
	 * @throws Throwable
	 */
	@SuppressWarnings("deprecation")
	public CheckTemplateInfo getEntity(String id) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * @return list 列表集合
	 * @throws Throwable
	 */
	public List<CheckTemplateInfo> getList() {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			return dao.find("orderId", OrderType.asc);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<CheckTemplateInfo> getEnList() {
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("isEnabled", 1);
			dao = this.getMapper(ICheckTemplateDao.class);
			return dao.findAnd(null, map, "orderId", OrderType.asc);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 根据map参数获取列表
	 * @param map查询参数
	 * @return 受理类型列表
	 */
	public List<CheckTemplateInfo> getList(Map<String, Object> map) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			return dao.findAnd(null, map, "createtime", OrderType.asc);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		try {
			dao = this.getMapper(ICheckTemplateDao.class);
			return commonManager.datagrid(ICheckTemplateDao.class, pageIndex, pageSize, map, dao, "createtime", OrderType.asc);
		} catch (Throwable e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
}
