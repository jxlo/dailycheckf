/**  
  * @Description: TODO
  * @Title: CreditParamManager.java 
  * @Package: com.itouch.application.fda.biz.bll.dailycheck.system.param.impl 
  * @author: xh
  * @date 2016-2-19 下午2:37:07 
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.system.param.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.param.ICreditParamManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.param.ICreditParamDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.param.CreditParamInfo;

/** 
 * @Description: TODO
 * @ClassName: CreditParamManager 
 * @author xh
 * @date 2016-2-19 下午2:37:07  
 */
@Service("creditParamManager")
public class CreditParamManager extends AppBusinessManager implements ICreditParamManager{
	Logger logger = LoggerFactory.getLogger(CreditParamManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	  * @Description: TODO 
	  * @Title: getList 
	  * @author xh
	  * @date 2016-2-19 下午2:41:54 
	  * @throws 
	  */ 
	@Override
	public List<CreditParamInfo> getList() {
		ICreditParamDao dao;
		try {
			dao = this.getMapper(ICreditParamDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	public boolean delete(String id) {
		try{
			ICreditParamDao dao = this.getMapper(ICreditParamDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description: TODO 
	  * @Title: addOrUpdate 
	  * @author xh
	  * @date 2016-2-19 下午2:47:43 
	  * @throws 
	  */ 
	@Override
	public void addOrUpdate(CreditParamInfo creditParamInfo) {
		try{
			ICreditParamDao dao = this.getMapper(ICreditParamDao.class);
			dao.saveOrUpdate(creditParamInfo);
		}catch(Exception ex){
		}
	}

	/**
	  * @Description: TODO 
	  * @Title: getListByPage 
	  * @author xh
	  * @date 2016-2-19 下午3:49:13 
	  * @throws 
	  */ 
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			String entTypeGroupId) {
		PageResultSet pageResultSet = new PageResultSet();
		List<CreditParamInfo> list = new ArrayList<CreditParamInfo>();
		ICreditParamDao dao;
		try {
			dao = this.getMapper(ICreditParamDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);
			
			String hql = " select t from CreditParamInfo t where 1=1 ";
			if( entTypeGroupId !=null && !"".equals(entTypeGroupId)){
				hql += " and t.entTypeGroupId = '"+entTypeGroupId+"'";
			}
			hql+=" order by orderNumber asc";
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: TODO 
	  * @Title: edit 
	  * @author xh
	  * @date 2016-2-19 下午4:48:18 
	  * @throws 
	  */ 
	@Override
	public CreditParamInfo getEntity(String id) {
		try{
			ICreditParamDao dao = this.getMapper(ICreditParamDao.class);
			return dao.getEntity(id);
		}catch(Exception ex){
			return null;
		}
	}

	/**
	  * @Description: 根据条件获取列表 
	  * @Title: getList 
	  * @author wangk
	  * @date 2016-2-25 下午2:15:19 
	  * @throws 
	  */ 
	public List<CreditParamInfo> getListBy(String entTypeGroupId,String creditTypeId) {
		ICreditParamDao dao;
		List<CreditParamInfo> list = new ArrayList<CreditParamInfo>();
		try {
			dao = this.getMapper(ICreditParamDao.class);
			
			String hql = "select t from  CreditParamInfo t where 1=1 ";
			if(entTypeGroupId!=null && !"".equals(entTypeGroupId)){
				hql+=" and t.entTypeGroupId = '"+entTypeGroupId+"'";
			}
			if(creditTypeId!=null && !"".equals(creditTypeId)){
				hql+=" and t.creditTypeId = '"+creditTypeId+"'";
			}
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
