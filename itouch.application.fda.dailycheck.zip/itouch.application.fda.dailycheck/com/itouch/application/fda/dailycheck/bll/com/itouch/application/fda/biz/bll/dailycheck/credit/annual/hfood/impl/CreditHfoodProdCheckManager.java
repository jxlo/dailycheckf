/**  
  * @Description: TODO
  * @Title: CreditHfoodGmpManager.java 
  * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.hfood.impl 
  * @author: xh
  * @date 2016-3-9 下午5:39:49 
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.credit.annual.hfood.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.annual.hfood.ICreditHfoodProdCheckManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood.ICreditHfoodProdCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood.CreditHfoodProdCheckInfo;

/** 
 * @Description: TODO
 * @ClassName: CreditHfoodGmpManager 
 * @author xh
 * @date 2016-3-9 下午5:39:49  
 */
@Service("CreditHfoodProdCheckManager")
public class CreditHfoodProdCheckManager extends AppBusinessManager implements ICreditHfoodProdCheckManager{
	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}
	
	/**
	  * @Description: 新增
	  * @Title: add 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object add(CreditHfoodProdCheckInfo CreditHfoodProdCheckInfo) {
		try{
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			dao.add(CreditHfoodProdCheckInfo);
			return CreditHfoodProdCheckInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 新增  
	  * @param list 实体集合
	  * @Title: add 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean add(List<CreditHfoodProdCheckInfo> list) {
		try{
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 更新 
	  * @Title: update 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean update(CreditHfoodProdCheckInfo CreditHfoodProdCheckInfo) {
		try{
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			dao.update(CreditHfoodProdCheckInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 批量更新 
	  * @Title: save 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean save(List<CreditHfoodProdCheckInfo> creditHfoodGmpList) {
		try{
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			dao.save(creditHfoodGmpList);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 新增/修改
	  * @Title: addOrUpdate 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object addOrUpdate(CreditHfoodProdCheckInfo CreditHfoodProdCheckInfo) {
		try{
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			dao.save(CreditHfoodProdCheckInfo);
			return CreditHfoodProdCheckInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 删除  
	  * @Title: delete 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(String id) {
		try{
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description:  删除 
	  * @Title: delete 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(CreditHfoodProdCheckInfo CreditHfoodProdCheckInfo) {
		try{
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			dao.delete(CreditHfoodProdCheckInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description: 获取实体
	  * @Title: getEntity 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public CreditHfoodProdCheckInfo getEntity(String id) {
		try {
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 获取列表
	  * @Title: getList 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<CreditHfoodProdCheckInfo> getList() {
		try {
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 根据map参数获取列表 
	  * @Title: getList 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<CreditHfoodProdCheckInfo> getList(Map<String, Object> map) {
		try {
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 获取分页列表 
	  * @Title: getListByPage 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			ICreditHfoodProdCheckDao dao = this.getMapper(ICreditHfoodProdCheckDao.class);
			pageResultSet = bizCommonManager.datagrid(ICreditHfoodProdCheckDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

}
