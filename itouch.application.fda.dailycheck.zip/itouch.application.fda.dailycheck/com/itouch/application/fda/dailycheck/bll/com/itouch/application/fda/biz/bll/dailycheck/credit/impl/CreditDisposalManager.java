package com.itouch.application.fda.biz.bll.dailycheck.credit.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.ICreditDisposalManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.credit.ICreditDisposalDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.CreditDisposalInfo;

@Service("dc_CreditDisposalManager")
public class CreditDisposalManager extends AppBusinessManager implements ICreditDisposalManager{
	
	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description: 新增
	 * @throws 
	 */ 
	public Object add(CreditDisposalInfo CreditDisposalInfo){
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			dao.add(CreditDisposalInfo);
			return CreditDisposalInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditDisposalInfo> list){
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			dao.add(list);
			return true ;
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
	}
	
	/**
	 * 更新
	 * @param CreditDisposalInfo 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(CreditDisposalInfo creditDisposalInfo){
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			dao.update(creditDisposalInfo);
			return true ;
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
	}
	
	/**
	 * 批量更新或保存
	 * @param CheckEntInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CreditDisposalInfo> CreditDisposalInfoList){
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			dao.save(CreditDisposalInfoList);
			return true ;
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
	}
	/**
	 * 新增/修改
	 * @param CheckEntInfo 实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(CreditDisposalInfo CreditDisposalInfo){
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			dao.save(CreditDisposalInfo);
			return true ;
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
	}
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id){
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			dao.delete(id);
			return true ;
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
	}
	
	/**
	 * 删除
	 * @param CheckEntInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(CreditDisposalInfo CreditDisposalInfo){
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			dao.delete(CreditDisposalInfo);
			return true ;
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
	}
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public CreditDisposalInfo getEntity(String id){
		CreditDisposalInfo creditDisposalInfo=null;
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			creditDisposalInfo=dao.getEntity(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
		}
		
		return creditDisposalInfo;
	}
	
	/**
	 * 获取列表
	 * @return 列表
	 */
	public List<CreditDisposalInfo> getList(){
		List<CreditDisposalInfo> list=null;
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			list=dao.find();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
		}
		return list;
	}
	
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<CreditDisposalInfo> getList(Map<String,Object> map){
		List<CreditDisposalInfo> list=null;
		try{
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			list=dao.findAnd(null, map);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
		}
		return list;
	}

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map){
		PageResultSet pageResultSet = new PageResultSet();
		try {
			ICreditDisposalDao dao = this.getMapper(ICreditDisposalDao.class);
			pageResultSet = bizCommonManager.datagrid(ICreditDisposalDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
