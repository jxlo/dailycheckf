/**  
  * @Description: TODO
  * @Title: CreditHfoodProdFormManager.java 
  * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.hfood.impl 
  * @author: xh
  * @date 2016-3-10 上午10:20:54 
  */ 
package com.itouch.application.fda.biz.bll.dailycheck.credit.annual.hfood.impl;

import iTouch.framework.application.dao.MapperSQLException;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.application.service.MapperNotFoundException;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.annual.hfood.ICreditHfoodProdPreviewManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckDao;
import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.hfood.ICreditHfoodProdPreviewDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.hfood.CreditHfoodProdPreviewInfo;

/** 
 * @Description: TODO
 * @ClassName: CreditHfoodProdFormManager 
 * @author xh
 * @date 2016-3-10 上午10:20:54  
 */
@Service("CreditHfoodProdPreviewManager")
public class CreditHfoodProdPreviewManager extends AppBusinessManager implements ICreditHfoodProdPreviewManager {
	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}
	
	/**
	  * @Description: 新增
	  * @Title: add 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object add(CreditHfoodProdPreviewInfo creditHfoodProdPreviewInfo) {
		try{
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			dao.add(creditHfoodProdPreviewInfo);
			return creditHfoodProdPreviewInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 新增  
	  * @param list 实体集合
	  * @Title: add 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean add(List<CreditHfoodProdPreviewInfo> list) {
		try{
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 更新 
	  * @Title: update 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean update(CreditHfoodProdPreviewInfo creditHfoodProdPreviewInfo) {
		try{
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			dao.update(creditHfoodProdPreviewInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 批量更新 
	  * @Title: save 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean save(List<CreditHfoodProdPreviewInfo> creditHfoodProdFormList) {
		try{
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			dao.save(creditHfoodProdFormList);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	  * @Description: 新增/修改
	  * @Title: addOrUpdate 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public Object addOrUpdate(CreditHfoodProdPreviewInfo creditHfoodProdPreviewInfo) {
		try{
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			dao.save(creditHfoodProdPreviewInfo);
			return creditHfoodProdPreviewInfo.getId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	  * @Description: 删除  
	  * @Title: delete 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(String id) {
		try{
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description:  删除 
	  * @Title: delete 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public boolean delete(CreditHfoodProdPreviewInfo creditHfoodProdPreviewInfo) {
		try{
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			dao.delete(creditHfoodProdPreviewInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	  * @Description: 获取实体
	  * @Title: getEntity 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public CreditHfoodProdPreviewInfo getEntity(String id) {
		try {
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			String hql="select new creditHfoodProdPreviewInfo(t1,t2,t3) from creditHfoodProdPreviewInfo t1,CreditHfoodGmpInfo t2,CreditAnnualInfo t3 where t1.creditAnnualId=t3.id and t1.creditAnnualId=t2.creditAnnualId and t3.id='"+id+"'";
			CreditHfoodProdPreviewInfo info=dao.uniqueResultByCommand(hql, null);
			return info;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 获取列表
	  * @Title: getList 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<CreditHfoodProdPreviewInfo> getList() {
		try {
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 根据map参数获取列表 
	  * @Title: getList 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public List<CreditHfoodProdPreviewInfo> getList(Map<String, Object> map) {
		try {
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 获取分页列表 
	  * @Title: getListByPage 
	  * @author xh
	  * @date 2016-2-24 下午5:09:19 
	  * @throws 
	  */ 
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			ICreditHfoodProdPreviewDao dao = this.getMapper(ICreditHfoodProdPreviewDao.class);
			pageResultSet = bizCommonManager.datagrid(ICreditHfoodProdPreviewDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	/**
	  * @Description: TODO 
	  * @Title: getCheckInfo 
	  * @author xh
	  * @date 2016-3-10 下午2:22:55 
	  * @throws 
	  */ 
	@Override
	public List<CheckInfo> getCheckInfoList(String entCode, String entTypeGroupId) {
		ICheckDao dao=null;
		List<CheckInfo> list=null;
		try {
			dao = this.getMapper(ICheckDao.class);
			String hql="select new CheckInfo(t1) from CheckInfo t1,CheckEntInfo t2 where t2.entCode='"+entCode+"' and t2.entTypeGroupId='"+entTypeGroupId+"' and t1.checkId=t2.checkId order by t1.createTime";
			list=dao.queryListByCommand(hql, null);
		} catch (MapperNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MapperSQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
