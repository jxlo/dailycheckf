package com.itouch.application.fda.biz.bll.dailycheck.index.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.index.IVCateringDynamicReportManager;
import com.itouch.application.fda.biz.dao.dailycheck.index.IVCateringDynamicReportDao;
import com.itouch.application.fda.biz.entity.dailycheck.index.VCateringDynamicReportInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: VCateringDynamicReportManager 
 * @author: wangk
 * @date: 2016-3-28 下午2:03:01  
 */
@Service("vCateringDynamicReportManager")
public class VCateringDynamicReportManager extends AppBusinessManager implements IVCateringDynamicReportManager{
	

	Logger logger = LoggerFactory.getLogger(VCateringDynamicReportManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}
	
	/**
	 * @Description: 根据条件获取列表 
	 * @Title: getByUnitId 
	 * @author: wangk
	 * @date: 2016-3-28 下午2:03:33 
	 * @throws 
	 */ 
	@Override
	public List<VCateringDynamicReportInfo> getByUnitId(String unitIds) {
		List<VCateringDynamicReportInfo> list = new ArrayList<VCateringDynamicReportInfo>();

		//当前时间
		Calendar calendar = Calendar.getInstance();
		Integer thisYear = calendar.get(Calendar.YEAR);
		
		try {
			IVCateringDynamicReportDao dao = this.getMapper(IVCateringDynamicReportDao.class);
			
			String hql = "select t from VCateringDynamicReportInfo t where 1=1 and t.creditYear = "+thisYear+" ";
			
			if(StringUtil.isNotEmpty(unitIds)){
				hql+=" and t.unitId in ("+unitIds+")";
			}
			
			list = dao.find(hql , null , null);
			
			return list;
			
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	
	}

}
