/**
 * @Description:TODO
 * @project:itouch.application.fda.online
 * @class:ICommonManager.java
 * @author:zhanglai
 * @time:2015年7月29日 下午4:13:48
 */

package com.itouch.application.fda.biz.bll.common;

import iTouch.framework.application.dao.ConditionEnum;
import iTouch.framework.application.dao.IBaseCommonDao;
import iTouch.framework.application.dao.OrderType;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

/**
 * @author  zhanglai
 *
 */
public interface ICommonManager extends IAppBusinessManager{
	/**
	 * 
	 * @Description:查询分页查询相关信息
	 * @param entityClass 对应的实体类
	 * @param index 第几页
	 * @param number 每页数量
	 * @param map 条件参数
	 * @param dao 对应的dao层
	 * @return
	 * @throws Throwable
	 * @author:zhanglai
	 * @time:2015年7月29日 下午4:28:04
	 */
	public <E> PageResultSet datagrid(Class<E> entityClass,int index,int number,Map<String,Object> map,IBaseCommonDao dao)throws Throwable;
	/**
	 * 
	 * @Description:查询分页查询相关信息
	 * @param entityClass 对应的实体类
	 * @param index 第几页
	 * @param number 每页数量
	 * @param map 条件参数
	 * @param dao 对应的dao层
	 * @param orderPropertyName 排序属性
	 * @param orderType 排序方式
	 * @return 
	 * @throws Throwable
	 * @author:zhanglai
	 * @time:2015年7月29日 下午4:26:18
	 */
	public <E> PageResultSet datagrid(Class<E> entityClass,int index,int number,Map<String,Object> map,IBaseCommonDao dao,String orderPropertyName,OrderType orderType)throws Throwable;
	
	
	public <E> PageResultSet datagrid(Class<E> entityClass, int index,
			int number, Map<String, Object> map,List<ConditionEnum> relations, IBaseCommonDao dao)
			throws Throwable;
	
	public <E> PageResultSet datagridRealation(Class<E> entityClass, int index,
			int number, Map<String, Object> map,List<ConditionEnum> relations, IBaseCommonDao dao,
			String orderPropertyName,OrderType orderType) throws Throwable ;
	
	/**
	 * @Description:TODO
	 * @param hql
	 * @param index
	 * @param number
	 * @param array
	 * @param dao
	 * @return
	 * @throws Throwable
	 * @author:zhangzt
	 * @time:2015年11月12日 下午8:06:25
	 */
	public <E> PageResultSet datagridHql(String hql, int index,int number, Object[] array, IBaseCommonDao dao)throws Throwable;

}
