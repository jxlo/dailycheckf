/**  
 * @Description: TODO
 * @Title: RepCosmDailyCheckManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.report.impl 
 * @author: xh
 * @date 2016-3-16 上午11:34:16 
 */
package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepCosmDailyCheckManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepCosmDailyCheckDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepCosmDailyCheckInfo;
import com.itouch.application.fda.foundation.util.StringUtil;

/**
 * @Description: TODO
 * @ClassName: RepCosmDailyCheckManager
 * @author xh
 * @date 2016-3-16 上午11:34:16
 */
@Service("repCosmDailyCheckManager")
public class RepCosmDailyCheckManager extends AppBusinessManager implements
		IRepCosmDailyCheckManager {
	Logger logger = LoggerFactory.getLogger(RepCosmDailyCheckManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: 新增
	 * @Title: add
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object add(RepCosmDailyCheckInfo repCosmDailyCheckInfo) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			dao.add(repCosmDailyCheckInfo);
			return repCosmDailyCheckInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 新增
	 * @param list
	 *            实体集合
	 * @Title: add
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean add(List<RepCosmDailyCheckInfo> list) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 更新
	 * @Title: update
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean update(RepCosmDailyCheckInfo repCosmDailyCheckInfo) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			dao.update(repCosmDailyCheckInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 批量更新
	 * @Title: save
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean save(List<RepCosmDailyCheckInfo> repCosmDailyCheckInfo) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			dao.save(repCosmDailyCheckInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 新增/修改
	 * @Title: addOrUpdate
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object addOrUpdate(RepCosmDailyCheckInfo repCosmDailyCheckInfo) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			dao.save(repCosmDailyCheckInfo);
			return repCosmDailyCheckInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(String id) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(RepCosmDailyCheckInfo repCosmDailyCheckInfo) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			dao.delete(repCosmDailyCheckInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * 
	 * @param reportId
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByReportId(String reportId) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			String sql = " delete RepCosmDailyCheckInfo t where t.reportId='"
					+ reportId + "'";
			dao.executeByCommand(sql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @Title: getEntity
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public RepCosmDailyCheckInfo getEntity(String id) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			RepCosmDailyCheckInfo info = dao.getEntity(id);
			return info;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepCosmDailyCheckInfo> getList(String reportId) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			String hql = "select t from RepCosmDailyCheckInfo t where t.reportId='"
					+ reportId + "'";
			return dao.queryListByCommand(hql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据条件获取列表
	 * @Title: getListBy
	 * @param reportId
	 * @return List<RepCosmDailyCheckInfo> 返回类型
	 * @author: wangk
	 * @date: 2016-3-17 下午4:13:51
	 * @throws
	 */
	public List<RepCosmDailyCheckInfo> getListByReportIds(String reportIds) {
		
		List<RepCosmDailyCheckInfo> list = new ArrayList<RepCosmDailyCheckInfo>();

		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);

			String hql = "select t from RepCosmDailyCheckInfo t where 1=1 ";

			if (StringUtil.isNotEmpty(reportIds)) {
				hql += " and t.reportId in(" + reportIds + ")";
			}

			list = dao.find(hql, null, null);

			return list;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据map参数获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepCosmDailyCheckInfo> getList(Map<String, Object> map) {
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取分页列表
	 * @Title: getListByPage
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			IRepCosmDailyCheckDao dao = this
					.getMapper(IRepCosmDailyCheckDao.class);
			pageResultSet = bizCommonManager.datagrid(
					IRepCosmDailyCheckDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
