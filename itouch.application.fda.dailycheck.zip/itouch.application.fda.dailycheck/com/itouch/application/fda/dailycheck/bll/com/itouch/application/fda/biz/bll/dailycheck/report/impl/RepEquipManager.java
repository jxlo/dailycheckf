package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepEquipManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepEquipDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepEquip;

@Service("repEquipManager")
public class RepEquipManager extends AppBusinessManager 
		implements IRepEquipManager {
	Logger logger = LoggerFactory.getLogger(RepEquipManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 */
	@SuppressWarnings("unused")
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	@Override
	public Object add(RepEquip repEquipInfo) {
		try {
			IRepEquipDao dao = this.getMapper(IRepEquipDao.class);
			dao.add(repEquipInfo);
			return repEquipInfo.getId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public boolean save(List<RepEquip> list) {
		try {
			IRepEquipDao dao = this.getMapper(IRepEquipDao.class);
			dao.save(list);
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return false;
		}
		
	}

	@Override
	public RepEquip getEntity(String id) {
		try {
			IRepEquipDao dao = this.getMapper(IRepEquipDao.class);
			RepEquip info = dao.getEntity(id);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public List<RepEquip> getList(String reportId) {
		try {
			IRepEquipDao dao = this.getMapper(IRepEquipDao.class);
			String hql = "select t from RepEquip t where t.reportId = '"+reportId+"' ";
			List<RepEquip> list = dao.queryListByCommand(hql, null);
			return list;
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
		
	}

}
