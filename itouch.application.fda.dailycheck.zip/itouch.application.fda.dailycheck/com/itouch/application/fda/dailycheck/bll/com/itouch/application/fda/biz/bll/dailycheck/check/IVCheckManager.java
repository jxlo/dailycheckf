package com.itouch.application.fda.biz.bll.dailycheck.check;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.check.VCheckInfo;

public interface IVCheckManager extends IAppBusinessManager {

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map);
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, VCheckInfo vCheckInfo);
	
	
	/** 
	 * @Description:获取列表
	 * @param map
	 * @return 
	 * @author:nihh 
	 * @time:2016年5月31日 下午1:43:49 
	 */
	public List<VCheckInfo> getList(Map<String, Object> map);
	
}
