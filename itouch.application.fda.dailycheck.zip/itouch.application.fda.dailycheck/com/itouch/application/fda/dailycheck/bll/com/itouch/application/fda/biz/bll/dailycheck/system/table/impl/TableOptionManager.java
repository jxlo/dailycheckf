/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckTableOptionManager.java
 * @author:fanghailong
 * @time:2015-10-12 下午12:34:33
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableOptionManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITableOptionDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TableOptionInfo;

/**
 * @author:fanghailong 
 */
@Service("checkTableOptionManager")
public class TableOptionManager extends AppBusinessManager implements ITableOptionManager{
	
	Logger logger = LoggerFactory.getLogger(TableOptionManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * 新增
	 * 
	 * @param TableOptionInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(TableOptionInfo checkTableOptionInfo)  {
		try{
			ITableOptionDao dao = this.getMapper(ITableOptionDao.class);
			dao.add(checkTableOptionInfo);
			return checkTableOptionInfo.getTableId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TableOptionInfo> list) {
		try{
			ITableOptionDao dao = this.getMapper(ITableOptionDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param TableOptionInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(TableOptionInfo checkTableOptionInfo) {
		try{
			ITableOptionDao dao = this.getMapper(ITableOptionDao.class);
			dao.update(checkTableOptionInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * 
	 * @param checkTableOptionInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(TableOptionInfo checkTableOptionInfo) {
		try{
			ITableOptionDao dao = this.getMapper(ITableOptionDao.class);
			dao.save(checkTableOptionInfo);
			return checkTableOptionInfo.getTableId();
		}catch(Exception ex){
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try{
			ITableOptionDao dao = this.getMapper(ITableOptionDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 删除
	 * 
	 * @param TableOptionInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(TableOptionInfo checkTableOptionInfo) {
		try{
			ITableOptionDao dao = this.getMapper(ITableOptionDao.class);
			dao.delete(checkTableOptionInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public TableOptionInfo getEntity(String id)  {
		try {
			ITableOptionDao dao = this.getMapper(ITableOptionDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<CheckTableOptionInfo> 列表集合
	 * @throws Throwable
	 */
	public List<TableOptionInfo> getList() {
		ITableOptionDao dao;
		try {
			dao = this.getMapper(ITableOptionDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<TableOptionInfo> getList(Map<String,Object> map){
		ITableOptionDao dao;
		try {
			dao = this.getMapper(ITableOptionDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		ITableOptionDao dao;
		try {
			dao = this.getMapper(ITableOptionDao.class);
			pageResultSet = bizCommonManager.datagrid(ITableOptionDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableOptionManager#getListByTableId()
	 */
	@Override
	public List<TableOptionInfo> getListByTableId(String tableId) {
		ITableOptionDao dao;
		try {
			dao = this.getMapper(ITableOptionDao.class);
			String hql="select t from TableOptionInfo t where t.tableId='"+tableId+"'";
			
			return dao.queryListByCommand(hql,null);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableOptionManager#delByTable(java.lang.String)
	 */
	@Override
	public void delByTable(String tableId) {
		ITableOptionDao dao;
		try {
			dao = this.getMapper(ITableOptionDao.class);
			String hql="delete from TableOptionInfo t where t.tableId='"+tableId+"'";
			
			dao.executeByCommand(hql, null);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
		}
	}
}
