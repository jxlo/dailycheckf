/**  
 * @Description: TODO
 * @Title: CreditAnnualManager.java 
 * @Package: com.itouch.application.fda.biz.bll.dailycheck.credit.food.catering.annual.impl 
 * @author: wangk
 * @date 2016-2-24 下午5:08:45 
 */
package com.itouch.application.fda.biz.bll.dailycheck.credit.annual.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;
import iTouch.framework.utility.text.StringUtil;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.credit.annual.IVCreditAnnualDisposalManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.credit.annual.IVCreditAnnualDisposalDao;
import com.itouch.application.fda.biz.entity.dailycheck.credit.annual.VCreditAnnualDisposalInfo;

/**
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @ClassName: CreditAnnualManager
 * @author wangk
 * @date 2016-2-24 下午5:08:45
 */
@Service("dc_VCreditAnnualDisposalManager")
public class VCreditAnnualDisposalManager extends AppBusinessManager implements IVCreditAnnualDisposalManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return 分页列表集合
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex, VCreditAnnualDisposalInfo vCreditAnnualDisposalInfo, Map<String, Object> map) {

		PageQueryParam page = new PageQueryParam();
		PageResultSet pageResultSet = new PageResultSet();
		page.setNumber(pageSize);
		page.setPageIndex(pageIndex);

		try {

			IVCreditAnnualDisposalDao dao = this.getMapper(IVCreditAnnualDisposalDao.class);
			String hql = "select t from VCreditAnnualDisposalInfo t where 1=1 ";

			if (null != vCreditAnnualDisposalInfo) {

				if (StringUtil.isNotEmpty(vCreditAnnualDisposalInfo.getEntName())) {
					hql += " and t.entName like '%" + vCreditAnnualDisposalInfo.getEntName() + "%' ";
				}

				if (StringUtil.isNotEmpty(vCreditAnnualDisposalInfo.getDispUnitId())) {
					hql += " and t.dispUnitId='" + vCreditAnnualDisposalInfo.getDispUnitId() + "' ";
				}

				if (StringUtil.isNotEmpty(vCreditAnnualDisposalInfo.getIsDisp())) {
					hql += " and t.isDisp='" + vCreditAnnualDisposalInfo.getIsDisp() + "' ";
				}
				
				if (StringUtil.isNotEmpty(vCreditAnnualDisposalInfo.getEntTypeGroupId())) {
					hql += " and t.entTypeGroupId='" + vCreditAnnualDisposalInfo.getEntTypeGroupId() + "' ";
				}

			}

			List<VCreditAnnualDisposalInfo> list = dao.queryByPageCommand(page, hql, null);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
