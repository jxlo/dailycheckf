/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateItemManager.java
 * @author:fanghailong
 * @time:2015-10-10 下午4:35:43
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateItemManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateItemDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateItemInfo;

/**
 * @author:fanghailong 
 */
@Service("templateItemManager")
public class TemplateItemManager extends AppBusinessManager implements ITemplateItemManager{
	
	Logger logger = LoggerFactory.getLogger(TemplateItemManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * 新增
	 * 
	 * @param TemplateItemInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(TemplateItemInfo templateItemInfo)  {
		try{
			ITemplateItemDao dao = this.getMapper(ITemplateItemDao.class);
			dao.add(templateItemInfo);
			return templateItemInfo.getItemId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TemplateItemInfo> list) {
		try{
			ITemplateItemDao dao = this.getMapper(ITemplateItemDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param TemplateItemInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(TemplateItemInfo templateItemInfo) {
		try{
			ITemplateItemDao dao = this.getMapper(ITemplateItemDao.class);
			dao.update(templateItemInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * 
	 * @param TemplateItemInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(TemplateItemInfo templateItemInfo) {
		try{
			ITemplateItemDao dao = this.getMapper(ITemplateItemDao.class);
			dao.save(templateItemInfo);
			return templateItemInfo.getItemId();
		}catch(Exception ex){
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try{
			ITemplateItemDao dao = this.getMapper(ITemplateItemDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 删除
	 * 
	 * @param TemplateItemInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(TemplateItemInfo templateItemInfo) {
		try{
			ITemplateItemDao dao = this.getMapper(ITemplateItemDao.class);
			dao.delete(templateItemInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public TemplateItemInfo getEntity(String id)  {
		try {
			ITemplateItemDao dao = this.getMapper(ITemplateItemDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<TemplateItemInfo> 列表集合
	 * @throws Throwable
	 */
	public List<TemplateItemInfo> getList() {
		ITemplateItemDao dao;
		try {
			dao = this.getMapper(ITemplateItemDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:根据模板获取获取列表
	 * @return 受理类型列表
	 */
	@Override
	public List<TemplateItemInfo> getListByTemplateId(String templateId){
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("templateId", templateId);
		return getList(map);
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<TemplateItemInfo> getList(Map<String,Object> map){
		ITemplateItemDao dao;
		try {
			dao = this.getMapper(ITemplateItemDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		ITemplateItemDao dao;
		try {
			dao = this.getMapper(ITemplateItemDao.class);
			pageResultSet = bizCommonManager.datagrid(ITemplateItemDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateItemManager#delBySubjectId(java.lang.String)
	 */
	@Override
	public void delBySubjectId(String subjectId) {
		// TODO Auto-generated method stub
		String hql="delete from TemplateItemInfo t where t.subjectId='"+subjectId+"'";
		ITemplateItemDao dao;
		try {
			dao = this.getMapper(ITemplateItemDao.class);
			dao.executeByCommand(hql, null);
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateItemManager#delBySmallId(java.lang.String)
	 */
	@Override
	public void delBySmallId(String smallId) {
		// TODO Auto-generated method stub
				String hql="delete from TemplateItemInfo t where t.smallSubjectId='"+smallId+"'";
				ITemplateItemDao dao;
				try {
					dao = this.getMapper(ITemplateItemDao.class);
					dao.executeByCommand(hql, null);
				} catch (Throwable ex) {
					logger.error(""+ex.getMessage());
					ex.printStackTrace();
				}
	}
}
