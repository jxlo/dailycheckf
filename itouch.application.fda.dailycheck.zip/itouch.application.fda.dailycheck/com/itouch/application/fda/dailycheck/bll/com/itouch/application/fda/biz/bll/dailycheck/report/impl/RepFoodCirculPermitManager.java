package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IRepFoodCirculPermitManager;
import com.itouch.application.fda.biz.dao.dailycheck.report.IRepFoodCirculPermitDao;
import com.itouch.application.fda.biz.entity.dailycheck.report.RepFoodCirculPermitInfo;
import com.itouch.application.fda.foundation.util.StringUtil;

/** 
 * @Description: 食品经营许可（流通）情况统计表
 * @ClassName: RepFoodCirculPermitManager 
 * @author: wangk
 * @date: 2016-3-24 下午1:52:57  
 */
@Service("repFoodCirculPermitManager")
public class RepFoodCirculPermitManager extends AppBusinessManager implements IRepFoodCirculPermitManager{
	Logger logger = LoggerFactory.getLogger(RepFoodCirculPermitManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * @Description: 新增
	 * @Title: add
	 * @author xh
	 * @date 2016-2RepFoodCirculPermitInfohrows
	 */
	@Override
	public Object add(RepFoodCirculPermitInfo repCosmDailyCheckInfo) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			dao.add(repCosmDailyCheckInfo);
			return repCosmDailyCheckInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 新增
	 * @param list
	 *            实体集合
	 * @Title: add
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean add(List<RepFoodCirculPermitInfo> list) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 更新
	 * @Title: update
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean update(RepFoodCirculPermitInfo RepFoodCirculPermitInfo) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			dao.update(RepFoodCirculPermitInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 批量更新
	 * @Title: save
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean save(List<RepFoodCirculPermitInfo> list) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			dao.save(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 新增/修改
	 * @Title: addOrUpdate
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public Object addOrUpdate(RepFoodCirculPermitInfo RepFoodCirculPermitInfo) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			dao.save(RepFoodCirculPermitInfo);
			return RepFoodCirculPermitInfo.getId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(String id) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 删除
	 * @Title: delete
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public boolean delete(RepFoodCirculPermitInfo RepFoodCirculPermitInfo) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			dao.delete(RepFoodCirculPermitInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * 
	 * @param reportId
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean deleteByReportId(String reportId) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			String sql = " delete RepFoodCirculPermitInfo t where t.reportId='"
					+ reportId + "'";
			dao.executeByCommand(sql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @Title: getEntity
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public RepFoodCirculPermitInfo getEntity(String id) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			RepFoodCirculPermitInfo info = dao.getEntity(id);
			return info;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepFoodCirculPermitInfo> getList(String reportId) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			String hql = "select t from RepFoodCirculPermitInfo t where t.reportId='"
					+ reportId + "'";
			return dao.queryListByCommand(hql, null);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据条件获取列表
	 * @Title: getListBy
	 * @param reportId
	 * @return List<RepCosmDailyCheckInfo> 返回类型
	 * @author: wangk
	 * @date: 2016-3-17 下午4:13:51
	 * @throws
	 */
	public List<RepFoodCirculPermitInfo> getListByReportIds(String reportIds) {
		
		List<RepFoodCirculPermitInfo> list = new ArrayList<RepFoodCirculPermitInfo>();

		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);

			String hql = "select t from RepFoodCirculPermitInfo t where 1=1 ";

			if (StringUtil.isNotEmpty(reportIds)) {
				hql += " and t.reportId in(" + reportIds + ")";
			}

			list = dao.find(hql, null, null);

			return list;
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 根据map参数获取列表
	 * @Title: getList
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public List<RepFoodCirculPermitInfo> getList(Map<String, Object> map) {
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * @Description: 获取分页列表
	 * @Title: getListByPage
	 * @author xh
	 * @date 2016-2-24 下午5:09:19
	 * @throws
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		try {
			IRepFoodCirculPermitDao dao = this
					.getMapper(IRepFoodCirculPermitDao.class);
			pageResultSet = bizCommonManager.datagrid(
					IRepFoodCirculPermitDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
