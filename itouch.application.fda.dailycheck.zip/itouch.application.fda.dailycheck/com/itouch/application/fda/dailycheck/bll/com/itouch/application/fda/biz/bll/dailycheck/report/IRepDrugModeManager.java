package com.itouch.application.fda.biz.bll.dailycheck.report;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.report.RepDrugMode;

import iTouch.framework.data.operation.IAppBusinessManager;


public interface IRepDrugModeManager extends IAppBusinessManager {
	
	/**
	 * 新增
	 * @param repDrugModeInfo
	 * @return Object
	 */
	public Object add(RepDrugMode repDrugModeInfo);
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean save(List<RepDrugMode> list) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public RepDrugMode getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 列表
	 */
	public List<RepDrugMode> getList(String reportId) ;
	
}
