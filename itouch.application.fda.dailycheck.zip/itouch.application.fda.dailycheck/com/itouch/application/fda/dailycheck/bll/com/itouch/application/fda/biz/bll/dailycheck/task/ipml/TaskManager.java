/**  
* @Title: TaskManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.task.ipml 
* @author wangk    
* @date 2015-10-26 下午2:27:59  
*/
package com.itouch.application.fda.biz.bll.dailycheck.task.ipml;

import iTouch.framework.application.dao.ConditionEnum;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.bll.dailycheck.task.ITaskManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckEntDao;
import com.itouch.application.fda.biz.dao.dailycheck.plan.IPlanUserDao;
import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskDao;
import com.itouch.application.fda.biz.entity.dailycheck.plan.PlanUserInfo;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskInfo;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-26 下午2:27:59  
 */
@Service("dcTaskManager")
public class TaskManager extends AppBusinessManager implements ITaskManager {

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:新增/修改
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-26 下午2:29:30
	 */
	@Override
	public Object addOrUpdate(TaskInfo taskInfo) {
		try {
			ITaskDao dao = this.getMapper(ITaskDao.class);
			dao.save(taskInfo);
			return taskInfo.getTaskId();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @Description: 根据Id删除
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-26 下午2:29:30
	 */
	@Override
	public boolean delete(String id) {
		try {
			ITaskDao dao = this.getMapper(ITaskDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error("" + e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 根据实体删除
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-26 下午2:29:30
	 */
	@Override
	public boolean delete(TaskInfo taskInfo) {
		try {
			ITaskDao dao = this.getMapper(ITaskDao.class);
			dao.delete(taskInfo);
		} catch (Exception e) {
			logger.error("" + e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-26 下午2:29:30
	 */
	@Override
	public TaskInfo getEntity(String id) {
		try {
			ITaskDao dao = this.getMapper(ITaskDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @Description:TODO
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time:2015-10-26 下午2:29:30
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();

		try {
			ITaskDao dao = this.getMapper(ITaskDao.class);
			pageResultSet = bizCommonManager.datagrid(ITaskDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据条件查询出列表
	 * @param 
	 * @return
	 * @throws Throwable
	 * @time:2015-10-26 下午4:41:45
	 */
	@Override
	public PageResultSet findListBySearch(int number, int pageIndex, TaskInfo taskInfo, String taskCreateOrg, Map<String, Object> map) throws Throwable {
		ITaskDao dao;
		List<TaskInfo> list = new ArrayList<TaskInfo>();
		PageResultSet pageResultSet = new PageResultSet();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		try {
			dao = this.getMapper(ITaskDao.class);

			PageQueryParam page = new PageQueryParam();
			page.setNumber(number);
			page.setPageIndex(pageIndex);

			String sql = "select t from TaskInfo t where t.taskCreateOrg = '" + taskCreateOrg + "' ";
			if (taskInfo.getTaskName() != null && !"".equals(taskInfo.getTaskName())) {
				sql += " and taskName like '%" + taskInfo.getTaskName() + "%' ";
			}
			if (taskInfo.getIsCompleted() != null && !"".equals(taskInfo.getIsCompleted())) {
				sql += " and isCompleted =" + taskInfo.getIsCompleted();
			}
			if (taskInfo.getTaskBeginDate() != null && !"".equals(taskInfo.getTaskBeginDate())) {
				sql += " and to_char(taskBeginDate,'yyyy-MM-dd') >='" + sdf.format(taskInfo.getTaskBeginDate()) + "'";
			}
			if (taskInfo.getTaskEndDate() != null && !"".equals(taskInfo.getTaskEndDate())) {
				sql += " and to_char(taskEndDate,'yyyy-MM-dd') <='" + sdf.format(taskInfo.getTaskEndDate()) + "'";
			}
			sql += " order by taskBeginDate desc";//排序
			list = dao.find(sql, null, page);

			pageResultSet.setList(list);
			pageResultSet.setPage(page);

			return pageResultSet;
		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: 根据条件查询出列表
	  * @Title: getList 
	  * @author wangk
	  * @date 2015-12-1 下午12:21:46 
	  * @throws 
	  */
	@Override
	public List<TaskInfo> getList(String tableId) {
		ITaskDao dao;
		List<TaskInfo> list = new ArrayList<TaskInfo>();

		try {
			dao = this.getMapper(ITaskDao.class);
			String hql = "select t from TaskInfo t where 1=1 ";
			if (tableId != null && !"".equals(tableId)) {
				hql += " and t.tableId = '" + tableId + "'";
			}
			list = dao.find(hql, null, null);
			return list;
		} catch (Throwable e) {
			logger.error("" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.itouch.application.fda.biz.bll.dailycheck.task.ITaskManager#getList(java.util.Map)
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<TaskInfo> getList(Map<String,Object> map){
		ITaskDao dao;
		try {
			dao = this.getMapper(ITaskDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map,List<ConditionEnum> relations)  {
		PageResultSet pageResultSet = new PageResultSet();
		ITaskDao dao;
		try {
			dao = this.getMapper(ITaskDao.class);
			pageResultSet = bizCommonManager.datagrid(ITaskDao.class, pageIndex, pageSize, map,relations, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

}
