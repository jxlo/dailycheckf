/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TemplateHeaderManager.java
 * @author:fanghailong
 * @time:2015-10-12 下午4:25:29
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITemplateHeaderManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.table.ITemplateHeaderDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateHeaderInfo;

/**
 * @author:fanghailong 
 */
@Service("templateHeaderManager")
public class TemplateHeaderManager extends AppBusinessManager implements ITemplateHeaderManager{
	
	Logger logger = LoggerFactory.getLogger(TemplateHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * 新增
	 * 
	 * @param TemplateHeaderInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(TemplateHeaderInfo templateHeaderInfo)  {
		try{
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			dao.add(templateHeaderInfo);
			return templateHeaderInfo.getHeaderId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TemplateHeaderInfo> list) {
		try{
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param TemplateHeaderInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(TemplateHeaderInfo templateHeaderInfo) {
		try{
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			dao.update(templateHeaderInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	
	/**
	 * 批量更新
	 * @param TemplateHeaderInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<TemplateHeaderInfo> templateHeaderInfoList){
		try{
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			dao.save(templateHeaderInfoList);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * 新增/修改
	 * 
	 * @param TemplateHeaderInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(TemplateHeaderInfo templateHeaderInfo) {
		try{
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			dao.save(templateHeaderInfo);
			return templateHeaderInfo.getHeaderId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try{
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 删除
	 * 
	 * @param TemplateHeaderInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(TemplateHeaderInfo templateHeaderInfo) {
		try{
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			dao.delete(templateHeaderInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public TemplateHeaderInfo getEntity(String id)  {
		try {
			ITemplateHeaderDao dao = this.getMapper(ITemplateHeaderDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<TemplateHeaderInfo> 列表集合
	 * @throws Throwable
	 */
	public List<TemplateHeaderInfo> getList() {
		ITemplateHeaderDao dao;
		try {
			dao = this.getMapper(ITemplateHeaderDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @Description:根据模板获取获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateHeaderInfo> getListByTemplateId(String templateId){
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("templateId", templateId);
		return getList(map);
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<TemplateHeaderInfo> getList(Map<String,Object> map){
		ITemplateHeaderDao dao;
		try {
			dao = this.getMapper(ITemplateHeaderDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		ITemplateHeaderDao dao;
		try {
			dao = this.getMapper(ITemplateHeaderDao.class);
			pageResultSet = bizCommonManager.datagrid(ITemplateHeaderDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
