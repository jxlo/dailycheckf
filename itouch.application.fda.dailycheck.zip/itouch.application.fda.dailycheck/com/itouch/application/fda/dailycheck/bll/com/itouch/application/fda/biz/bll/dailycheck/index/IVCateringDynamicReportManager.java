package com.itouch.application.fda.biz.bll.dailycheck.index;

import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;

import com.itouch.application.fda.biz.entity.dailycheck.index.VCateringDynamicReportInfo;

/** 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @ClassName: IVCateringDynamicReportManager 
 * @author: wangk
 * @date: 2016-3-28 下午2:01:34  
 */
public interface IVCateringDynamicReportManager extends IAppBusinessManager{

	/**
	 * @Description: 根据条件获取列表 
	 * @Title: getByUnitId 
	 * @author: wangk
	 * @date: 2016-3-28 下午2:03:33 
	 * @throws 
	 */ 
	public List<VCateringDynamicReportInfo> getByUnitId(String unitIds);
	
}
