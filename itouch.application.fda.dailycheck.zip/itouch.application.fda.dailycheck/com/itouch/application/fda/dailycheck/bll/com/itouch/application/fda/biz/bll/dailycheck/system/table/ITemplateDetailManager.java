/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:ITemplateItemDetailManager.java
 * @author:fanghailong
 * @time:2015-10-10 下午4:47:41
 */
package com.itouch.application.fda.biz.bll.dailycheck.system.table;

import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.data.operation.IAppBusinessManager;

import java.util.List;
import java.util.Map;

import com.itouch.application.fda.biz.entity.dailycheck.system.table.TemplateDetailInfo;

/**
 * @author:fanghailong 
 */
public interface ITemplateDetailManager extends IAppBusinessManager{
	
	/**
	 * 新增
	 * @param TemplateDetailInfo 模板实体
	 * @return 实体id
	 */
	public Object add(TemplateDetailInfo templateItemDetailInfo) ;
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TemplateDetailInfo> list) ;
	
	/**
	 * 更新
	 * @param TemplateDetailInfo 模板实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean update(TemplateDetailInfo templateItemDetailInfo)  ;
	
	/**
	 * 新增/修改
	 * @param TemplateDetailInfo 模板实体
	 * @return 是否新增/更新成功,是：true，否：false
	 */
	public Object addOrUpdate(TemplateDetailInfo templateItemDetailInfo) ;
	
	/**
	 * 删除
	 * @param id 主键Id
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(String id)  ;
	
	/**
	 * 删除
	 * @param TemplateDetailInfo  实体
	 * @return 是否删除成功,是：true，否：false
	 */
	public boolean delete(TemplateDetailInfo templateItemDetailInfo) ;
	
	/**
	 * 获取实体
	 * @param id  主键Id
	 * @return 实体
	 */
	public TemplateDetailInfo getEntity(String id) ;
	
	/**
	 * 获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateDetailInfo> getList() ;
	
	/**
	 * @Description:根据模板获取获取列表
	 * @return 受理类型列表
	 */
	public List<TemplateDetailInfo> getListByTemplateId(String templateId);
	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 受理类型列表
	 */
	public List<TemplateDetailInfo> getList(Map<String,Object> map) ;

	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex,  Map<String, Object> map) ;

	/**
	 * 根据大项ID删除条款明细
	 */
	public void delBySubjectId(String subjectId) ;
	
	/**
	 * 根据小项ID删除条款明细
	 */
	public void delBySmallId(String smallId) ;
	
	/**
	 * 根据条款ID删除条款明细
	 */
	public void delByItemId(String itemId) ;
}
