/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:CheckReviewManager.java
 * @author:fanghailong
 * @time:2015-10-20 下午5:10:30
 */
package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.ICheckReviewManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.impl.TalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckReviewDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckReviewInfo;

/**
 * @author:fanghailong
 */
@Service("checkReviewManager")
public class CheckReviewManager extends AppBusinessManager implements ICheckReviewManager {

	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 新增
	 * 
	 * @param CheckReviewInfo
	 *            实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(CheckReviewInfo checkReviewInfo) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			dao.add(checkReviewInfo);
			return checkReviewInfo.getReviewId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 新增
	 * 
	 * @param list
	 *            实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CheckReviewInfo> list) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			dao.add(list);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param CheckReviewInfo
	 *            实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(CheckReviewInfo checkReviewInfo) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			dao.update(checkReviewInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 批量更新
	 * 
	 * @param CheckReviewInfoList
	 *            实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<CheckReviewInfo> checkReviewInfoList) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			dao.save(checkReviewInfoList);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * 
	 * @param CheckReviewInfo
	 *            实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(CheckReviewInfo checkReviewInfo) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			dao.save(checkReviewInfo);
			return checkReviewInfo.getReviewId();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id
	 *            主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			dao.delete(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * 
	 * @param CheckReviewInfo
	 *            实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(CheckReviewInfo checkReviewInfo) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			dao.delete(checkReviewInfo);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 获取实体
	 * 
	 * @param id
	 *            主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public CheckReviewInfo getEntity(String id) {
		try {
			ICheckReviewDao dao = this.getMapper(ICheckReviewDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<CheckReviewInfo> 列表集合
	 * @throws Throwable
	 */
	public List<CheckReviewInfo> getList() {
		ICheckReviewDao dao;
		try {
			dao = this.getMapper(ICheckReviewDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * 
	 * @param map
	 *            map查询参数
	 * @return 列表
	 */
	public List<CheckReviewInfo> getList(Map<String, Object> map) {
		ICheckReviewDao dao;
		try {
			dao = this.getMapper(ICheckReviewDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取分页列表
	 * 
	 * @param pageSize
	 *            分页数量
	 * @param pageIndex
	 *            当前页索引
	 * @param map
	 *            查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
		ICheckReviewDao dao;
		try {
			dao = this.getMapper(ICheckReviewDao.class);
			pageResultSet = bizCommonManager.datagrid(ICheckReviewDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error("" + ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
