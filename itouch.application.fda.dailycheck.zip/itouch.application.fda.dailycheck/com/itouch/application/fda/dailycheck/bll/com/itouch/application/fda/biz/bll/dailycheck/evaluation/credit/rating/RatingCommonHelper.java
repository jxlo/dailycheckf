package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating;

/**
 * @author qiuy
 * 评价公共帮助类
 */
public class RatingCommonHelper {
	
	/**
	 * 获得逻辑运算符名称
	 * @param logicalOperator
	 * @return
	 */
	public static String GetLogicalOperatorName(String logicalOperator) {
		if(logicalOperator.equals("&&")) {
			return "并且";
		} else if(logicalOperator.equals("||")) {
			return "或者";
		}
		return "";
	}
}
