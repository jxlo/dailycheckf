package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.calculators;

import iTouch.framework.application.manager.IAppBusinessManagerMapper;

import com.itouch.application.ent.entity.basic.VEntBasic;
import com.itouch.application.fda.biz.dailycheck.enums.EnumVerdictType;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;

/**
 * @author qiuy
 * 计算类接口
 */
public interface ICalculator {
	
	/**
	 * 是否为本计算类
	 * @param verdictType
	 * @return
	 */
	public boolean IsTheCalculator(EnumVerdictType verdictType);
	
	/**
	 * 计算指定企业的值
	 * @param year
	 * @param vEntBasic
	 * @param expInfo
	 */
	public void Calculate(String year, VEntBasic vEntBasic, ExpressionInfo expInfo, IAppBusinessManagerMapper mapper);
}
