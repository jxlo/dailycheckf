package com.itouch.application.fda.biz.bll.dailycheck.evaluation.credit.rating.calculators;

import iTouch.framework.application.manager.IAppBusinessManagerMapper;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.itouch.application.ent.entity.basic.VEntBasic;
import com.itouch.application.fda.biz.bll.dailycheck.check.ICheckManager;
import com.itouch.application.fda.biz.dailycheck.enums.EnumRatingResults;
import com.itouch.application.fda.biz.dailycheck.enums.EnumVerdictType;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.credit.rating.ExpressionInfo;

/**
 * @author qiuy
 * 结果计算类
 */
public class ResultCalculator implements ICalculator {

	/**
	 * 检查结论结果
	 */
	Map<String, String> checkVerdictResultMap = new HashMap<String, String>();
	
	/**
	 * 是否为本计算类
	 * @param verdictType
	 * @return
	 */
	@Override
	public boolean IsTheCalculator(EnumVerdictType verdictType) {
		return EnumVerdictType.Result.equals(verdictType);
	}

	/**
	 * 计算指定企业的值
	 * @param year
	 * @param vEntBasic
	 * @param expInfo
	 */
	@Override
	public void Calculate(String year, VEntBasic vEntBasic, ExpressionInfo expInfo, IAppBusinessManagerMapper mapper) {
		
		ICheckManager checkManager = mapper.getMapper(ICheckManager.class);
		
		String key = year + "-" + vEntBasic.getEntCode() + "-" + vEntBasic.getEntTypeGroupId();
		String count;
		
		//如果已经查询过
		if(checkVerdictResultMap.containsKey(key)) {
			count = checkVerdictResultMap.get(key);
		}
		
		//如果没有查询过
		else {
			count = checkManager.getCheckVerdictResult(year, vEntBasic.getEntCode(), vEntBasic.getEntTypeGroupId(), expInfo.getContent());
			checkVerdictResultMap.put(key, count);
		}
		
		if(!StringUtils.isEmpty(count)) {
			expInfo.setContent(count);
		} else {
			expInfo.setResult(EnumRatingResults.NoData);
		}
	}
}
