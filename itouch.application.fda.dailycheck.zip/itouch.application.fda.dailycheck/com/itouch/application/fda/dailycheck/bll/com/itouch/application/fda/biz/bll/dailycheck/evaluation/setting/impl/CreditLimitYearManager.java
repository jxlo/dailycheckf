package com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.impl;

import iTouch.framework.application.dao.OrderType;
import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.evaluation.setting.ICreditLimitYearManager;
import com.itouch.application.fda.biz.dao.dailycheck.evaluation.setting.ICreditLimitYearDao;
import com.itouch.application.fda.biz.entity.dailycheck.evaluation.setting.CreditLimitYearInfo;

/**
 * @author qiuy
 * 年度评定限制业务层
 */
@Service("CreditLimitYear")
@Lazy
public class CreditLimitYearManager extends AppBusinessManager implements ICreditLimitYearManager {
	
	Logger logger = LoggerFactory.getLogger(CreditLimitYearManager.class);

	@Autowired
	private ICommonManager commonManager;

	private ICreditLimitYearDao dao;
	
	/**
	 * 新增
	 * @param 受理类型实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public String add(CreditLimitYearInfo info) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			dao.add(info);
			return info.getId();
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<CreditLimitYearInfo> list) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			dao.add(list);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(CreditLimitYearInfo info) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			dao.update(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 新增/修改
	 * @param 受理类型实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(CreditLimitYearInfo info) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			dao.save(info);
			return info;
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 删除
	 * @param Id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 删除
	 * @param 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(CreditLimitYearInfo info) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			dao.delete(info);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 获取实体
	 * @param Id 主键ID
	 * @return 实体
	 * @throws Throwable
	 */
	@SuppressWarnings("deprecation")
	public CreditLimitYearInfo getEntity(String id) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * @return list 列表集合
	 * @throws Throwable
	 */
	public List<CreditLimitYearInfo> getList() {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			return dao.find("orderId", OrderType.asc);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map查询参数
	 * @return 受理类型列表
	 */
	public List<CreditLimitYearInfo> getList(Map<String, Object> map) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			return dao.findAnd(null, map, "orderId", OrderType.asc);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public PageResultSet getListByPage(int pageSize, int pageIndex, Map<String, Object> map) {
		try {
			dao = this.getMapper(ICreditLimitYearDao.class);
			return commonManager.datagrid(ICreditLimitYearDao.class, pageIndex, pageSize, map, dao, "orderId", OrderType.asc);
		} catch (Throwable e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
}
