/**  
* @Title: CheckManager.java 
* @Package com.itouch.application.fda.biz.bll.dailycheck.check.impl 
* @author wangk    
* @date 2015-10-20 下午4:27:23  
*/ 
package com.itouch.application.fda.biz.bll.dailycheck.check.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.check.ICheckManager2;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckDao2;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckInfo2;

/**
 * @author wangk
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @date 2015-10-20 下午4:27:23  
 */
@Service("CheckManager")
@Transactional
public class CheckManager2 extends AppBusinessManager implements ICheckManager2{

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:新增/修改
	 * @param checkInfo
	 * @return 是否新增/更新成功,是：true，否：false
	 * @author:wangk
	 * @time:2015-10-20 下午4:21:02
	 */
	public Object add(CheckInfo2 checkInfo) {
		try {
			ICheckDao2 dao = this.getMapper(ICheckDao2.class);
			dao.add(checkInfo);
			return checkInfo.getCheckId();
		} catch (Exception e) {
			return null;
		}
	}
}
