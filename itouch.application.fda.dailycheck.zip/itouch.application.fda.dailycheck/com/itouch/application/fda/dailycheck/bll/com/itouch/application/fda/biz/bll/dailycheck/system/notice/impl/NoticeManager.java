package com.itouch.application.fda.biz.bll.dailycheck.system.notice.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.notice.INoticeManager;
import com.itouch.application.fda.biz.bll.dailycheck.system.table.ITableHeaderManager;
import com.itouch.application.fda.biz.bll.dailycheck.task.ITaskSourceManager;
import com.itouch.application.fda.biz.dao.dailycheck.system.notice.INoticeDao;
import com.itouch.application.fda.biz.dao.dailycheck.task.ITaskSourceDao;
import com.itouch.application.fda.biz.entity.dailycheck.system.notice.NoticeInfo;
import com.itouch.application.fda.biz.entity.dailycheck.task.TaskSourceInfo;

/**   
 * @ClassName: TaskSourceManager   
 * @Description: TODO(这里用一句话描述这个类的作用)   
 * @author wangk  
 * @date 2015-11-12 下午4:32:18      
 */
@Service("NoticeManager")
public class NoticeManager extends AppBusinessManager implements INoticeManager{

	Logger logger = LoggerFactory.getLogger(ITableHeaderManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:新增/修改
	 * @pram：INoticeManager
	 * @author: jx
	 * @return:  
	 */
	@Override
	public Object addOrUpdate(NoticeInfo noticeInfo) {
		try {
			INoticeDao dao = this.getMapper(INoticeDao.class);
			dao.save(noticeInfo);
			return noticeInfo.getId();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @Description: 根据Id删除
	 * @pram：INoticeManager
	 * @author: jx
	 * @return:  
	 */
	@Override
	public boolean delete(String id) {
		try {
			INoticeDao dao = this.getMapper(INoticeDao.class);
			dao.delete(id);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * @Description: 获取实体
	 * @pram：ITaskManager
	 * @author: jx
	 * @return:  
	 */
	@Override
	public NoticeInfo getEntity(String id) {
		try {
			INoticeDao dao = this.getMapper(INoticeDao.class);
			return dao.getEntity(id);
		} catch (Exception e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * @Description:TODO
	 * @pram：ITaskManager
	 * @author: wangk
	 * @return:  
	 * @time 2015-11-12 下午4:33:32
	 */
	@Override
	public PageResultSet getListByPage(int pageSize, int pageIndex,Map<String, Object> map) {
		PageResultSet pageResultSet = new PageResultSet();
	
		try {
			ITaskSourceDao dao = this.getMapper(ITaskSourceDao.class);
			pageResultSet = bizCommonManager.datagrid(ITaskSourceDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取List
	 * @param id  主键Id
	 * @return 实体
	 * @author:wangk
	 * @time 2015-11-12 下午4:30:50
	 */
	@Override
	public List<NoticeInfo> getList(String unitId) {
		INoticeDao dao;
		List<NoticeInfo> list = new ArrayList<NoticeInfo>();
		
		try {
			dao = this.getMapper(INoticeDao.class);
			
			String hql = "select t from NoticeInfo t where 1=1 ";
			if(unitId != null && !"".equals(unitId)){
				hql += " and t.unitId = '"+unitId+"'";
			}
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/**
	  * @Description: TODO(这里用一句话描述这个方法的作用)  
	  * @Title: findListBySearch 
	  * @author jx
	  * @throws 
	  */ 
	@Override
	public PageResultSet findListBySearch(int pageSize,int pageIndex,String title,String unitId)throws Throwable {
		INoticeDao dao ;
		PageResultSet pageResultSet = new PageResultSet();
		List<NoticeInfo> list = new ArrayList<NoticeInfo>();
		
		try {
			dao = this.getMapper(INoticeDao.class);
			
			PageQueryParam page = new PageQueryParam();
			page.setNumber(pageSize);
			page.setPageIndex(pageIndex);
			
			String hql = "select t from NoticeInfo t where 1=1 ";
			if(title != null && !"".equals(title)){
				hql += " and t.title like '%"+title+"%'";
			}
			hql += " order by t.startTime";
			list = dao.find(hql , null , page);
			
			pageResultSet.setList(list);
			pageResultSet.setPage(page);
			
			return pageResultSet;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 根据任务来源名称查询是否存在
	 * @param name
	 * @return
	 */
	public List<NoticeInfo> getTaskByName(String name){
		INoticeDao dao;
		List<NoticeInfo> list = new ArrayList<NoticeInfo>();
		
		try {
			dao = this.getMapper(INoticeDao.class);
			String hql = "select t from TaskSourceInfo t where 1=1 and name='"+name+"' ";
			
			list = dao.find(hql , null , null);
			
			return list;
		} catch (Throwable e) {
			logger.error(""+e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

}
