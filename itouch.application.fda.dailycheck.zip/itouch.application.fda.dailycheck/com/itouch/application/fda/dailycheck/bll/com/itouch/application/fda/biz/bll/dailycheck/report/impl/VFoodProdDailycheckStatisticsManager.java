/**
 * @Description:TODO
 * @project:itouch.application.fda.dailycheck
 * @class:VFoodProdDailycheckStatisticsManager.java
 * @author:xh
 * @time:2016-1-9 下午4:29:01
 */
package com.itouch.application.fda.biz.bll.dailycheck.report.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.report.IVFoodProdDailycheckStatisticsManager;
import com.itouch.application.fda.biz.dao.dailycheck.check.ICheckEntDao;
import com.itouch.application.fda.biz.dao.dailycheck.report.IVFoodProdDailycheckStatisticsDao;
import com.itouch.application.fda.biz.entity.dailycheck.check.CheckEntInfo;

/**
 * 食品生产日常监督检查统计
 * @author xh
 */
@Service("VFoodProdDailycheckStatisticsManager")
public class VFoodProdDailycheckStatisticsManager  extends AppBusinessManager implements IVFoodProdDailycheckStatisticsManager{

	Logger logger = LoggerFactory.getLogger(VFoodProdDailycheckStatisticsManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}

	/* 获取列表 通过 unitId
	 * @see com.itouch.application.fda.biz.bll.dailycheck.report.IVFoodProdDailycheckStatisticsManager#getListByUnitId(java.lang.String)
	 */
	@Override
	public List<Object[]> getList(String unitId,String entTypeGroupId,String checkBeginDate,String checkEndDate) {
		
		List<Object[]> list=null;
		IVFoodProdDailycheckStatisticsDao dao;
		try {
			dao= this.getMapper(IVFoodProdDailycheckStatisticsDao.class);
			String hql="select nvl(UNIT_ID,'total') UNIT_ID,nvl(UNIT_NAME,'总计') UNIT_NAME,SUM(CHECK_USER_IDS_LENG),count(distinct case when (ENT_TYPE_GROUP_ID='1201') then ENT_ID else null end),";
			hql +="count(distinct case when (ENT_TYPE_GROUP_ID='1202') then ENT_ID else null end),";
			hql +="count(distinct case when (ENT_TYPE_GROUP_ID='1203') then ENT_ID else null end),";
			hql +="count(distinct ENT_ID),";
			hql +="count(distinct case when(RESULT_VERDICT_ID<0) then ENT_ID else null end),";
			hql +="count(case when(RESULT_VERDICT_ID<0) then 1 else null end ),";
			hql +="cast(count(case when(result_verdict_id<0) then 1 else null end )/count(check_id) as decimal(10,2)),";
			hql +="cast(count(case when(result_verdict_id<0) then 1 else null end )/sum(CHECK_USER_IDS_LENG) as decimal(10,2)),";
			hql +="count(distinct case when (RESULT_VERDICT_ID=-1 or RESULT_VERDICT_ID=-2) then ENT_ID else null end),";
			hql +="count(distinct case when (RESULT_VERDICT_ID=-3) then ENT_ID else null end) from v_food_prod_dailycheck where UNIT_ID in ("+unitId+")";
			
			if (entTypeGroupId!=null)
			{
				if(entTypeGroupId==""){
					hql +=" and ENT_TYPE_GROUP_ID in ('')";
				}else{
					hql +=" and ENT_TYPE_GROUP_ID in ("+entTypeGroupId+")";
				}
			}
			
			if (checkBeginDate != null && checkEndDate != null)
			{
				hql +=" and CHECK_BEGIN_DATE >= to_date('"+checkBeginDate+"','yyyy-mm-dd') and CHECK_BEGIN_DATE <= to_date('"+checkEndDate+"','yyyy-mm-dd')";
			}
			
			hql +=" group by rollup(UNIT_ID,UNIT_NAME) having (UNIT_NAME is not null ) or (UNIT_ID is null and UNIT_NAME is null)";
			list=dao.getListObjectBySql(hql, null);
			return list;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取被检查企业不重复的entIds 
	 * @param 
	 * @return 
	 */
	public String getDistinctEntId(String unitId,String entTypeGroupIds,String resultVerdictIds){
		ICheckEntDao dao;
		String entIds="";
		try {
			dao= this.getMapper(ICheckEntDao.class);
			String hql="select distinct new CheckEntInfo(t.entId) from CheckEntInfo t,CheckInfo s where" +
					" t.checkId=s.checkId and s.unitId in ("+unitId+") and t.entTypeGroupId in ("+entTypeGroupIds+")";
			if(resultVerdictIds!=null&&!resultVerdictIds.equals("")){
				hql+=" and s.resultVerdictId in("+resultVerdictIds+")";
			}
			List<CheckEntInfo> checkEntInfoList=dao.find(hql, null, null);
			if(checkEntInfoList!=null&&checkEntInfoList.size()>0){
				for(CheckEntInfo checkEntInfo:checkEntInfoList){
					entIds+="'"+checkEntInfo.getEntId()+"',";
				}
				entIds=entIds.substring(0,entIds.length()-1);
			}
			return entIds;
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
}
