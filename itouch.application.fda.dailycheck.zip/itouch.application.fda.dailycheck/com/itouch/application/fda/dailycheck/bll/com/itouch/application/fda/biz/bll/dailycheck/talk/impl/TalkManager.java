/**
 * @Description:TODO
 * @project:itouch.application.fda.biz
 * @class:TalkManager.java
 * @author:fanghailong
 * @time:2015-10-13 下午3:04:22
 */
package com.itouch.application.fda.biz.bll.dailycheck.talk.impl;

import iTouch.framework.application.manager.AppBusinessManager;
import iTouch.framework.data.model.PageQueryParam;
import iTouch.framework.data.model.PageResultSet;
import iTouch.framework.utility.log.Logger;
import iTouch.framework.utility.log.LoggerFactory;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itouch.application.fda.biz.bll.common.ICommonManager;
import com.itouch.application.fda.biz.bll.dailycheck.talk.ITalkManager;
import com.itouch.application.fda.biz.dao.dailycheck.talk.ITalkDao;
import com.itouch.application.fda.biz.entity.dailycheck.talk.TalkInfo;
/**
 * @author:fanghailong 
 */
@Service("talkManager")
public class TalkManager extends AppBusinessManager implements ITalkManager{
	
	Logger logger = LoggerFactory.getLogger(TalkManager.class);
	@Autowired
	private ICommonManager bizCommonManager;

	public void setCommonManager(ICommonManager bizCommonManager) {
		this.bizCommonManager = bizCommonManager;
	}
	
	/**
	 * @Description:添加日志
	 * @param msg
	 * @author:fanghailong
	 * @time:2015年8月14日 上午10:48:34
	 */
	private void addLogger(String msg) {
		logger.error("" + msg);
	}

	/**
	 * 新增
	 * 
	 * @param TalkInfo 实体
	 * @return 是否新增成功
	 * @throws Throwable
	 */
	public Object add(TalkInfo talkInfo)  {
		try{
			ITalkDao dao = this.getMapper(ITalkDao.class);
			dao.add(talkInfo);
			return talkInfo.getTalkId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}
	
	/**
	 * 新增
	 * @param list 实体集合
	 * @return 是否新增成功，是：true，否：false
	 */
	public boolean add(List<TalkInfo> list) {
		try{
			ITalkDao dao = this.getMapper(ITalkDao.class);
			dao.add(list);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 更新
	 * 
	 * @param TalkInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public boolean update(TalkInfo talkInfo) {
		try{
			ITalkDao dao = this.getMapper(ITalkDao.class);
			dao.update(talkInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	
	/**
	 * 批量更新
	 * @param TalkInfoList 实体
	 * @return 是否更新成功,是：true，否：false
	 */
	public boolean save(List<TalkInfo> talkInfoList){
		try{
			ITalkDao dao = this.getMapper(ITalkDao.class);
			dao.save(talkInfoList);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * 新增/修改
	 * 
	 * @param TalkInfo 实体
	 * @return 是否更新成功
	 * @throws Throwable
	 */
	public Object addOrUpdate(TalkInfo talkInfo) {
		try{
			ITalkDao dao = this.getMapper(ITalkDao.class);
			dao.save(talkInfo);
			return talkInfo.getTalkId();
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return null;
		}
	}

	/**
	 * 删除
	 * 
	 * @param id 主键Id
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(String id) {
		try{
			ITalkDao dao = this.getMapper(ITalkDao.class);
			dao.delete(id);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 删除
	 * 
	 * @param TalkInfo 实体
	 * @return 是否删除成功
	 * @throws Throwable
	 */
	public boolean delete(TalkInfo talkInfo) {
		try{
			ITalkDao dao = this.getMapper(ITalkDao.class);
			dao.delete(talkInfo);
		}catch(Exception ex){
			logger.error(""+ex.getMessage());
			return false;
		}
		return true ;
	}

	/**
	 * 获取实体
	 * 
	 * @param id 主键Id
	 * @return 实体
	 * @throws Throwable
	 */
	public TalkInfo getEntity(String id)  {
		try {
			ITalkDao dao = this.getMapper(ITalkDao.class);
			return dao.getEntity(id);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 获取列表
	 * 
	 * @return List<TalkInfo> 列表集合
	 * @throws Throwable
	 */
	public List<TalkInfo> getList() {
		ITalkDao dao;
		try {
			dao = this.getMapper(ITalkDao.class);
			return dao.find();
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 * 根据map参数获取列表
	 * @param map  map查询参数
	 * @return 列表
	 */
	public List<TalkInfo> getList(Map<String,Object> map){
		ITalkDao dao;
		try {
			dao = this.getMapper(ITalkDao.class);
			return dao.findAnd(null, map);
		} catch (Exception ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * 
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return PageResultSet 分页列表集合
	 * @throws Throwable
	 */
	public  PageResultSet getListByPage(int pageSize, int pageIndex,
			Map<String, Object> map)  {
		PageResultSet pageResultSet = new PageResultSet();
		ITalkDao dao;
		try {
			dao = this.getMapper(ITalkDao.class);
			pageResultSet = bizCommonManager.datagrid(ITalkDao.class, pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			logger.error(""+ex.getMessage());
			ex.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 获取分页列表
	 * @param pageSize 分页数量
	 * @param pageIndex 当前页索引
	 * @param map 查询参数
	 * @return 分页列表集合
	 */
	public PageResultSet getTalkInfoList(int pageSize, int pageIndex, TalkInfo talkInfo){
		PageResultSet pageResultSet = new PageResultSet();
		ITalkDao dao = null;

		PageQueryParam page = new PageQueryParam();
		page.setPageIndex(pageIndex);
		page.setNumber(pageSize);
		try {
			dao = this.getMapper(ITalkDao.class);
			// dao.setDataSourceName(DbConfig.online);
			String hql = "select t from TalkInfo t where 1=1 ";
			if (talkInfo != null) {
				if (talkInfo.getEntName() != null
						&& talkInfo.getEntName().length() > 0) {
					hql += " and t.entName like '%" + talkInfo.getEntName()
							+ "%'";
				}
				if (talkInfo.getUnitId() != null
						&& talkInfo.getUnitId().length() > 0) {
					hql += " and t.unitId = '" + talkInfo.getUnitId()
							+ "'";
				}
				if (talkInfo.getPreTalkDateBegin() != null
						&& talkInfo.getPreTalkDateBegin().length() > 0) {
					hql += " and TO_CHAR(t.preTalkDate,'yyyy-mm-dd') >= '"
							+ talkInfo.getPreTalkDateBegin() + "'";
				}
				if (talkInfo.getPreTalkDateEnd() != null
						&& talkInfo.getPreTalkDateEnd().length() > 0) {
					hql += " and TO_CHAR(t.preTalkDate,'yyyy-mm-dd') <= '"
							+ talkInfo.getPreTalkDateEnd() + "'";
				}
			}
			 hql += " order by t.preTalkDate desc";//当createTime都为null时，排序会导致翻页无效果
			List<TalkInfo> talkInfoList = dao.find(hql, null, page);
			pageResultSet.setPage(page);
			pageResultSet.setList(talkInfoList);
			// pageResultSet = commonManager.datagrid(IVAccBasicDao.class,
			// pageIndex, pageSize, map, dao);
			return pageResultSet;
		} catch (Throwable ex) {
			addLogger(ex.getMessage());
			ex.printStackTrace();
			return null;
		} finally {
			// dao.setDataSourceName(DbConfig.enterprises);
		}
	}
	/**
	 * 获取最大编号
	 * @param unitId 单位id
	 * @return 最大编号
	 */
	public int getMaxCode(String unitId,Date preTalkDate){
		ITalkDao dao = null;
		int maxCode=0;
		Map<String,Object> map=new HashMap<String, Object>();
		Calendar currCal=Calendar.getInstance();
		int currentYear=currCal.get(Calendar.YEAR);
		String date=currentYear+""+"-01-01";
		try {
			String hql="select t from TalkInfo t where t.unitId='"+unitId+"' and TO_CHAR(t.preTalkDate,'yyyy-mm-dd')>='"+date+"' order by t.serialNumber desc";
			dao = this.getMapper(ITalkDao.class);
			List<TalkInfo> list=dao.find(hql,null,null);
			if(list==null||list.size()<1){
				maxCode=0;
			}else{
				maxCode=list.get(0).getSerialNumber();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return maxCode;
	}
	
}
